﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEngine;

    public class TerrainSlice
    {
        /// <summary>
        /// The terrain of the slice
        /// </summary>
        public Terrain SliceTerrain { get; private set; }

        /// <summary>
        /// The terrain data of the slice
        /// </summary>
        public TerrainData SliceTerrainData { get; private set; }

        /// <summary>
        /// The size of the slice in relation to the source terrain. For example, a value of .25 indicates that
        /// the slice is 1/4 the size of the original source terrain.
        /// </summary>
        public float ProportionOfSliceToSource { get; private set; }

        /// <summary>
        /// The row of the slice within the sliced group (note that this encompasses the entire group 
        /// when slicing a group of terrains at the same time)
        /// </summary>
        public int Row { get; private set; }

        /// <summary>
        /// The column of the slice within the sliced group (note that this encompasses the entire group 
        /// when slicing a group of terrains at the same time)
        /// </summary>
        public int Column { get; private set; }

        /// <summary>
        /// The normalized X position of the slice in relation to the dimensions of the source terrain.
        /// For example, a value of .5 indicates that the slices x position is at half way point of the source 
        /// terrain. This is most useful for texture slicing, in determining the block of pixels from a 
        /// source texture to use in building a sliced texture.
        /// </summary>
        public float NormalizedXPosition { get; private set; }

        /// <summary>
        /// The normalized Z position of the slice in relation to the dimensions of the source terrain.
        /// For example, a value of .5 indicates that the slices z position is at half way point of the source 
        /// terrain. This is most useful for texture slicing, in determining the block of pixels from a 
        /// source texture to use in building a sliced texture.
        /// </summary>
        public float NormalizedZPosition { get; private set; }

        /// <summary>
        /// The position of the slice in world space.
        /// </summary>
        public Vector3 Position { get; private set; }

        internal TerrainSlice(Terrain sliceTerrain, int row, int column, float proportionOfSliceToSource, float normalizedXPosition, float normalizedZPosition, Vector3 position)
        {
            SliceTerrain = sliceTerrain;
            SliceTerrainData = sliceTerrain.terrainData;
            Row = row;
            Column = column;
            ProportionOfSliceToSource = proportionOfSliceToSource;
            NormalizedXPosition = normalizedXPosition;
            NormalizedZPosition = normalizedZPosition;
            Position = position;
        }
    }
}
