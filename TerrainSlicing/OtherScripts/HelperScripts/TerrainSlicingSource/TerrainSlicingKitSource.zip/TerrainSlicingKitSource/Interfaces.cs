﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEngine;
    
    public abstract class UnityVersionDependentDataCopier
    {
        public abstract void CopyAdditionalSplatSettings(SplatPrototype copyFrom, SplatPrototype copyTo);
        public abstract void CopyOtherSettings(Terrain copyFrom, Terrain copyTo);
    }

    [System.Serializable]
    public abstract class TreeDataHandler
    {
        public abstract Vector3 RetrievePosition(TreeInstance treeInstance);
        public abstract int GetTreePrototypeIndex(TreeInstance treeInstance);

        public abstract void AddTreeInstance(Terrain slice, TreeInstance treeInstanceToUse, Vector3 treePosition, int treePrototypeIndex);
    }
}