﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEngine;
    using DynamicLoadingKit;

    public enum SliceMethod { SliceSingleTerrain, SliceTerrainGroup }

    [System.Serializable]
    public class SliceConfiguration
    {
        [SerializeField]
        internal bool copyAllDetails, copyAllTrees, createPrefabs, removeSlicesFromSceneAfterCreation, disableEdgeBlending, copyBaseLayer = true, copyBaseTag = true, dontSliceAlphamap, copySplatTextures = true;

        [SerializeField]
        internal Color slicingGridColor = Color.black;

        

        [SerializeField]
        internal int firstRow = 1, lastRow = 4, firstColumn = 1, lastColumn = 4, edgeBlendingWidth = 1, rowsOfSlices = 2, columnsOfSlices = 2, baseTerrainToSliceRatio = 2/*ex 2 = base terrain is twice the size of slice*/;

        [SerializeField]
        internal float normalizedXPosition, normalizedZPosition;
        
        [SerializeField]
        internal SliceMethod sliceMethod;

        [SerializeField]
        internal string sliceDataSaveFolder = "/", prefabSaveFolder = "/", sliceDataOutputBaseName = "SliceData", sliceOutputBaseName = "Slice";

        [SerializeField]
        internal Terrain sampleTerrain;

        [SerializeField]
        internal SliceProcessor[] sliceProcessors;

        [SerializeField]
        internal NamingConvention inputNamingConvention, outputNamingConvention;
        
        public SliceConfiguration() { }

        public SliceConfiguration(SliceConfiguration sliceConfigurationToCopy)
        {
            CopySettings(sliceConfigurationToCopy);
        }

        public SliceConfiguration(SliceConfiguration sliceConfigurationToCopy, Terrain sampleTerrainOverride) : this(sliceConfigurationToCopy)
        {
            sampleTerrain = sampleTerrainOverride;
        }

        public void CopySettings(SliceConfiguration sliceConfigurationToCopy)
        {
            firstRow = sliceConfigurationToCopy.firstRow;
            lastRow = sliceConfigurationToCopy.lastRow;
            firstColumn = sliceConfigurationToCopy.firstColumn;
            lastColumn = sliceConfigurationToCopy.lastColumn;
            rowsOfSlices = sliceConfigurationToCopy.rowsOfSlices;
            columnsOfSlices = sliceConfigurationToCopy.columnsOfSlices;
            edgeBlendingWidth = sliceConfigurationToCopy.edgeBlendingWidth;
            baseTerrainToSliceRatio = sliceConfigurationToCopy.baseTerrainToSliceRatio;

            sliceMethod = sliceConfigurationToCopy.sliceMethod;

            sampleTerrain = sliceConfigurationToCopy.sampleTerrain;

            sliceDataSaveFolder = sliceConfigurationToCopy.sliceDataSaveFolder;
            prefabSaveFolder = sliceConfigurationToCopy.prefabSaveFolder;
            sliceDataOutputBaseName = sliceConfigurationToCopy.sliceDataOutputBaseName;
            sliceOutputBaseName = sliceConfigurationToCopy.sliceOutputBaseName;

            copyBaseLayer = sliceConfigurationToCopy.copyBaseLayer;
            copyBaseTag = sliceConfigurationToCopy.copyBaseTag;
            copyAllDetails = sliceConfigurationToCopy.copyAllDetails;
            copyAllTrees = sliceConfigurationToCopy.copyAllTrees;
            createPrefabs = sliceConfigurationToCopy.createPrefabs;
            dontSliceAlphamap = sliceConfigurationToCopy.dontSliceAlphamap;
            copySplatTextures = sliceConfigurationToCopy.copySplatTextures;
            removeSlicesFromSceneAfterCreation = sliceConfigurationToCopy.removeSlicesFromSceneAfterCreation;
            disableEdgeBlending = sliceConfigurationToCopy.disableEdgeBlending;
            
            normalizedXPosition = sliceConfigurationToCopy.normalizedXPosition;
            normalizedZPosition = sliceConfigurationToCopy.normalizedZPosition;

            slicingGridColor = sliceConfigurationToCopy.slicingGridColor;

            inputNamingConvention = sliceConfigurationToCopy.inputNamingConvention;
            outputNamingConvention = sliceConfigurationToCopy.outputNamingConvention;
            sliceProcessors = sliceConfigurationToCopy.sliceProcessors;

            OutputNameGenerator = sliceConfigurationToCopy.OutputNameGenerator;
        }

        public bool AllFoldersSpecified { get { return sliceDataSaveFolder != "" && (!createPrefabs || prefabSaveFolder != ""); } }

        public bool AllOutputNamesSpecified { get { return sliceDataOutputBaseName != "" && sliceOutputBaseName != ""; } }

        public bool HasTerrainSample { get { return sampleTerrain != null; } }

        public Vector3 NormalizedSlicingGridPosition { get { return new Vector3(normalizedXPosition, 0f, normalizedZPosition); } }

        /// <summary>
        /// Whether the detail prototypes will be copied to each slice, regardless of whether that slice 
        /// contains the detail texture/mesh.
        /// </summary>
        public bool CopyAllDetails { get { return copyAllDetails; } }

        /// <summary>
        /// Whether the tree prototypes will be copied to each slice, regardless of whether that slice 
        /// contains the tree.
        /// </summary>
        public bool CopyAllTrees { get { return copyAllTrees; } }

        /// <summary>
        /// Whether prefabs will be automatically created from the generated slices.
        /// </summary>
        public bool CreatePrefabs { get { return createPrefabs; } }

        /// <summary>
        /// Whether slices will be removed from the scene after they are created.
        /// </summary>
        public bool RemoveSlicesFromSceneAfterCreation { get { return RemoveSlicesFromSceneAfterCreation; } }

        /// <summary>
        /// Whether edge blending of the slice's alphamaps is disabled.
        /// </summary>
        public bool DisableEdgeBlending { get { return disableEdgeBlending; } }

        /// <summary>
        /// Whether the layer of the source terrain will be applied to each individual slice.
        /// </summary>
        public bool CopyBaseLayer { get { return copyBaseLayer; } }

        /// <summary>
        /// Whether the tag from the source terrain will be applied to each individual slice.
        /// </summary>
        public bool CopyBaseTag { get { return copyBaseTag; } }

        /// <summary>
        /// The width of the area on each slices edge that will have its alphamap blended.
        /// </summary>
        public float EdgeBlendingWidth { get { return edgeBlendingWidth; } }

        /// <summary>
        /// The size of the slices in relation to the source terrain. For example, a value of .25 indicates that 
        /// the slices are 1/4th the size of the source terrain. This can be used for slicing textures and 
        /// slicing/dividing other objects/values.
        /// </summary>
        public float ProportionOfSlicesToSourceTerrain { get { return 1f / baseTerrainToSliceRatio; } }
        
        /// <summary>
        /// The number of columns that will be sliced (note, for group slices, this is the number of 
        /// columns per each individual terrain in the group).
        /// </summary>
        public int Columns { get { return columnsOfSlices; } }

        /// <summary>
        /// The number of rows that will be sliced (note, for group slices, this is the number of 
        /// rows per each individual terrain in the group).
        /// </summary>
        public int Rows { get { return rowsOfSlices; } }

        /// <summary>
        /// A name generator based on the output naming convention. Use this to generate names for folders 
        /// and assets created for each slice.
        /// </summary>
        public NameGenerator2D OutputNameGenerator { get; internal set; }

        /// <summary>
        /// The slice method (slicing a single terrain or group?)
        /// </summary>
        public SliceMethod SliceMethod { get { return sliceMethod; } }

        /// <summary>
        /// The name common to all the outputted slice terrain objects.
        /// </summary>
        public string SliceOutputGroupIdentifier { get { return sliceOutputBaseName; } }

        /// <summary>
        /// The sample terrain provided for the slice.
        /// </summary>
        public Terrain SampleTerrain { get { return sampleTerrain; } }

    }
}