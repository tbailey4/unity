﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using DynamicLoadingKit;

    public class SliceNameCreator
    {
        string formatString;

        public SliceNameCreator(INamingConvention namingConvention)
        {
            formatString = namingConvention.GetStringFormatVersion2DWithoutGroupName();
        }

        public string CreateSlicedName(string groupIdentifier, int row, int column)
        {
            return string.Format(formatString, column, row, groupIdentifier);
        }
    }
}