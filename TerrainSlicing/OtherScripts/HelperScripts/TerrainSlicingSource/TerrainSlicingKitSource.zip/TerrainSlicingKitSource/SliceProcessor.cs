﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEngine;
    using UnityEditor;
    using System.IO;
    using System.Collections.Generic;

    public enum WhatToDoIfFolderAlreadyExists
    { AbortNewFolderCreation, CreateDuplicateFolder, OverwriteExistingFolder }

    /// <summary>
    /// A class that can be implmented to create a Slice Processor, which you can use to perform
    /// custom actions on terrain slices before, as, and after they are generated.
    /// </summary>
    public abstract class SliceProcessor : ScriptableObject
    {
        

        /// <summary>
        /// Method called once for the whole group before slicing begins. Take care of any pre 
        /// slice preparation using this method, such as creating folders for storing assets.
        /// </summary>
        /// <param name="sliceConfiguration"></param>
        public virtual void PreSlicingPrep(SliceConfiguration sliceConfiguration) { }

        /// <summary>
        /// Called for each slice after it is created (but before alphamap blending).
        /// </summary>
        /// <param name="sourceTerrain">The source terrain that is being sliced.</param>
        /// <param name="terrainSlice">The slice that was generated. This contains all the information you should need about the slice.</param>
        public abstract void ProcessSlice(Terrain sourceTerrain, TerrainSlice terrainSlice);

        /// <summary>
        /// Perform any final work. This is called once for the entire group of slices.
        /// </summary>
        public virtual void PostSlicingPrep() { }

        /// <summary>
        /// Creates the folder specified by path
        /// </summary>
        /// <param name="path">
        /// The folder path to create
        /// </param>
        /// <param name="whatToDoIfFolderAlreadyExists">
        /// This dictates what action the program will take if the folder you are trying to create 
        /// already exists.
        /// </param>
        /// <param name="applicationSavePathOfFolder">
        /// The application specific save path of the folder.
        /// </param>
        /// <param name="unitySavePathOfFolder">
        /// The Unity specific save path of the folder.
        /// </param>
        public static void CreateFolder(string path, WhatToDoIfFolderAlreadyExists whatToDoIfFolderAlreadyExists, out string applicationSavePathOfFolder, out string unitySavePathOfFolder)
        {
            string folderPath = path;
            if (folderPath.StartsWith("Assets"))
                folderPath.Remove(0, 6);

            if (folderPath[0] != '/')
                folderPath = "/" + folderPath;

            if (folderPath.EndsWith("/"))
                folderPath.Remove(folderPath.Length - 1);

            string systemPathToSaveIn = Application.dataPath + folderPath;

            if (Directory.Exists(systemPathToSaveIn))
            {
                if (whatToDoIfFolderAlreadyExists != WhatToDoIfFolderAlreadyExists.AbortNewFolderCreation)
                {
                    if (whatToDoIfFolderAlreadyExists == WhatToDoIfFolderAlreadyExists.OverwriteExistingFolder)
                    {
                        Directory.Delete(systemPathToSaveIn, true);
                        RefreshAssetDatabase();
                    }
                    else
                    {
                        string uniqueSystemPath;
                        int i = 2;
                        do
                        {
                            uniqueSystemPath = string.Format("{0} [Slice {1}]", systemPathToSaveIn, i);
                            i++;
                        }
                        while (Directory.Exists(uniqueSystemPath));
                        systemPathToSaveIn = uniqueSystemPath;
                    }
                    Directory.CreateDirectory(systemPathToSaveIn);
                }
            }
            else
                Directory.CreateDirectory(systemPathToSaveIn);

            systemPathToSaveIn += "/";

            applicationSavePathOfFolder = systemPathToSaveIn;
            unitySavePathOfFolder = "Assets" + systemPathToSaveIn.Substring(Application.dataPath.Length);
        }

        /// <summary>
        /// Reimports and saves assets that have been changed.
        /// </summary>
        public static void RefreshAssetDatabase()
        {
            AssetDatabase.Refresh();
            AssetDatabase.SaveAssets();
        }

        /// <summary>
        /// Gets a texture from a material.
        /// </summary>
        /// <param name="material">The material to get the texture from.</param>
        /// <param name="texturePropertyName">The name of the texture property on the shader.</param>
        /// <returns>The Texture.</returns>
        public static Texture GetTextureFromMaterial(Material material, string texturePropertyName)
        {
            return (Texture)material.GetTexture(texturePropertyName);
        }

        /// <summary>
        /// Slices the texture indicated by texturePropertyName. 
        /// The resulting sliced texture is in png format.
        /// </summary>
        /// <param name="material">The material which contains the texture to slice.</param>
        /// <param name="texturePropertyName">The name of the texture property on the shader.</param>
        /// <param name="terrainSlice">
        /// The terrain slice which we are trying to slice the texture for. 
        /// The normalized position of the slice is used to slice the texture correctly.
        /// </param>
        /// <param name="sliceConfiguration">The SliceConfiguration object for this slicing job.</param>
        /// <param name="applicationSavePath">
        /// The application save path to save the newly sliced texture.
        /// </param>
        /// <param name="unityPathToSaveTextureAt">
        /// The unity save path to save the newly sliced texture.
        /// </param>
        public static void SliceTexture(Material material, string texturePropertyName, TerrainSlice terrainSlice, SliceConfiguration sliceConfiguration, string applicationSavePath, string unityPathToSaveTextureAt)
        {
            Texture sourceTexture = GetTextureFromMaterial(material, texturePropertyName);

            string textureName = sliceConfiguration.OutputNameGenerator.GenerateName(sourceTexture.name, terrainSlice.Row, terrainSlice.Column) + ".png";

            string fullAssetPathOfSourceTexture = AssetDatabase.GetAssetPath(sourceTexture);

            string fullAssetPathOfNewTexture = unityPathToSaveTextureAt + sliceConfiguration.OutputNameGenerator.GenerateName(sourceTexture.name, terrainSlice.Row, terrainSlice.Column) + ".png";

            TextureImporter sourceTextureImporter = (TextureImporter)AssetImporter.GetAtPath(fullAssetPathOfSourceTexture);

            TextureImporterFormat sourceTextureFormat = sourceTextureImporter.textureFormat;
            sourceTextureImporter.textureFormat = TextureImporterFormat.ARGB32;
            bool isReadable = sourceTextureImporter.isReadable;
            sourceTextureImporter.isReadable = true;
            AssetDatabase.ImportAsset(fullAssetPathOfSourceTexture, ImportAssetOptions.ForceUpdate);

#if UNITY_4
            Texture2D originalTexture2D = AssetDatabase.LoadAssetAtPath(fullAssetPathOfSourceTexture, typeof(Texture2D)) as Texture2D;
#else
            Texture2D originalTexture2D = AssetDatabase.LoadAssetAtPath<Texture2D>(fullAssetPathOfSourceTexture);
#endif

            int width = (int)(sourceTexture.width * terrainSlice.ProportionOfSliceToSource);
            int height = (int)(sourceTexture.height * terrainSlice.ProportionOfSliceToSource);

            try
            {
                Texture2D newTexture = new Texture2D(width, height, TextureFormat.ARGB32, sourceTextureImporter.mipmapEnabled);

                int startX = (int)(originalTexture2D.width * terrainSlice.NormalizedXPosition);
                int startY = (int)(originalTexture2D.height * terrainSlice.NormalizedZPosition);

                Color[] pixels = originalTexture2D.GetPixels(startX, startY, width, height);

                newTexture.SetPixels(0, 0, width, height, pixels);
                newTexture.Apply();

                string fullApplicationPathOfNewTexture = applicationSavePath + textureName;

                File.WriteAllBytes(fullApplicationPathOfNewTexture, newTexture.EncodeToPNG());
                GameObject.DestroyImmediate(newTexture);

                AssetDatabase.ImportAsset(fullAssetPathOfNewTexture);
                RefreshAssetDatabase();

                TextureImporter newTextureImporter = (TextureImporter)AssetImporter.GetAtPath(fullAssetPathOfNewTexture);

                TextureImporterSettings sourceTextureSettings = new TextureImporterSettings();
                TextureImporterSettings newTextureSettings = new TextureImporterSettings();

                sourceTextureImporter.ReadTextureSettings(sourceTextureSettings);
                sourceTextureSettings.CopyTo(newTextureSettings);
                newTextureImporter.SetTextureSettings(newTextureSettings);

                sourceTextureImporter.textureFormat = sourceTextureFormat;
                sourceTextureImporter.isReadable = isReadable;

                AssetDatabase.ImportAsset(fullAssetPathOfSourceTexture, ImportAssetOptions.ForceUpdate);
                AssetDatabase.ImportAsset(fullAssetPathOfNewTexture, ImportAssetOptions.ForceUpdate);
                RefreshAssetDatabase();

#if UNITY_4
                material.SetTexture(texturePropertyName, (Texture2D)AssetDatabase.LoadAssetAtPath(fullAssetPathOfNewTexture, typeof(Texture2D)));
#else
                material.SetTexture(texturePropertyName, AssetDatabase.LoadAssetAtPath<Texture>(fullAssetPathOfNewTexture));
#endif
                RefreshAssetDatabase();
            }
            catch (System.Exception e)
            {
                sourceTextureImporter.textureFormat = sourceTextureFormat;
                sourceTextureImporter.isReadable = isReadable;
                AssetDatabase.ImportAsset(fullAssetPathOfSourceTexture);
                RefreshAssetDatabase();
                throw e;
            }
        }

        /// <summary>
        /// Sets the textures of a material to the splat/alpha maps of a terrain slice.
        /// </summary>
        /// <param name="terrainSlice">The sliced terrain</param>
        /// <param name="material">The material whose textures will be set to the slices splat maps</param>
        /// <param name="texturesToSet">
        /// The textures to set (these are the texture names as found within the shader source). 
        /// The position of the texture name in the array determines which splat is applied to it. 
        /// For instance, the texture at index 0 will be set to SplatAlpha 0 (as seen in the Terrain 
        /// Data foldout within your project hierarchy). If you want to skip an alphamap, set the 
        /// value at that index to null within the array.
        /// </param>
        public static void SetMaterialTexturesToTerrainSplats(TerrainSlice terrainSlice, Material material, string[] texturesToSet)
        {
            Object[] assets = AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(terrainSlice.SliceTerrainData));

            for (int i = 0; i < assets.Length; i++)
            {
                Texture2D splat = assets[i] as Texture2D;
                if (splat == null)
                    continue;

                string splatName = splat.name;
                int index = int.Parse(splatName.Remove(0, 11));

                if (index < texturesToSet.Length && texturesToSet[index] != null)
                    material.SetTexture(texturesToSet[index], splat);                
            }

            RefreshAssetDatabase();
        }

        /// <summary>
        /// Takes the base float properties of a material and "slices" them so they are 
        /// representative of the slice (rather than the original source terrain).
        /// For instance, if the value on the source terrains material was 1, and the slice is 1/4 the 
        /// size of the source terrain, the value on the slices material will be set to .25.
        /// </summary>
        /// <param name="terrainSlice">The terrain slice.</param>
        /// <param name="material">The material used by the slice terrain whose values will be sliced.</param>
        /// <param name="floatPropertiesToSlice">The lsit of float properties that should be sliced.</param>
        public static void SliceMaterialFloatProperties(TerrainSlice terrainSlice, Material material, List<string> floatPropertiesToSlice)
        {
            for (int i = 0; i < ShaderUtil.GetPropertyCount(material.shader); i++)
            {
                ShaderUtil.ShaderPropertyType propertyType = ShaderUtil.GetPropertyType(material.shader, i);
                if (propertyType == ShaderUtil.ShaderPropertyType.Float)
                {
                    string floatPropertyName = ShaderUtil.GetPropertyName(material.shader, i);
                    if (floatPropertiesToSlice.Contains(floatPropertyName))
                    {
                        float unslicedValue = material.GetFloat(floatPropertyName);
                        material.SetFloat(floatPropertyName, unslicedValue * terrainSlice.ProportionOfSliceToSource);
                    }
                }
            }
        }

        /// <summary>
        /// Multiply source texture scale by ProportionOfSliceToSource value and sets the texture offset 
        /// to the normalized position of the slice in relation to the source terrains position.
        /// </summary>
        /// <param name="terrainSlice">The terrain slice.</param>
        /// <param name="material">The material of the terrain slice.</param>
        /// <param name="texturePropertiesToAdjust">
        /// The texture properties of the material whose scale and offset values will be adjusted.
        /// </param>
        public static void SliceTextureScaleAndOffset_NormalMethod(TerrainSlice terrainSlice, Material material, List<string> texturePropertiesToAdjust)
        {
            foreach (string textureProperty in texturePropertiesToAdjust)
            {
                Vector2 unslicedScale = material.GetTextureScale(textureProperty);
                Vector2 slicedScale = unslicedScale * terrainSlice.ProportionOfSliceToSource;
                material.SetTextureScale(textureProperty, slicedScale);
                material.SetTextureOffset(textureProperty, new Vector2(terrainSlice.NormalizedXPosition, terrainSlice.NormalizedZPosition));
            }
        }

        /// <summary>
        /// Multiply source texture scale by ProportionOfSliceToSource value and sets the texture offset 
        /// to an adjusted value. 
        /// This should be used if AdjustTextureScaleAndOffset_NormalMethod does not produce accurate results.
        /// It may be most useful for tiled textures that repeat across the terrain (such as grass, rocks, 
        /// etc.). For instance, it is used to correctly offset the splat textures in the ats ULTRA shader.
        /// </summary>
        /// <param name="terrainSlice">The terrain slice.</param>
        /// <param name="material">The material of the terrain slice.</param>
        /// <param name="texturePropertiesToAdjust">
        /// The texture properties of the material whose scale and offset values will be adjusted.
        /// </param>
        public static void SliceTextureScaleAndOffset_AbnormalMethod(TerrainSlice terrainSlice, Material material, List<string> texturePropertiesToAdjust)
        {
            foreach (string textureProperty in texturePropertiesToAdjust)
            {
                Vector2 unslicedScale = material.GetTextureScale(textureProperty);
                Vector2 slicedScale = unslicedScale * terrainSlice.ProportionOfSliceToSource;

                double xOffset = unslicedScale.x * terrainSlice.NormalizedXPosition;
                double xRemainder = xOffset % 10d;

                double zOffset = unslicedScale.y * terrainSlice.NormalizedZPosition;
                double zRemainder = zOffset % 10d;

                material.SetTextureScale(textureProperty, slicedScale);
                material.SetTextureOffset(textureProperty, new Vector2((float)xRemainder, (float)zRemainder));
            }
        }
    }
}