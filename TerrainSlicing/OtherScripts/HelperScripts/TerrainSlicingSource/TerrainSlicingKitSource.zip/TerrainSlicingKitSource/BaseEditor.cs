﻿////Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
//namespace TerrainSlicingKit
//{
//    using System;
//    using UnityEditor;
//    using UnityEngine;
//    using System.Collections.Generic;

//    public abstract class BaseEditor
//    {
//        public bool playMode;

//        protected GUILayoutOption smallLabel, wideLabel, extraWideLabel, mediumLabel;
//        protected GUIStyle boldFoldout;

//        protected SerializedObject serializedObject;
//        public SerializedObjectHelper helper;

//        public BaseEditor(SerializedObject serializedObject)
//        {
//            this.serializedObject = serializedObject;
//            helper = new SerializedObjectHelper(serializedObject);

//            smallLabel = GUILayout.Width(40f);
//            wideLabel = GUILayout.Width(150f);
//            mediumLabel = GUILayout.Width(270f);
//            extraWideLabel = GUILayout.Width(310f);
//        }

//        public void OnInspectorGUI(bool dontApplyModifiedProperties = false)
//        {
//            playMode = Application.isPlaying;

//            if (playMode)
//            {
//                EditorGUILayout.LabelField("Editing is not allowed while in play mode!");
//                EditorGUILayout.Space();
//            }

//            if (boldFoldout == null)
//                CreateBoldFoldoutLabel();

//            serializedObject.Update();
//            DrawInspector();

//            if (!playMode && !dontApplyModifiedProperties)
//                serializedObject.ApplyModifiedProperties();
//        }

//        public virtual void OnSceneGUI(SceneView sceneView) { }

//        void CreateBoldFoldoutLabel()
//        {
//            boldFoldout = new GUIStyle(EditorStyles.foldout);
//            boldFoldout.font = EditorStyles.boldLabel.font;
//        }

//        protected abstract void DrawInspector();
//    }
//}