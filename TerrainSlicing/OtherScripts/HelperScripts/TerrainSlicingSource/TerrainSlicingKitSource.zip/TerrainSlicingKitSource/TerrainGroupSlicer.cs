﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using System;
    using UnityEditor;
    using UnityEngine;
    using DynamicLoadingKit;
    using Object = UnityEngine.Object;

    internal class TerrainGroupSlicer : TerrainSlicer
    {
        int totalNumRowsToSlice, totalNumColumnsToSlice;
        string unityFolderWhereTerrainGroupDataIsStored, unityFolderWhereTerrainGroupPrefabsAreStored, baseNameOfTerrainGroupData, baseNameOfTerrainGroup, inputNamingConventionFormatStringNonTerrainData;
        ITerrainGetter terrainGetter;
        int inputRowStart, inputColumnStart;

        internal TerrainGroupSlicer(SliceConfiguration sliceConfiguration, UnityVersionDependentDataCopier versionDependentDataCopier)
            : base(sliceConfiguration, versionDependentDataCopier)
        {
            terrainSliceCreator = new TerrainSliceCreator(versionDependentDataCopier,
                                                            unitySliceDataSavePath,
                                                            sliceConfiguration.sliceDataOutputBaseName,
                                                            sliceConfiguration.sliceOutputBaseName,
                                                            outputNamingConventionFormatStringForTerrainData,
                                                            outputNamingConventionFormatStringForTerrainObject,
                                                            outputNumberingStartsAt0,
                                                            sliceConfiguration.baseTerrainToSliceRatio,
                                                            sliceConfiguration.baseTerrainToSliceRatio,
                                                            sliceConfiguration.baseTerrainToSliceRatio,
                                                            Vector3.zero,
                                                            sliceConfiguration.sliceProcessors,
                                                            sliceConfiguration.copyBaseLayer,
                                                            sliceConfiguration.copyBaseTag,
                                                            sliceConfiguration.copyAllTrees,
                                                            sliceConfiguration.copyAllDetails,
                                                            !sliceConfiguration.dontSliceAlphamap,
                                                            sliceConfiguration.copySplatTextures,
                                                            sliceConfiguration.createPrefabs,
                                                            prefabSliceSavePath,
                                                            sliceConfiguration.removeSlicesFromSceneAfterCreation);

            INamingConvention namingConventionToUse = sliceConfiguration.inputNamingConvention.GetCorrectNamingConvention(false);

            string formatString1 = namingConventionToUse.GetStringFormatVersion2DWithoutGroupName();

            baseNameOfTerrainGroup = FindBaseName(sliceConfiguration.sampleTerrain.name, formatString1);
            if (baseNameOfTerrainGroup == null)
                throw new SliceException("The terrain you've provides does not follow the correct terrain group naming convention. It should follow the convention found in the naming convention you've provided, or the default naming convention (GroupName_Row_Column) if no convention was provided.");

            inputNamingConventionFormatStringNonTerrainData = namingConventionToUse.GetStringFormatVersion(false, baseNameOfTerrainGroup);

            baseNameOfTerrainGroupData = FindBaseName(sliceConfiguration.sampleTerrain.terrainData.name, formatString1);
            if (baseNameOfTerrainGroupData == null)
                throw new SliceException("The terrain data of the terrain you've provides does not follow the correct terrain group naming convention.  It should follow the convention found in the naming convention you've provided, or the default naming convention (GroupName_Row_Column) if no convention was provided.");

            if (namingConventionToUse.NumberingStartsAt0)
                inputRowStart = inputColumnStart = 0;
            else
                inputRowStart = inputColumnStart = 1;

            unityFolderWhereTerrainGroupDataIsStored = GetFolderFromFullAssetPath(AssetDatabase.GetAssetPath(sliceConfiguration.sampleTerrain.terrainData));

            if(EditorUtility.IsPersistent(sliceConfiguration.sampleTerrain))
            {
                unityFolderWhereTerrainGroupPrefabsAreStored = GetFolderFromFullAssetPath(AssetDatabase.GetAssetPath(sliceConfiguration.sampleTerrain));
                terrainGetter = new ProjectHiearchyTerrainGetter(unityFolderWhereTerrainGroupPrefabsAreStored);
            }
            else
                terrainGetter = new SceneTerrainGetter();

            totalNumRowsToSlice = sliceConfiguration.lastRow - sliceConfiguration.firstRow + 1;
            totalNumColumnsToSlice = sliceConfiguration.lastColumn - sliceConfiguration.firstColumn + 1;
        }

        //change this to return total 
        protected sealed override int OutputFirstRow { get { return ((sliceConfiguration.firstRow - inputRowStart) * sliceConfiguration.baseTerrainToSliceRatio) + outputRowStart; } }

        protected sealed override int OutputFirstColumn { get { return ((sliceConfiguration.firstColumn - inputColumnStart) * sliceConfiguration.baseTerrainToSliceRatio) + outputColumnStart;} }

        protected sealed override int OutputLastRow { get { return ((sliceConfiguration.lastRow - inputRowStart) * sliceConfiguration.baseTerrainToSliceRatio) + outputRowStart; } }
        protected sealed override int OutputLastColumn { get { return ((sliceConfiguration.lastColumn - inputColumnStart) * sliceConfiguration.baseTerrainToSliceRatio) + outputColumnStart; } }

        string FindBaseName(string nameWithRowAndColumn, string inputNamingConventionFormatString)
        {
            string[] parsedString = nameWithRowAndColumn.ParseExact(inputNamingConventionFormatString);
            return parsedString[2];
        }

        string GetFolderFromFullAssetPath(string fullAssetPath)
        {
            string[] assetPathSplit = fullAssetPath.Split('/');
            
            Array.Resize<string>(ref assetPathSplit, assetPathSplit.Length - 1);
            return string.Join("/", assetPathSplit) + "/"; 
        }

        protected override void OverwriteProtection()
        {
            DataOverwriteProtection();
            if (sliceConfiguration.createPrefabs && EditorUtility.IsPersistent(sliceConfiguration.sampleTerrain))
                PrefabOverwriteProtection();
        }

        void DataOverwriteProtection()
        {
            if (string.Compare(unitySliceDataSavePath, unityFolderWhereTerrainGroupDataIsStored) == 0 && string.Compare(baseNameOfTerrainGroupData, sliceConfiguration.sliceDataOutputBaseName) == 0)
                throw new SliceException("The base name you've specified for the created slice data is the same base name of the terrain data you are slicing, and the folder you've set where the slice data should be saved to " +
                "is the same folder where the data you are slicing is stored. This is not allowed, as it will most likely result in the data you are trying to slice being overwritten by the output slice data.");

        }

        void PrefabOverwriteProtection()
        {
            if (string.Compare(prefabSliceSavePath, unityFolderWhereTerrainGroupPrefabsAreStored) == 0 && string.Compare(baseNameOfTerrainGroup, sliceConfiguration.sliceOutputBaseName) == 0)
                throw new SliceException("The base name you've specified for the slices is the same base name of the terrain group you are slicing, and the folder you've set where the slice prefabs should be saved to " +
            "is the same folder where the prefabs you are slicing are stored. This is not allowed, as it will most likely result in the prefabs you are trying to slice being overwritten by the output slice prefabs.");
        }




        protected override void SliceTerrain(TreeDataHandler treeDataHandler)
        {
            float startingProgress = 0f;

            int numberOfTerrainsInGroup = (sliceConfiguration.lastRow - sliceConfiguration.firstRow + 1) * (sliceConfiguration.lastColumn - sliceConfiguration.firstColumn + 1);
            float progressIncrement = 1f / numberOfTerrainsInGroup;

            int desiredSlices = sliceConfiguration.baseTerrainToSliceRatio;

            for (int row = sliceConfiguration.firstRow; row <= sliceConfiguration.lastRow; row++)
            {
                for (int column = sliceConfiguration.firstColumn; column <= sliceConfiguration.lastColumn; column++)
                {
                    string terrainToSliceName = string.Format(inputNamingConventionFormatStringNonTerrainData, column, row);

                    Terrain terrainToSlice = terrainGetter.GetTerrain(terrainToSliceName);
                    int maxSlicesForTerrain = terrainToSlice.DetermineMaxSlice();
                    if (maxSlicesForTerrain < desiredSlices)
                    {
                        additionalDetailsOnSliceResult += "The terrain named " + terrainToSliceName + " was not sliced. The max allowed slices for this terrain is " + maxSlicesForTerrain + ". Yet you have specified all terrains in the " +
                            "group should be sliced " + desiredSlices + "times.\n";
                    }
                    else
                        terrainSliceCreator.CreateSlices(terrainToSlice, treeDataHandler, (row - inputRowStart) * desiredSlices, (column - inputColumnStart) * desiredSlices, startingProgress, progressIncrement);

                    startingProgress += progressIncrement;
                }
            }
        }





        interface ITerrainGetter
        {
            Terrain GetTerrain(string terrainName);
        }

        class SceneTerrainGetter : ITerrainGetter
        {
            public SceneTerrainGetter() { }

            public Terrain GetTerrain(string terrainName)
            {
                return GameObject.Find(terrainName).GetComponent<Terrain>();
            }
        }

        class ProjectHiearchyTerrainGetter : ITerrainGetter
        {
            string unityFolderWhereTerrainGroupPrefabsAreStored;

            public ProjectHiearchyTerrainGetter(string unityFolderWhereTerrainGroupPrefabsAreStored) 
            {
                this.unityFolderWhereTerrainGroupPrefabsAreStored = unityFolderWhereTerrainGroupPrefabsAreStored;
            }

            public Terrain GetTerrain(string terrainName)
            {
#if UNITY_4
                GameObject terrainPrefab = (GameObject)Resources.LoadAssetAtPath(string.Format("{0}{1}.prefab", unityFolderWhereTerrainGroupPrefabsAreStored, terrainName), typeof(GameObject));
#else
                GameObject terrainPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(string.Format("{0}{1}.prefab", unityFolderWhereTerrainGroupPrefabsAreStored, terrainName));
#endif
                return terrainPrefab.GetComponent<Terrain>();
            }
        }
    }
}
