﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEditor;
    using UnityEngine;
    using DynamicLoadingKit;

    internal abstract class TerrainSlicer
    {
        protected SliceConfiguration sliceConfiguration;
        protected UnityVersionDependentDataCopier versionDependentDataCopier;

        protected string additionalDetailsOnSliceResult = "";

        protected string prefabSliceSavePath;
        protected string unitySliceDataSavePath;
        protected string outputNamingConventionFormatStringForTerrainData, outputNamingConventionFormatStringForTerrainObject;
        protected int outputRowStart, outputColumnStart, outputRowEnd, outputColumnEnd;
        protected bool outputNumberingStartsAt0;

        protected TerrainSliceCreator terrainSliceCreator;

        internal TerrainSlicer(SliceConfiguration sliceConfiguration, UnityVersionDependentDataCopier versionDependentDataCopier)
        {
            this.sliceConfiguration = sliceConfiguration;
            this.versionDependentDataCopier = versionDependentDataCopier;

            unitySliceDataSavePath = sliceConfiguration.sliceDataSaveFolder.PrepareRelativeFolderPathForSaving();
            prefabSliceSavePath = sliceConfiguration.prefabSaveFolder.PrepareRelativeFolderPathForSaving();

            INamingConvention outputNamingConventionToUse = sliceConfiguration.outputNamingConvention.GetCorrectNamingConvention(false);
            outputNumberingStartsAt0 = outputNamingConventionToUse.NumberingStartsAt0;
            sliceConfiguration.OutputNameGenerator = new NameGenerator2D(outputNamingConventionToUse);

            if (outputNumberingStartsAt0)
                outputRowStart = outputColumnStart = 0;
            else
                outputRowStart = outputColumnStart = 1;

            outputRowEnd = outputRowStart + sliceConfiguration.rowsOfSlices - 1;
            outputColumnEnd = outputColumnStart + sliceConfiguration.columnsOfSlices - 1;

            outputNamingConventionFormatStringForTerrainData = outputNamingConventionToUse.GetStringFormatVersion(false, sliceConfiguration.sliceDataOutputBaseName);

            outputNamingConventionFormatStringForTerrainObject = outputNamingConventionToUse.GetStringFormatVersion(false, sliceConfiguration.sliceOutputBaseName);
        }

        protected abstract int OutputFirstRow { get; }
        protected abstract int OutputFirstColumn { get; }
        protected abstract int OutputLastRow { get; }
        protected abstract int OutputLastColumn { get; }

        internal string InitializeSlice(TreeDataHandler treeDataHandler)
        {
            OverwriteProtection();
            RunSliceProcessorPreSlicingPrep();

            SliceTerrain(treeDataHandler);

            if (!sliceConfiguration.dontSliceAlphamap && !sliceConfiguration.disableEdgeBlending)
                BlendTerrainAlphamaps();

            RemoveDuplicateTerrainInScene();
#if UNITY_4
            EditorApplication.SaveScene();
#else
            UnityEngine.SceneManagement.Scene scene = UnityEditor.SceneManagement.EditorSceneManager.GetActiveScene();
            UnityEditor.SceneManagement.EditorSceneManager.SaveScene(scene);
#endif

            return additionalDetailsOnSliceResult;
        }

        void RunSliceProcessorPreSlicingPrep()
        {
            if (sliceConfiguration.sliceProcessors != null && sliceConfiguration.sliceProcessors.Length != 0)
            {
                for (int i = 0; i < sliceConfiguration.sliceProcessors.Length; i++)
                {
                    if (sliceConfiguration.sliceProcessors[i] != null)
                        sliceConfiguration.sliceProcessors[i].PreSlicingPrep(sliceConfiguration);
                }
            }
        }

        void RemoveDuplicateTerrainInScene()
        {
#if UNITY_4
            Terrain[] terrainsInScene = (Terrain[])GameObject.FindObjectsOfType(typeof(Terrain));
#else
            Terrain[] terrainsInScene = GameObject.FindObjectsOfType<Terrain>();
#endif

            //Debug.Log(terrainsInScene.Length);
            for (int i = terrainsInScene.Length - 1; i >= 0; i--)
            {
                if (terrainsInScene[i].terrainData == null)
                    GameObject.DestroyImmediate(terrainsInScene[i].gameObject);
            }

#if UNITY_4
            EditorUtility.UnloadUnusedAssets();
#else
            EditorUtility.UnloadUnusedAssetsImmediate();
#endif
            System.GC.Collect();
        }

        protected abstract void OverwriteProtection();

        protected abstract void SliceTerrain(TreeDataHandler treeDataHandler);

        void BlendTerrainAlphamaps()
        {
            AssetAlphamapBlender blender = new AssetAlphamapBlender(unitySliceDataSavePath, outputNamingConventionFormatStringForTerrainData);
            blender.BlendTerrainDataAssets(OutputFirstRow, OutputLastRow, OutputFirstColumn, OutputLastColumn, sliceConfiguration.edgeBlendingWidth, PortionToTile.TileInner);
        }
    }
}