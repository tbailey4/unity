﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
using System;
using System.Collections.Generic;
using UnityEngine;

namespace TerrainSlicingKit
{
    public class TreeCopier
    {
        Terrain sourceTerrain;
        TerrainData sourceTerrainData;
        TreeDataHandler treeDataHandler;

        TreePrototype[] treeProtos;
        List<TreeInstance>[][] sortedTreeInstances;
        int[] defaultTreePrototypeIndexes;
        int[][][] treePrototypeIndexes;
        HashSet<int> indexOfPrototypesOnSlice;

        float oldWidth, oldLength, newWidth, newLength, normalizedSliceToBaseTerrainRatio;
        int rowsOfSlices, columnsOfSlices, baseTerrainToSliceRatio;
        Vector3 normalizedCopyStart;

        public TreeCopier(Terrain sourceTerrain, TreeDataHandler treeDataHandler, int rowsOfSlices, int columnsOfSlices, int baseTerrainToSliceRatio, Vector3 normalizedCopyStart)
        {
            this.sourceTerrain = sourceTerrain;
            this.rowsOfSlices = rowsOfSlices;
            this.columnsOfSlices = columnsOfSlices;
            this.baseTerrainToSliceRatio = baseTerrainToSliceRatio;
            this.treeDataHandler = treeDataHandler;
            this.normalizedCopyStart = normalizedCopyStart;

            sourceTerrainData = sourceTerrain.terrainData;
            treeProtos = sourceTerrainData.treePrototypes;
            indexOfPrototypesOnSlice = new HashSet<int>();

            oldWidth = sourceTerrainData.size.x;
            oldLength = sourceTerrainData.size.z;

            newWidth = oldWidth / baseTerrainToSliceRatio;
            newLength = oldLength / baseTerrainToSliceRatio;

            normalizedSliceToBaseTerrainRatio = 1f / baseTerrainToSliceRatio;

            CreateDefaultTreePrototypeIndexesArray();
        }

        void CreateDefaultTreePrototypeIndexesArray()
        {
            defaultTreePrototypeIndexes = new int[treeProtos.Length];
            for (int i = 0; i < defaultTreePrototypeIndexes.Length; i++)
                defaultTreePrototypeIndexes[i] = i;
        }

        public void IdentifySlicePlacementOfTrees()
        {
            TreeInstance[] unsortedTreeInstances = sourceTerrainData.treeInstances;
            if(unsortedTreeInstances == null || unsortedTreeInstances.Length == 0)
            {
                sortedTreeInstances = null;
                return;
            }

            sortedTreeInstances = new List<TreeInstance>[rowsOfSlices][];
            for (int row = 0; row < sortedTreeInstances.Length; row++)
            {
                sortedTreeInstances[row] = new List<TreeInstance>[columnsOfSlices];
                for (int column = 0; column < sortedTreeInstances[row].Length; column++)
                    sortedTreeInstances[row][column] = new List<TreeInstance>();
            }


            float normalizedMaxX = normalizedCopyStart.x + (normalizedSliceToBaseTerrainRatio * columnsOfSlices);
            float normalizedMaxZ = normalizedCopyStart.z + (normalizedSliceToBaseTerrainRatio * rowsOfSlices);

            for (int i = 0; i < unsortedTreeInstances.Length; i++)
            {
                Vector3 normalizedTreePosition = treeDataHandler.RetrievePosition(unsortedTreeInstances[i]);

                int column = Mathf.FloorToInt((normalizedTreePosition.x - normalizedCopyStart.x) / normalizedSliceToBaseTerrainRatio);
                if(column >= 0 && column < columnsOfSlices)
                {
                    int row = Mathf.FloorToInt((normalizedTreePosition.z - normalizedCopyStart.z) / normalizedSliceToBaseTerrainRatio);
                    if (row >= 0 && row < rowsOfSlices)
                        sortedTreeInstances[row][column].Add(unsortedTreeInstances[i]);
                }                
            }
        }

        public void IdentifyWhichPrototypesArePresentOnEachSlice(bool copyAllTrees)
        {
            if(sortedTreeInstances == null)
            {
                treePrototypeIndexes = null;
                return;
            }

            treePrototypeIndexes = new int[rowsOfSlices][][];
            for (int row = 0; row < treePrototypeIndexes.Length; row++)
            {
                treePrototypeIndexes[row] = new int[columnsOfSlices][];
                for (int column = 0; column < treePrototypeIndexes[row].Length; column++)
                {
                    if (copyAllTrees)
                        treePrototypeIndexes[row][column] = defaultTreePrototypeIndexes;
                    else
                        treePrototypeIndexes[row][column] = DetermineTreePrototypesPresentOnSlice(row, column);
                }
            }
        }

        int[] DetermineTreePrototypesPresentOnSlice(int rowOfSlice, int columnOfSlice)
        {
            List<TreeInstance> treesOnSlice = sortedTreeInstances[rowOfSlice][columnOfSlice];

            foreach (TreeInstance tree in treesOnSlice)
                indexOfPrototypesOnSlice.Add(treeDataHandler.GetTreePrototypeIndex(tree));

            int[] indexes = new int[indexOfPrototypesOnSlice.Count];
            indexOfPrototypesOnSlice.CopyTo(indexes);

            indexOfPrototypesOnSlice.Clear();
            return indexes;
        }

        public void CopyTreesToSlice(Terrain slice, int rowOfSlice, int columnOfSlice)
        {
            if (sortedTreeInstances == null)
                return;

            TerrainData sliceData = slice.terrainData;
            int[] slicePrototypeIndexes = treePrototypeIndexes[rowOfSlice][columnOfSlice];
            sliceData.treePrototypes = GetTreePrototypes(slicePrototypeIndexes);

            List<TreeInstance> trees = sortedTreeInstances[rowOfSlice][columnOfSlice];
            
            foreach (TreeInstance tree in trees)
            {
                Vector3 normalizedTreePositionOnSourceTerrain = treeDataHandler.RetrievePosition(tree);
                float normalizedTreeXPositionOnNewTerrain = (normalizedTreePositionOnSourceTerrain.x - (normalizedCopyStart.x + (normalizedSliceToBaseTerrainRatio * columnOfSlice))) / normalizedSliceToBaseTerrainRatio;

                float normalizedTreeZPositionOnNewTerrain = (normalizedTreePositionOnSourceTerrain.z - (normalizedCopyStart.z + (normalizedSliceToBaseTerrainRatio * rowOfSlice))) / normalizedSliceToBaseTerrainRatio;

                treeDataHandler.AddTreeInstance(slice, tree, new Vector3(normalizedTreeXPositionOnNewTerrain, normalizedTreePositionOnSourceTerrain.y, normalizedTreeZPositionOnNewTerrain), Array.IndexOf(slicePrototypeIndexes, treeDataHandler.GetTreePrototypeIndex(tree)));
            }
        }

        public void NullDataRelatedToSlice(int rowOfSlice, int columnOfSlice)
        {
            if (sortedTreeInstances == null)
                return;

            sortedTreeInstances[rowOfSlice][columnOfSlice].Clear();
            sortedTreeInstances[rowOfSlice][columnOfSlice] = null;

            treePrototypeIndexes[rowOfSlice][columnOfSlice] = null;
        }

        TreePrototype[] GetTreePrototypes(int[] slicePrototypeIndexes)
        {
            TreePrototype[] treePrototypes = new TreePrototype[slicePrototypeIndexes.Length];

            for (int i = 0; i < slicePrototypeIndexes.Length; i++)
                treePrototypes[i] = treeProtos[slicePrototypeIndexes[i]];

            return treePrototypes;
        }
    }
}