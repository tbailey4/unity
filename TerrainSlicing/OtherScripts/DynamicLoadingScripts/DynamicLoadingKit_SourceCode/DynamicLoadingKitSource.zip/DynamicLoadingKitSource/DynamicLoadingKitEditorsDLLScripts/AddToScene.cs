﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEditor;
    using UnityEngine;

    static class PrefabSceneAdder
    {
        [MenuItem("Assets/Dynamic Loading Kit/Add Prefabs To Scene")]
        public static void AddPrefabsToScene()
        {
            Object[] selectedPrefabs = Selection.GetFiltered(typeof(GameObject), SelectionMode.Assets);

            System.Array.Sort(selectedPrefabs, delegate(Object g1, Object g2) { return g1.name.CompareTo(g2.name); });
            System.Array.Reverse(selectedPrefabs);

            foreach (GameObject gameObject in selectedPrefabs)
                PrefabUtility.InstantiatePrefab(gameObject);
        }
    }
}