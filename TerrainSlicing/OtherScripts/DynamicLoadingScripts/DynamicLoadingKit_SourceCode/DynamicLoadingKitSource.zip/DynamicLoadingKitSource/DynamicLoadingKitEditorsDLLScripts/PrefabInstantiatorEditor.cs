//Terrain Slicing & Dynamic Loading Kits v1.5 copyright © 2013 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEditor;
	using UnityEngine;
	using DynamicLoadingKit;
	
	[CustomEditor(typeof(PrefabInstantiator))]
    class PrefabInstantiatorEditor : Editor
	{
        SerializedProperty timeToWaitBetweenInstantiatesProperty;
        
        public override void OnInspectorGUI()
		{
            if (timeToWaitBetweenInstantiatesProperty == null)
                timeToWaitBetweenInstantiatesProperty = serializedObject.FindProperty("timeToYieldBetweenInstantiates");

            serializedObject.Update();

            if (Application.isPlaying)
            {
                EditorGUILayout.LabelField("Editing is not allowed while in play mode!");
                EditorGUILayout.PropertyField(timeToWaitBetweenInstantiatesProperty, instantiateFrequencyLabel);
            }
            else
            {
                EditorGUILayout.PropertyField(timeToWaitBetweenInstantiatesProperty, instantiateFrequencyLabel);
                serializedObject.ApplyModifiedProperties();
            }
		}

        GUIContent instantiateFrequencyLabel = new GUIContent("Instantiate Frequency*", "The amount of time (in seconds) to wait " +
                "between object instantiations.\n\n" +
                "Basically, after each cell object is instantiated, the program will wait this amount of time before " +
                "instantiating the next cell object. Experiment to find the best value.");
	}
}