﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;

    internal abstract class IWorldGridDataRetriever
    {
        internal abstract WorldGridSetupData RetrieveWorldGridData();
    }

    internal class DefaultDataRetriever : IWorldGridDataRetriever
    {
        GridValues<int> gridDimensions;
        GridValues<float> defaultGridMeasurements;

        bool[] emptyGridLocations;
        float[] rowLengths, columnWidths, layerHeights;


        WorldType worldType;

        internal DefaultDataRetriever(WorldType worldType, GridValues<int> gridDimensions, GridValues<float> defaultGridMeasurements)
        {
            this.defaultGridMeasurements = defaultGridMeasurements;
            this.worldType = worldType;

            if (worldType == WorldType.Three_Dimensional)
            {
                this.gridDimensions = gridDimensions;
            }
            else
            {
                this.gridDimensions = new GridValues<int>(1, gridDimensions.rowValue, gridDimensions.columnValue);
            }
        }

        internal sealed override WorldGridSetupData RetrieveWorldGridData()
        {
            CreateSpaceForArrays();
            rowLengths.SetAllValuesToSingleValue<float>(defaultGridMeasurements.rowValue);
            columnWidths.SetAllValuesToSingleValue<float>(defaultGridMeasurements.columnValue);
            emptyGridLocations.SetAllValuesToSingleValue<bool>(false);

            if (worldType == WorldType.Three_Dimensional)
                layerHeights.SetAllValuesToSingleValue<float>(defaultGridMeasurements.layerValue);

            return new WorldGridSetupData(emptyGridLocations, layerHeights, rowLengths, columnWidths);
        }

        void CreateSpaceForArrays()
        {
            rowLengths = new float[gridDimensions.rowValue];
            columnWidths = new float[gridDimensions.columnValue];

            if (worldType == WorldType.Three_Dimensional)
                layerHeights = new float[gridDimensions.layerValue];

            emptyGridLocations = new bool[gridDimensions.layerValue * gridDimensions.rowValue * gridDimensions.columnValue];
        }
    }
}
