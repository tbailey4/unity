//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEditor;
	using UnityEngine;
	using DynamicLoadingKit;
	
	[CustomEditor(typeof(PoolingPrimaryCellObjectSubController))]
    class PoolingPrimaryCellObjectSubControllerEditor : Editor
	{
        PrimaryCellObjectSubControllerEditor baseEditor;

		public override void OnInspectorGUI()
		{
            if (baseEditor == null)
                baseEditor = new PrimaryCellObjectSubControllerEditor(serializedObject);
            
            //pass in true to tell the base inpector not to apply modified properties,
            //as we'll do it in manually at the end of this method
            baseEditor.OnInspectorGUI(true);

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(objectsInPoolLabel, GUILayout.Width(175f));
            baseEditor.helper.DrawSerializedPropertyField("maxObjectsInPool", GUIContent.none);
            EditorGUILayout.EndHorizontal();
            
            if (!Application.isPlaying)
                serializedObject.ApplyModifiedProperties();
		}

        GUIContent objectsInPoolLabel = new GUIContent("Max Objects to Pool Per Cell*", "This is the maximum number of cell objects that can be stored in the pool for each cell.\n\n" +
            "For example, if you set this value to 2 and a cell object is deactivated on a cell that already has 2 objects in the pool, the deactivated cell object will be destroyed.\n\n" +
            "A higher value may improve performance, but will also potentially increase memory usage.");
	}
}