﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEngine;

    //class is no longer uses, but we'll keep it in to avoid compiler errors in the unity editor
    public class ComponentDataSetter
    {
        public ComponentDataSetter() { }
        public void SetComponentData(ActiveGrid grid, Transform player, int innerRows, int innerColumns, int outerRingWidth, bool useDynamicBoundaries) { }

        public void SetComponentData(World world, WorldGridBase worldGrid, bool isHorizontalAxisEndless, bool isVerticalAxisEndless, bool usePositionOfThisGameObjectAsOrigin, Vector3 worldOrigin) { }
    }
}