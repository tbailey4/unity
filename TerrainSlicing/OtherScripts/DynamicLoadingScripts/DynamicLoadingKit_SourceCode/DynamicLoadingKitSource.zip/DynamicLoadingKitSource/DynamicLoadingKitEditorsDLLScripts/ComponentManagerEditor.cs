﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEngine;
    using UnityEditor;
    using System;

    internal class ComponentManagerBaseEditor : BaseEditor
    {
        public ComponentManagerBaseEditor(SerializedObject serializedObject) : base(serializedObject) { }

        protected sealed override void DrawInspector()
        {
            helper.DrawSerializedPropertyField("componentManagerID", componentManagerIDLabel);
            helper.DrawSerializedPropertyField("initializeOnAwake", initializeOnAwakeLabel);
            helper.DrawSerializedPropertyField("suppressWarnings", suppressWarningsLabel);          
            DrawDataSavingOptions();
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField(prototypeLabel);

            DrawActiveGridPrototypeFields();
            EditorGUILayout.Space();
            DrawWorldPrototypeFields();
        }

        void DrawDataSavingOptions()
        {
            EditorGUILayout.LabelField(useCustomSaveLoadSolutionLabel1);
            SerializedProperty useCustomSaveLoadSolutionProperty = helper.GetPropertyByName("useCustomSaveLoadSolution");
            helper.DrawSerializedPropertyField(useCustomSaveLoadSolutionProperty, useCustomSaveLoadSolutionLabel2);

            if (!useCustomSaveLoadSolutionProperty.boolValue)
            {
                EditorGUILayout.LabelField(autoSaveLabel1);
                helper.DrawSerializedPropertyField("autoSaveDataOnGameExit", autoSaveLabel2);

                SerializedProperty persistentDataControllerProperty = helper.GetPropertyByName("persistentDataController");

                EditorGUILayout.LabelField(persistentDataControllerLabel1);
                helper.DrawSerializedPropertyField(persistentDataControllerProperty, persistentDataControllerLabel2);
                
                if (persistentDataControllerProperty.objectReferenceValue == null)
                    EditorGUILayout.HelpBox("A Persistent Data Controller Component must be provided!", MessageType.Warning);
            }
        }

        void DrawActiveGridPrototypeFields()
        {
            helper.DrawSerializedPropertyArrayField("activeGridPrototypes");
        }

        void DrawWorldPrototypeFields()
        {
            helper.DrawSerializedPropertyArrayField("worldPrototypes");
        }

        GUIContent componentManagerIDLabel = new GUIContent("Component Manager ID*", "An int ID that should be unique to this Component Manager in this scene (there should be " +
            "no other Component Managers in this scene with this ID).\n\nThis ID is used in " +
            "conjuction with the Persistent Data Controller's Scene ID to form a unique key for persistent data storage of data for this component.");

        static string autoSaveInfo = "If checked, all component manager data and data for every Active Grid in the scene will be saved when the game exits.\n\nThis is mainly useful for testing " +
            "purposes. In your actual game, you will probably want to limit saving to specific times (such as when the player clicks a 'Save Game' option). Use Save() (when using a persistent data controller) or GetSaveData (when using a custom save/load solution) in these situations.";

        GUIContent autoSaveLabel1 = new GUIContent("Auto Save Data", autoSaveInfo);
        GUIContent autoSaveLabel2 = new GUIContent("On Game Exit*", autoSaveInfo);

        GUIContent initializeOnAwakeLabel = new GUIContent("Initialze On Awake*", "If checked, the Component Manager will be initialized when its Awake method is called. This closes the window for loading save data and initializes all uninitialized Active Grids and Worlds in the scene.\n\nIn most situations, this is ideal, as it ensures all world's are fully loaded before the game starts.\n\nIn some situations, however, you may need to load save data or perform some other action before the Component Manager is initialized, in which case you can uncheck this option and call Initialize or InitializeGradually manually.");

        static string persistentDataControllerLabelString = "The Persistent Data Controller that will be used to save/load this component manager's data.";

        GUIContent persistentDataControllerLabel1 = new GUIContent("Persistent", persistentDataControllerLabelString);

        GUIContent persistentDataControllerLabel2 = new GUIContent("Data Controller*", persistentDataControllerLabelString);

        GUIContent prototypeLabel = new GUIContent("Component Prototypes*", "Prototypes are used to create Worlds and Active Grids during run time.\n\nThese prototypes control some of the default configuration for the Worlds/Active Grids, and also act as a repository for references to need objects (such as the Primary Cell Object Sub Controller used by a world).");

        static string useCustomSaveLoadSolutionLabelString = "Enable this if you'd like to use a custom saving/loading solution rather than the Persistent Data Controller (or if you know you won't be saving/loading data).\n\nWhile the persistent data controller is good for use in the editor while building/debugging your scene, you'll probably wish to utilize a better solution (such as serialization) before shipping your game.\n\nWhen this option is enabled, you can get a string representation of the Dynamic Loading Kit's persistent data (component manager and all persistent active grids/worlds in the scene) via the GetSaveData method.\n\nYou can then serialize or store this string however you wish, and when you're ready to load the save, simply deserialize/retrieve the string and pass it back to the component manager via the LoadSaveData method.\n\nNote, you must call LoadSaveData before the Component Manager is initialized, and before creating any Active Grids or Worlds procedurally.\n\n";

        GUIContent useCustomSaveLoadSolutionLabel1 = new GUIContent("Use Custom", useCustomSaveLoadSolutionLabelString);

        GUIContent useCustomSaveLoadSolutionLabel2 = new GUIContent("Save/Load Solution*", useCustomSaveLoadSolutionLabelString);

        GUIContent suppressWarningsLabel = new GUIContent("Suppress Warnings", "When enabled, various warnings will not be displayed in the console. It's a good idea to leave this option unchecked until you become familiar with the kit and get it configured to your liking.");
    }


    [CustomEditor(typeof(ComponentManager))]
    class ComponentManagerEditor : Editor
    {
        ComponentManagerBaseEditor baseEditor;

        public override void OnInspectorGUI()
        {
            if (baseEditor == null)
                baseEditor = new ComponentManagerBaseEditor(serializedObject);
            
            baseEditor.OnInspectorGUI();
        }
    }
}