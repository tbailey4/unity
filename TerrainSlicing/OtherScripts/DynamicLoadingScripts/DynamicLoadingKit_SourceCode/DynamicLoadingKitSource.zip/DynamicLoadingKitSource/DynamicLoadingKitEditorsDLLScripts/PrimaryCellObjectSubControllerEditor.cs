﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEngine;
    using UnityEditor;

    public class PrimaryCellObjectSubControllerEditor : BaseEditor
    {
        public PrimaryCellObjectSubControllerEditor(SerializedObject serializedObject) : base(serializedObject) { }

        protected sealed override void DrawInspector()
        {
            DrawCellObjectLoaderField();
            DrawCellObjectDestroyerField();
            DrawPostDestroyYieldTimeField();
            DrawUseCellActionsField();
            DrawMemoryFreeingStrategyField();
        }

        void DrawCellObjectLoaderField()
        {
            SerializedProperty cellObjectLoaderProp = helper.GetPropertyByName("cellObjectLoader");
            helper.DrawSerializedPropertyField(cellObjectLoaderProp, cellObjectLoaderLabel);

            if (cellObjectLoaderProp.objectReferenceValue == null)
                EditorGUILayout.HelpBox("A Cell Object Loader Component must be provided!", MessageType.Warning);
        }

        void DrawCellObjectDestroyerField()
        {
            helper.DrawSerializedPropertyField("cellObjectDestroyer", cellObjectDestroyerLabel);
        }

        void DrawPostDestroyYieldTimeField()
        {
            helper.DrawSerializedPropertyField("timeToYieldForAfterDestroyingCellObject", yieldAfterDestroyLabel);
        }

        void DrawUseCellActionsField()
        {
            helper.DrawSerializedPropertyField("useCellActions", useCellActionsLabel);
        }

        void DrawMemoryFreeingStrategyField()
        {
            helper.DrawSerializedPropertyField("memoryFreeingStrategy", memoryFreeingStrategyLabel);
        }

        GUIContent cellObjectLoaderLabel = new GUIContent("Cell Object Loader*", "The cell object loader component this sub controller should " +
            "use to load new cell objects into the scene.\n\nNote: It is OKAY to use the same cell object loader between multiple sub controllers.");

        GUIContent cellObjectDestroyerLabel = new GUIContent("Cell Object Destroyer*", "The cell object destroyer component this sub controller should " +
            "use to destroy cell objects.\n\nThis is an optional component. If left blank, the cell object and all of its children will be destroyed " +
            "in a single frame.");

        GUIContent memoryFreeingStrategyLabel = new GUIContent("Memory Freeing Strategy*", "The memory freeing strategy to use after one or more game objects have been destroyed by the Primary Cell Object Sub Controller. There may be a performance penalty when utilizing one of the automatic stategies, so you may wish to set this to Manual and call the memory freeing methods (Resources.UnloadUnusedAssets and System.GC.Collect) yourself at a time of your choosing.\n\n" +
        "Also note that Resources.UnloadUnusedAssets will usually free more memory than GC.Collect (this method may actually be useless for your game, you will have to test this out yourself).");

        GUIContent useCellActionsLabel = new GUIContent("Use Cell Actions*", "Enable this option if one or more of your cell objects use one or more Cell Action Components.\n\n" +
            "If not using cell actions (for instance, if you don't know what they are!), disable this option, as it will reduce some garbage generation.\n\n" +
            "(Please Note, garbage is generated only when this option is enabled and cell actions are not present on your cell objects, so don't be concerned about generating garbage " +
            "if Cell Actions ARE present on your cell objects.");

        GUIContent yieldAfterDestroyLabel = new GUIContent("Post Destroy Yield Time*", "The amount of time (in seconds) to yield for " +
                "after a cell object is destroyed. A time of 0 will result in no yielding. ");
    }
}
