﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEditor;
    using UnityEngine;
    using System;

    [CustomEditor(typeof(ObjectGroup))]
    class ObjectGroupEditor : Editor
    {
        ObjectGroupBaseEditor baseEditor;

        public override void OnInspectorGUI()
        {
            if (baseEditor == null)
                baseEditor = new ObjectGroupBaseEditor(serializedObject);
            
            baseEditor.OnInspectorGUI();
        }
    }

    internal class ObjectGroupBaseEditor : BaseEditor
    {
        bool groupIs3D;
        int layers, rows, columns;
        string formatStringRow = "R{0}", formatStringColumn = "C{0}";
        Texture enableButtonTex, disableButtonTex;

        SerializedProperty layersProperty, layerSelectProperty, rowsProperty, rowSelectProperty, columnsProperty, columnSelectProperty, usedCellsProperty;

        public ObjectGroupBaseEditor(SerializedObject serializedObject)
            : base(serializedObject)
        {
            columnsProperty = helper.GetPropertyByName("columns");
            columnSelectProperty = helper.GetPropertyByName("columnSelect");
            rowsProperty = helper.GetPropertyByName("rows");
            rowSelectProperty = helper.GetPropertyByName("rowSelect");
            layersProperty = helper.GetPropertyByName("layers");
            layerSelectProperty = helper.GetPropertyByName("layerSelect");
            usedCellsProperty = helper.GetPropertyByName("usedCells");

            layers = layersProperty.intValue;
            rows = rowsProperty.intValue;
            columns = columnsProperty.intValue;
            groupIs3D = helper.GetPropertyByName("groupIs3D").boolValue;

            enableButtonTex = (Texture2D)AssetDatabase.LoadAssetAtPath("Assets/TerrainSlicing/EditorResources/EnabledOption.png", typeof(Texture2D));
            disableButtonTex = (Texture2D)AssetDatabase.LoadAssetAtPath("Assets/TerrainSlicing/EditorResources/DisabledOption.png", typeof(Texture2D));

            SaveAndRebuildGrid();
            serializedObject.ApplyModifiedProperties();
        }

        protected sealed override void DrawInspector()
        {
            DrawGroupNamingOption();
            EditorGUILayout.Space();
            DrawUseBaseSettingsOption();
            
            if (!helper.GetPropertyByName("useBaseWorldSettings").boolValue)
                DrawManualSettingsOptions();

            DrawUsedCellsOptions();
        }

        void DrawGroupNamingOption()
        {
            helper.DrawSerializedPropertyField("groupName", groupNameLabel);
        }

        void DrawUseBaseSettingsOption()
        {
            helper.DrawSerializedPropertyField("useBaseWorldSettings", useBaseWorldSettingsLabel);
        }

        void DrawManualSettingsOptions()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Manual Settings Specified Below Will Be Used.");
            EditorGUILayout.Space();
            helper.DrawSerializedPropertyField("namingConvention");
            
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(primaryCellObjectSubControllerLabel);
            SerializedProperty primaryCellObjectSubControllerProperty = helper.GetPropertyByName("primaryCellObjectSubController");
            helper.DrawSerializedPropertyField(primaryCellObjectSubControllerProperty, GUIContent.none);
            EditorGUILayout.EndHorizontal();

            if (primaryCellObjectSubControllerProperty.objectReferenceValue == null)
                EditorGUILayout.HelpBox("A Primary Cell Object Sub Controller Component must be provided!", MessageType.Warning, true);

            DrawPositionOffsetOption();
        }

        void DrawPositionOffsetOption()
        {
            EditorGUILayout.LabelField("Offsets (Mouse Over Each Option for info)");
            EditorGUILayout.Space();

            EditorGUILayout.HelpBox("Note that the y and z offsets will only be used if the world the object group is linked to calls for them (y will be used for 2D XY and 3D worlds, z will be used for 2D XZ and 3D worlds).\n\nThe y offset is not used when the World uses Unity Terrains as its base.", MessageType.Info);

            SerializedProperty positionOffsetProperty = helper.GetPropertyByName("positionOffset");
            Vector3 positionOffset = positionOffsetProperty.vector3Value;

            float xCellOffsetPercent = EditorGUILayout.Slider(xCellOffsetPercentLabel, positionOffset.x, 0f, 1f);
            float yCellOffsetPercent = EditorGUILayout.Slider(yCellOffsetPercentLabel, positionOffset.y, 0f, 1f);
            float zCellOffsetPercent = EditorGUILayout.Slider(zCellOffsetPercentLabel, positionOffset.z, 0f, 1f);
            
            if (!Mathf.Approximately(xCellOffsetPercent, positionOffset.x)
                || !Mathf.Approximately(yCellOffsetPercent, positionOffset.y)
                || !Mathf.Approximately(zCellOffsetPercent, positionOffset.z))
            {
                positionOffsetProperty.vector3Value = new Vector3(xCellOffsetPercent, yCellOffsetPercent, zCellOffsetPercent);
            }
        }

        void DrawUsedCellsOptions()
        {
            EditorGUILayout.HelpBox("It is likely that your object group will not contain a valid object for each cell of the World it is linked to. For example, the World may have a 4 x 4 World Grid, but you only have objects in the first cell that you want to load.\n\nThe grid below is used to denote which objects/cells are present in your object group. A green square (enabled state) is used to denote a present object/cell, while a red square (disabled state) denotes a missing object/cell.\n\nClick on each cell to change its designation, or click on the row (ex: R1) button to change the desination of an entire row, or column (ex: C2) to change the designation of an entire column. The Layer button can be used to change the designation of every cell in the layer, while the All Layers button will change the designation of every cell in the grid.\n\nNote, if a World this Object Group is associated with has a World Grid with a cell that is empty (red square), then the corresponding cell of this object group will be treated as empty, regardless of how you set it here.", MessageType.Info, true);

            EditorGUILayout.HelpBox("Also note that this grid ignores whatever Naming Convention you are using, so if your actual group begins at 0 instead of 1, you will need to take that into account (simply add 1 to the row/column of your game object to get the equivalent row/column in the grid.\n\nWhen changing the Is Group 3D? setting or Layers/Rows/Columns settings, you will need to press the 'Save And Rebuild Grid' button to commit the changes and rebuild the displayed grid.", MessageType.Info, true);

            groupIs3D = EditorGUILayout.Toggle("Is Group 3D?", groupIs3D);

            if (groupIs3D)
                layers = EditorGUILayout.IntField("Layers", layers);

            rows = EditorGUILayout.IntField("Rows", rows);
            columns = EditorGUILayout.IntField("Columns", columns);

            if (GUILayout.Button("Save And Rebuild Grid"))
                SaveAndRebuildGrid();

            DisplayUsedCellArray();
        }

        void DisplayUsedCellArray()
        {
            SerializedProperty layerSelectProperty = helper.GetPropertyByName("layerSelect");
            if (helper.GetPropertyByName("groupIs3D").boolValue)
            {
                int layerSelect = EditorGUILayout.IntSlider("Layer", layerSelectProperty.intValue + 1, 1, helper.GetPropertyByName("layers").intValue) - 1;

                if (layerSelect != layerSelectProperty.intValue)
                    layerSelectProperty.intValue = layerSelect;                
            }

            if (helper.GetPropertyByName("groupIs3D").boolValue)
                DisplayArray(layerSelectProperty.intValue);
            else
                DisplayArray(0);
        }

        void DisplayArray(int layer)
        {
            GUIStyle style = new GUIStyle(GUI.skin.button);
            style.fixedHeight = 60f;
            style.fixedWidth = 60f;

            GUIStyle emptyStyle = new GUIStyle(style);
            emptyStyle.fixedHeight = 20f;
            emptyStyle.normal.background = null;
            emptyStyle.active.background = null;
            emptyStyle.normal.background = null;
            emptyStyle.normal.background = null;
            
            if (columnsProperty.intValue > 4)
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button(" ", emptyStyle))
                {

                }
                int columnSelect = (int)GUILayout.HorizontalScrollbar(columnSelectProperty.intValue, 1f, 0f, columnsProperty.intValue - 3, GUILayout.Width(252f));
                if (columnSelect != columnSelectProperty.intValue)
                    columnSelectProperty.intValue = columnSelect;
                
                EditorGUILayout.EndHorizontal();
            }
            
            int startingRow = rowSelectProperty.intValue + 3;
            if (startingRow >= rowsProperty.intValue)
                startingRow = rowsProperty.intValue - 1;

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.BeginVertical(GUILayout.Width(60f));
            for (int row = startingRow; row >= rowSelectProperty.intValue; row--)
            {
                if (GUILayout.Button(string.Format(formatStringRow, row + 1), style))
                {
                    if (IsRowAllTrue(row, layer))
                        SetRow(false, row, layer);
                    else
                        SetRow(true, row, layer);
                }
            }

            if (GUILayout.Button(layerButton, style))
            {
                if (IsLayerAllTrue(layer))
                    SetLayer(false, layer);
                else
                    SetLayer(true, layer);
            }

            EditorGUILayout.EndVertical();
            
            for (int column = columnSelectProperty.intValue; column <= columnSelectProperty.intValue + 3 && column < columnsProperty.intValue; column++)
            {
                EditorGUILayout.BeginVertical(GUILayout.Width(60f));
                for (int row = startingRow; row >= rowSelectProperty.intValue; row--)
                {
                    int index = usedCellsProperty.arraySize == 1 ? 0 : column + (row * columnsProperty.intValue) + (rowsProperty.intValue * columnsProperty.intValue * layer);

                    if (usedCellsProperty.GetArrayElementAtIndex(index).boolValue)
                    {
                        if (GUILayout.Button(enableButtonTex, style))
                        {
                            if(usedCellsProperty.arraySize == 1)
                            {
                                usedCellsProperty.ResizeBoolArrayAndSetAllValuesToSingleValue(rowsProperty.intValue * columnsProperty.intValue * layersProperty.intValue, true);

                                index = column + (row * columnsProperty.intValue) + (rowsProperty.intValue * columnsProperty.intValue * layer);

                                usedCellsProperty.GetArrayElementAtIndex(index).boolValue = false;
                            }
                            else
                            {
                                usedCellsProperty.GetArrayElementAtIndex(index).boolValue = false;
                                //check if all values are the same now that this cell was changed
                                if (usedCellsProperty.DoAllBoolValuesMatchInputVaue(false))
                                {
                                    //if they are the same, store as single value
                                    usedCellsProperty.arraySize = 1;
                                    usedCellsProperty.GetArrayElementAtIndex(0).boolValue = false;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (GUILayout.Button(disableButtonTex, style))
                        {
                            if (usedCellsProperty.arraySize == 1)
                            {
                                usedCellsProperty.ResizeBoolArrayAndSetAllValuesToSingleValue(rowsProperty.intValue * columnsProperty.intValue * layersProperty.intValue, false);
                                
                                index = column + (row * columnsProperty.intValue) + (rowsProperty.intValue * columnsProperty.intValue * layer);

                                //now just need to correct the cell that was changed
                                usedCellsProperty.GetArrayElementAtIndex(index).boolValue = true;
                            }
                            else
                            {
                                usedCellsProperty.GetArrayElementAtIndex(index).boolValue = true;
                                //check if all values are the same now that this cell was changed
                                if (usedCellsProperty.DoAllBoolValuesMatchInputVaue(true))
                                {
                                    //if they are the same, store as single value
                                    usedCellsProperty.arraySize = 1;
                                    usedCellsProperty.GetArrayElementAtIndex(0).boolValue = true;
                                }
                            }
                            
                        }
                    }
                }
                if (GUILayout.Button(string.Format(formatStringColumn, column + 1), style))
                {
                    if (IsColumnAllTrue(column, layer))
                        SetColumn(false, column, layer);
                    else
                        SetColumn(true, column, layer);
                }
                EditorGUILayout.EndVertical();

            }

            if (rowsProperty.intValue > 4)
            {
                int rowSelect = (int)GUILayout.VerticalScrollbar(rowSelectProperty.intValue, 1f, rowsProperty.intValue - 3, 0f, GUILayout.Height(249f));
                if (rowSelect != rowSelectProperty.intValue)
                    rowSelectProperty.intValue = rowSelect;
            }

            EditorGUILayout.EndHorizontal();
            if (GUILayout.Button(allLayersButton))
                SetGrid(!IsGridAllTrue());
        }
        
        void SaveAndRebuildGrid()
        {
            if (!groupIs3D)
                layers = 1;

            usedCellsProperty.RebuildBoolArrayForNewWorldDimensions(true, layers, rows, columns, layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);
            
            rowsProperty.intValue = rows;
            columnsProperty.intValue = columns;
            layersProperty.intValue = layers;
            helper.GetPropertyByName("groupIs3D").boolValue = groupIs3D;
            VerifyRowAndColumnSelect();
        }

        void VerifyRowAndColumnSelect()
        {
            int lastValidRowSelect = rowsProperty.intValue - 4;
            if (lastValidRowSelect < 0)
                lastValidRowSelect = 0;
            else if (rowSelectProperty.intValue > lastValidRowSelect)
                rowSelectProperty.intValue = lastValidRowSelect;

            int lastValidColumnSelect = columnsProperty.intValue - 4;
            if (lastValidColumnSelect < 0)
                lastValidColumnSelect = 0;
            else if (columnSelectProperty.intValue > lastValidColumnSelect)
                columnSelectProperty.intValue = lastValidColumnSelect;
        }

        void SetRow(bool value, int row, int layer)
        {
            usedCellsProperty.SetRowInBoolArray(value, row, layer, layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);
        }

        bool IsRowAllTrue(int row, int layer)
        {
            return usedCellsProperty.AreAllBoolsInRowEqualToValue(true, row, layer, rowsProperty.intValue, columnsProperty.intValue);
        }

        void SetColumn(bool value, int column, int layer)
        {
            usedCellsProperty.SetColumnInBoolArray(value, column, layer, layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);
        }

        bool IsColumnAllTrue(int column, int layer)
        {
            return usedCellsProperty.AreAllBoolsInColumnEqualToValue(true, column, layer, rowsProperty.intValue, columnsProperty.intValue);
        }

        void SetGrid(bool value)
        {
            usedCellsProperty.arraySize = 1;
            usedCellsProperty.GetArrayElementAtIndex(0).boolValue = value;
        }

        bool IsGridAllTrue()
        {
            if (usedCellsProperty.arraySize == 1 && usedCellsProperty.GetArrayElementAtIndex(0).boolValue == true)
                return true;

            for (int i = 0; i < layersProperty.intValue; i++)
            {
                if (!IsLayerAllTrue(i))
                    return false;
            }
            return true;
        }

        void SetLayer(bool value, int layer)
        {
            usedCellsProperty.SetLayerInBoolArray(value, layer, layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);
        }

        bool IsLayerAllTrue(int layer)
        {
            return usedCellsProperty.AreAllBoolsInLayerEqualToValue(true, layer, rowsProperty.intValue, columnsProperty.intValue);
        }

        GUIContent allLayersButton = new GUIContent("All Layers", "If all cells in every layer of the grid are enabled, will change all cells to a disabled state (indicating each cell is not used). Otherwise, will set all disbaled cells to enabled so that every cell in the grid is in an enabled state (indicating each cell is used [i.e. has an object]).");

        GUIContent layerButton = new GUIContent("Layer", "If all cells on the current layer are enabled, will change all the cells to a disabled state (indicating each cell is not used). Otherwise, will set all disabled cells on the layer to enabled so that every cell on the layer is in an enabled state (indicating each cell is used [i.e. has an object]).");

        GUIContent groupNameLabel = new GUIContent("Group Name*", "The base name shared by all objects in this object group, i.e., the name before the _1_1, _1_2, etc. of your objects.");

        GUIContent primaryCellObjectSubControllerLabel = new GUIContent("Primary Cell Object Sub Controller*", "The Primary Cell Object " +
            "Sub Controller component which will be used to retrieve and dispose of the cell objects from this object group.");

        GUIContent useBaseWorldSettingsLabel = new GUIContent("Use Base World Settings*", "If checked, all settings below this option will be set using whatever World this object group is linked to.\n\nIf unchecked, the settings you manually specify below will be used.\n\nNote that each object group can be linked to multiple Worlds.");

        //Offset Labels
        GUIContent xCellOffsetPercentLabel = new GUIContent("X Cell Offset %*", "The amount the objects in your cells will be offet on the X axis in relation to " +
            "the total width of your cell.\n\nFor instance, .5 (50%) will set the position of your object to the mid point (on the X axis) of your cell.\n\n" +
            "For objects who's pivot point is in the center of the object (such as the default Unity objects), this will effectively center the object in your cell.\n\n" +
            "You can leave this value at 0 if your objects pivot point is at the bottom left, and the object and cell's width is the same.\n\nPlease consult the " +
            "full guide for more information.");

        GUIContent yCellOffsetPercentLabel = new GUIContent("Y Cell Offset %*", "The amount the objects in your cells will be offet on the Y axis in relation to " +
            "the total length of your cell.\n\nFor instance, .5 (50%) will set the position of your object to the mid point (on the Y axis) of your cell.\n\n" +
            "For objects who's pivot point is in the center of the object (such as the default Unity objects), this will effectively center the object in your cell.\n\n" +
            "You can leave this value at 0 if your objects pivot point is at the bottom left, and the object and cell's length is the same.\n\nPlease consult the " +
            "full guide for more information.");

        GUIContent zCellOffsetPercentLabel = new GUIContent("Z Cell Offset %*", "The amount the objects in your cells will be offet on the Z axis in relation to " +
            "the total length of your cell.\n\nFor instance, .5 (50%) will set the position of your object to the mid point (on the Z axis) of your cell.\n\n" +
            "For objects who's pivot point is in the center of the object (such as the default Unity objects), this will effectively center the object in your cell.\n\n" +
            "You can leave this value at 0 if your objects pivot point is at the bottom left, and the object and cell's length is the same.\n\nPlease consult the " +
            "full guide for more information.");
    }
}