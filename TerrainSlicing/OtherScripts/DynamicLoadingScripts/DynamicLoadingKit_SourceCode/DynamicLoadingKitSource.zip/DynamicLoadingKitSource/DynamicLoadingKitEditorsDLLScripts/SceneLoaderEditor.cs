//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEditor;
	using UnityEngine;
	using DynamicLoadingKit;
	
	[CustomEditor(typeof(SceneLoader))]
    class SceneLoaderEditor : Editor
	{
        SceneLoaderBaseEditor baseEditor;

        public override void OnInspectorGUI()
        {
            if (baseEditor == null)
                baseEditor = new SceneLoaderBaseEditor(serializedObject);
            
            baseEditor.OnInspectorGUI();
        }
    }

    internal class SceneLoaderBaseEditor : BaseSceneLoaderBaseEditor
    {
        public SceneLoaderBaseEditor(SerializedObject serializedObject)
            : base(serializedObject) { }

		protected sealed override void DrawInspector()
		{
            EditorGUILayout.LabelField(timeToWaitBetweenLoadsLabel);
            helper.DrawSerializedPropertyField("timeToWaitBetweenLoads", timeToWaitBetweenLoadsLabel);

            base.DrawInspector();
		}

        GUIContent timeToWaitBetweenLoadsLabel = new GUIContent("Time To Wait Between Loads*", "When a cell object is loaded, the program will "
            + "wait this amount of time before initiating the next load. Increasing this value may boost performance, but will also increase the amount "
            + "of time it takes to load cell objects.\n\nExperiment to find the best value for your project.");
	}
}