﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEditor;
    using UnityEngine;
    using DynamicLoadingKit;

    internal class WorldBaseEditor : BaseEditor
    {
        RangeSettingsGUIDrawer rangeSettingsGUIDrawer;
        int numObjectGroups;
        public WorldBaseEditor(SerializedObject serializedObject) : base(serializedObject)
        {
            numObjectGroups = helper.GetPropertyByName("objectGroups").arraySize;
            rangeSettingsGUIDrawer = new RangeSettingsGUIDrawer(helper, mediumLabel);
        }

        protected sealed override void DrawInspector()
        {
            helper.DrawSerializedPropertyField("worldID", worldIDLabel);
            EditorGUILayout.Space();

            DrawObjectGroupOptions();
            EditorGUILayout.Space();

            helper.DrawSerializedPropertyField("loadCushion", loadCushionLabel);
            EditorGUILayout.Space();

            DrawEndlessOptions();
            EditorGUILayout.Space();

            DrawOriginCellOptions();
            EditorGUILayout.Space();

            DrawOriginOptions();
            DrawOriginCenteredOptions();
            EditorGUILayout.Space();

            DrawPrimaryCellObjectSubControllerOption();
            //DrawCellObjectMasterControllerCreatorOption();
            DrawWorldGridOption();

            if(!playMode)
            {
                rangeSettingsGUIDrawer.DrawGUI();
                
                EditorGUILayout.Space();
                DrawRemoveCellObjectsButton();
            }
        }

        void DrawObjectGroupOptions()
        {
            helper.DrawSerializedPropertyArrayField("objectGroups");
        }
        
        void DrawEndlessOptions()
        {
            helper.DrawSerializedPropertyField("areLayersEndless", layersEndlessLabel);
            helper.DrawSerializedPropertyField("areRowsEndless");
            helper.DrawSerializedPropertyField("areColumnsEndless");
        }

        void DrawOriginCellOptions()
        {
            EditorGUILayout.LabelField(originCellLabel);
            helper.DrawSerializedPropertyField("oneBasedOriginCellLayer", originCellLayerLabel);
            helper.DrawSerializedPropertyField("oneBasedOriginCellRow", "Row");
            helper.DrawSerializedPropertyField("oneBasedOriginCellColumn", "Column");
        }

        void DrawOriginOptions()
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(usePositionAsOrigin, extraWideLabel);
            helper.DrawSerializedPropertyField("useThisGameObjectsPositionAsWorldOrigin", GUIContent.none);
            EditorGUILayout.EndHorizontal();

            if (!helper.GetPropertyByName("useThisGameObjectsPositionAsWorldOrigin").boolValue)
                helper.DrawSerializedPropertyField("worldOrigin", "World Origin");      
        }

        void DrawOriginCenteredOptions()
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(keepWorldCenteredAroundOriginLabel, extraWideLabel);
            helper.DrawSerializedPropertyField("keepWorldCenteredAroundOrigin", GUIContent.none);
            EditorGUILayout.EndHorizontal();

            if(helper.GetPropertyByName("keepWorldCenteredAroundOrigin").boolValue)
            {
                EditorGUILayout.HelpBox("Note: If you're boundaries are too close to your World's origin, you may get some overlap of the new objects and old objects when a shift occurs, which will cause flickering. Move the boundaries farther from your world origin or try to enable the Perform Shift Activation In Single Frame option.", MessageType.Info);

                EditorGUILayout.LabelField(performShiftActivationInSingleFrameLabel1);
                helper.DrawSerializedPropertyField("performShiftActivationInSingleFrame", performShiftActivationInSingleFrameLabel2);

                EditorGUILayout.Space();
                EditorGUILayout.LabelField(boundaryDistancesLabel);

                DrawAxisBoundaryOption("West", "East", helper.GetPropertyByName("distanceOfWestBoundaryFromOrigin"), helper.GetPropertyByName("distanceOfEastAndWestShiftBoundaryFromOrigin"));

                DrawAxisBoundaryOption("South", "North", helper.GetPropertyByName("distanceOfSouthBoundaryFromOrigin"), helper.GetPropertyByName("distanceOfNorthAndSouthShiftBoundaryFromOrigin"));

                DrawAxisBoundaryOption(bottomBoundaryDistanceLabel, topBoundaryDistanceLabel, helper.GetPropertyByName("distanceOfBottomBoundaryFromOrigin"), helper.GetPropertyByName("distanceOfTopAndBottomShiftBoundaryFromOrigin"));
                
                EditorGUILayout.HelpBox("For World Shifting to occur, at least one Active Grid using the World must have it's 'Allow Grid To Force World Shifts' option enabled.", MessageType.Info);
            }
        }

        void DrawAxisBoundaryOption(string boundary1Label, string boundary2Label, SerializedProperty boundary1Property, SerializedProperty boundary2Property)
        {
            EditorGUILayout.BeginHorizontal();
            DrawBoundaryOption(boundary1Label, boundary1Property);
            DrawBoundaryOption(boundary2Label, boundary2Property);
            EditorGUILayout.EndHorizontal();
        }

        void DrawBoundaryOption(string boundaryLabel, SerializedProperty boundaryProperty)
        {
            EditorGUILayout.LabelField(boundaryLabel, smallLabel);

            float boundaryDistanceFromOrigin = EditorGUILayout.FloatField(boundaryProperty.floatValue);
            if (boundaryDistanceFromOrigin < 0f)
                boundaryDistanceFromOrigin = 0f;

            if (!Mathf.Approximately(boundaryDistanceFromOrigin, boundaryProperty.floatValue))
                boundaryProperty.floatValue = boundaryDistanceFromOrigin;
        }

        void DrawAxisBoundaryOption(GUIContent boundary1Label, GUIContent boundary2Label, SerializedProperty boundary1Property, SerializedProperty boundary2Property)
        {
            EditorGUILayout.BeginHorizontal();
            DrawBoundaryOption(boundary1Label, boundary1Property);
            DrawBoundaryOption(boundary2Label, boundary2Property);
            EditorGUILayout.EndHorizontal();
        }

        void DrawBoundaryOption(GUIContent boundaryLabel, SerializedProperty boundaryProperty)
        {
            EditorGUILayout.LabelField(boundaryLabel, smallLabel);

            float boundaryDistanceFromOrigin = EditorGUILayout.FloatField(boundaryProperty.floatValue);
            if (boundaryDistanceFromOrigin < 0f)
                boundaryDistanceFromOrigin = 0f;

            if (!Mathf.Approximately(boundaryDistanceFromOrigin, boundaryProperty.floatValue))
                boundaryProperty.floatValue = boundaryDistanceFromOrigin;
        }

        void DrawPrimaryCellObjectSubControllerOption()
        {
            EditorGUILayout.LabelField(primaryCellObjectSubControllerLabel1);
            helper.DrawSerializedPropertyField("primaryCellObjectSubController", primaryCellObjectSubControllerLabel2);

            if (helper.GetPropertyByName("primaryCellObjectSubController").objectReferenceValue == null)
                EditorGUILayout.HelpBox("A Primary Cell Object Sub Controller Component must be provided!", MessageType.Warning);
        }
        
        void DrawWorldGridOption()
        {
            helper.DrawSerializedPropertyField("worldGrid", worldGridLabel);
            
            if (helper.GetPropertyByName("worldGrid").objectReferenceValue == null)
                EditorGUILayout.HelpBox("A World Grid must be provided!", MessageType.Warning);
            else
            {
                //check to make sure world grid is initialized
                WorldGridBase worldGrid = helper.GetPropertyByName("worldGrid").objectReferenceValue as WorldGridBase;
                if(!worldGrid.DataSet)
                {
                    WorldGridBaseEditor ed = new WorldGridBaseEditor(new SerializedObject(worldGrid));
                    ed.InitializeWorldGrid();
                }
            }
        }

        void DrawRemoveCellObjectsButton()
        {
            SerializedProperty previewCellObjectsProperty = helper.GetPropertyByName("previewCellObjects");
            if (previewCellObjectsProperty.arraySize != 0)
            {
                if (GUILayout.Button("Remove Preview Objects From Scene"))
                {
                    for (int i = previewCellObjectsProperty.arraySize - 1; i >= 0; i--)
                    {
                        GameObject obj = previewCellObjectsProperty.GetArrayElementAtIndex(i).objectReferenceValue as GameObject;

                        previewCellObjectsProperty.DeleteArrayElementAtIndex(i);

                        if(obj != null)
                            Object.DestroyImmediate(obj);
                    }
                    previewCellObjectsProperty.arraySize = 0;
                }
                else
                    helper.DrawSerializedPropertyField("destroyObjectsOnPlay", "Destroy Objects on Play");
            }
        }

        GUIContent boundaryDistancesLabel = new GUIContent("Boundary Distances From Origin*", "These values dictate how far each boundary will be placed from the origin. For example, assuming an origin of x = 0 and a value of 400 for 'East', the eastern boundary will be placed at x = 400. The same 400 value for 'West' will place the western boundary at x = -400.\n\nNegative values are not allowed.\n\nWhen the player crosses a boundary, a shift in the world occurs back towards the origin. In this way, the world stays centered around the origin.");

        GUIContent bottomBoundaryDistanceLabel = new GUIContent("Bottom*", "The bottom boundary is measured on the Y Axis but is only relevant to 3D Worlds.");

         GUIContent topBoundaryDistanceLabel = new GUIContent("Top*", "The top boundary is measured on the Y Axis but is only relevant to 3D Worlds.");

        GUIContent keepWorldCenteredAroundOriginLabel = new GUIContent("Keep World Centered Around Origin*", "If checked, any Active Grids synced to this world will " +
            "monitor their associated player (as long as that Active Grid's 'AllowGridToForceWorldShifts' option is enabled) in order to detect if that player crosses a set of fixed boundaries (defined below).\n\nWhen a boundary is crossed, " + 
            "the world is shifted back towards the origin.\n\nThe primary reason for enabling this option is to avoid floating point precision errors when dealing with extremely large worlds. If this isn't a concern for you, " + 
            "leave this option disabled.");

        GUIContent eastWestBoundaryDistanceLabel = new GUIContent("Distance of East and West Boundaries from Origin", "The distance of the east and west boundary from the world origin.\n\n" + 
            "The east and west boundaries are always on the X Axis.");

        GUIContent northAndSouthBoundaryDistanceLabel = new GUIContent("Distance of North and South Boundaries from Origin", "The distance of the north and south boundaries from the world origin.\n\n" +
            "The north and south boundaries will be on the Y Axis for a 2D XY world, or on the Z Axis otherwise.");

        GUIContent layersEndlessLabel = new GUIContent("Are Layers Endless*", "Are the layers on this world endless?\n\nPlease note, this setting is only used when the " +
            "World Grid for this world has a world type of Three_Dimensional.");

        GUIContent loadCushionLabel = new GUIContent("Load Cushion*", "Once all add and remove request have been processed, the world will wait this amount of time and then check to see if " +
            "any additional add/remove requests have been sent to it.\n\nA larger value will allow other Active Grids (or custom types) to send add/remove requests to the world before the world proceeds to " +
            "it's refresh phase (where obsolete cell objects are removed and required cell objects are loaded).\n\nThis can be useful, especially when you have multiple Active Grids operating at the same time on the same World, as " +
            "it can cut down on some unecessary cell object loading and unloading (improving performance).\n\nThe larger the value, the slower the load speed, so I suggest testing different values to find the maximum " +
            "value that works with your game.\n\nAlternatively, you can set this value to 0 and no waiting will occur.");

        GUIContent originCellLabel = new GUIContent("Origin Cell*", "This is the cell that will be placed at the World's origin upon the start of your game. The origin cell will usually be Row 1, Column 1, and Layer 1 (for 3D worlds), and will not change unless the 'Keep World Centered Around Origin' option is checked.\n\nYou should only need to change these values from their default value of 1 when you have a large world that you want to stay centered around the origin and your player's position dictates that the World start at a non standard position.\n\nFor example, consider a player start position of x = 31,000, where each terrain/object on your world has a width of 10000 and the world's origin is x = 0.\n\nIdeally, the player's start position of 31,000 would result in him starting in column 4. However, 31,000 is too large a number and would cause floating point errors. By setting the Origin Cell Column to 4 and placing the player at x = 1000, you can create the same starting zone while avoiding floating point errors.");

        GUIContent originCellLayerLabel = new GUIContent("Layer*", "This value is only used for 3D worlds.");

        GUIContent performShiftActivationInSingleFrameLabel1 = new GUIContent("Perform Shift Activation", "When enabled, during a world shift the DLK will activate the new shifted world and deactivate the old unshifted world in the same frame.\n\nThis can be used to eliminate some flickering issues when the new shifted world is spawned on top of the old unshifted world.\n\nPlease note that this option forces the Cell Actions on the objects to be performed in a single frame, which may cuase performance issues. In addition, the player really needs to be moved in the same frame as the activation/deactivation in order to avoid issues, so using a Player Mover is discouraged.\n\nFinally, for this to work the objects cannot be deactivated prior to being handled by the world. This means if using a Prefab Instantiator, the prefabs must be deactivated in the editor, or if using a custom designed cell object loader, do not activate the objects yourself.\n\nNote that you can also address flickering issues during world shifts by moving your shift boundaries farther away from your world origin.");

        GUIContent performShiftActivationInSingleFrameLabel2 = new GUIContent("In Single Frame", "When enabled, during a world shift the DLK will activate the new shifted world and deactivate the old unshifted world in the same frame.\n\nThis can be used to eliminate some flickering issues when the new shifted world is spawned on top of the old unshifted world.\n\nPlease note that this option forces the Cell Actions on the objects to be performed in a single frame, which may cuase performance issues. In addition, the player really needs to be moved in the same frame as the activation/deactivation in order to avoid issues, so using a Player Mover is discouraged.\n\nYou can also address flickering issues during world shifts by moving your shift boundaries farther away from your world origin.");

        static string primaryCellObjectSubControllerLabelString = "The Primary Cell Object " +
            "Sub Controller component which will be used by this World to retrieve and dispose of cell objects.\n\nBy default there are " +
            "two types available, a non pooling and pooling version, and you are free to create your own custom sub controllers as well.";

        GUIContent primaryCellObjectSubControllerLabel1 = new GUIContent("Primary Cell", primaryCellObjectSubControllerLabelString);

        GUIContent primaryCellObjectSubControllerLabel2 = new GUIContent("Object Sub Controller*", primaryCellObjectSubControllerLabelString);

        GUIContent topAndBottomBoundaryDistanceLabel = new GUIContent("Distance of Top and Bottom Boundaries from Origin", "The distance of the north and south boundaries from the world origin.\n\n" +
            "The north and south boundaries will be on the Y Axis for a 2D XY world and on the Z Axis for any other world type.");

        GUIContent usePositionAsOrigin = new GUIContent("Use this Game Object's Position as World Origin", "When enabled, the position of whatever game object this script is attached to will be used as the World's origin.\n\nNote that this position is fixed once the game starts (i.e., changing the position of the game object will not change the origin of the World when in 'Play' mode.");

        GUIContent worldGridLabel = new GUIContent("World Grid*", "The World Grid you wish this World to represent. Right click a folder and select " +
            "Dynamic Loading Kit -> Create World Grid to create a World Grid Asset. Configure the grid in the inspector, and then ensure its data is set.\n\n" +
            "More information can be found in the Dynamic Loading Kit_Full_Guide found in TerrainSlicing/Instructions.");

        GUIContent worldIDLabel = new GUIContent("World ID*", "An int ID that should be unique to this World in this scene (there should be " +
           "no other Worlds in this scene with this ID).\n\nThis ID can be used to retrieve this World via the Component Manager.");
    }

    //@ToDo : change prefab loading to folder, and make it so you can specifiy row start, column start, rows, and columns to load
    [CustomEditor(typeof(World))]
    class WorldEditor : Editor
    {
        WorldBaseEditor baseEditor;

        public override void OnInspectorGUI()
        {
            if (baseEditor == null)
                baseEditor = new WorldBaseEditor(serializedObject);
            
            baseEditor.OnInspectorGUI();
        }

        GUIContent loadCellObjectsButtonLabel = new GUIContent("Load Cell Objects", "Load the cell object(s) into the " +
        "scene.\n\nThis loads all game object prefabs in your grid at their base position (whateve position the prefab has set in its Transform), " +
        "and will only work if you have the prefabs stored in a folder named 'Resources'.\n\n" +
        "If you make changes to these prefabs, make sure to apply them before removing the game objects!");

        GUIContent removeCellObjectsButtonLabel = new GUIContent("Remove Cell Objects", "Removes the game object(s) for each cell " +
        "from the scene. Make sure to apply prefab changes if you've edited the game objects! Changes will not be " +
        "saved if you don't! Game Objects are temporarily removed from the scene on Play (if you haven't removed them already).");
    }
}