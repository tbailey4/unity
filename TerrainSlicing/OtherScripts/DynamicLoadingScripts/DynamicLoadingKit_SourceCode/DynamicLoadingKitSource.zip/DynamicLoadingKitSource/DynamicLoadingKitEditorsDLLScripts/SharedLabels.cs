//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEngine;
	
	internal static class SharedLabels
	{
        internal static GUIContent destroyFrequencyLabel = new GUIContent("Destroy Frequency", "The amount of time (in seconds) to wait between destroying objects.\n\n" +
            "Experiment to find the best value that works for your game.");

        static string loadFromResourcesFolderString = "If you're prefabs are stored in a folder called 'Resources', you can use this option.\n\n" +
            "Otherwise, you will need to enter the folder path where the prefabs are stored.";

        internal static GUIContent loadPrefabsFromResourcesFolderLabel1 = new GUIContent("Load From", loadFromResourcesFolderString);
        internal static GUIContent loadPrefabsFromResourcesFolderLabel2 = new GUIContent("Resources Folder", loadFromResourcesFolderString);

        internal static GUIContent namingConventionLabel = new GUIContent("Naming Convention*", "A Naming Convention implemented as a scriptable object. You can create a NamingConvention asset via Assets -> Dynamic Loading Kit -> Create Naming Convention Asset.\n\nThis can be used to change the naming convention used by the Dynamic Loading Kit for various purposes. If a NamingConvention field is visible on a component or tool and no asset is provided, the default naming convention will be used (_%y_%x or _Row_Column).\n\nYou can find more information about Naming Conventions in the Quick Guides folder within your project.");

        static string prefabFolderPathString = "The folder path relative to the Assets folder where the prefabs are stored.\n\nFor instance, if they're in a folder called 'Prefabs', which is located " +
           "directly under the Assets folder, you'd just type /Prefabs.\n\nYou can right click and select Dynamic Loading Kit -> Copy Relative Folder Path to easily copy the folder's path, then use " +
           "Edit -> Paste (or Ctrl-V) to paste the path into this field.\n\nIf the folder IS valid, " +
           "any expected prefabs not found for a grid location will result in that grid being marked as EMPTY. If at least one prefab cannot be found for a given layer, row, and/or column, " +
           "the default layer height, row length, and/or column width will be used.";

        internal static GUIContent prefabFolderPathLabel1 = new GUIContent("Relative Folder Path Where", prefabFolderPathString);
        internal static GUIContent prefabFolderPathLabel2 = new GUIContent("Prefabs Are Stored", prefabFolderPathString);
	}
}