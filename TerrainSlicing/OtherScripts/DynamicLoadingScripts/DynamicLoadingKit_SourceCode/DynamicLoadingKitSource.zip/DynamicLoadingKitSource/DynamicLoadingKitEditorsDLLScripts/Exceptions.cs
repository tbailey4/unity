//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using System;

    public class EmptyWorldGridException : System.Exception
    {
        public EmptyWorldGridException() : base() { }
        public EmptyWorldGridException(string message) : base(message) { }
        public EmptyWorldGridException(string message, System.Exception inner) : base(message, inner) { }
    }

	public class InvalidCellObjectTypeException : System.Exception
	{
		public InvalidCellObjectTypeException() : base(){}
		public InvalidCellObjectTypeException(string message) : base(message){}
		public InvalidCellObjectTypeException(string message, System.Exception inner) : base(message, inner){}
	}

    public class InvalidTextAssetFormatException : System.Exception
    {
        public InvalidTextAssetFormatException() : base() { }
        public InvalidTextAssetFormatException(string message) : base(message) { }
        public InvalidTextAssetFormatException(string message, System.Exception inner) : base(message, inner) { }
    }
}