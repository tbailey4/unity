//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using System.IO;
    using UnityEngine;
    using DynamicLoadingKit;

    internal class WorldGridDataReader : IWorldGridDataRetriever
    {
        TextAsset dataFile;
        string[] linesOfData;
        int currentLine = 0;
        GridValues<int> gridDimensions;
        bool worldIs3D = false;

        internal WorldGridDataReader(TextAsset dataFile, WorldType worldType, GridValues<int> gridDimensions)
        {
            if (worldType == WorldType.Three_Dimensional)
            {
                worldIs3D = true;
                this.gridDimensions = gridDimensions;
            }
            else
            {
                worldIs3D = false;
                this.gridDimensions = new GridValues<int>(1, gridDimensions.rowValue, gridDimensions.columnValue);
            }

            this.dataFile = dataFile;
        }

        internal sealed override WorldGridSetupData RetrieveWorldGridData()
        {
            linesOfData = GetTextFromTextAsset();

            float[] layerHeights = null;
            if (worldIs3D)
            {
                layerHeights = ReadFloatDataFromTextAsset(gridDimensions.layerValue);
                ThrowExceptionIfCurrentLineIsNotWhiteSpace();
                currentLine++;
            }

            float[] rowLengths = ReadFloatDataFromTextAsset(gridDimensions.rowValue);
            ThrowExceptionIfCurrentLineIsNotWhiteSpace();
            currentLine++;

            float[] columnWidths = ReadFloatDataFromTextAsset(gridDimensions.columnValue);
            ThrowExceptionIfCurrentLineIsNotWhiteSpace();
            currentLine++;

            bool[] emptyGridLocations = ReadBooleanDataFromTextAsset(gridDimensions.layerValue * gridDimensions.rowValue * gridDimensions.columnValue);

            return new WorldGridSetupData(emptyGridLocations, layerHeights, rowLengths, columnWidths);
        }

        bool AllGridLocationsEmpty(bool[] emptyGridLocations)
        {
            return emptyGridLocations.AreAllValuesTrue();
        }

        string[] GetTextFromTextAsset()
        {
            char[] deliminator = new char[1];
            deliminator[0] = '\n';

            return dataFile.text.Split(deliminator);
        }

        float[] ReadFloatDataFromTextAsset(int linesToRead)
        {
            float[] floatData = new float[linesToRead];
            string floatString = "float";

            int nextLine = currentLine + 1;

            //If the second line of this set of data is white space, then treat the first line as if it were the value for all lines to read
            if (linesOfData[nextLine].IsWhiteSpace())
            {
                ThrowExceptionIfCurrentLineIsWhiteSpace(floatString);
                floatData.SetAllValuesToSingleValue<float>(float.Parse(linesOfData[currentLine++], System.Globalization.CultureInfo.InvariantCulture.NumberFormat));
            }
            else
            {
                for (int i = 0; i < floatData.Length; i++, currentLine++)
                {
                    ThrowExceptionIfCurrentLineIsWhiteSpace(floatString);
                    floatData[i] = float.Parse(linesOfData[currentLine], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                }
            }

            return floatData;
        }

        bool[] ReadBooleanDataFromTextAsset(int linesToRead)
        {
            bool[] booleanData = new bool[linesToRead];
            string boolString = "boolean";

            int nextLine = currentLine + 1;

            if (nextLine == linesOfData.Length || linesOfData[nextLine].IsWhiteSpace())
            {
                ThrowExceptionIfCurrentLineIsWhiteSpace(boolString);
                booleanData.SetAllValuesToSingleValue<bool>(bool.Parse(linesOfData[currentLine++]));
            }
            else
            {
                for (int i = 0; i < booleanData.Length; i++, currentLine++)
                {
                    ThrowExceptionIfCurrentLineIsWhiteSpace(boolString);
                    booleanData[i] = bool.Parse(linesOfData[currentLine]);
                }
            }

            return booleanData;
        }

        void ThrowExceptionIfCurrentLineIsNotWhiteSpace()
        {
            if (!linesOfData[currentLine].IsWhiteSpace())
                throw new InvalidTextAssetFormatException("Data Update Failed! Line " + (currentLine + 1) + "of text file should be a " +
                    "blank line, but it isn't. Check format of text asset.");
        }

        void ThrowExceptionIfCurrentLineIsWhiteSpace(string floatOrBoolString)
        {
            if (linesOfData[currentLine].IsWhiteSpace())
                throw new InvalidTextAssetFormatException(string.Format("Data Update Failed! Line {0} should have a {1} value, but is a blank line instead! Check format of text asset.", currentLine + 1, floatOrBoolString));
        }
    }
}