//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEditor;
	using UnityEngine;
	using DynamicLoadingKit;
	
	[CustomEditor(typeof(BoundaryMonitor))]
    class BoundaryMonitorEditor : Editor
	{
        SerializedProperty detectionFrequencyProperty;
		
		public override void OnInspectorGUI()
		{
            if (detectionFrequencyProperty == null)
                detectionFrequencyProperty = serializedObject.FindProperty("detectionFrequency");

            serializedObject.Update();

            if (Application.isPlaying)
            {
                EditorGUILayout.LabelField("Editing is not allowed while in play mode!");
                EditorGUILayout.PropertyField(detectionFrequencyProperty, detectionFrequencyLabel);
            }
            else
            {
                EditorGUILayout.PropertyField(detectionFrequencyProperty, detectionFrequencyLabel);
                serializedObject.ApplyModifiedProperties();
            }            
		}

        GUIContent detectionFrequencyLabel = new GUIContent("Detection Frequency*", "The amount of time (in seconds) to wait between checks to see if " +
			"the player has crossed a boundary (of any type).\n\nIf your player is frequently going to be crossing boundaries, use a smaller value. " +
			"If your terrain/object chunks are large or player walks very slowly, you can use a larger value.\n\nA value of 0 will result in a one frame yield between checks.");
	}
}