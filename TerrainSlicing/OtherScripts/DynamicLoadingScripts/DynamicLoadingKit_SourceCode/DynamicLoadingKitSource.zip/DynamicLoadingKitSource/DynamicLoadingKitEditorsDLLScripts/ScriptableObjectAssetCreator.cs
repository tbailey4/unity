﻿///Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEngine;
    using UnityEditor;
    using System.IO;

    public static class ScriptableObjectAssetCreator
    {
        public static void GenerateScriptableObjectAssetAtSelectedFolder<T>(string desiredAssetName) where T : ScriptableObject
        {
            GenerateAndRetrieveScriptableObjectAssetAtSelectedFolder<T>(desiredAssetName);
        }

        public static T GenerateAndRetrieveScriptableObjectAssetAtSelectedFolder<T>(string desiredAssetName) where T : ScriptableObject
        {
            string path = "Assets";

            foreach (UnityEngine.Object obj in Selection.GetFiltered(typeof(UnityEngine.Object), SelectionMode.Assets))
            {
                path = AssetDatabase.GetAssetPath(obj);

                if (File.Exists(path))
                    path = Path.GetDirectoryName(path);

                break;
            }

            if (path[0] == 'a')//Check to make sure the path begins with 'A' and not 'a'. Change it to 'A' if it is an 'a'.
                path = "A" + path.Substring(1, path.Length - 1);

            if (!desiredAssetName.EndsWith(".asset"))
                desiredAssetName += ".asset";

            path = path + "/" + desiredAssetName;
            path = AssetDatabase.GenerateUniqueAssetPath(path);

            AssetDatabase.CreateAsset(ScriptableObject.CreateInstance(typeof(T)), path);
            return AssetDatabase.LoadAssetAtPath(path, typeof(T)) as T;
        }
    }
}