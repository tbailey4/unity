﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEditor;
    using DynamicLoadingKit;

    [CustomEditor(typeof(ActiveGridResetter))]
    class ActiveGridResetterEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            EditorGUILayout.HelpBox("This component is now obsolete. Set the appropriate fields on the World and Active Grid components instead.", MessageType.Warning);
        }
    }
}
