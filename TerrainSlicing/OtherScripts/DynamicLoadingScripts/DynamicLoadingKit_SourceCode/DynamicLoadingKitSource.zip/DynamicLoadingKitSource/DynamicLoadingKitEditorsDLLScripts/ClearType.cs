﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEngine;

    internal interface IClearType
    {
        bool TryClearData(SerializedObjectHelper persistenDataHelper);
    }

    internal abstract class ComponentManagerClearType : IClearType
    {
        protected SerializedObjectHelper persistenDataHelper;
        protected string[] data;

        public virtual bool TryClearData(SerializedObjectHelper persistenDataHelper)
        {
            this.persistenDataHelper = persistenDataHelper;
            string componentManagerKey = persistenDataHelper.GetPropertyByName("sceneID").stringValue + "_CM_" + persistenDataHelper.GetPropertyByName("componentManagerID").intValue;
            string rawData;

            PersistentDataController persistentDataController = (PersistentDataController)persistenDataHelper.SerializedObject.targetObject;

            if (!persistentDataController.TryGetData(componentManagerKey, out rawData))
                return false;

            data = rawData.Split(';');

            if (!TryClearSpecificData())
                return false;

            if (data[0] == "X" && data[1] == "X" && data[2] == "X" && data[3] == "X")
                ((PersistentDataController)persistenDataHelper.SerializedObject.targetObject).TryDeleteData(componentManagerKey);
            else
                persistentDataController.SaveData(componentManagerKey, string.Join(";", data));

            return true;
        }

        protected virtual bool TryClearSpecificData() { return true; }

        protected void ClearAllRuntimeCreatedActiveGrids()
        {
            if (data[2] == "X")
                return;

            string[] runtimeCreatedActiveGrids = data[2].Split('/');

            for (int i = 0; i < runtimeCreatedActiveGrids.Length; i++)
            {
                string[] agData = runtimeCreatedActiveGrids[i].Split('|');
                int activeGridID = int.Parse(agData[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                string agKey = persistenDataHelper.GetPropertyByName("sceneID").stringValue + "_AG_" + activeGridID;
                ((PersistentDataController)persistenDataHelper.SerializedObject.targetObject).TryDeleteData(agKey);
            }
            data[2] = "X";
        }

        protected void ClearAllRuntimeCreatedWorlds()
        {
            data[3] = "X";
        }
    }

    //Clear Obsolete Active Grid
    internal class ClearType0 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            if (data[0] == "X")
                return true;

            string[] obsoleteActiveGrids = data[0].Split('|');

            for(int i = 0; i < obsoleteActiveGrids.Length; i++)
            {
                int activeGridID = int.Parse(obsoleteActiveGrids[i], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                if(activeGridID == persistenDataHelper.GetPropertyByName("ID").intValue)
                {
                    if (obsoleteActiveGrids.Length == 1)
                        data[0] = "X";
                    else
                        data[0] = string.Join("|", obsoleteActiveGrids.RemoveAt<string>(i));
                    return true;
                }
            }
            return false;
        }
    }

    //Clear All Obsolete Active Grids
    internal class ClearType1 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            data[0] = "X";
            return true;
        }
    }

    //Clear Obsolete World
    internal class ClearType2 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            if (data[1] == "X")
                return true;

            string[] obsoleteWorlds = data[1].Split('|');

            for (int i = 0; i < obsoleteWorlds.Length; i++)
            {
                int worldID = int.Parse(obsoleteWorlds[i], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                if (worldID == persistenDataHelper.GetPropertyByName("ID").intValue)
                {
                    if (obsoleteWorlds.Length == 1)
                        data[1] = "X";
                    else
                        data[1] = string.Join("|", obsoleteWorlds.RemoveAt<string>(i));
                    return true;
                }
            }
            return false;
        }
    }

    //Clear All Obsolete Worlds
    internal class ClearType3 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            data[1] = "X";
            return true;
        }
    }

    //Clear All Obsolete Data
    internal class ClearType4 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            data[0] = "X";
            data[1] = "X";
            return true;
        }
    }




    //Clear Runtime Created Active Grid
    internal class ClearType5 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            if (data[2] == "X")
                return true;

            string[] runtimeCreatedActiveGrids = data[2].Split('/');

            for (int i = 0; i < runtimeCreatedActiveGrids.Length; i++)
            {
                string[] agData = runtimeCreatedActiveGrids[i].Split('|');
                int activeGridID = int.Parse(agData[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                if (activeGridID == persistenDataHelper.GetPropertyByName("ID").intValue)
                {
                    string agKey = persistenDataHelper.GetPropertyByName("sceneID").stringValue + "_AG_" + activeGridID;
                    ((PersistentDataController)persistenDataHelper.SerializedObject.targetObject).TryDeleteData(agKey);

                    if (runtimeCreatedActiveGrids.Length == 1)
                        data[2] = "X";
                    else
                        data[2] = string.Join("/", runtimeCreatedActiveGrids.RemoveAt<string>(i));
                    
                    return true;
                }
            }
            return false;
        }
    }

    //Clear All Runtime Created Active Grids
    internal class ClearType6 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            ClearAllRuntimeCreatedActiveGrids();
            return true;
        }
    }

    //Clear Runtime Created World
    internal class ClearType7 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            if (data[3] == "X")
                return true;

            string[] runtimeCreatedWorlds = data[3].Split('/');

            for (int i = 0; i < runtimeCreatedWorlds.Length; i++)
            {
                string[] worldData = runtimeCreatedWorlds[i].Split('|');
                int worldID = int.Parse(worldData[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);

                if (worldID == persistenDataHelper.GetPropertyByName("ID").intValue)
                {
                    if (runtimeCreatedWorlds.Length == 1)
                        data[3] = "X";
                    else
                        data[3] = string.Join("/", runtimeCreatedWorlds.RemoveAt<string>(i));
                    return true;
                }
            }

            return false;
        }
    }

    //Clear All Runtime Created Worlds
    internal class ClearType8 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            ClearAllRuntimeCreatedWorlds();
            return true;
        }
    }

    //Clear All Runtime Created Data
    internal class ClearType9 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            ClearAllRuntimeCreatedActiveGrids();
            ClearAllRuntimeCreatedWorlds();
            return true;
        }
    }






    //Clear All Obsolete and Runtime Created Active Grid Data
    internal class ClearType10 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            data[0] = "X";
            ClearAllRuntimeCreatedActiveGrids();
            return true;
        }
    }

    //Clear All Obsolete and Runtime Created World Data
    internal class ClearType11 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            data[1] = "X";
            ClearAllRuntimeCreatedWorlds();
            return true;
        }
    }

    //Clear All Obsolete and Runtime Created Data
    internal class ClearType12 : ComponentManagerClearType
    {
        protected sealed override bool TryClearSpecificData()
        {
            data[0] = "X";
            data[1] = "X";
            ClearAllRuntimeCreatedWorlds();
            ClearAllRuntimeCreatedWorlds();
            return true;
        }
    }

    //Clear Inspector Created Active Grid Data
    internal class ClearType13 : IClearType
    {
        public bool TryClearData(SerializedObjectHelper persistenDataHelper)
        {
            string key = persistenDataHelper.GetPropertyByName("sceneID").stringValue + "_AG_" + persistenDataHelper.GetPropertyByName("ID").intValue;
            return ((PersistentDataController)persistenDataHelper.SerializedObject.targetObject).TryDeleteData(key);
        }
    }

    internal class ClearType14 : IClearType
    {
        public bool TryClearData(SerializedObjectHelper persistenDataHelper)
        {
            string key = persistenDataHelper.GetPropertyByName("sceneID").stringValue + "_W_" + persistenDataHelper.GetPropertyByName("ID").intValue;
            return ((PersistentDataController)persistenDataHelper.SerializedObject.targetObject).TryDeleteData(key);
        }
    }

    internal class ClearComponentManagerData : ComponentManagerClearType
    {
        string componentManagerKey;

        public ClearComponentManagerData(string componentManagerKey)
            : base()
        {
            this.componentManagerKey = componentManagerKey;
        }

        public override bool TryClearData(SerializedObjectHelper persistenDataHelper)
        {            
            string rawData;

            if (!((PersistentDataController)persistenDataHelper.SerializedObject.targetObject).TryGetData(componentManagerKey, out rawData))
                return false;

            data = rawData.Split(';');

            ClearAllRuntimeCreatedActiveGrids();

            ((PersistentDataController)persistenDataHelper.SerializedObject.targetObject).TryDeleteData(componentManagerKey);
            return true;
        }
    }
}