///Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEditor;
	using UnityEngine;
	using DynamicLoadingKit;

	[CustomEditor(typeof(PlayerPrefsPersistentDataController))]
    class PlayerPrefsPersistentDataControllerEditor : Editor
	{
        PersistentDataControllerEditor baseEditor;
        		
		public sealed override void OnInspectorGUI()
		{
            if (baseEditor == null)
                baseEditor = new PersistentDataControllerEditor(serializedObject);

            baseEditor.OnInspectorGUI();
		}
	}
}