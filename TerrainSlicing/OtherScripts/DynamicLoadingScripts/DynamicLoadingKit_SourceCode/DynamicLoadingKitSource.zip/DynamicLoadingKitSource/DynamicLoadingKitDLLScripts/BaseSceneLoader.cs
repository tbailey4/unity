﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;
#if !UNITY_4
    using UnityEngine.SceneManagement;
#endif

    /// <summary>
    /// The abstract Cell Object Loader class from which the <see cref="SceneLoader" href = "SceneLoader.html">SceneLoader</see> and
    /// <see cref="AsyncSceneLoader" href = "AsyncSceneLoader.html">AsyncSceneLoader</see> components derive from.
    /// <para>You can derive your own custom class from this, though you will need to ensure your scene objects are properly tagged and
    /// set to a non-visible layer. If you wish to create your own custom CellObjectLoaderUser object, you will need to have it derive from
    /// SceneLoaderUser.</para>
    /// <para>Also note that you should never have to interact directly with this component, as the methods/properties are called/used
    /// as needed by the Dynamic Loading Kit.</para>
    /// <para>
    /// Setting up your scene loader components and the scenes used with them can be a bit complicated. Please take a look at 
    /// Chapter 4, Section 3, Setting Up Scenes for the Scene Loader Components, and Chapter 4, Section 3, Configuring
    /// </para>
    /// </summary>
    /// <title>BaseSceneLoader Abstract Class</title>
    /// <category>Cell Object Loaders</category>
    /// <navigationName>BaseSceneLoader</navigationName>
    /// <fileName>BaseSceneLoader.html</fileName>
    /// <syntax>public abstract class BaseSceneLoader : <see cref = "CellObjectLoader" href = "CellObjectLoader.html">CellObjectLoader</see></syntax>
    /// 
    /// <inspector name = "Unbound Object Tag" type = "string">When you created your scenes via the Generate Scenes Tool (found under Assets -> Dynamic Loading Kit), you should have
    /// specified a special tag to apply to the objects in your scenes. This tag is used to make searching for the newly loaded
    /// scene objects more efficient, so you should ensure the tag is only used with the Dynamic Loading Kit.</inspector>
    /// 
    /// <inspector name = "Visible Layer" type = "int">After the objects from the scene are loaded and positioned correctly, they will be moved to this layer.
    /// <para>You can use any layer, as long as that layer is visible to your camera. Most likely, you will want to leave this at
    /// its default value of 0.</para></inspector>
    public abstract class BaseSceneLoader : CellObjectLoader
    {
        [SerializeField]
        internal int visibleLayer = 0;

        [SerializeField]
        internal string unboundObjectTag = "";

        [SerializeField]
        internal bool useLayerHiding = false, areScenesFixed = true;

        /// <summary>
        /// Scene objects cannot be fully loaded/initialized in a single scene; they need one frame before they actually "exist"
        /// in the scene they're loaded into. Because of this, pre loading is required, and so this property is overridden
        /// to always return true.
        /// </summary>
        /// <type>bool</type>
        public override bool IsSingleFrameAttachmentPreloadRequired { get { return true; } }

        /// <summary>
        /// Gets the Unbound Object Tag set in the inspector.
        /// </summary>
        /// <type>string</type>
        public string UnboundObjectTag { get { return unboundObjectTag; } }

        /// <summary>
        /// Gets the Visible Layer set in the inspector.
        /// </summary>
        /// <type>int</type>
        public int VisibleLayer { get { return visibleLayer; } }

        

        /// <summary>
        /// Creates a new SceneLoaderUser, which is a custom type which derives from CellObjectLoaderUser. This user object
        /// contains a <see cref="CellString" href = "CellString.html">CellString</see> and some other data used specifically by this class.
        /// </summary>
        ///  <param name="cellObjectGroup" type="ICellObjectGroup" link="ICellObjectGroup.html">
        /// The cell object group being registered.
        /// </param>
        /// <displayName id = "CreateNewUser">CreateNewUser(ICellObjectGroup)</displayName>
        /// <syntax>protected override CellObjectLoaderUser CreateNewUser(ICellObjectGroup cellObjectGroup)</syntax>
        /// <returns type = "CellObjectLoaderUser">A new user object created using the worldAssociatedWithUser as input.</returns>
        protected override CellObjectLoaderUser CreateNewUser(ICellObjectGroup cellObjectGroup)
        {
            return new SceneLoaderUser(cellObjectGroup);
        }

        /// <summary>
        /// When overridden in a derived class, loads the object specified by objectName via the scene loading method
        /// preferred by the derived class.
        /// </summary>
        /// <param name="objectName" type = "string">The name of the object/scene to load.</param>
        /// <displayName id = "LoadCellObjectIntoLevel">LoadCellObjectIntoLevel(string)</displayName>
        /// <syntax>protected abstract YieldInstruction LoadCellObjectIntoLevel(string objectName)</syntax>
        /// <returns type = "YieldInstruction" link = "http://docs.unity3d.com/ScriptReference/YieldInstruction.html">An object which
        /// inherits from YieldInstruction. Can also be null.</returns>
        protected abstract YieldInstruction LoadCellObjectIntoLevel(string objectName);

        /// <summary>
        /// Pre loads the objects needed for the input cells for the user identified by loaderID. This ensures
        /// that when <see cref="AttachCellObjectsToCellsInSingleFrame" href = "#AttachCellObjectsToCellsInSingleFrame">AttachCellObjectsToCellsInSingleFrame</see> is
        /// called in a subsequent frame, it will work properly.
        /// <para>Note that T must implement the <see cref="IAttachableWorldCell" href = "IAttachableWorldCell.html">IAttachableWorldCell</see> interface.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be pre loaded.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the pre load.</param>
        /// <displayName id = "PerformSingleFrameAttachmentPreload">PerformSingleFrameAttachmentPreload&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override void PerformSingleFrameAttachmentPreload&lt;T&gt;(List&lt;T&gt; cells, int loaderID)</syntax>
        public override void PerformSingleFrameAttachmentPreload<T>(List<T> cells, int loaderID)
        {
            CellString cellString = RegisteredUsers[loaderID].CellString;

            foreach(T cell in cells)
            {
                cellString.MatchStringToCell(cell.CellOnWorldGrid);
#if UNITY_4
            Application.LoadLevelAdditive(cellString.ToString());
#else
                SceneManager.LoadScene(cellString.ToString(), LoadSceneMode.Additive);
#endif
            }
        }


        /// <summary>
        /// Attaches the objects associated with the input cells to the cells in a single frame. Because 
        /// <see cref="IsSingleFrameAttachmentPreloadRequired" href = "#IsSingleFrameAttachmentPreloadRequired">IsSingleFrameAttachmentPreloadRequired</see> is
        /// set to return true, <see cref="PerformSingleFrameAttachmentPreload" href = "#PerformSingleFrameAttachmentPreload">PerformSingleFrameAttachmentPreload</see> 
        /// must be called in an earlier frame prior to this method being called.
        /// <para>Note that T must implement the <see cref="IAttachableWorldCell" href = "IAttachableWorldCell.html">IAttachableWorldCell</see> interface.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the attachment.</param>
        /// <displayName id = "AttachCellObjectsToCellsInSingleFrame">AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override void AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int loaderID)</syntax>
        public override void AttachCellObjectsToCellsInSingleFrame<T>(List<T> cells, int loaderID)
        {
            SceneLoaderUser user = (SceneLoaderUser)(RegisteredUsers[loaderID]);

            GameObject[] unboundCellObjects = FindAllUnboundCellObjectsInScene(user.UnboundCellObjectNames, user.UnboundCellObjectIndexes);
            CellString cellString = user.CellString;

            foreach (T cell in cells)
            {
                cellString.MatchStringToCell(cell.CellOnWorldGrid);

                int index;
                GameObject objectToBindToCell = FindCellObjectToBindToCell(cellString, unboundCellObjects, user.UnboundCellObjectNames, user.UnboundCellObjectIndexes, out index);
                user.UnboundCellObjectIndexes.RemoveAt(index);

                if(areScenesFixed)
                    cell.AttachCellObjectToCell(objectToBindToCell, true);
                else if(useLayerHiding)
                {
                    if(objectToBindToCell.layer == visibleLayer)
                    {
                        Debug.Log("You've indicated your scenes are not fixed and that you are using layer hiding, but the root object (" + objectToBindToCell.name + ") is already set to the visible layer. The player may see the objects in the scene before they are positioned correctly! If you meant for your scenes to be fixed, please enable the 'Are Scenes Fixed' option in the Scene Loader's inspector.");
                        cell.AttachCellObjectToCell(objectToBindToCell, false);
                        continue;
                    }
                    else
                    {
                        Transform objectTransform = objectToBindToCell.transform;

                        cell.AttachCellObjectToCell(objectToBindToCell, false);

                        int childCount = objectTransform.childCount;
                        if (childCount == 0)
                        {
                            objectToBindToCell.SetActive(false);
                            objectToBindToCell.layer = visibleLayer;
                        }
                            
                        else
                        {
                            //Found deactivated node
                            if (childCount == 1)
                            {
                                GameObject possibleDeactivatedNode = objectTransform.GetChild(0).gameObject;
                                if (!possibleDeactivatedNode.activeSelf)
                                {
                                    objectToBindToCell.layer = visibleLayer;
                                    objectToBindToCell.SetActive(false);
                                    possibleDeactivatedNode.SetActive(true);
                                    continue;
                                }
                            }
                            else
                            {
                                //If child count != 1 or if the only child is not a deactivated node, do this stuff
                                objectToBindToCell.SetActive(false);
                                Transform[] t = objectToBindToCell.GetComponentsInChildren<Transform>(true);
                                for (int i = 0; i < t.Length; i++)
                                    t[i].gameObject.layer = visibleLayer;
                            }                            
                        } 
                    }
                }
                else
                {
                    Transform objectTransform = objectToBindToCell.transform;

                    cell.AttachCellObjectToCell(objectToBindToCell, false);

                    int childCount = objectTransform.childCount;
                    if (childCount == 1)
                    {
                        GameObject possibleDeactivatedNode = objectTransform.GetChild(0).gameObject;
                        if (!possibleDeactivatedNode.activeSelf)
                        {
                            objectToBindToCell.SetActive(false);
                            possibleDeactivatedNode.SetActive(true);
                            continue;
                        }
                        else
                        {
                            Debug.Log("You've indicated that your scenes are not fixed and you are not using Layer Hiding, yet the child of the root object " + objectToBindToCell.name + " is not in a deactivated state. The player may see the object's in the scene before they are positioned correctly. Either mark your scenes as fixed in the Scene Loader's inspector, or add a deactivated node (see docs).");
                        }
                    }
                    else
                    {
                        Debug.Log("You've indicated that your scenes are not fixed and you are not using Layer Hiding, yet no children have been detected on the root object " + objectToBindToCell.name + ". The player may see the object's in the scene before they are positioned correctly. Either mark your scenes as fixed in the Scene Loader's inspector, or change your root object to be an empty game object (with the appropriate name/unbound object tag), parent your terrain/main mesh object to the new root object, and deactivate the terrain/mesh object. Also make sure to remove the unbound object tag from your terrain/mesh object.");
                    } 
                }                    
            }

            user.UnboundCellObjectNames.Clear();
            user.UnboundCellObjectIndexes.Clear();
            unboundCellObjects = null;
        }


        /// <summary>
        /// Loads and attaches the objects associated with the input cells to the cells over a period of frames.
        /// <para>The exact method of loading is determined by the inheriting classes implementation of
        /// <see cref="LoadCellObjectIntoLevel" href = "#LoadCellObjectIntoLevel">LoadCellObjectIntoLevel</see>.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be loaded and attached.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the load and attachment.</param>
        /// <displayName id = "AttachCellObjectsToCellsInSingleFrame">LoadAndAttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int loaderID)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> LoadAndAttachCellObjectsToCells<T>(List<T> cells, int loaderID)
        {
            SceneLoaderUser user = (SceneLoaderUser)(RegisteredUsers[loaderID]);
            CellString cellString = user.CellString;

            foreach(T cell in cells)
            {
                cellString.MatchStringToCell(cell.CellOnWorldGrid);
                YieldInstruction yieldInstruction = LoadCellObjectIntoLevel(cellString.ToString());
                if (yieldInstruction != null)
                    yield return yieldInstruction;
            }

            yield return null;

            GameObject[] unboundCellObjects = FindAllUnboundCellObjectsInScene(user.UnboundCellObjectNames, user.UnboundCellObjectIndexes);
            foreach (T cell in cells)
            {
                cellString.MatchStringToCell(cell.CellOnWorldGrid);

                int index;
                GameObject objectToBindToCell = FindCellObjectToBindToCell(cellString, unboundCellObjects, user.UnboundCellObjectNames, user.UnboundCellObjectIndexes, out index);
                user.UnboundCellObjectIndexes.RemoveAt(index);

                if (areScenesFixed)
                    cell.AttachCellObjectToCell(objectToBindToCell, true);
                else if (useLayerHiding)
                {
                    if (objectToBindToCell.layer == visibleLayer)
                    {
                        Debug.Log("You've indicated your scenes are not fixed and that you are using layer hiding, but the root object (" + objectToBindToCell.name + ") is already set to the visible layer. The player may see the objects in the scene before they are positioned correctly! If you meant for your scenes to be fixed, please enable the 'Are Scenes Fixed' option in the Scene Loader's inspector.");
                        cell.AttachCellObjectToCell(objectToBindToCell, false);
                        continue;
                    }
                    else
                    {
                        Transform objectTransform = objectToBindToCell.transform;
                        objectToBindToCell.SetActive(false);
                        cell.AttachCellObjectToCell(objectToBindToCell, false);

                        int childCount = objectTransform.childCount;
                        if (childCount == 0)
                            objectToBindToCell.layer = visibleLayer;
                        else
                        {
                            //Found deactivated node
                            if (childCount == 1)
                            {
                                GameObject possibleDeactivatedNode = objectTransform.GetChild(0).gameObject;
                                if (!possibleDeactivatedNode.activeSelf)
                                {
                                    objectToBindToCell.layer = visibleLayer;
                                    possibleDeactivatedNode.SetActive(true);
                                    goto EndYield;
                                }
                            }
                            
                            //If child count != 1 or if the only child is not a deactivated node, do this stuff
                            Transform[] t = objectToBindToCell.GetComponentsInChildren<Transform>(true);

                            int i = 0, max;
                            do
                            {
                                yield return null;
                                max = i + 30;
                                if (max > t.Length)
                                    max = t.Length;

                                for (; i < max; i++)
                                    t[i].gameObject.layer = visibleLayer;
                            }
                            while (max != t.Length);
                        }
                    }
                }
                else
                {
                    Transform objectTransform = objectToBindToCell.transform;
                    objectToBindToCell.SetActive(false);
                    cell.AttachCellObjectToCell(objectToBindToCell, false);

                    int childCount = objectTransform.childCount;
                    if (childCount == 1)
                    {
                        GameObject possibleDeactivatedNode = objectTransform.GetChild(0).gameObject;
                        if (!possibleDeactivatedNode.activeSelf)
                            possibleDeactivatedNode.SetActive(true);                        
                        else
                        {
                            Debug.Log("You've indicated that your scenes are not fixed and you are not using Layer Hiding, yet the child of the root object " + objectToBindToCell.name + " is not in a deactivated state. The player may see the object's in the scene before they are positioned correctly. Either mark your scenes as fixed in the Scene Loader's inspector, or add a deactivated node (see docs).");
                        }
                    }
                    else
                    {
                        Debug.Log("You've indicated that your scenes are not fixed and you are not using Layer Hiding, yet no children have been detected on the root object " + objectToBindToCell.name + ". The player may see the object's in the scene before they are positioned correctly. Either mark your scenes as fixed in the Scene Loader's inspector, or change your root object to be an empty game object (with the appropriate name/unbound object tag), parent your terrain/main mesh object to the new root object, and deactivate the terrain/mesh object. Also make sure to remove the unbound object tag from your terrain/mesh object.");
                    }
                }

            EndYield:
                yield return null;
            }

            user.UnboundCellObjectNames.Clear();
            user.UnboundCellObjectIndexes.Clear();
            unboundCellObjects = null;
        }
        
        GameObject[] FindAllUnboundCellObjectsInScene(List<string> unboundCellObjectNames, List<int> unboundCellObjectIndexes)
        {
            GameObject[] unboundCellObjects = GameObject.FindGameObjectsWithTag(unboundObjectTag);

            for (int i = 0; i < unboundCellObjects.Length; i++)
            {
                unboundCellObjectNames.Add(unboundCellObjects[i].name);
                unboundCellObjectIndexes.Add(i);
            }
            return unboundCellObjects;
        }

        GameObject FindCellObjectToBindToCell(CellString cellString, GameObject[] possibleUnboundCellObjects, 
            List<string> unboundCellObjectNames, List<int> unboundCellObjectIndexes, out int indexWhereObjectFound)
        {
            for (indexWhereObjectFound = 0; indexWhereObjectFound < unboundCellObjectIndexes.Count; indexWhereObjectFound++)
            {
                int index = unboundCellObjectIndexes[indexWhereObjectFound];
                if (cellString.IsEqualTo(unboundCellObjectNames[index]))
                {
                    GameObject possibleMatch = possibleUnboundCellObjects[index];
                    if (possibleMatch.CompareTag(unboundObjectTag))
                    {
                        possibleMatch.tag = "Untagged";
                        return possibleMatch;
                    }
                }
            }

            throw new UnboundCellObjectNotFoundException("The cell object named " +
                cellString.ToString() + " could not be found in the scene. Make sure it is correctly named " +
                "and appropriately tagged, and ensure you have specified the tag you are using in the Scene Loader's " +
                "Inspector.");
        }

        protected class SceneLoaderUser : CellObjectLoaderUser
        {
            public List<string> UnboundCellObjectNames { get; private set; }
            public List<int> UnboundCellObjectIndexes { get; private set; }

            public SceneLoaderUser(ICellObjectGroup cellObjectGroup)
                : base(cellObjectGroup)
            {
                UnboundCellObjectNames = new List<string>();
                UnboundCellObjectIndexes = new List<int>();
            }
        }
    }
}