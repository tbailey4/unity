﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System.Collections.Generic;

    //This comparer are only used with Terrain, so there's no need to
    //create Three Dimensional versions.
    internal class EndlessGridTwoDimensionalWorldCellComparer : EqualityComparer<WorldCellWithTerrain>
    {
        public override bool Equals(WorldCellWithTerrain cell1, WorldCellWithTerrain cell2)
        {
            return cell1.zeroBasedCellOnEndlessGrid.row == cell2.zeroBasedCellOnEndlessGrid.row && cell1.zeroBasedCellOnEndlessGrid.column == cell2.zeroBasedCellOnEndlessGrid.column;
        }

        public override int GetHashCode(WorldCellWithTerrain cell)
        {
            int hash = 23 * 31 + cell.zeroBasedCellOnEndlessGrid.row;
            hash = hash * 31 + cell.zeroBasedCellOnEndlessGrid.column;

            return hash;
        }
    }

    internal class TwoDimensionalCellComparer : EqualityComparer<Cell>
    {
        public override bool Equals(Cell cell1, Cell cell2)
        {
            return cell1.row == cell2.row && cell1.column == cell2.column;
        }

        public override int GetHashCode(Cell cell)
        {
            int hash = 23 * 31 + cell.row;
            hash = hash * 31 + cell.column;

            return hash;
        }
    }

    internal class ThreeDimensionalCellComparer : EqualityComparer<Cell>
    {
        public override bool Equals(Cell cell1, Cell cell2)
        {
            return cell1.row == cell2.row && cell1.column == cell2.column && cell1.layer == cell2.layer;
        }

        public override int GetHashCode(Cell cell)
        {
            int hash = 23 * 31 + cell.layer;
            hash = hash * 31 + cell.row;
            hash = hash * 31 + cell.column;

            return hash;
        }
    }
}