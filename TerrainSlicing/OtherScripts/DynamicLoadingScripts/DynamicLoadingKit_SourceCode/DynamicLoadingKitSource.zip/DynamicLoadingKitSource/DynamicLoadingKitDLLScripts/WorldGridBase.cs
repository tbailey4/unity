﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Provides a base implementation for World Grid's. The World Grid provided 
    /// in the DLK is simply an empty shell which derives from
    /// WorldGridBase, so you can effectively treat the WorldGrid and WorldGridBase like they are one in the same.
    /// <para>
    /// Each World Grid represents a group of objects. It stores vital information about these objects and serves as a blueprint
    /// for building <see cref="World" href="World.html">World's</see> at runtime.
    /// </para>
    /// <para>
    /// Remember to hover over option names with a * to see more information about that option. 
    /// Ensure all the options are set correctly,
    /// and then press the "Set Data" button. The data MUST be set in order for the DLk to function properly.
    /// </para>
    /// <para>
    /// Also note, Initialize should be called prior to any other methods/properties being called/accessed.
    /// </para>
    /// <para>
    /// To create a World Grid asset, right click the folder where you'd like to create it and choose 
    /// "Dynamic Loading Kit -> Create World Grid".
    /// </para>
    /// <para>
    /// Finally, note that all of the public methods that take in or return a <see cref="Cell" href="Cell.html">Cell</see> 
    /// are 0 based. This means the first 
    /// cell on the world grid or endless world grid is 0, 0, 0 rather than 1, 1, 1.
    /// </para>
    /// </summary>
    /// <title>WorldGridBase Abstract Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>WorldGridBase</navigationName>
    /// <fileName>WorldGridBase.html</fileName>
    /// <syntax>public abstract class WorldGridBase : <see href="http://docs.unity3d.com/ScriptReference/ScriptableObject.html">ScriptableObject</see></syntax>
    /// 
    /// <inspector name = "Cell Object Type" type="CellObjectType" link="CellObjectType.html">The type of the objects associated with this World Grid.</inspector>
    /// 
    /// <inspector name="Columns" type="int">The number of columns in the object group associated with this World Grid.</inspector>
    /// 
    /// <inspector name="Default Column Width" type="float">The default column width to use when setting the World Grid's data.
    /// <para>This is displayed and used only when "Method to Set Data" is set to "Set Using Default Values", or when the method is "Set Using Prefabs" and no
    /// data can be found for a particular column.</para></inspector>
    /// 
    /// <inspector name="Default Layer Height" type="float">The default layer height to use when setting the World Grid's data.
    /// <para>This is displayed and used for Three Dimensional World Types, only when "Method to Set Data" is set to "Set Using Default Values", or when the method is "Set Using Prefabs" and no
    /// data can be found for a particular layer.</para></inspector>
    /// 
    /// <inspector name="Default Row Length" type="float">The default row length to use when setting the World Grid's data.
    /// <para>This is displayed and used only when "Method to Set Data" is set to "Set Using Default Values", or when the method is "Set Using Prefabs" and no
    /// data can be found for a particular row.</para></inspector>
    /// 
    /// <inspector name = "Default Group Name" type = "string">The group name of the cell objects associated with this World Grid. For instance, if your objects are 
    /// named "Slice_1_1," "Slice_1_2_," "Slice_1_3," etc., the group name would be "Slice".</inspector>
    /// 
    /// <inspector name="Layers" type="int">The number of layers in the object group associated with this World Grid.
    /// <para>This option is only displayed when the "World Type" is set to "Three Dimensional".</para></inspector>
    /// 
    /// <inspector name="Method to Set Data" type="string">The method to use to set the World Grid's data.
    /// <para>There are three options; select and hover over each option in the inspector to see more information about them.</para></inspector>
    /// 
    /// <inspector name="Naming Convention" type="NamingConvention" link="NamingConvention.html">
    /// The Naming Convention that describes the objects in this World's group. If no naming convention is provided, the default naming 
    /// convention of GroupName_Row_Column (or GroupName_Layer_Row_Column) will be used.
    /// </inspector>
    /// 
    /// <inspector name="Rows" type="int">The number of rows in the object group associated with this World Grid.</inspector>
    /// 
    /// <inspector name="Text Asset With Data" type="TextAsset" link="http://docs.unity3d.com/ScriptReference/TextAsset.html">
    /// The TextAsset that should be used to set this World Grid's data.<para>Only displayed when "Method to Set Data" is set to
    /// "Set Using Text Asset".</para></inspector>
    /// 
    /// <inspector name="World Type" type="WorldType" link="WorldType.html">The type of world formed by the objects associated with this World Grid.</inspector>
    /// 
    /// <inspector name="X Cell Offset %" type="float">The amount your objects will be offset on the X axis in relation to the total width of your cells.
    /// <para>This option is only displayed and used after you set your Grid's data, and only if your "Cell Object Type" is not "Unity Terrains".
    /// </para><para>This is mainly useful for centering objects which are smaller than the cells they are contained within. 
    /// If your objects and cells dimensions along the X axis are the same, you do not need to worry about setting this value</para></inspector>
    /// 
    /// <inspector name="Y Cell Offset %" type="float">The amount your objects will be offset on the Y axis in relation to the total length/height of your cells.
    /// <para>This option is only displayed and used after you set your Grid's data, and only if your "Cell Object Type" is not "Unity Terrains".
    /// </para><para>This is mainly useful for centering objects which are smaller than the cells they are contained within. 
    /// If your objects and cells dimensions along the Y axis are the same, you do not need to worry about setting this value</para></inspector>
    /// 
    /// <inspector name="Z Cell Offset %" type="float">The amount your objects will be offset on the Z axis in relation to the total length of your cells.
    /// <para>This option is only displayed and used after you set your Grid's data, and only if your "Cell Object Type" is not "Unity Terrains".
    /// </para><para>This is mainly useful for centering objects which are smaller than the cells they are contained within. 
    /// If your objects and cells dimensions along the Z axis are the same, you do not need to worry about setting this value</para></inspector>
    public abstract class WorldGridBase : ScriptableObject
    {
        #region Fields

        //These fields are set in the inspector and used at runtime
        [SerializeField]
        internal string gridName = "Slice";

        [SerializeField]
        internal int columns = 4, rows = 4, layers = 1, dataSetMethod, columnSelect, rowSelect, layerSelect, indexToSet = 1, newDataSetOptionsChoice = 6;

        [SerializeField]
        internal CellObjectType cellObjectType = CellObjectType.Unity_Terrain;

        [SerializeField]
        internal float[] rowLengths, columnWidths, layerHeights;

        [SerializeField]
        internal bool[] emptyGridLocations;

        [SerializeField]
        internal WorldType worldType = WorldType.Two_Dimensional_On_XZ_Axes;
        
        [SerializeField]
        internal TextAsset assetWithData;

        [SerializeField]
        internal string folderPathWherePrefabsAreStored = "/";

        [SerializeField]
        internal bool loadPrefabsFromResourcesFolder = true, showGridHelpFoldout = true, showNewDataSetFoldout = true, showOldDataSetFoldout;

        [SerializeField]
        internal NamingConvention namingConvention;

        [SerializeField]
        internal float defaultColumnWidth = 500f, defaultRowLength = 500f, defaultLayerHeight = 500f, setValue = 500f;

        [SerializeField]
        internal Vector3 positionOffset;

        //Other Fields
        float height, length, width;
        int cellsOnEachLayer;

        ColumnInfoCalculator columnInfoCalculator;
        LayerInfoCalculator layerInfoCalculator;
        RowInfoCalculator rowInfoCalculator;

        Func<Cell, bool> IsCellEmpty, IsCellEmpty_ZeroBased;
        #endregion

        #region Initialization Methods

        /// <summary>
        /// Initializes the World Grid. Must be called once before other methods can be called.
        /// </summary>
        /// <displayName id="Initialize">Initialize()</displayName>
        /// <syntax>public void Initialize()</syntax>
        /// <exception name="WorldGridNotSetException" link="WorldGridNotSetException.html">Thrown when the World Grid's data has not been set prior (in the inspector)
        /// to this method being called.</exception>
        public void Initialize()
        {
            //Initialize has already been called - do not allow it to run again
            if (IsInitialized)
                return;

            if (!DataSet)
                throw new WorldGridNotSetException("World Grid Data for World Grid with Grid Name '" + gridName + "' is not set!");

            if (cellObjectType == CellObjectType.Unity_Terrain)
                positionOffset = new Vector3(0f, 0f, 0f);

            cellsOnEachLayer = rows * columns;

            ConstructIsCellEmptyFunction();
            SetData();

            CreateOffsetCalculator();
        }

        void ConstructIsCellEmptyFunction()
        {
            if (!DoEmptyGridLocationsExist())
            {
                IsCellEmpty = cellOnWorldGrid => false;
                IsCellEmpty_ZeroBased = cellOnWorldGrid => false;
            }
            else if (worldType == WorldType.Three_Dimensional)
            {
                IsCellEmpty_ZeroBased = cellOnWorldGrid => emptyGridLocations[(cellOnWorldGrid.row * columns + cellOnWorldGrid.column) + (cellsOnEachLayer * cellOnWorldGrid.layer)];

                IsCellEmpty = cellOnWorldGrid => emptyGridLocations[((cellOnWorldGrid.row - 1) * columns + (cellOnWorldGrid.column - 1)) + (cellsOnEachLayer * (cellOnWorldGrid.layer - 1))];
            }
            else
            {
                IsCellEmpty_ZeroBased = cellOnWorldGrid => emptyGridLocations[cellOnWorldGrid.row * columns + cellOnWorldGrid.column];
                IsCellEmpty = cellOnWorldGrid => emptyGridLocations[(cellOnWorldGrid.row - 1) * columns + (cellOnWorldGrid.column - 1)];
            }
        }

        void SetData()
        {
            SetWorldGridLayerData();
            SetWorldGridRowData();
            SetWorldGridColumnData();
        }

        void SetWorldGridLayerData()
        {
            if (worldType == WorldType.Three_Dimensional)
            {
                if (layerHeights.AreAllValuesTheSame())
                {
                    float heightOfEveryLayer = layerHeights[0];
                    layerHeights = new float[1] { heightOfEveryLayer };
                }

                if (layerHeights.Length == 1)
                {
                    height = layerHeights[0] * layers;
                    layerInfoCalculator = new EqualHeightLayerInfoCalculator(this);
                }
                else
                {
                    height = layerHeights.ComputeSum();
                    layerInfoCalculator = new RegularLayerInfoCalculator(this);
                }
            }
            else
            {
                layerInfoCalculator = new NullLayerInfoCalculator(this);
                layerHeights = null;
                height = 0f;
                layers = 1;
            }
        }

        void SetWorldGridRowData()
        {
            if (rowLengths.AreAllValuesTheSame())
            {
                float heightOfEveryRow = rowLengths[0];
                rowLengths = new float[1] { heightOfEveryRow };
            }

            if (rowLengths.Length == 1)
            {
                length = rowLengths[0] * rows;
                rowInfoCalculator = new EqualLengthRowInfoCalculator(this);
            }
            else
            {
                length = rowLengths.ComputeSum();
                rowInfoCalculator = new RegularRowInfoCalculator(this);
            }
        }

        void SetWorldGridColumnData()
        {
            if (columnWidths.AreAllValuesTheSame())
            {
                float heightOfEveryColumn = columnWidths[0];
                columnWidths = new float[1] { heightOfEveryColumn };
            }

            if (columnWidths.Length == 1)
            {
                width = columnWidths[0] * columns;
                columnInfoCalculator = new EqualWidthColumnInfoCalculator(this);
            }
            else
            {
                width = columnWidths.ComputeSum();
                columnInfoCalculator = new RegularColumnInfoCalculator(this);
            }
        }

        bool DoEmptyGridLocationsExist()
        {
            for (int i = 0; i < emptyGridLocations.Length; i++)
            {
                if (emptyGridLocations[i])//If an empty grid location is found (set to true)
                    return true;//Indicates at least one empty grid location exist
            }
            return false; //Indicates no empty grid locations exist
        }

        void CreateOffsetCalculator()
        {
            OffsetCalculator = OffsetCalculatorCreator.CreateOffsetCalculator(worldType, positionOffset);
        }

        #endregion

        # region Properties
        /// <summary>
        /// Gets the Cell Object Type of the objects associated with the World Grid.
        /// </summary>
        /// <type link="CellObjectType.html">CellObjectType</type>
        public CellObjectType CellObjectType { get { return cellObjectType; } }

        /// <summary>
        /// Gets the number of columns on the World Grid.
        /// </summary>
        /// <type>int</type>
        public int Columns { get { return columns; } }

        /// <summary>
        /// Gets a value indicating whether the World Grid's data has been set (in the inspector).
        /// </summary>
        /// <type>bool</type>
        public bool DataSet { get { return emptyGridLocations != null && rowLengths != null && columnWidths != null && (WorldType != WorldType.Three_Dimensional || layerHeights != null) && (rangeTemplates != null && rangeTemplates.Count != 0); } }

        /// <summary>
        /// Gets the default group name of this World Grid. This is the name assigned in the inspector. 
        /// If you wish to load alternate versions of your objects, you can change the World's Group name via the 
        /// <see cref="World.ChangeGroupName" href="World.html#ChangeGroupName">ChangeGroupName</see> method.
        /// </summary>
        /// <type>string</type>
        public string GroupName { get { return gridName; } }

        /// <summary>
        /// Gets the height of the World Grid, which is the distance between the beginning of the first layer and end of the last layer.
        /// <para>Will always be 0 if the World Type is not Three Dimensional</para>
        /// </summary>
        /// <type>float</type>
        public float Height { get { return height; } }

        /// <summary>
        /// Gets a value indicating if the World Grid is initialized.
        /// </summary>
        /// <type>bool</type>
        public bool IsInitialized { get { return IsCellEmpty != null; } }

        /// <summary>
        /// Gets the number of layers on the World Grid. Will be 1 if the World Type is not Three Dimensional.
        /// </summary>
        /// <type>int</type>
        public int Layers { get { return layers; } }

        /// <summary>
        /// Gets the length of the World Grid, which is the distance between the beginning of the first row and end of the last row.
        /// </summary>
        /// <type>float</type>
        public float Length { get { return length; } }

        /// <summary>
        /// Gets the x, y, and z position offsets of the World Grid.
        /// </summary>
        /// <type>Vector3</type>
        public Vector3 PositionOffset { get { return positionOffset; } }

        /// <summary>
        /// Gets the number of rows on the World Grid.
        /// </summary>
        /// <type>int</type>
        public int Rows { get { return rows; } }

        /// <summary>
        /// Gets the width of the World Grid, which is the distance between the beginning of the first column and end of the last column.
        /// </summary>
        /// <type>float</type>
        public float Width { get { return width; } }

        /// <summary>
        /// Gets the World Type of the World Grid.
        /// </summary>
        /// <type link="WorldType.html">WorldType</type>
        public WorldType WorldType      { get { return worldType; } }

        internal float HeightOfFirstLayer { get { return layerHeights[0]; } }
        internal float LengthOfFirstRow { get { return rowLengths[0]; } }
        internal float WidthOfFirstColumn { get { return columnWidths[0]; } }

        bool IsWorldGrid3D { get { return worldType == WorldType.Three_Dimensional; } }
        
        internal IOffsetCalculator OffsetCalculator { get; private set; }
        #endregion

        #region Public Runtime Methods


        /// <summary>
        /// Gets a Function that can be used to check if a given world grid cell is empty. It will be empty if an object
        /// is not associated with that cell.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <returns type="Func&lt;Cell, bool&gt;">
        /// A function that can be used to determine if a cell on the world grid is empty (has an object associated with it.
        /// </returns>
        /// <displayName id="GetIsWorldGridCellEmptyFunction">GetIsWorldGridCellEmptyFunction()</displayName>
        /// <syntax>public Func&lt;Cell, bool&gt; GetIsWorldGridCellEmptyFunction()</syntax>
        public Func<Cell, bool> GetIsWorldGridCellEmptyFunction()
        {
            Initialize();
            return IsCellEmpty;
        }

        internal Func<Cell, bool> GetIsWorldGridCellEmptyFunction_ZeroBased()
        {
            Initialize();
            return IsCellEmpty_ZeroBased;
        }


        /// <summary>
        /// Get the length of a world grid row. The input worldGridRow should be 0 index based. 
        /// For instance, to get the length of the very first row
        /// in the grid, you would pass in 0, not 1. To get the second row, you'd pass in 1, not 2, and so on.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="worldGridRow" type="float">The row who's length should be retrieved.</param>
        /// <displayName id="GetLengthOfWorldGridRow">GetLengthOfWorldGridRow(int)</displayName>
        /// <syntax>public float GetLengthOfWorldGridRow(int worldGridRow)</syntax>
        /// <returns type="float">The length of the input worldGridRow.</returns>
        public float GetLengthOfWorldGridRow(int worldGridRow)
        {
            Initialize();
            return rowInfoCalculator.GetLengthOfWorldGridRow_ZeroBased(worldGridRow - 1);
        }

        internal float GetLengthOfWorldGridRow_ZeroBased(int worldGridRow)
        {
            Initialize();
            return rowInfoCalculator.GetLengthOfWorldGridRow_ZeroBased(worldGridRow);
        }

        /// <summary>
        /// Get the length of an endless grid row. Each input endless grid row is translated
        /// to its equivalent world grid row, and then the length of that world grid row is returned.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="endlessGridRow" type="float">The row who's length should be retrieved.</param>
        /// <displayName id="GetLengthOfEndlessGridRow">GetLengthOfEndlessGridRow(int)</displayName>
        /// <syntax>public float GetLengthOfEndlessGridRow(int endlessGridRow)</syntax>
        /// <returns type="float">The length of the input endlessGridRow.</returns>
        public float GetLengthOfEndlessGridRow(int endlessGridRow)
        {
            Initialize();
            return rowInfoCalculator.GetLengthOfEndlessGridRow_ZeroBased(endlessGridRow - 1);
        }

        internal float GetLengthOfEndlessGridRow_ZeroBased(int endlessGridRow)
        {
            Initialize();
            return rowInfoCalculator.GetLengthOfEndlessGridRow_ZeroBased(endlessGridRow);
        }

        /// <summary>
        /// Gets the position of a row on a theoretically endless grid. Note that the World Grid knows nothing about 
        /// positioning in World Space, so for this method to work you you must pass in the current origin cell row of your world and 
        /// the position of that origin cell row. If using this with a World component, the origin cell row can be queried 
        /// via the World's OriginCell property, while the position can be queried via the OriginRowPosition property.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="endlessGridRow" type="int">The row whose position you wish to get.</param>
        /// <param name="originCellRow" type="int">The origin cell row of your World.</param>
        /// <param name="originCellRowPosition" type="float">The origin cell row position of your World.</param>
        /// <displayName id="GetPositionOfEndlessGridRow">GetPositionOfEndlessGridRow(int, int, float)</displayName>
        /// <syntax>public float GetPositionOfEndlessGridRow(int endlessGridRow, int originCellRow, float originCellRowPosition)</syntax>
        /// <returns type="flaot">The position of the endless grid row.</returns>
        public float GetPositionOfEndlessGridRow(int endlessGridRow, int originCellRow, float originCellRowPosition)
        {
            Initialize();
            return rowInfoCalculator.GetPositionOfEndlessGridRow_ZeroBased(endlessGridRow - 1, originCellRow - 1, originCellRowPosition);
        }

        internal float GetPositionOfEndlessGridRow_ZeroBased(int endlessGridRow, int originCellRow, float originCellRowPosition)
        {
            Initialize();
            return rowInfoCalculator.GetPositionOfEndlessGridRow_ZeroBased(endlessGridRow, originCellRow, originCellRowPosition);
        }

        /// <summary>
        /// Finds the endless grid row that a point in world space falls within.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="point" type="float">The point that will be used to find the endless grid row.</param>
        /// <param name="originCellRow" type="int">The origin cell row of your World.</param>
        /// <param name="originCellRowPosition" type="float">The origin cell row position of your World.</param>
        /// <displayName id="FindEndlessGridRowPointIsIn1">FindEndlessGridRowPointIsIn(float, int, float)</displayName>
        /// <syntax>public int FindEndlessGridRowPointIsIn(float point, int originCellRow, float originCellRowPosition)</syntax>
        /// <returns type="int">The endless grid row that the point is in.</returns>
        public int FindEndlessGridRowPointIsIn(float point, int originCellRow, float originCellRowPosition)
        {
            Initialize();
            return rowInfoCalculator.FindEndlessGridRowPointIsIn_ZeroBased(point, originCellRow - 1, originCellRowPosition) + 1;
        }

        internal int FindEndlessGridRowPointIsIn_ZeroBased(float point, int originCellRow, float originCellRowPosition)
        {
            Initialize();
            return rowInfoCalculator.FindEndlessGridRowPointIsIn_ZeroBased(point, originCellRow, originCellRowPosition);
        }

        /// <summary>
        /// Finds the endless grid row that a point in world space falls within.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="point" type="float">The point that will be used to find the endless grid row.</param>
        /// <param name="originCellRow" type="int">The origin cell row of your World.</param>
        /// <param name="originCellRowPosition" type="float">The origin cell row position of your World.</param>
        /// <param name="rowDisplacementFromOrigin" type="out float">An additional out parameter that meausres the displacement of the 
        /// found endless grid row to the origin cell's row.</param>
        /// <displayName id="FindEndlessGridRowPointIsIn2">FindEndlessGridRowPointIsIn(float, int, float, out float)</displayName>
        /// <syntax>public int FindEndlessGridRowPointIsIn(float point, int originCellRow, float originCellRowPosition, out float rowDistanceFromOrigin)</syntax>
        /// <returns type="int">The endless grid row that the point is in.</returns>
        public int FindEndlessGridRowPointIsIn(float point, int originCellRow, float originCellRowPosition, out float rowDisplacementFromOrigin)
        {
            Initialize();
            return rowInfoCalculator.FindEndlessGridRowPointIsIn_ZeroBased(point, originCellRow - 1, originCellRowPosition, out rowDisplacementFromOrigin) + 1;
        }

        internal int FindEndlessGridRowPointIsIn_ZeroBased(float point, int originCellRow, float originCellRowPosition, out float rowDisplacementFromOrigin)
        {
            Initialize();
            return rowInfoCalculator.FindEndlessGridRowPointIsIn_ZeroBased(point, originCellRow, originCellRowPosition, out rowDisplacementFromOrigin);
        }

        /// <summary>
        /// Converts an endless grid row to a row on the World Grid.
        /// </summary>
        /// <param name="endlessGridRow" type="int">The endless grid row to convert.</param>
        /// <displayName id="ConvertEndlessGridRowToWorldGridRow">ConvertEndlessGridRowToWorldGridRow(int)</displayName>
        /// <syntax>public int ConvertEndlessGridRowToWorldGridRow(int endlessGridRow)</syntax>
        /// <returns type="int">The row on the World Grid</returns>
        public int ConvertEndlessGridRowToWorldGridRow(int endlessGridRow)
        {
            return EndlessToWorldIndex(endlessGridRow - 1, rows) + 1;
        }

        internal int ConvertEndlessGridRowToWorldGridRow_ZeroBased(int endlessGridRow)
        {
            return EndlessToWorldIndex(endlessGridRow, rows);
        }



        /// <summary>
        /// Get the width of a world grid column. The input worldGridColumn should be 0 index based. 
        /// For instance, to get the width of the very first column
        /// in the grid, you would pass in 0, not 1. To get the second column, you'd pass in 1, not 2, and so on.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="worldGridColumn" type="float">The column who's width should be retrieved.</param>
        /// <displayName id="GetWidthOfWorldGridColumn">GetWidthOfWorldGridColumn(int)</displayName>
        /// <syntax>public float GetWidthOfWorldGridColumn(int worldGridColumn)</syntax>
        /// <returns type="float">The width of the input worldGridColumn.</returns>
        public float GetWidthOfWorldGridColumn(int worldGridColumn)
        {
            Initialize();
            return columnInfoCalculator.GetWidthOfWorldGridColumn_ZeroBased(worldGridColumn - 1);
        }

        internal float GetWidthOfWorldGridColumn_ZeroBased(int worldGridColumn)
        {
            Initialize();
            return columnInfoCalculator.GetWidthOfWorldGridColumn_ZeroBased(worldGridColumn);
        }

        /// <summary>
        /// Get the width of an endless grid column. Each input endless grid column is translated
        /// to its equivalent world grid column, and then the width of that world grid column is returned.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="endlessGridColumn" type="float">The column who's width should be retrieved.</param>
        /// <displayName id="GetWidthOfEndlessGridColumn">GetWidthOfEndlessGridColumn(int)</displayName>
        /// <syntax>public float GetWidthOfEndlessGridColumn(int endlessGridColumn)</syntax>
        /// <returns type="float">The width of the input endlessGridColumn.</returns>
        public float GetWidthOfEndlessGridColumn(int endlessGridColumn)
        {
            Initialize();
            return columnInfoCalculator.GetWidthOfEndlessGridColumn_ZeroBased(endlessGridColumn - 1);
        }

        internal float GetWidthOfEndlessGridColumn_ZeroBased(int endlessGridColumn)
        {
            Initialize();
            return columnInfoCalculator.GetWidthOfEndlessGridColumn_ZeroBased(endlessGridColumn);
        }

        /// <summary>
        /// Gets the position of a column on a theoretically endless grid. Note that the World Grid knows nothing about 
        /// positioning in World Space, so for this method to work you you must pass in the current origin 
        /// cell column of your world and 
        /// the position of that origin cell column. If using this with a World component, the origin cell column can be queried 
        /// via the World's OriginCell property, while the position can be queried via the OriginColumnPosition property.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="endlessGridColumn" type="int">The column whose position you wish to get.</param>
        /// <param name="originCellColumn" type="int">The origin cell column of your World.</param>
        /// <param name="originCellColumnPosition" type="float">The origin cell column position of your World.</param>
        /// <displayName id="GetPositionOfEndlessGridColumn">GetPositionOfEndlessGridColumn(int, int, float)</displayName>
        /// <syntax>public float GetPositionOfEndlessGridColumn(int endlessGridColumn, int originCellColumn, float originCellColumnPosition))</syntax>
        /// <returns type="flaot">The position of the endless grid column.</returns>
        public float GetPositionOfEndlessGridColumn(int endlessGridColumn, int originCellColumn, float originCellColumnPosition)
        {
            Initialize();
            return columnInfoCalculator.GetPositionOfEndlessGridColumn_ZeroBased(endlessGridColumn - 1, originCellColumn - 1, originCellColumnPosition);
        }

        internal float GetPositionOfEndlessGridColumn_ZeroBased(int endlessGridColumn, int originCellColumn, float originCellColumnPosition)
        {
            Initialize();
            return columnInfoCalculator.GetPositionOfEndlessGridColumn_ZeroBased(endlessGridColumn, originCellColumn, originCellColumnPosition);
        }

        /// <summary>
        /// Finds the endless grid column that a point in world space falls within.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="point" type="float">The point that will be used to find the endless grid column.</param>
        /// <param name="originCellColumn" type="int">The origin cell column of your World.</param>
        /// <param name="originCellColumnPosition" type="float">The origin cell column position of your World.</param>
        /// <displayName id="FindEndlessGridColumnPointIsIn1">FindEndlessGridColumnPointIsIn(float, int, float)</displayName>
        /// <syntax>public int FindEndlessGridColumnPointIsIn(float point, int originCellColumn, float originCellColumnPosition)</syntax>
        /// <returns type="int">The endless grid column that the point is in.</returns>
        public int FindEndlessGridColumnPointIsIn(float point, int originCellColumn, float originCellColumnPosition)
        {
            Initialize();
            return columnInfoCalculator.FindEndlessGridColumnPointIsIn_ZeroBased(point, originCellColumn - 1, originCellColumnPosition) + 1;
        }

        internal int FindEndlessGridColumnPointIsIn_ZeroBased(float point, int originCellColumn, float originCellColumnPosition)
        {
            Initialize();
            return columnInfoCalculator.FindEndlessGridColumnPointIsIn_ZeroBased(point, originCellColumn, originCellColumnPosition);
        }

        /// <summary>
        /// Finds the endless grid column that a point in world space falls within.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="point" type="float">The point that will be used to find the endless grid column.</param>
        /// <param name="originCellColumn" type="int">The origin cell column of your World.</param>
        /// <param name="originCellColumnPosition" type="float">The origin cell column position of your World.</param>
        /// <param name="columnDisplacementFromOrigin" type="out float">An additional out parameter that meausres the displacement of the 
        /// found endless grid column to the origin cell's column.</param>
        /// <displayName id="FindEndlessGridColumnPointIsIn2">FindEndlessGridColumnPointIsIn(float, int, float, out float)</displayName>
        /// <syntax>public int FindEndlessGridColumnPointIsIn(float point, int originCellColumn, float originCellColumnPosition, out float columnDistanceFromOrigin)</syntax>
        /// <returns type="int">The endless grid column that the point is in.</returns>
        public int FindEndlessGridColumnPointIsIn(float point, int originCellColumn, float originCellColumnPosition, out float columnDisplacementFromOrigin)
        {
            Initialize();
            return columnInfoCalculator.FindEndlessGridColumnPointIsIn_ZeroBased(point, originCellColumn - 1, originCellColumnPosition, out columnDisplacementFromOrigin) + 1;
        }

        internal int FindEndlessGridColumnPointIsIn_ZeroBased(float point, int originCellColumn, float originCellColumnPosition, out float columnDisplacementFromOrigin)
        {
            Initialize();
            return columnInfoCalculator.FindEndlessGridColumnPointIsIn_ZeroBased(point, originCellColumn, originCellColumnPosition, out columnDisplacementFromOrigin);
        }

        /// <summary>
        /// Converts an endless grid column to a column on the World Grid.
        /// </summary>
        /// <param name="endlessGridColumn" type="int">The endless grid column to convert.</param>
        /// <displayName id="ConvertEndlessGridColumnToWorldGridColumn">ConvertEndlessGridColumnToWorldGridColumn(int)</displayName>
        /// <syntax>public int ConvertEndlessGridColumnToWorldGridColumn(int endlessGridColumn)</syntax>
        /// <returns type="int">The column on the World Grid</returns>
        public int ConvertEndlessGridColumnToWorldGridColumn(int endlessGridColumn)
        {
            return EndlessToWorldIndex(endlessGridColumn - 1, columns) + 1;
        }

        internal int ConvertEndlessGridColumnToWorldGridColumn_ZeroBased(int endlessGridColumn)
        {
            return EndlessToWorldIndex(endlessGridColumn, columns);
        }

        /// <summary>
        /// Get the height of a world grid layer. The input worldGridLayer should be 0 index based. For instance, to get the 
        /// height of the very first layer
        /// in the grid, you would pass in 0, not 1. To get the second layer, you'd pass in 1, not 2, and so on.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="worldGridLayer" type="float">The layer who's height should be retrieved.</param>
        /// <displayName id="GetHeightOfWorldGridLayer">GetHeightOfWorldGridLayer(int)</displayName>
        /// <syntax>public float GetHeightOfWorldGridLayer(int worldGridLayer)</syntax>
        /// <returns type="float">The height of the input worldGridLayer.</returns>
        public float GetHeightOfWorldGridLayer(int worldGridLayer)
        {
            Initialize();
            return layerInfoCalculator.GetHeightOfWorldGridLayer_ZeroBased(worldGridLayer - 1);
        }

        internal float GetHeightOfWorldGridLayer_ZeroBased(int worldGridLayer)
        {
            Initialize();
            return layerInfoCalculator.GetHeightOfWorldGridLayer_ZeroBased(worldGridLayer);
        }

        /// <summary>
        /// Get the height of an endless grid layer. Each input endless grid layer is translated
        /// to its equivalent world grid layer, and then the height of that world grid layer is returned.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="endlessGridLayer" type="float">The layer who's height should be retrieved.</param>
        /// <displayName id="GetHeightOfEndlessGridLayer">GetHeightOfEndlessGridLayer(int)</displayName>
        /// <syntax>public float GetHeightOfEndlessGridLayer(int endlessGridLayer)</syntax>
        /// <returns type="float">The height of the input endlessGridLayer.</returns>
        public float GetHeightOfEndlessGridLayer(int endlessGridLayer)
        {
            Initialize();
            return layerInfoCalculator.GetHeightOfEndlessGridLayer_ZeroBased(endlessGridLayer - 1);
        }

        internal float GetHeightOfEndlessGridLayer_ZeroBased(int endlessGridLayer)
        {
            Initialize();
            return layerInfoCalculator.GetHeightOfEndlessGridLayer_ZeroBased(endlessGridLayer);
        }

        /// <summary>
        /// Gets the position of a layer on a theoretically endless grid. Note that the World Grid knows nothing about 
        /// positioning in World Space, so for this method to work you you must pass in the current origin cell layer of your world and 
        /// the position of that origin cell layer. If using this with a World component, the origin cell layer can be queried 
        /// via the World's OriginCell property, while the position can be queried via the OriginLayerPosition property.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="endlessGridLayer" type="int">The layer whose position you wish to get.</param>
        /// <param name="originCellLayer" type="int">The origin cell layer of your World.</param>
        /// <param name="originCellLayerPosition" type="float">The origin cell layer position of your World.</param>
        /// <displayName id="GetPositionOfEndlessGridLayer">GetPositionOfEndlessGridLayer(int, int, float)</displayName>
        /// <syntax>public float GetPositionOfEndlessGridLayer(int endlessGridLayer, int originCellLayer, float originCellLayerPosition)</syntax>
        /// <returns type="float">The position of the endless grid layer.</returns>
        public float GetPositionOfEndlessGridLayer(int endlessGridLayer, int originCellLayer, float originCellLayerPosition)
        {
            Initialize();
            return layerInfoCalculator.GetPositionOfEndlessGridLayer_ZeroBased(endlessGridLayer - 1, originCellLayer - 1, originCellLayerPosition);
        }

        internal float GetPositionOfEndlessGridLayer_ZeroBased(int endlessGridLayer, int originCellLayer, float originCellLayerPosition)
        {
            Initialize();
            return layerInfoCalculator.GetPositionOfEndlessGridLayer_ZeroBased(endlessGridLayer, originCellLayer, originCellLayerPosition);
        }

        /// <summary>
        /// Finds the endless grid layer that a point in world space falls within.
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// </summary>
        /// <param name="point" type="float">The point that will be used to find the endless grid layer.</param>
        /// <param name="originCellLayer" type="int">The origin cell layer of your World.</param>
        /// <param name="originCellLayerPosition" type="float">The origin cell layer position of your World.</param>
        /// <displayName id="FindEndlessGridLayerPointIsIn1">FindEndlessGridLayerPointIsIn(float, int, float)</displayName>
        /// <syntax>public int FindEndlessGridLayerPointIsIn(float point, int originCellLayer, float originCellLayerPosition)</syntax>
        /// <returns type="int">The endless grid layer that the point is in.</returns>
        public int FindEndlessGridLayerPointIsIn(float point, int originCellLayer, float originCellLayerPosition)
        {
            Initialize();
            return layerInfoCalculator.FindEndlessGridLayerPointIsIn_ZeroBased(point, originCellLayer - 1, originCellLayerPosition) + 1;
        }

        internal int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition)
        {
            Initialize();
            return layerInfoCalculator.FindEndlessGridLayerPointIsIn_ZeroBased(point, originCellLayer, originCellLayerPosition);
        }

        /// <summary>
        /// Finds the endless grid layer that a point in world space falls within.
        /// </summary>
        /// <para>This is a runtime method and should not be used in the editor.</para>
        /// <param name="point" type="float">The point that will be used to find the endless grid layer.</param>
        /// <param name="originCellLayer" type="int">The origin cell layer of your World.</param>
        /// <param name="originCellLayerPosition" type="float">The origin cell layer position of your World.</param>
        /// <param name="layerDisplacementFromOrigin" type="out float">An additional out parameter that meausres the displacement of the 
        /// found endless grid layer to the origin cell's layer. (Ex: if found cell is above the origin, displacement will be positive, if below it will be negative).</param>
        /// <displayName id="FindEndlessGridLayerPointIsIn2">FindEndlessGridLayerPointIsIn(float, int, float, out float)</displayName>
        /// <syntax>public int FindEndlessGridLayerPointIsIn(float point, int originCellLayer, float originCellLayerPosition, out float layerDistanceFromOrigin)</syntax>
        /// <returns type="int">The endless grid layer that the point is in.</returns>
        public int FindEndlessGridLayerPointIsIn(float point, int originCellLayer, float originCellLayerPosition, out float layerDisplacementFromOrigin)
        {
            Initialize();
            return layerInfoCalculator.FindEndlessGridLayerPointIsIn_ZeroBased(point, originCellLayer - 1, originCellLayerPosition, out layerDisplacementFromOrigin) + 1;
        }

        internal int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition, out float layerDisplacementFromOrigin)
        {
            Initialize();
            return layerInfoCalculator.FindEndlessGridLayerPointIsIn_ZeroBased(point, originCellLayer, originCellLayerPosition, out layerDisplacementFromOrigin);
        }

        /// <summary>
        /// Converts an endless grid layer to a layer on the World Grid.
        /// </summary>
        /// <param name="endlessGridLayer" type="int">The endless grid layer to convert.</param>
        /// <displayName id="ConvertEndlessGridLayersToWorldGridLayers">ConvertEndlessGridLayersToWorldGridLayers(int)</displayName>
        /// <syntax>public int ConvertEndlessGridLayersToWorldGridLayers(int endlessGridLayer)</syntax>
        /// <returns type="int">The layer on the World Grid</returns>
        public int ConvertEndlessGridLayerToWorldGridLayer(int endlessGridLayer)
        {
            if (layerHeights == null)
                return 1;
            else
                return EndlessToWorldIndex(endlessGridLayer - 1, layers) + 1;
        }

        internal int ConvertEndlessGridLayerToWorldGridLayer_ZeroBased(int endlessGridLayer)
        {
            if (layerHeights == null)
                return 0;
            else
                return EndlessToWorldIndex(endlessGridLayer, layers);
        }

        /// <summary>
        /// Gets the position of an endless grid cell in world space. Because the World Grid knows nothing about
        /// world space, you must pass in the origin cell and origin cell position of your world for this to work.
        /// <para>
        /// It is recommended to use the inidivual get position methods (GetPositionOfEndlessGridColumn, etc.) if you 
        /// are getting the position frequently, as those methods are slightly more performant.
        /// </para>
        /// </summary>
        /// <param name="endlessGridCell" type="Cell" link="Cell.html">The endless grid cell whose position will be found.</param>
        /// <param name="originCell" type="Cell" link="Cell.html">The origin cell of your world. Usually will be (1, 1, 1), 
        /// unless your world is set to stay centered around the origin.</param>
        /// <param name="originCellPosition" type="Vector3">
        /// The position of the origin cell of your world. This should simply be the origin of your world.
        /// </param>
        /// <displayName id="GetPositionOfEndlessGridCell">
        /// GetPositionOfEndlessGridCell(Cell, Cell, Vector3)
        /// </displayName>
        /// <syntax>
        /// public Vector3 GetPositionOfEndlessGridCell(Cell endlessGridCell, Cell originCell, Vector3 originCellPosition)
        /// </syntax>
        /// <returns type="Vector3">The position of the endless grid cell.</returns>
        public Vector3 GetPositionOfEndlessGridCell(Cell endlessGridCell, Cell originCell, Vector3 originCellPosition)
        {
            return GetPositionOfEndlessGridCell_ZeroBased(endlessGridCell.ConvertTo0Based(IsWorldGrid3D), originCell.ConvertTo0Based(IsWorldGrid3D), originCellPosition);
        }

        internal Vector3 GetPositionOfEndlessGridCell_ZeroBased(Cell endlessGridCell, Cell originCell, Vector3 originCellPosition)
        {
            float xPosition, yPosition, zPosition;
            if(columnWidths.Length == 1)
                xPosition = FindPositionOfEndlessGridIndex(endlessGridCell.column, originCell.column, originCellPosition.x, columnWidths[0]);
            else
                xPosition = FindPositionOfEndlessGridIndex(endlessGridCell.column, originCell.column, originCellPosition.x, columnWidths);

            if(worldType == WorldType.Three_Dimensional || worldType == WorldType.Two_Dimensional_On_XZ_Axes)
            {
                if(rowLengths.Length == 1)
                    zPosition = FindPositionOfEndlessGridIndex(endlessGridCell.row, originCell.row, originCellPosition.z, rowLengths[0]);
                else
                    zPosition = FindPositionOfEndlessGridIndex(endlessGridCell.row, originCell.row, originCellPosition.z, rowLengths);

                if(worldType == WorldType.Three_Dimensional)
                {
                    if (layerHeights.Length == 1)
                        yPosition = FindPositionOfEndlessGridIndex(endlessGridCell.layer, originCell.layer, originCellPosition.y, layerHeights[0]);
                    else
                        yPosition = FindPositionOfEndlessGridIndex(endlessGridCell.layer, originCell.layer, originCellPosition.y, layerHeights);
                }
                else
                    yPosition = originCellPosition.y;
            }
            else//XY world
            {
                if (rowLengths.Length == 1)
                    yPosition = FindPositionOfEndlessGridIndex(endlessGridCell.row, originCell.row, originCellPosition.y, rowLengths[0]);
                else
                    yPosition = FindPositionOfEndlessGridIndex(endlessGridCell.row, originCell.row, originCellPosition.y, rowLengths);

                zPosition = originCellPosition.z;
            }

            return new Vector3(xPosition, yPosition, zPosition);
        }

        #endregion

        #region Helper Functions

        //All helper functions use 0 based indexing
        int EndlessToWorldIndex(int endlessIndex, int cellsOnAxis)
        {
            return (Math.Abs(endlessIndex * cellsOnAxis) + endlessIndex) % cellsOnAxis;
        }

        int FindEndlessGridIndexPointIsIn(float point, int cellOriginIndex, float cellOriginPosition, float[] cellDimensions, out float indexDistanceFromOrigin)
        {
            indexDistanceFromOrigin = 0f;

            if (Mathf.Approximately(point, cellOriginPosition))
                return cellOriginIndex;
            
            int endlessGridIndex = cellOriginIndex;
            float positionOfNextCell = cellOriginPosition;
            int cellsOnAxis = cellDimensions.Length;
            int worldGridIndex = EndlessToWorldIndex(endlessGridIndex, cellsOnAxis);

            if (point > cellOriginPosition)
            {
                float currentCellDimension = cellDimensions[worldGridIndex];
                positionOfNextCell += currentCellDimension;

                while (point > positionOfNextCell)
                {
                    endlessGridIndex++;
                    indexDistanceFromOrigin += currentCellDimension;
                    worldGridIndex++;
                    if (worldGridIndex == cellsOnAxis)
                        worldGridIndex = 0;//Reset world grid index to 0 when it goes beyond max

                    currentCellDimension = cellDimensions[worldGridIndex];
                    positionOfNextCell += currentCellDimension;
                }

                if (Mathf.Approximately(point, positionOfNextCell))
                {
                    endlessGridIndex++;
                    indexDistanceFromOrigin += currentCellDimension;
                }
            }
            else
            {
                do
                {
                    endlessGridIndex--;
                    worldGridIndex--;
                    if (worldGridIndex == -1)
                        worldGridIndex = cellsOnAxis - 1;//Reset world grid index to max index when it goes below min

                    float currentCellDimension = cellDimensions[worldGridIndex];
                    indexDistanceFromOrigin -= currentCellDimension;
                    positionOfNextCell -= currentCellDimension;

                } while (point < positionOfNextCell);
            }

            return endlessGridIndex;
        }

        int FindEndlessGridIndexPointIsIn(float point, int cellOriginIndex, float cellOriginPosition, float[] cellDimensions)
        {
            if (Mathf.Approximately(point, cellOriginPosition))
                return cellOriginIndex;

            int endlessGridIndex = cellOriginIndex;
            float positionOfNextCell = cellOriginPosition;
            int cellsOnAxis = cellDimensions.Length;
            int worldGridIndex = EndlessToWorldIndex(endlessGridIndex, cellsOnAxis);

            if (point > cellOriginPosition)
            {
                float currentCellDimension = cellDimensions[worldGridIndex];
                positionOfNextCell += currentCellDimension;

                while (point > positionOfNextCell)
                {
                    endlessGridIndex++;
                    worldGridIndex++;
                    if (worldGridIndex == cellsOnAxis)
                        worldGridIndex = 0;//Reset world grid index to 0 when it goes beyond max

                    currentCellDimension = cellDimensions[worldGridIndex];
                    positionOfNextCell += currentCellDimension;
                }

                if (Mathf.Approximately(point, positionOfNextCell))
                    endlessGridIndex++;
            }
            else
            {
                do
                {
                    endlessGridIndex--;
                    worldGridIndex--;
                    if (worldGridIndex == -1)
                        worldGridIndex = cellsOnAxis - 1;//Reset world grid index to max index when it goes below min

                    float currentCellDimension = cellDimensions[worldGridIndex];
                    positionOfNextCell -= currentCellDimension;

                } while (point < positionOfNextCell);
            }

            return endlessGridIndex;
        }

        float FindPositionOfEndlessGridIndex(int targetEndlessGridIndex, int cellOriginIndex, float cellOriginPosition, float cellDimensions)
        {
            return cellOriginPosition + ((targetEndlessGridIndex - cellOriginIndex) * cellDimensions);
        }

        float FindPositionOfEndlessGridIndex(int targetEndlessGridIndex, int cellOriginIndex, float cellOriginPosition, float[] cellDimensions)
        {
            if (targetEndlessGridIndex == cellOriginIndex)
                return cellOriginPosition;

            float position = cellOriginPosition;
            int cellsOnAxis = cellDimensions.Length;

            int currentEndlessGridIndex = cellOriginIndex;
            int currentWorldGridIndex = EndlessToWorldIndex(currentEndlessGridIndex, cellsOnAxis);

            if (currentEndlessGridIndex > targetEndlessGridIndex)
            {
                position += cellDimensions[currentWorldGridIndex];
                currentEndlessGridIndex++;

                while (currentEndlessGridIndex > targetEndlessGridIndex)
                {
                    currentWorldGridIndex++;
                    if (currentWorldGridIndex == cellsOnAxis)
                        currentWorldGridIndex = 0;

                    position += cellDimensions[currentWorldGridIndex];
                    currentEndlessGridIndex++;
                }
            }
            else
            {
                do
                {
                    currentWorldGridIndex--;
                    if (currentWorldGridIndex == -1)
                        currentWorldGridIndex = cellsOnAxis;

                    position -= cellDimensions[currentWorldGridIndex];
                    currentEndlessGridIndex--;

                } while (currentEndlessGridIndex < targetEndlessGridIndex);
            }

            return position;
        }

        //safe to use pre init
        internal Vector3 GetDistanceFromOriginOfWorldGridCell_ZeroBased(Cell worldGridCell)
        {
            float rowDistance = 0f;
            if (rowLengths.Length == 1)
                rowDistance = rowLengths[0] * worldGridCell.Row;
            else
            {
                for (int i = 0; i < worldGridCell.Row; i++)
                    rowDistance += rowLengths[i];
            }

            float columnDistance = 0f;
            if (columnWidths.Length == 1)
                columnDistance = columnWidths[0] * worldGridCell.Column;
            else
            {
                for (int i = 0; i < worldGridCell.Column; i++)
                    columnDistance += columnWidths[i];
            }

            float layerDistance = 0f;
            if (WorldType == WorldType.Three_Dimensional)
            {
                if (layerHeights.Length == 1)
                    layerDistance = layerHeights[0] * worldGridCell.Layer;
                else
                {
                    for (int i = 0; i < worldGridCell.Layer; i++)
                        layerDistance += layerHeights[i];
                }
            }

            return new Vector3(rowDistance, columnDistance, layerDistance);
        }

        //safe to use pre init
        internal Cell GetWorldGridCellPositionIsIn_OneBased(Vector3 position, Vector3 worldOrigin)
        {
            int row = 1, column = 1, layer = 1;

            bool error = false;
            //Find the column
            float widthOfWorld = columnWidths.Length == 1 ? columnWidths[0] * columns : columnWidths.ComputeSum();
            if(position.x < worldOrigin.x || position.x > worldOrigin.x + widthOfWorld)
                error = true;
            else
            {
                if (columnWidths.Length == 1)
                    column = (int)(position.x / columnWidths[0]) + 1;
                else
                {
                    float currentColumnRightEdgePosition = columnWidths[0] + worldOrigin.x;
                    while(position.x > currentColumnRightEdgePosition)
                        currentColumnRightEdgePosition += columnWidths[column++];
                }
            }

            //Now find the row
            float lengthOfWorld = rowLengths.Length == 1 ? rowLengths[0] * rows : rowLengths.ComputeSum();

            float rowTargetPosition, rowOrigin;
            if(WorldType == DynamicLoadingKit.WorldType.Two_Dimensional_On_XY_Axes)
            {
                rowTargetPosition = position.y;
                rowOrigin = worldOrigin.y;
            }
            else
            {
                rowTargetPosition = position.z;
                rowOrigin = worldOrigin.z;
            }

            if (rowTargetPosition < rowOrigin || rowTargetPosition > rowOrigin + lengthOfWorld)
                error = true;
            else
            {
                if (rowLengths.Length == 1)
                    row = (int)(rowTargetPosition / rowLengths[0]) + 1;
                else
                {
                    float currentRowTopEdgePosition = rowLengths[0] + rowOrigin;
                    while (rowTargetPosition > currentRowTopEdgePosition)
                        currentRowTopEdgePosition += rowLengths[row++];
                }
            }

            //finally find the layer if the world is 3d
            if(WorldType == DynamicLoadingKit.WorldType.Three_Dimensional)
            {
                float heightOfWorld = layerHeights.Length == 1 ? layerHeights[0] * layers : layerHeights.ComputeSum();

                if (position.y < worldOrigin.y || position.y > worldOrigin.y + heightOfWorld)
                    error = true;
                else
                {
                    if (rowLengths.Length == 1)
                        layer = (int)(position.y / layerHeights[0]) + 1;
                    else
                    {
                        float currentLayerTopEdgePosition = layerHeights[0] + worldOrigin.y;
                        while (position.y > currentLayerTopEdgePosition)
                            currentLayerTopEdgePosition += layerHeights[layer++];
                    }
                }
            }

            if (error)
                throw new ArgumentOutOfRangeException("The input position does not fall within the bounds of the World.");

            return new Cell(row, column, layer);
        }

        #endregion

        #region Internal Classes

        abstract class RowInfoCalculator
        {
            protected WorldGridBase worldGrid;
            public RowInfoCalculator(WorldGridBase worldGrid) { this.worldGrid = worldGrid; }

            public abstract float GetLengthOfWorldGridRow_ZeroBased(int worldGridRow);
            public abstract float GetLengthOfEndlessGridRow_ZeroBased(int endlessGridRow);
            public abstract float GetPositionOfEndlessGridRow_ZeroBased(int row, int originCellRow, float originCellRowPosition);
            public abstract int FindEndlessGridRowPointIsIn_ZeroBased(float point, int originCellRow, float originCellRowPosition);
            public abstract int FindEndlessGridRowPointIsIn_ZeroBased(float point, int originCellRow, float originCellRowPosition, out float rowDisplacementFromOrigin);
        }

        class EqualLengthRowInfoCalculator : RowInfoCalculator
        {
            public EqualLengthRowInfoCalculator(WorldGridBase worldGrid) : base(worldGrid) { }

            public sealed override float GetLengthOfWorldGridRow_ZeroBased(int worldGridRow)
            {
                return worldGrid.rowLengths[0];
            }

            public sealed override float GetLengthOfEndlessGridRow_ZeroBased(int endlessGridRow)
            {
                return worldGrid.rowLengths[0];
            }

            public sealed override float GetPositionOfEndlessGridRow_ZeroBased(int row, int originCellRow, float originCellRowPosition)
            {
                return worldGrid.FindPositionOfEndlessGridIndex(row, originCellRow, originCellRowPosition, worldGrid.rowLengths[0]);
            }

            public sealed override int FindEndlessGridRowPointIsIn_ZeroBased(float point, int originCellRow, float originCellRowPosition)
            {
                int rowsBetweenOriginAndPoint = Mathf.FloorToInt((point - originCellRowPosition) / worldGrid.rowLengths[0]);
                return originCellRow + rowsBetweenOriginAndPoint;
            }

            public sealed override int FindEndlessGridRowPointIsIn_ZeroBased(float point, int originCellRow, float originCellRowPosition, out float rowDisplacementFromOrigin)
            {
                int rowsBetweenOriginAndPoint = Mathf.FloorToInt((point - originCellRowPosition) / worldGrid.rowLengths[0]);
                rowDisplacementFromOrigin = rowsBetweenOriginAndPoint * worldGrid.rowLengths[0];
                return originCellRow + rowsBetweenOriginAndPoint;
            }
        }

        class RegularRowInfoCalculator : RowInfoCalculator
        {
            public RegularRowInfoCalculator(WorldGridBase worldGrid) : base(worldGrid) { }

            public sealed override float GetLengthOfWorldGridRow_ZeroBased(int worldGridRow)
            {
                return worldGrid.rowLengths[worldGridRow];
            }

            public sealed override float GetLengthOfEndlessGridRow_ZeroBased(int endlessGridRow)
            {
                int worldGridRow = worldGrid.EndlessToWorldIndex(endlessGridRow, worldGrid.rows);
                return worldGrid.rowLengths[worldGridRow];
            }

            public sealed override float GetPositionOfEndlessGridRow_ZeroBased(int row, int originCellRow, float originCellRowPosition)
            {
                return worldGrid.FindPositionOfEndlessGridIndex(row, originCellRow, originCellRowPosition, worldGrid.rowLengths);
            }

            public sealed override int FindEndlessGridRowPointIsIn_ZeroBased(float point, int originCellRow, float originCellRowPosition)
            {
                return worldGrid.FindEndlessGridIndexPointIsIn(point, originCellRow, originCellRowPosition, worldGrid.rowLengths);
            }

            public sealed override int FindEndlessGridRowPointIsIn_ZeroBased(float point, int originCellRow, float originCellRowPosition, out float rowDisplacementFromOrigin)
            {
                return worldGrid.FindEndlessGridIndexPointIsIn(point, originCellRow, originCellRowPosition, worldGrid.rowLengths, out rowDisplacementFromOrigin);
            }
        }

        abstract class ColumnInfoCalculator
        {
            protected WorldGridBase worldGrid;
            public ColumnInfoCalculator(WorldGridBase worldGrid) { this.worldGrid = worldGrid; }

            public abstract float GetWidthOfWorldGridColumn_ZeroBased(int worldGridColumn);
            public abstract float GetWidthOfEndlessGridColumn_ZeroBased(int endlessGridColumn);
            public abstract float GetPositionOfEndlessGridColumn_ZeroBased(int column, int originCellColumn, float originCellColumnPosition);
            public abstract int FindEndlessGridColumnPointIsIn_ZeroBased(float point, int originCellColumn, float originCellColumnPosition);
            public abstract int FindEndlessGridColumnPointIsIn_ZeroBased(float point, int originCellColumn, float originCellColumnPosition, out float columnDisplacementFromOrigin);
        }

        class EqualWidthColumnInfoCalculator : ColumnInfoCalculator
        {
            public EqualWidthColumnInfoCalculator(WorldGridBase worldGrid) : base(worldGrid) { }

            public sealed override float GetWidthOfWorldGridColumn_ZeroBased(int worldGridColumn)
            {
                return worldGrid.columnWidths[0];
            }

            public sealed override float GetWidthOfEndlessGridColumn_ZeroBased(int endlessGridColumn)
            {
                return worldGrid.columnWidths[0];
            }

            public sealed override float GetPositionOfEndlessGridColumn_ZeroBased(int column, int originCellColumn, float originCellColumnPosition)
            {
                return worldGrid.FindPositionOfEndlessGridIndex(column, originCellColumn, originCellColumnPosition, worldGrid.columnWidths[0]);
            }

            public sealed override int FindEndlessGridColumnPointIsIn_ZeroBased(float point, int originCellColumn, float originCellColumnPosition)
            {
                int columnsBetweenOriginAndPoint = Mathf.FloorToInt((point - originCellColumnPosition) / worldGrid.columnWidths[0]);
                return originCellColumn + columnsBetweenOriginAndPoint;
            }

            public sealed override int FindEndlessGridColumnPointIsIn_ZeroBased(float point, int originCellColumn, float originCellColumnPosition, out float columnDisplacementFromOrigin)
            {
                int columnsBetweenOriginAndPoint = Mathf.FloorToInt((point - originCellColumnPosition) / worldGrid.columnWidths[0]);
                columnDisplacementFromOrigin = columnsBetweenOriginAndPoint * worldGrid.columnWidths[0];
                return originCellColumn + columnsBetweenOriginAndPoint;
            }
        }

        class RegularColumnInfoCalculator : ColumnInfoCalculator
        {
            public RegularColumnInfoCalculator(WorldGridBase worldGrid) : base(worldGrid) { }

            public sealed override float GetWidthOfWorldGridColumn_ZeroBased(int worldGridColumn)
            {
                return worldGrid.columnWidths[worldGridColumn];
            }

            public sealed override float GetWidthOfEndlessGridColumn_ZeroBased(int endlessGridColumn)
            {
                int worldGridColumn = worldGrid.EndlessToWorldIndex(endlessGridColumn, worldGrid.columns);
                return worldGrid.columnWidths[worldGridColumn];
            }

            public sealed override float GetPositionOfEndlessGridColumn_ZeroBased(int column, int originCellColumn, float originCellColumnPosition)
            {
                return worldGrid.FindPositionOfEndlessGridIndex(column, originCellColumn, originCellColumnPosition, worldGrid.columnWidths);
            }

            public sealed override int FindEndlessGridColumnPointIsIn_ZeroBased(float point, int originCellColumn, float originCellColumnPosition)
            {
                return worldGrid.FindEndlessGridIndexPointIsIn(point, originCellColumn, originCellColumnPosition, worldGrid.columnWidths);
            }

            public sealed override int FindEndlessGridColumnPointIsIn_ZeroBased(float point, int originCellColumn, float originCellColumnPosition, out float columnDisplacementFromOrigin)
            {
                return worldGrid.FindEndlessGridIndexPointIsIn(point, originCellColumn, originCellColumnPosition, worldGrid.columnWidths, out columnDisplacementFromOrigin);
            }
        }

        abstract class LayerInfoCalculator
        {
            protected WorldGridBase worldGrid;
            public LayerInfoCalculator(WorldGridBase worldGrid) { this.worldGrid = worldGrid; }

            public abstract float GetHeightOfWorldGridLayer_ZeroBased(int worldGridLayer);
            public abstract float GetHeightOfEndlessGridLayer_ZeroBased(int endlessGridLayer);
            public abstract float GetPositionOfEndlessGridLayer_ZeroBased(int layer, int originCellLayer, float originCellLayerPosition);
            public abstract int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition);
            public abstract int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition, out float layerDisplacementFromOrigin);            
        }

        class NullLayerInfoCalculator : LayerInfoCalculator
        {
            public NullLayerInfoCalculator(WorldGridBase worldGrid) : base(worldGrid) { }

            public sealed override float GetHeightOfWorldGridLayer_ZeroBased(int worldGridLayer)
            {
                return 0f;
            }

            public sealed override float GetHeightOfEndlessGridLayer_ZeroBased(int endlessGridLayer)
            {
                return 0f;
            }

            public sealed override float GetPositionOfEndlessGridLayer_ZeroBased(int layer, int originCellLayer, float originCellLayerPosition)
            {
                return originCellLayerPosition;
            }

            public sealed override int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition)
            {
                return 0;
            }

            public sealed override int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition, out float layerDisplacementFromOrigin)
            {
                layerDisplacementFromOrigin = 0f;
                return 0;
            }
        }

        class EqualHeightLayerInfoCalculator : LayerInfoCalculator
        {
            public EqualHeightLayerInfoCalculator(WorldGridBase worldGrid) : base(worldGrid) { }

            public sealed override float GetHeightOfWorldGridLayer_ZeroBased(int worldGridLayer)
            {
                return worldGrid.layerHeights[0];
            }

            public sealed override float GetHeightOfEndlessGridLayer_ZeroBased(int endlessGridLayer)
            {
                return worldGrid.layerHeights[0];
            }

            public sealed override float GetPositionOfEndlessGridLayer_ZeroBased(int layer, int originCellLayer, float originCellLayerPosition)
            {
                return worldGrid.FindPositionOfEndlessGridIndex(layer, originCellLayer, originCellLayerPosition, worldGrid.layerHeights[0]);
            }

            public sealed override int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition)
            {
                int layersBetweenOriginAndPoint = Mathf.FloorToInt((point - originCellLayerPosition) / worldGrid.layerHeights[0]);
                return originCellLayer + layersBetweenOriginAndPoint;
            }

            public sealed override int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition, out float layerDisplacementFromOrigin)
            {
                int layersBetweenOriginAndPoint = Mathf.FloorToInt((point - originCellLayerPosition) / worldGrid.layerHeights[0]);
                layerDisplacementFromOrigin = layersBetweenOriginAndPoint * worldGrid.layerHeights[0];
                return originCellLayer + layersBetweenOriginAndPoint;
            }
        }

        class RegularLayerInfoCalculator : LayerInfoCalculator
        {
            public RegularLayerInfoCalculator(WorldGridBase worldGrid) : base(worldGrid) { }

            public sealed override float GetHeightOfWorldGridLayer_ZeroBased(int worldGridLayer)
            {
                return worldGrid.layerHeights[worldGridLayer];
            }

            public sealed override float GetHeightOfEndlessGridLayer_ZeroBased(int endlessGridLayer)
            {
                int worldGridLayer = worldGrid.EndlessToWorldIndex(endlessGridLayer, worldGrid.layers);
                return worldGrid.layerHeights[worldGridLayer];
            }

            public sealed override float GetPositionOfEndlessGridLayer_ZeroBased(int layer, int originCellLayer, float originCellLayerPosition)
            {
                return worldGrid.FindPositionOfEndlessGridIndex(layer, originCellLayer, originCellLayerPosition, worldGrid.layerHeights);
            }

            public sealed override int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition)
            {
                return worldGrid.FindEndlessGridIndexPointIsIn(point, originCellLayer, originCellLayerPosition, worldGrid.layerHeights);
            }

            public sealed override int FindEndlessGridLayerPointIsIn_ZeroBased(float point, int originCellLayer, float originCellLayerPosition, out float layerDisplacementFromOrigin)
            {
                return worldGrid.FindEndlessGridIndexPointIsIn(point, originCellLayer, originCellLayerPosition, worldGrid.layerHeights, out layerDisplacementFromOrigin);
            }
        }

        #endregion

        #region Range Stuff
        //Range and object loading stuff

        [HideInInspector]
        [SerializeField]
        List<Range> rangeTemplates = new List<Range>();

        [HideInInspector]
        [SerializeField]
        internal string[] rangeTemplateNames = new string[1] { "(1) Load All Objects" };

        #endregion
    }
}