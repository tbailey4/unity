﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;

    internal interface IOffsetCalculator
    {
        Vector3 CalculateOffset(CellDimensions cellDimensions);
    }

    //Case where cell offsets and fixed offset are all equal to 0
    internal class NoOffsetCalculator : IOffsetCalculator
    {
        public Vector3 CalculateOffset(CellDimensions cellDimensions)
        {
            return Vector3.zero;
        }
    }


    //Cases where cell offsets are equal to 1
    internal class FullOffsetXZCalculator : IOffsetCalculator
    {
        public Vector3 CalculateOffset(CellDimensions cellDimensions)
        {
            return new Vector3(cellDimensions.width, 0f, cellDimensions.length);
        }
    }

    internal class FullOffsetXYCalculator : IOffsetCalculator
    {
        public Vector3 CalculateOffset(CellDimensions cellDimensions)
        {
            return new Vector3(cellDimensions.width, cellDimensions.length, 0f);
        }
    }

    internal class FullOffsetXYZCalculator : IOffsetCalculator
    {
        public Vector3 CalculateOffset(CellDimensions cellDimensions)
        {
            return new Vector3(cellDimensions.width, cellDimensions.height, cellDimensions.length);
        }
    }


    //Case where one or more cell offsets are > 0 and less than 1
    internal class PartialOffsetXZCalculator : IOffsetCalculator
    {
        Vector3 offsets;

        internal PartialOffsetXZCalculator(Vector3 offsets)
        {
            this.offsets = offsets;
        }

        public Vector3 CalculateOffset(CellDimensions cellDimensions)
        {
            return new Vector3(cellDimensions.width * offsets.x, 0f, cellDimensions.length * offsets.z);
        }
    }

    internal class PartialOffsetXYCalculator : IOffsetCalculator
    {
        Vector3 offsets;
        internal PartialOffsetXYCalculator(Vector3 offsets)
        {
            this.offsets = offsets;
        }

        public Vector3 CalculateOffset(CellDimensions cellDimensions)
        {
            return new Vector3(cellDimensions.width * offsets.x, cellDimensions.length * offsets.y, 0f);
        }
    }

    internal class PartialOffsetXYZCalculator : IOffsetCalculator
    {
        Vector3 offsets;
        internal PartialOffsetXYZCalculator(Vector3 offsets)
        {
            this.offsets = offsets;
        }

        public Vector3 CalculateOffset(CellDimensions cellDimensions)
        {
            return new Vector3(cellDimensions.width * offsets.x, cellDimensions.height * offsets.y, cellDimensions.length * offsets.z);
        }
    }

    internal static class OffsetCalculatorCreator
    {
        internal static IOffsetCalculator CreateOffsetCalculator(WorldType worldType, Vector3 positionOffset)
        {
            IOffsetCalculator OffsetCalculator;
            if (worldType == WorldType.Two_Dimensional_On_XZ_Axes)
            {
                if (Mathf.Approximately(positionOffset.x, 1f) && Mathf.Approximately(positionOffset.z, 1f))
                    OffsetCalculator = new FullOffsetXZCalculator();
                else if (Mathf.Approximately(positionOffset.x, 0f) && Mathf.Approximately(positionOffset.z, 0f))
                    OffsetCalculator = new NoOffsetCalculator();
                else
                    OffsetCalculator = new PartialOffsetXZCalculator(positionOffset);
            }
            else if (worldType == WorldType.Two_Dimensional_On_XY_Axes)
            {
                if (Mathf.Approximately(positionOffset.x, 1f) && Mathf.Approximately(positionOffset.y, 1f))
                    OffsetCalculator = new FullOffsetXYCalculator();
                else if (Mathf.Approximately(positionOffset.x, 0f) && Mathf.Approximately(positionOffset.y, 0f))
                    OffsetCalculator = new NoOffsetCalculator();
                else
                    OffsetCalculator = new PartialOffsetXYCalculator(positionOffset);
            }
            else
            {
                if (Mathf.Approximately(positionOffset.x, 1f) && Mathf.Approximately(positionOffset.y, 1f) && Mathf.Approximately(positionOffset.z, 1f))
                    OffsetCalculator = new FullOffsetXYZCalculator();
                else if (Mathf.Approximately(positionOffset.x, 0f) && Mathf.Approximately(positionOffset.y, 0f) && Mathf.Approximately(positionOffset.z, 0f))
                    OffsetCalculator = new NoOffsetCalculator();
                else
                    OffsetCalculator = new PartialOffsetXYZCalculator(positionOffset);
            }

            return OffsetCalculator;
        }
    }
}
