//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
	using System.Collections.Generic;

    /// <summary>
    /// Provides a base implementation for Cell Object Loaders. Cell Object Loaders must be able
    /// to load objects over several frames or in a single frame. When single frame loading is impossible
    /// (as is the case with some load methods) pre-loading will be used (pre-loading occurs in one frame, then
    /// the actual single frame load occurs in the next).
    /// <para>In order to accomplish this, the 
    /// <see href = "#IsSingleFrameAttachmentPreloadRequired">IsSingleFrameAttachmentPreloadRequired</see> property must be
    /// overridden in the derived class to indicate whether pre-loading is required.</para>
    /// <para>Additional Note: This component contains its own special class (CellObjectLoaderUser) which enables multiple 
    /// users to use the cell object loader at the same time. The data associated with each user is stored in this user object and retrieved
    /// using the loaderID passed into each method.</para>
    /// <para>This user object contains a <see cref="CellString" href = "CellString.html">Cell String</see>, which you are
    /// free to use in your own derived cell object loader component. You can access the user object and cell string via the  
    /// <see cref="RegisteredUsers" href = "#RegisteredUsers">RegisteredUsers</see> property and loaderID, like so: RegisteredUsers[loaderID] (accesses the user object) or RegisteredUsers[loaderID].CellString.</para>
    /// <para>You may also create your own custom user object class which
    /// derives from CellObjectLoaderUser. In fact, this strategy is utilized by some of the other Cell Object Loaders in the kit. Simply override the
    /// <see cref="CreateNewUser" href = "#CreateNewUser">CreateNewUser</see> method and return your custom user object.</para>
    /// <para>You should never have to interact directly with this component, as the methods/properties are called/used
    /// as needed by the Dynamic Loading Kit.</para>
    /// </summary>
    /// <title>CellObjectLoader Abstract Class</title>
    /// <category>Cell Object Loaders</category>
    /// <navigationName>CellObjectLoader</navigationName>
    /// <fileName>CellObjectLoader.html</fileName>
    /// <syntax>public abstract class CellObjectLoader : MonoBehaviour</syntax>
	public abstract class CellObjectLoader : MonoBehaviour
	{
        RegistrationHandler<CellObjectLoaderUser> registeredUsers;

        /// <summary>
        /// When overridden in derived class, gets a bool value indicating whether the derived class
        /// requires pre loading in order to perform a single frame attachment.
        /// <para>If overridden to return true, then the 
        /// <see cref="PerformSingleFrameAttachmentPreload" href = "#PerformSingleFrameAttachmentPreload">PerformSingleFrameAttachmentPreload</see> method must also be overridden.</para>
        /// </summary>
        /// <type>bool</type>
        public abstract bool IsSingleFrameAttachmentPreloadRequired { get; }

        /// <summary>
        /// The users registered with the Cell Object Loader.
        /// </summary>
        /// <type link = "RegistrationHandler.html">RegistrationHandler&lt;CellObjectLoaderUser&gt; (protected)</type>
        protected RegistrationHandler<CellObjectLoaderUser> RegisteredUsers { get { return registeredUsers; } }

        /// <summary>
        /// A user can call this method to register with the Cell Object Loader. The loaderID must be stored by the user
        /// and passed in when calling the methods of the Cell Object Loader.
        /// </summary>
        /// <param name="cellObjectGroup" type="ICellObjectGroup" link="ICellObjectGroup.html">
        /// The cell object group being registered.
        /// </param>
        /// <param name="loaderID" type = "int">
        /// An ID that is assigned to the user when this method is called. Each user has its
        /// own CellObjectLoaderUser object created for it.
        /// </param>
        /// <displayName id = "Register">Register(ICellObjectGroup, out int)</displayName>
        /// <syntax>public void Register(ICellObjectGroup cellObjectGroup, out int loaderID)</syntax>
        public void Register(ICellObjectGroup cellObjectGroup, out int loaderID)
        {
            if (registeredUsers == null)
                registeredUsers = new RegistrationHandler<CellObjectLoaderUser>();

            registeredUsers.AddRegistrant(CreateNewUser(cellObjectGroup), out loaderID);
        }

        /// <summary>
        /// A user can call this method to de register with the Cell Object Loader.
        /// </summary>
        /// <param name="loaderID" type = "int">The ID of the user to de register.</param>
        /// <displayName id = "DeRegister">DeRegister(int)</displayName>
        /// <syntax>public void DeRegister(int loaderID)</syntax>
        public void DeRegister(int loaderID)
        {
            registeredUsers.RemoveRegistrant(loaderID);
        }

        /// <summary>
        /// Method used to create a new user object during user registration. This can be overridden to return
        /// a custom user object.
        /// </summary>
        /// <param name="cellObjectGroup" type="ICellObjectGroup" link="ICellObjectGroup.html">The cell object group being registered.</param>
        /// <displayName id = "CreateNewUser">CreateNewUser(ICellObjectGroup)</displayName>
        /// <syntax>protected virtual CellObjectLoaderUser CreateNewUser(ICellObjectGroup cellObjectGroup)</syntax>
        /// <returns type = "CellObjectLoaderUser">A new user object created using the worldAssociatedWithUser as input.</returns>
        protected virtual CellObjectLoaderUser CreateNewUser(ICellObjectGroup cellObjectGroup)
        {
            return new CellObjectLoaderUser(cellObjectGroup);
        }

        /// <summary>
        /// Certain types of load methods require a frame to pass before objects are added to the scene (LoadLevelAdditive for example). In order to 
        /// properly utilize the AttachCellObjectsToCellsInSingleFrame method, these load methods must "pre load" the objects in the frame before. 
        /// This method is used to do that, but should only be called by the registered user when IsSingleFrameAttachmentPreloadRequired is true.
        /// <para>By default, this method does nothing, and you only need to provide your own implementation if pre loading is required (in 
        /// which case, <see cref="IsSingleFrameAttachmentPreloadRequired" href = "#IsSingleFrameAttachmentPreloadRequired">IsSingleFrameAttachmentPreloadRequired</see> 
        /// must also be overridden to return true.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be pre loaded.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the pre load.</param>
        /// <displayName id = "PerformSingleFrameAttachmentPreload">PerformSingleFrameAttachmentPreload&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public virtual void PerformSingleFrameAttachmentPreload&lt;T&gt;(List&lt;T&gt; cells, int loaderID) where T : IAttachableWorldCell</syntax>
        public virtual void PerformSingleFrameAttachmentPreload<T>(List<T> cells, int loaderID) where T : IAttachableWorldCell { }

        /// <summary>
        /// When overridden in a derived class, attaches the objects associated with the input cells to the cells in a single frame.
        /// <para>Note that T must implement the <see cref="IAttachableWorldCell" href = "IAttachableWorldCell.html">IAttachableWorldCell</see> interface.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attachment.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the attachment.</param>
        /// <displayName id = "AttachCellObjectsToCellsInSingleFrame">AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public abstract void AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int loaderID) where T : IAttachableWorldCell</syntax>
        public abstract void AttachCellObjectsToCellsInSingleFrame<T>(List<T> cells, int loaderID) where T : IAttachableWorldCell;

        /// <summary>
        /// When overridden in a derived class, loads and attaches the objects associated with the input cells to the cells over a period of frames.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be loaded and attached.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the load and attachment.</param>
        /// <displayName id = "LoadAndAttachCellObjectsToCells">LoadAndAttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public abstract IEnumerator&lt;YieldInstruction&gt; LoadAndAttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt; cells, int loaderID) where T : IAttachableWorldCell</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public abstract IEnumerator<YieldInstruction> LoadAndAttachCellObjectsToCells<T>(List<T> cells, int loaderID) where T : IAttachableWorldCell;

        protected class CellObjectLoaderUser
        {
            public CellString CellString { get; private set; }

            public CellObjectLoaderUser(ICellObjectGroup cellObjectGroup)
            {
                CellString = CreateCellString(cellObjectGroup);
            }

            protected virtual CellString CreateCellString(ICellObjectGroup cellObjectGroup)
            {
                WorldGridBase worldGrid = cellObjectGroup.World.WorldGrid;
                if (worldGrid.worldType == WorldType.Three_Dimensional)
                    return new CellString3D(cellObjectGroup.GroupName, cellObjectGroup.NamingConvention);
                else
                    return new CellString2D(cellObjectGroup.GroupName, cellObjectGroup.NamingConvention);
            }
        }
	}
}