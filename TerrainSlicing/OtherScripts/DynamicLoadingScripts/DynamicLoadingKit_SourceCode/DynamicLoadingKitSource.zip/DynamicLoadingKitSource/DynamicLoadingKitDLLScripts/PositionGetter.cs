﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;

    internal abstract class PositionGetter
    {
        public abstract void GetRowAndLayerPosition(Vector3 cellPosition, out float rowPosition, out float layerPosition);
    }

    internal class PositionGetter2DXY : PositionGetter
    {
        public sealed override void GetRowAndLayerPosition(Vector3 cellPosition, out float rowPosition, out float layerPosition)
        {
            rowPosition = cellPosition.y;
            layerPosition = cellPosition.z;
        }
    }

    internal class PositionGetter2DXZ : PositionGetter
    {
        public sealed override void GetRowAndLayerPosition(Vector3 cellPosition, out float rowPosition, out float layerPosition)
        {
            rowPosition = cellPosition.z;
            layerPosition = cellPosition.y;
        }
    }

    internal class PositionGetter3D : PositionGetter
    {
        public sealed override void GetRowAndLayerPosition(Vector3 cellPosition, out float rowPosition, out float layerPosition)
        {
            rowPosition = cellPosition.z;
            layerPosition = cellPosition.y;
        }
    }
}