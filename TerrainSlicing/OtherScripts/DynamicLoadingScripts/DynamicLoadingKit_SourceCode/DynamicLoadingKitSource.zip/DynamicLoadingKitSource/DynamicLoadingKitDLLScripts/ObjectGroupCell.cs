﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;

    /// <summary>
    /// Represents a cell in an <see cref="ObjectGroup" href="ObjectGroup.html">Object Group</see>. Each object group cell belongs to 
    /// a world cell.
    /// </summary>
    /// <title>ObjectGroupCell Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>ObjectGroupCell</navigationName>
    /// <fileName>ObjectGroupCell.html</fileName>
    /// <syntax>public class ObjectGroupCell : <see cref="IAttachableWorldCell" href="IAttachableWorldCell.html">IAttachableWorldCell</see>, <see cref="IDetachableWorldCell" href="IDetachableWorldCell.html">IDetachableWorldCell</see></syntax>
    public class ObjectGroupCell : IAttachableWorldCell, IDetachableWorldCell
    {
        internal bool positioned;
        internal CellAction[] cellActions;
        internal GameObject primaryCellObject;
        internal Vector3 offset;
        internal WorldCell worldCellThisCellBelongsTo;
        
        /// <summary>
        /// Initializes a new instance of the ObjectGroupCell class.
        /// </summary>
        /// <displayName id="ObjectGroupCell">ObjectGroupCell()</displayName>
        /// <syntax>public ObjectGroupCell()</syntax>
        public ObjectGroupCell() { }

        /// <summary>
        /// Gets the position that the cell object should be placed at. You can position the object manually, or 
        /// let it be automatically positioned via AttachCellObjectToCell (by passing in false for 
        /// objectPositionedCorrectlyAlready).
        /// </summary>
        /// <type>bool</type>
        public Vector3 CellObjectPosition { get { return worldCellThisCellBelongsTo.position + offset; } }

        /// <summary>
        /// Gets the cell's index on the World Grid associated with the World this cell belongs to.
        /// </summary>
        /// <type link="Cell.html">Cell</type>
        public Cell CellOnWorldGrid { get { return worldCellThisCellBelongsTo.oneBasedCellOnWorldGrid; } }

        /// <summary>
        /// Gets the position of the cell in world space (note, this may be different than the position of the 
        /// cell object, since the cell object can be offset from the cell).
        /// </summary>
        /// <type>Vector3</type>
        public Vector3 CellPosition { get { return worldCellThisCellBelongsTo.position; } }

        /// <summary>
        /// Gets the height of the cell.
        /// </summary>
        /// <type>float</type>
        public float Height { get { return worldCellThisCellBelongsTo.dimensions.height; } }
        
        /// <summary>
        /// Gets the Cell Object associated with the World Cell.
        /// <para>Explicit Interface Implementation for <see cref="IAttachableWorldCell" href="IAttachableWorldCell.html">IAttachableWorldCell</see></para>
        /// </summary>
        /// <type>GameObject</type>
        /// <displayName>IAttachableWorldCell.CellObject</displayName>
        GameObject IAttachableWorldCell.CellObject { get { return primaryCellObject; } }

        /// <summary>
        /// Gets the length of the cell.
        /// </summary>
        /// <type>float</type>
        public float Length { get { return worldCellThisCellBelongsTo.dimensions.length; } }

        /// <summary>
        /// Gets the width of the cell.
        /// </summary>
        /// <type>float</type>
        public float Width { get { return worldCellThisCellBelongsTo.dimensions.width; } }


        /// <summary>
        /// Attaches a GameObject to the cell. If creating a custom Cell Object Loader or Primary Cell Object 
        /// Sub Controller class, you should either let the ObjectGroupCell position the cell object correctly by 
        /// passing in false for objectPositionedCorrectlyAlready, or position the object manually (or instantiate it 
        /// at the correct position) and pass in true. The correct position to manually position the object can be retrieved via 
        /// the CellObjectPosition property.
        /// <para>Explicit Interface Implementation for 
        /// <see cref="IAttachableWorldCell" href="IAttachableWorldCell.html">IAttachableWorldCell</see>
        /// </para>
        /// </summary>
        /// <param name="obj" type = "GameObject" link = "http://docs.unity3d.com/ScriptReference/GameObject.html">
        /// The object to attach to the cell.
        /// </param>
        /// <param name="objectPositionedCorrectlyAlready" type="bool">
        /// If false, the object will be moved to its correct position. If you've already positioned the object at the correct 
        /// location (CellObjectPosition), you must pass in true.
        /// </param>
        /// <displayName id = "AttachCellObjectToCell">IAttachableWorldCell.AttachCellObjectToCell(GameObject, bool)</displayName>
        /// <syntax>void IAttachableWorldCell.AttachCellObjectToCell(GameObject obj)</syntax>
        void IAttachableWorldCell.AttachCellObjectToCell(GameObject obj, bool objectPositionedCorrectlyAlready)
        {
            AttachCellObjectToCell(obj, objectPositionedCorrectlyAlready);
        }

        internal void AttachCellObjectToCell(GameObject obj, bool objectPositionedCorrectlyAlready)
        {
            primaryCellObject = obj;
            if (!objectPositionedCorrectlyAlready)
                obj.transform.position = CellObjectPosition;

            positioned = true;
        }

        /// <summary>
        /// Detaches a cell object from the Object Group Cell. The object is returned and no longer associated with the 
        /// Object Group Cell.
        /// <para>Explicit Interface Implementation for <see cref="IDetachableWorldCell" href="IDetachableWorldCell.html">IDetachableWorldCell</see></para>
        /// </summary>
        /// <displayName id="DetachCellObjectFromCell">IDetachableWorldCell.DetachCellObjectFromCell()</displayName>
        /// <syntax>GameObject IDetachableWorldCell.DetachCellObjectFromCell()</syntax>
        /// <returns type="GameObject">The cell object that was detached from the Object Group Cell.</returns>
        GameObject IDetachableWorldCell.DetachCellObjectFromCell()
        {
            return DetachCellObjectFromCell();
        }

        internal GameObject DetachCellObjectFromCell()
        {
            GameObject obj = primaryCellObject;
            primaryCellObject = null;
            return obj;
        }

        internal void RepositionPrimaryCellObject()
        {
            primaryCellObject.transform.position = CellObjectPosition;
            positioned = true;
        }

        //internal void RemoveUsers(int numUsers)
        //{
        //    users -= numUsers;
        //}

        //internal void AddUsers(int numUsers)
        //{
        //    users += numUsers;
        //}
    }
}
