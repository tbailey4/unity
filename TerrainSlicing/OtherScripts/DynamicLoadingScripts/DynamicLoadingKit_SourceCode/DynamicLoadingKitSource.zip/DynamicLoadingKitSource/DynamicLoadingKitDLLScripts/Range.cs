﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System;
    using UnityEngine;

    [Serializable]
    internal class Range
    {
        [SerializeField]
        internal int firstRow = 1, firstColumn = 1, firstLayer = 1, lastRow, lastColumn, lastLayer;
        
        [SerializeField]
        internal string name = "Default Range";

        internal Range() { }

        internal Range(Range rangeTemplate)
        {
            CopyRangeValues(rangeTemplate);
        }

        internal Range(int lastLayer, int lastRow, int lastColumn)
        {
            this.lastLayer = lastLayer;
            this.lastRow = lastRow;
            this.lastColumn = lastColumn;
        }

        internal Range(string name, int firstRow, int firstColumn, int lastRow, int lastColumn) :
            this(1, lastRow, lastColumn)
        {
            this.name = name;
            this.firstRow = firstRow;
            this.firstColumn = firstColumn;
        }

        internal Range(string name, int firstRow, int firstColumn, int lastRow, int lastColumn, int levelOfDetail) :
            this(1, lastRow, lastColumn)
        {
            this.name = name;
            this.firstRow = firstRow;
            this.firstColumn = firstColumn;
        }

        internal Range(string name, int firstLayer, int firstRow, int firstColumn, int lastLayer, int lastRow, int lastColumn)
            :this(name, firstRow, firstColumn, lastRow, lastColumn)
        {
            this.firstLayer = firstLayer;
            this.lastLayer = lastLayer;
        }

        internal void CopyRangeValues(Range copyFrom)
        {
            name = copyFrom.name;
            firstLayer = copyFrom.firstLayer;
            firstRow = copyFrom.firstRow;
            firstColumn = copyFrom.firstColumn;

            lastLayer = copyFrom.lastLayer;
            lastRow = copyFrom.lastRow;
            lastColumn = copyFrom.lastColumn;
        }
    }
}