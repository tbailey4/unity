﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.

namespace DynamicLoadingKit
{
    using UnityEngine;

    /// <summary>
    /// A Naming Convention implemented as a scriptable object. You can create a NamingConvention asset via 
    /// Assets -> Dynamic Loading Kit -> Create Naming Convention Asset. This can be used to change the naming convention used 
    /// by the Dynamic Loading Kit for various purposes. If a NamingConvention field is visible on a component or tool and no 
    /// asset is provided, the default naming convention will be used (%g_%y_%x or GroupName_Row_Column). 
    /// <para>
    /// You can find more information about 
    /// Naming Conventions in the Quick Guides folder within your project.
    /// </para>
    /// </summary>
    /// <title>NamingConvention Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>NamingConvention</navigationName>
    /// <fileName>NamingConvention.html</fileName>
    /// <syntax>public class NamingConvention : <see href="http://docs.unity3d.com/ScriptReference/ScriptableObject.html">ScriptableObject</see>, <see cref="INamingConvention" href="INamingConvention.html">INamingConvention</see></syntax>
    public class NamingConvention : ScriptableObject, INamingConvention
    {
        [SerializeField]
        internal string format = "%g_x%x_y%y";

        [SerializeField]
        internal bool numberingStartsAt0 = true;

        /// <summary>
        /// Gets the format of the naming convention. This describes the format of the text following the 
        /// group name of the terrain or object (the group name is the name common to all objects/terrain in the same group).
        /// <para>
        /// When setting the format, keep in mind that %x will be replaced by the column number of the object/terrain, %y will be 
        /// replaced by the row number, and %z will be replaced by the layer number. All other characters will be interpreted literally.
        /// </para>
        /// </summary>
        /// <type>string</type>
        public string Format { get { return format; } }

        /// <summary>
        /// Gets a value indicating whether the naming convention calls for row/column/layer numbers to start at 0.
        /// If false, the numbers will start at 1 instead.
        /// </summary>
        /// <type>bool</type>
        public bool NumberingStartsAt0 { get { return numberingStartsAt0; } }
    }

    internal class Default2DNamingConvention : INamingConvention
    {
        public string Format { get { return "%g_%y_%x"; } }
        public bool NumberingStartsAt0 { get { return false; } }
    }

    internal class Default3DNamingConvention : INamingConvention
    {
        public string Format { get { return "%g_%z_%y_%x"; } }
        public bool NumberingStartsAt0 { get { return false; } }
    }
}