//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
	using System;
	using System.Collections;
	using System.Collections.Generic;

    /// <summary>
    /// Provides a base implementation for Cell Strings.
    /// <para>Cell Strings are a special class of objects used in the DLK to load objects and scenes in a more efficient manner 
    /// (reduced garbage generation). You use the <see cref="MatchStringToCell" href="#MatchStringToCell">MatchStringToCell(<see cref="Cell" href="Cell.html">Cell</see>)</see> method to
    /// set the state of a Cell String, and then run comparisons or create string objects using the other methods.</para>
    /// <para>
    /// Now uses 1 based indexing (i.e. passing in a cell with row = 1, column = 1 creates a string of baseName_1_1).
    /// </para>
    /// </summary>
    /// <title>CellString Abstract Class</title>
    /// <category>Cell Strings</category>
    /// <navigationName>CellString</navigationName>
    /// <fileName>CellString.html</fileName>
    /// <syntax>public abstract class CellString</syntax>
    public abstract class CellString
    {
        protected int row, column;
        protected string stringFormat, cellString;
        protected Func<int, int> NumConverter;

        protected abstract bool Is3DCellString { get; }

        /// <summary>
        /// The base name of the Cell String. This should match the base name of the object group associated with your World.
        /// </summary>
        /// <type>readonly string</type>
        /// <defaultValue>Not Applicable</defaultValue>
        public readonly string baseName;
        

        protected CellString(string baseName, INamingConvention namingConvention)
        {
            stringFormat = namingConvention.GetStringFormatVersion(Is3DCellString, baseName);
            //We'll be using string.Format to generate the strings, so we need to replace the %x, %y, and %z in the naming convention 
            //format with {#}
            

            if (namingConvention.NumberingStartsAt0)
                NumConverter = (num) => num - 1;
            else
                NumConverter = (num) => num;
        }

        protected void ReplaceRow(int newRow)
        {
            if (newRow == row)
                return;

            row = newRow;
        }

        protected void ReplaceColumn(int newColumn)
        {
            if (newColumn == column)
                return;

            column = newColumn;
        }


        /// <summary>
        /// Checks whether the provided string (str) matches the Cell String.
        /// </summary>
        /// <param name="str" type="string">The string to compare the Cell String to.</param>
        /// <displayName id = "IsEqualTo">IsEqualTo(string)</displayName>
        /// <syntax>public abstract bool IsEqualTo(string str)</syntax>
        /// <returns type = "bool">A bool indicating whether the input string matches the Cell String.</returns>
        public bool IsEqualTo(string str)
        {
            return str == cellString;
        }

        protected abstract void UpdateCellString();

        /// <summary>
        /// When overridden in a derived class, adjust the Cell String to match the input cell's properties.
        /// </summary>
        /// <param name="cell" type = "Cell" link = "Cell.html">The cell to match this cell string to.</param>
        /// <displayName id = "MatchStringToCell">MatchStringToCell(Cell)</displayName>
        /// <syntax>public abstract void MatchStringToCell(Cell cell)</syntax>
        public abstract void MatchStringToCell(Cell cell);

        /// <summary>
        /// Rreturns a string representing the Cell String.
        /// </summary>
        /// <displayName id = "ToString">ToString()</displayName>
        /// <syntax>public abstract string ToString()</syntax>
        /// <returns type = "string">A string representing the Cell String</returns>
        public override string ToString()
        {
            return cellString;
        }
    }

    /// <summary>
    /// A Cell String class designed to be used with two dimensional worlds.
    /// <para>You should only need to worry about this class when creating custom 
    /// <see cref="CellObjectLoader" href="CellObjectLoader.html">Cell Object Loaders</see>, but if you need more information 
    /// about what this class is for, please visit the <see cref="CellString" href="CellString.html">CellString</see> page.</para>
    /// <para>
    /// Now uses 1 based indexing (i.e. passing in a cell with row = 1, column = 1 creates a string of baseName_1_1).
    /// </para>
    /// </summary>
    /// <title>CellString2D Class</title>
    /// <category>Cell Strings</category>
    /// <navigationName>CellString2D</navigationName>
    /// <fileName>CellString2D.html</fileName>
    /// <syntax>public class CellString2D : <see cref="CellString" href="CellString.html">CellString</see></syntax>
    public sealed class CellString2D : CellString
    {
        protected sealed override bool Is3DCellString { get { return false; } }

        /// <summary>
        /// Initializes a new instance of the CellString2D with the specified baseName, maxRow, and maxColumn.
        /// </summary>
        /// <param name="baseName" type = "string">The base name of the Cell String which will remain constant for the life of the Cell String.</param>
        /// <param name="maxRow" type="int">The maximum possible row value this Cell String will need to handle.</param>
        /// <param name="maxColumn" type="int">The maximum possible column value this Cell String will need to handle.</param>
        /// <displayName id = "CellString2D">CellString2D(string, int, int)</displayName>
        /// <syntax>public CellString2D(string baseName, int maxRow, int maxColumn)</syntax>
        public CellString2D(string baseName, INamingConvention namingConvention)
            : base(baseName, namingConvention){ }

        /// <summary>
        /// Adjust the Cell String to match the input cell's properties (its row and column indexes).
        /// </summary>
        /// <param name="cell" type = "Cell" link = "Cell.html">The cell to match this cell string to.</param>
        /// <displayName id = "MatchStringToCell">MatchStringToCell(Cell)</displayName>
        /// <syntax>public sealed override void MatchStringToCell(Cell cell)</syntax>
        public sealed override void MatchStringToCell(Cell cell)
        {
            ReplaceRow(NumConverter(cell.row));
            ReplaceColumn(NumConverter(cell.column));
            UpdateCellString();
        }

        protected sealed override void UpdateCellString()
        {
            cellString = string.Format(stringFormat, column, row);
        }
    }

    /// <summary>
    /// A Cell String class designed to be used with three dimensional worlds.
    /// <para>You should only need to worry about this class when creating custom 
    /// <see cref="CellObjectLoader" href="CellObjectLoader.html">Cell Object Loaders</see>, but if you need more information 
    /// about what this class is for, please visit the <see cref="CellString" href="CellString.html">CellString</see> page.</para>
    /// <para>
    /// Now uses 1 based indexing (i.e. passing in a cell with layer = 1, row = 1, column = 1 creates a string of baseName_1_1_1).
    /// </para>
    /// </summary>
    /// <title>CellString3D Class</title>
    /// <category>Cell Strings</category>
    /// <navigationName>CellString3D</navigationName>
    /// <fileName>CellString3D.html</fileName>
    /// <syntax>public class CellString3D : <see cref="CellString" href="CellString.html">CellString</see></syntax>
    public class CellString3D : CellString
    {
        int layer;

        protected sealed override bool Is3DCellString { get { return true; } }

        /// <summary>
        /// Initializes a new instance of the CellString3D with the specified baseName, maxLayer, maxRow, and maxColumn.
        /// </summary>
        /// <param name="baseName" type = "string">The base name of the Cell String which will remain constant for the life of the Cell String.</param>
        /// <param name="maxLayer" type="int">The maximum possible layer value this Cell String will need to handle.</param>
        /// <param name="maxRow" type="int">The maximum possible row value this Cell String will need to handle.</param>
        /// <param name="maxColumn" type="int">The maximum possible column value this Cell String will need to handle.</param>
        /// <displayName id = "CellString3D">CellString3D(string, int, int, int)</displayName>
        /// <syntax>public CellString3D(string baseName, int maxLayer, int maxRow, int maxColumn)</syntax>
        public CellString3D(string baseName, INamingConvention namingConvention)
            : base(baseName, namingConvention){ }

        void ReplaceLayer(int newLayer)
        {
            if (newLayer == layer)
                return;

            layer = newLayer;
        }

        /// <summary>
        /// Adjust the Cell String to match the input cell's properties (its layer, row and column indexes).
        /// </summary>
        /// <param name="cell" type = "Cell" link = "Cell.html">The cell to match this cell string to.</param>
        /// <displayName id = "MatchStringToCell">MatchStringToCell(Cell)</displayName>
        /// <syntax>public sealed override void MatchStringToCell(Cell cell)</syntax>
        public sealed override void MatchStringToCell(Cell cell)
        {
            ReplaceLayer(NumConverter(cell.layer));
            ReplaceRow(cell.row);
            ReplaceColumn(cell.column);
            UpdateCellString();
        }

        protected sealed override void UpdateCellString()
        {
            cellString = string.Format(stringFormat, column, row, layer);
        }
    }




















    ///// <summary>
    ///// Provides a base implementation for Cell Strings.
    ///// <para>Cell Strings are a special class of objects used in the DLK to load objects and scenes in a more efficient manner 
    ///// (reduced garbage generation). You use the <see cref="MatchStringToCell" href="#MatchStringToCell">MatchStringToCell(<see cref="Cell" href="Cell.html">Cell</see>)</see> method to
    ///// set the state of a Cell String, and then run comparisons or create string objects using the other methods.</para>
    ///// <para>
    ///// Now uses 1 based indexing (i.e. passing in a cell with row = 1, column = 1 creates a string of baseName_1_1).
    ///// </para>
    ///// </summary>
    ///// <title>CellString Abstract Class</title>
    ///// <category>Cell Strings</category>
    ///// <navigationName>CellString</navigationName>
    ///// <fileName>CellString.html</fileName>
    ///// <syntax>public abstract class CellString</syntax>
    //public abstract class CellString
    //{
    //    const int IntToASCIIModifier = 48;

    //    int row, column;

    //    protected char[] rowBuffer, columnBuffer;
    //    protected int rowDigitsInUse, columnDigitsInUse;
    //    protected bool startNumberingAt0;
    //    protected string namingConventionFormat;

    //    /// <summary>
    //    /// The base name of the Cell String. This should match the base name of the object group associated with your World.
    //    /// </summary>
    //    /// <type>readonly string</type>
    //    /// <defaultValue>Not Applicable</defaultValue>
    //    public readonly string baseName;

        
    //    protected CellString(string baseName, int maxRow, int maxColumn)
    //    {
    //        row = 1;
    //        column = 1;
    //        rowDigitsInUse = 1;
    //        columnDigitsInUse = 1;

    //        rowBuffer = new char[DetermineDigitsNeededToRepresentNumber(maxRow)];
    //        rowBuffer[rowBuffer.Length - 1] = '1';

    //        columnBuffer = new char[DetermineDigitsNeededToRepresentNumber(maxColumn)];
    //        columnBuffer[columnBuffer.Length - 1] = '1';

    //        this.baseName = baseName;
    //    }

    //    protected int StoreNewValueInBuffer(int newValue, char[] buffer)
    //    {
    //        int startIndex = buffer.Length - 1;
    //        int index = startIndex;
    //        while (newValue > 0)
    //        {
    //            int initialValue = newValue;
    //            newValue /= 10;
    //            buffer[index] = (char)((initialValue - 10 * newValue) + IntToASCIIModifier);
    //            index--;
    //        }

    //        return startIndex - index;
    //    }

    //    protected int DetermineDigitsNeededToRepresentNumber(int number)
    //    {
    //        int digitsNeeded = 1; //We'll need at least one digit
    //        number /= 10;
    //        while (number > 0)
    //        {
    //            digitsNeeded++;
    //            number /= 10;
    //        }
    //        return digitsNeeded;
    //    }

    //    protected void ReplaceRow(int newRow)
    //    {
    //        if (newRow == row)
    //            return;

    //        rowDigitsInUse = StoreNewValueInBuffer(newRow, rowBuffer);
    //        row = newRow;
    //    }

    //    protected void ReplaceColumn(int newColumn)
    //    {
    //        if (newColumn == column)
    //            return;

    //        columnDigitsInUse = StoreNewValueInBuffer(newColumn, columnBuffer);
    //        column = newColumn;
    //    }

    //    protected bool DoesColumnMatch(string str, ref int strIndex)
    //    {
    //        int startIndex = columnBuffer.Length - 1;
    //        int endIndex = startIndex - columnDigitsInUse;

    //        for (int i = startIndex; i > endIndex; i--, strIndex--)
    //        {
    //            if (columnBuffer[i] != str[strIndex])
    //                return false;
    //        }
    //        return true;
    //    }

    //    protected bool DoesRowMatch(string str, ref int strIndex)
    //    {
    //        int startIndex = rowBuffer.Length - 1;
    //        int endIndex = startIndex - rowDigitsInUse;

    //        for (int i = startIndex; i > endIndex; i--, strIndex--)
    //        {
    //            if (rowBuffer[i] != str[strIndex])
    //                return false;
    //        }
    //        return true;
    //    }

    //    protected bool DoesBaseNameMatch(string str)
    //    {
    //        for (int i = 0; i < baseName.Length; i++)
    //        {
    //            if (baseName[i] != str[i])
    //                return false;
    //        }
    //        return true;
    //    }

    //    /// <summary>
    //    /// When overridden in a derived class, checks whether the provided string (str) matches the Cell String.
    //    /// </summary>
    //    /// <param name="str" type="string">The string to compare the Cell String to.</param>
    //    /// <displayName id = "IsEqualTo">IsEqualTo(string)</displayName>
    //    /// <syntax>public abstract bool IsEqualTo(string str)</syntax>
    //    /// <returns type = "bool">A bool indicating whether the input string matches the Cell String.</returns>
    //    public abstract bool IsEqualTo(string str);

    //    /// <summary>
    //    /// When overridden in a derived class, adjust the Cell String to match the input cell's properties.
    //    /// </summary>
    //    /// <param name="cell" type = "Cell" link = "Cell.html"></param>
    //    /// <displayName id = "MatchStringToCell">MatchStringToCell(Cell)</displayName>
    //    /// <syntax>public abstract void MatchStringToCell(Cell cell)</syntax>
    //    public abstract void MatchStringToCell(Cell cell);

    //    /// <summary>
    //    /// When overridden in a derived class, returns a string representing the Cell String.
    //    /// </summary>
    //    /// <displayName id = "ToString">ToString()</displayName>
    //    /// <syntax>public abstract string ToString()</syntax>
    //    /// <returns type = "string">A string representing the Cell String</returns>
    //    public override abstract string ToString();
    //}

    ///// <summary>
    ///// A Cell String class designed to be used with two dimensional worlds.
    ///// <para>You should only need to worry about this class when creating custom 
    ///// <see cref="CellObjectLoader" href="CellObjectLoader.html">Cell Object Loaders</see>, but if you need more information 
    ///// about what this class is for, please visit the <see cref="CellString" href="CellString.html">CellString</see> page.</para>
    ///// <para>
    ///// Now uses 1 based indexing (i.e. passing in a cell with row = 1, column = 1 creates a string of baseName_1_1).
    ///// </para>
    ///// </summary>
    ///// <title>CellString2D Class</title>
    ///// <category>Cell Strings</category>
    ///// <navigationName>CellString2D</navigationName>
    ///// <fileName>CellString2D.html</fileName>
    ///// <syntax>public class CellString2D : <see cref="CellString" href="CellString.html">CellString</see></syntax>
    //public sealed class CellString2D : CellString
    //{
    //    int expectedLength;
    //    char[] toStringBuffer;

    //    /// <summary>
    //    /// Initializes a new instance of the CellString2D with the specified baseName, maxRow, and maxColumn.
    //    /// </summary>
    //    /// <param name="baseName" type = "string">The base name of the Cell String which will remain constant for the life of the Cell String.</param>
    //    /// <param name="maxRow" type="int">The maximum possible row value this Cell String will need to handle.</param>
    //    /// <param name="maxColumn" type="int">The maximum possible column value this Cell String will need to handle.</param>
    //    /// <displayName id = "CellString2D">CellString2D(string, int, int)</displayName>
    //    /// <syntax>public CellString2D(string baseName, int maxRow, int maxColumn)</syntax>
    //    public CellString2D(string baseName, int maxRow, int maxColumn)
    //         : base(baseName, maxRow, maxColumn)
    //    {
    //        expectedLength = baseName.Length + 2 + rowDigitsInUse + columnDigitsInUse;
    //        toStringBuffer = new char[expectedLength];
    //        int toStringBufferIndex = 0;
    //        for (; toStringBufferIndex < baseName.Length; toStringBufferIndex++)
    //            toStringBuffer[toStringBufferIndex] = baseName[toStringBufferIndex];

    //        toStringBuffer[toStringBufferIndex] = '_';
    //    }

    //    /// <summary>
    //    /// Checks whether the provided string (str) matches the Cell String.
    //    /// </summary>
    //    /// <param name="str" type="string">The string to compare the Cell String to.</param>
    //    /// <displayName id = "IsEqualTo">IsEqualTo(string)</displayName>
    //    /// <syntax>public sealed override bool IsEqualTo(string str)</syntax>
    //    /// <returns type = "bool">A bool indicating whether the input string matches the Cell String.</returns>
    //    public sealed override bool IsEqualTo(string str)
    //    {
    //        if (str.Length != expectedLength)
    //            return false;

    //        int strIndex = str.Length - 1;
    //        if (!DoesColumnMatch(str, ref strIndex))
    //            return false;

    //        if (str[strIndex--] != '_')
    //            return false;

    //        if (!DoesRowMatch(str, ref strIndex))
    //            return false;

    //        if (str[strIndex--] != '_')
    //            return false;

    //        return DoesBaseNameMatch(str);
    //    }

    //    /// <summary>
    //    /// Adjust the Cell String to match the input cell's properties (its row and column indexes).
    //    /// </summary>
    //    /// <param name="cell" type = "Cell" link = "Cell.html"></param>
    //    /// <displayName id = "MatchStringToCell">MatchStringToCell(Cell)</displayName>
    //    /// <syntax>public sealed override void MatchStringToCell(Cell cell)</syntax>
    //    public sealed override void MatchStringToCell(Cell cell)
    //    {
    //        ReplaceRow(cell.row);
    //        ReplaceColumn(cell.column);
    //        expectedLength = baseName.Length + 2 + rowDigitsInUse + columnDigitsInUse;
    //    }

    //    /// <summary>
    //    /// Returns a string representing the Cell String.
    //    /// <para>This is not a trivial operation (in terms of performance and garbage generation) so you should cache this
    //    /// string whenever possible. Note, however, that if you change the Cell String via 
    //    /// <see cref="MatchStringToCell" href="#MatchStringToCell">MatchStringToCell</see>, you should call this method to retrieve
    //    /// a new string representing the Cell String's current state.</para>
    //    /// </summary>
    //    /// <displayName id = "ToString">ToString()</displayName>
    //    /// <syntax>public sealed override string ToString()</syntax>
    //    /// <returns type = "string">A string representing the Cell String</returns>
    //    public sealed override string ToString()
    //    {
    //        if (toStringBuffer.Length != expectedLength)
    //            Array.Resize<char>(ref toStringBuffer, expectedLength);

    //        int toStringBufferIndex = baseName.Length + 1;

    //        for (int i = rowBuffer.Length - rowDigitsInUse; i < rowBuffer.Length; i++, toStringBufferIndex++)
    //            toStringBuffer[toStringBufferIndex] = rowBuffer[i];

    //        toStringBuffer[toStringBufferIndex++] = '_';

    //        for (int i = columnBuffer.Length - columnDigitsInUse; i < columnBuffer.Length; i++, toStringBufferIndex++)
    //            toStringBuffer[toStringBufferIndex] = columnBuffer[i];

    //        return new string(toStringBuffer);
    //    }
    //}

    ///// <summary>
    ///// A Cell String class designed to be used with three dimensional worlds.
    ///// <para>You should only need to worry about this class when creating custom 
    ///// <see cref="CellObjectLoader" href="CellObjectLoader.html">Cell Object Loaders</see>, but if you need more information 
    ///// about what this class is for, please visit the <see cref="CellString" href="CellString.html">CellString</see> page.</para>
    ///// <para>
    ///// Now uses 1 based indexing (i.e. passing in a cell with layer = 1, row = 1, column = 1 creates a string of baseName_1_1_1).
    ///// </para>
    ///// </summary>
    ///// <title>CellString3D Class</title>
    ///// <category>Cell Strings</category>
    ///// <navigationName>CellString3D</navigationName>
    ///// <fileName>CellString3D.html</fileName>
    ///// <syntax>public class CellString3D : <see cref="CellString" href="CellString.html">CellString</see></syntax>
    //public class CellString3D : CellString
    //{
    //    int expectedLength, layer, layerDigitsInUse;
    //    char[] toStringBuffer, layerBuffer;

    //    /// <summary>
    //    /// Initializes a new instance of the CellString3D with the specified baseName, maxLayer, maxRow, and maxColumn.
    //    /// </summary>
    //    /// <param name="baseName" type = "string">The base name of the Cell String which will remain constant for the life of the Cell String.</param>
    //    /// <param name="maxLayer" type="int">The maximum possible layer value this Cell String will need to handle.</param>
    //    /// <param name="maxRow" type="int">The maximum possible row value this Cell String will need to handle.</param>
    //    /// <param name="maxColumn" type="int">The maximum possible column value this Cell String will need to handle.</param>
    //    /// <displayName id = "CellString3D">CellString3D(string, int, int, int)</displayName>
    //    /// <syntax>public CellString3D(string baseName, int maxLayer, int maxRow, int maxColumn)</syntax>
    //    public CellString3D(string baseName, int maxLayer, int maxRow, int maxColumn)
    //        : base(baseName, maxRow, maxColumn)
    //    {
    //        layer = 1;
    //        layerDigitsInUse = 1;
    //        layerBuffer = new char[DetermineDigitsNeededToRepresentNumber(maxLayer)];
    //        layerBuffer[layerBuffer.Length - 1] = '1';

    //        expectedLength = baseName.Length + 3 + rowDigitsInUse + columnDigitsInUse + layerDigitsInUse;
    //        toStringBuffer = new char[expectedLength];
    //        int toStringBufferIndex = 0;
    //        for (; toStringBufferIndex < baseName.Length; toStringBufferIndex++)
    //            toStringBuffer[toStringBufferIndex] = baseName[toStringBufferIndex];

    //        toStringBuffer[toStringBufferIndex] = '_';
    //    }

    //    void ReplaceLayer(int newLayer)
    //    {
    //        if (newLayer == layer)
    //            return;

    //        layerDigitsInUse = StoreNewValueInBuffer(newLayer, layerBuffer);
    //        layer = newLayer;
    //    }

    //    bool DoesLayerMatch(string str, ref int strIndex)
    //    {
    //        int startIndex = layerBuffer.Length - 1;
    //        int endIndex = startIndex - layerDigitsInUse;

    //        for (int i = startIndex; i > endIndex; i--, strIndex--)
    //        {
    //            if (layerBuffer[i] != str[strIndex])
    //                return false;
    //        }
    //        return true;
    //    }

    //    /// <summary>
    //    /// Checks whether the provided string (str) matches the Cell String.
    //    /// </summary>
    //    /// <param name="str" type="string">The string to compare the Cell String to.</param>
    //    /// <displayName id = "IsEqualTo">IsEqualTo(string)</displayName>
    //    /// <syntax>public sealed override bool IsEqualTo(string str)</syntax>
    //    /// <returns type = "bool">A bool indicating whether the input string matches the Cell String.</returns>
    //    public sealed override bool IsEqualTo(string str)
    //    {
    //        if (str.Length != expectedLength)
    //            return false;

    //        int strIndex = str.Length - 1;

    //        if (!DoesColumnMatch(str, ref strIndex))
    //            return false;

    //        if (str[strIndex--] != '_')
    //            return false;

    //        if (!DoesRowMatch(str, ref strIndex))
    //            return false;

    //        if (str[strIndex--] != '_')
    //            return false;

    //        if (!DoesLayerMatch(str, ref strIndex))
    //            return false;

    //        if (str[strIndex--] != '_')
    //            return false;

    //        return DoesBaseNameMatch(str);
    //    }

    //    /// <summary>
    //    /// Adjust the Cell String to match the input cell's properties (its layer, row and column indexes).
    //    /// </summary>
    //    /// <param name="cell" type = "Cell" link = "Cell.html"></param>
    //    /// <displayName id = "MatchStringToCell">MatchStringToCell(Cell)</displayName>
    //    /// <syntax>public sealed override void MatchStringToCell(Cell cell)</syntax>
    //    public sealed override void MatchStringToCell(Cell cell)
    //    {
    //        ReplaceLayer(cell.layer);
    //        ReplaceRow(cell.row);
    //        ReplaceColumn(cell.column);
    //        expectedLength = baseName.Length + 3 + rowDigitsInUse + columnDigitsInUse + layerDigitsInUse;
    //    }

    //    /// <summary>
    //    /// Returns a string representing the Cell String.
    //    /// <para>This is not a trivial operation (in terms of performance and garbage generation) so you should cache this
    //    /// string whenever possible. Note, however, that if you change the Cell String via 
    //    /// <see cref="MatchStringToCell" href="#MatchStringToCell">MatchStringToCell</see>, you should call this method to retrieve
    //    /// a new string representing the Cell String's current state.</para>
    //    /// </summary>
    //    /// <displayName id = "ToString">ToString()</displayName>
    //    /// <syntax>public sealed override string ToString()</syntax>
    //    /// <returns type = "string">A string representing the Cell String</returns>
    //    public sealed override string ToString()
    //    {
    //        if (toStringBuffer.Length != expectedLength)
    //            Array.Resize<char>(ref toStringBuffer, expectedLength);

    //        int toStringBufferIndex = baseName.Length + 1;

    //        for (int i = layerBuffer.Length - layerDigitsInUse; i < layerBuffer.Length; i++, toStringBufferIndex++)
    //            toStringBuffer[toStringBufferIndex] = layerBuffer[i];

    //        toStringBuffer[toStringBufferIndex++] = '_';

    //        for (int i = rowBuffer.Length - rowDigitsInUse; i < rowBuffer.Length; i++, toStringBufferIndex++)
    //            toStringBuffer[toStringBufferIndex] = rowBuffer[i];

    //        toStringBuffer[toStringBufferIndex++] = '_';

    //        for (int i = columnBuffer.Length - columnDigitsInUse; i < columnBuffer.Length; i++, toStringBufferIndex++)
    //            toStringBuffer[toStringBufferIndex] = columnBuffer[i];

    //        return new string(toStringBuffer);
    //    }
    //}
}