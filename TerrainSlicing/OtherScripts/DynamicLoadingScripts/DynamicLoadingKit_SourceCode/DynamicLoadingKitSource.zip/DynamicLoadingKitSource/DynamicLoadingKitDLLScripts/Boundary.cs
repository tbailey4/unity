//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System;

    internal class Boundary
    {
        public float west, east, south, north, top, bottom;

        InternalBoundary internalBoundary;

        public Boundary() { }

        public Boundary(WorldType worldTypeOfWorldBoundaryIsOn)
        {
            ChangeWorldType(worldTypeOfWorldBoundaryIsOn);
        }

        public Boundary(WorldType worldTypeOfWorldBoundaryIsOn, Vector3 origin, float eastAndWestBoundaryDistanceFromOrigin, 
            float northAndSouthBoundaryDistanceFromOrigin, float topAndBottomBoundaryDistanceFromOrigin)
        {
            ChangeWorldType(worldTypeOfWorldBoundaryIsOn);
            east = origin.x + eastAndWestBoundaryDistanceFromOrigin;
            west = origin.x - eastAndWestBoundaryDistanceFromOrigin;

            internalBoundary.SetNorthAndSouthBoundaries(origin, northAndSouthBoundaryDistanceFromOrigin);
            internalBoundary.SetTopAndBottomBoundaries(origin, topAndBottomBoundaryDistanceFromOrigin);
        }

        public void ChangeWorldType(WorldType newWorldType)
        {
            if (newWorldType == WorldType.Three_Dimensional)
            {
                if (internalBoundary is BoundaryXYZ)
                    return;

                internalBoundary = new BoundaryXYZ(this);
            }
            else if (newWorldType == WorldType.Two_Dimensional_On_XY_Axes)
            {
                if (internalBoundary is BoundaryXY)
                    return;
                internalBoundary = new BoundaryXY(this);
            }
            else
            {
                if (internalBoundary is BoundaryXZ)
                    return;

                internalBoundary = new BoundaryXZ(this);
            }
        }




        public void WereBoundariesCrossed(Vector3 position, out BoundaryCrossed eastOrWestBoundaryCrossed,
                out BoundaryCrossed northOrSouthBoundaryCrossed, out BoundaryCrossed topOrBottomBoundaryCrossed)
        {
            eastOrWestBoundaryCrossed = WasEastOrWestBoundaryCrossed(position);
            northOrSouthBoundaryCrossed = WasNorthOrSouthBoundaryCrossed(position);
            topOrBottomBoundaryCrossed = WasTopOrBottomBoundaryCrossed(position);
        }

        public BoundaryCrossed WasEastOrWestBoundaryCrossed(Vector3 position)
        {
            if (position.x > east)
                return BoundaryCrossed.East;
            else if (position.x < west)
                return BoundaryCrossed.West;
            else
                return BoundaryCrossed.None;
        }

        public BoundaryCrossed WasNorthOrSouthBoundaryCrossed(Vector3 position)
        {
            return internalBoundary.WasNorthOrSouthBoundaryCrossed(position);
        }

        public BoundaryCrossed WasTopOrBottomBoundaryCrossed(Vector3 position)
        {
            return internalBoundary.WasTopOrBottomBoundaryCrossed(position);
        }

        public void AdjustBoundaryByAmount(Vector3 amount)
        {
            internalBoundary.AdjustBoundaryByAmount(amount);
        }

        public void SetWestSouthAndBottomBoundaries(Vector3 positionOfCellToUseToSetBoundary)
        {
            internalBoundary.SetWestSouthBottomBoundaries(positionOfCellToUseToSetBoundary);
        }

        public void SetEastNorthAndTopBoundaries(Vector3 positionOfCellToUseToSetBoundary, CellDimensions dimensionsOfCellToUseToSetBoundary)
        {
            internalBoundary.SetEastNorthTopBoundaries(positionOfCellToUseToSetBoundary, dimensionsOfCellToUseToSetBoundary);
        }

        public bool IsPositionWestOfWestBoundary(Vector3 position)
        {
            return position.x < west;
        }

        public bool IsPositionEastOfEastBoundary(Vector3 position)
        {
            return position.x > east;
        }

        public bool IsPositionNorthOfNorthBoundary(Vector3 position)
        {
            return internalBoundary.IsPositionNorthOfNorthBoundary(position);
        }

        public bool IsPositionSouthOfSouthBoundary(Vector3 position)
        {
            return internalBoundary.IsPositionSouthOfSouthBoundary(position);
        }

        public bool IsPositionAboveTopBoundary(Vector3 position)
        {
            return internalBoundary.IsPositionAboveTopBoundary(position);
        }

        public bool IsPositionBelowBottomBoundary(Vector3 position)
        {
            return internalBoundary.IsPositionBelowBottomBoundary(position);
        }

        abstract class InternalBoundary
        {
            protected Boundary parent;

            public InternalBoundary(Boundary parent) { this.parent = parent; }

            public abstract BoundaryCrossed WasNorthOrSouthBoundaryCrossed(Vector3 position);

            public abstract BoundaryCrossed WasTopOrBottomBoundaryCrossed(Vector3 position);

            public abstract void SetNorthAndSouthBoundaries(Vector3 origin, float northAndSouthBoundaryDistanceFromOrigin);

            public abstract void SetTopAndBottomBoundaries(Vector3 origin, float topAndBottomBoundaryDistanceFromOrigin);

            public abstract void AdjustBoundaryByAmount(Vector3 amount);

            public abstract void SetWestSouthBottomBoundaries(Vector3 positionOfCellToUseToSetBoundary);

            public abstract void SetEastNorthTopBoundaries(Vector3 positionOfCellToUseToSetBoundary, CellDimensions dimensionsOfCellToUseToSetBoundary);

            public abstract bool IsPositionNorthOfNorthBoundary(Vector3 position);

            public abstract bool IsPositionSouthOfSouthBoundary(Vector3 position);

            public abstract bool IsPositionAboveTopBoundary(Vector3 position);

            public abstract bool IsPositionBelowBottomBoundary(Vector3 position);
        }

        class BoundaryXY : InternalBoundary
        {
            public BoundaryXY(Boundary parent) : base(parent) { }

            public sealed override BoundaryCrossed WasNorthOrSouthBoundaryCrossed(Vector3 position)
            {
                if (position.y > parent.north)
                    return BoundaryCrossed.North;
                else if (position.y < parent.south)
                    return BoundaryCrossed.South;
                else
                    return BoundaryCrossed.None;
            }

            public sealed override BoundaryCrossed WasTopOrBottomBoundaryCrossed(Vector3 position)
            {
                return BoundaryCrossed.None;
            }

            public sealed override void SetNorthAndSouthBoundaries(Vector3 origin, float northAndSouthBoundaryDistanceFromOrigin)
            {
                parent.north = origin.y + northAndSouthBoundaryDistanceFromOrigin;
                parent.south = origin.y - northAndSouthBoundaryDistanceFromOrigin;
            }

            public sealed override void SetTopAndBottomBoundaries(Vector3 origin, float topAndBottomBoundaryDistanceFromOrigin)
            {
                return;
            }

            public sealed override void AdjustBoundaryByAmount(Vector3 amount)
            {
                parent.west += amount.x;
                parent.east += amount.x;
                parent.north += amount.y;
                parent.south += amount.y;
            }

            public sealed override void SetWestSouthBottomBoundaries(Vector3 positionOfCellToUseToSetBoundary)
            {
                parent.west = positionOfCellToUseToSetBoundary.x;
                parent.south = positionOfCellToUseToSetBoundary.y;
            }

            public sealed override void SetEastNorthTopBoundaries(Vector3 positionOfCellToUseToSetBoundary, CellDimensions dimensionsOfCellToUseToSetBoundary)
            {
                parent.east = positionOfCellToUseToSetBoundary.x + dimensionsOfCellToUseToSetBoundary.width;
                parent.north = positionOfCellToUseToSetBoundary.y + dimensionsOfCellToUseToSetBoundary.length;
            }

            public sealed override bool IsPositionNorthOfNorthBoundary(Vector3 position)
            {
                return position.y > parent.north;
            }

            public sealed override bool IsPositionSouthOfSouthBoundary(Vector3 position)
            {
                return position.y < parent.south;
            }

            public sealed override bool IsPositionAboveTopBoundary(Vector3 position)
            {
                return false;
            }

            public sealed override bool IsPositionBelowBottomBoundary(Vector3 position)
            {
                return false;
            }
        }

        class BoundaryXZ : InternalBoundary
        {
            public BoundaryXZ(Boundary parent) : base(parent) { }

            public sealed override BoundaryCrossed WasNorthOrSouthBoundaryCrossed(Vector3 position)
            {
                if (position.z > parent.north)
                    return BoundaryCrossed.North;
                else if (position.z < parent.south)
                    return BoundaryCrossed.South;
                else
                    return BoundaryCrossed.None;
            }

            public sealed override BoundaryCrossed WasTopOrBottomBoundaryCrossed(Vector3 position)
            {
                return BoundaryCrossed.None;
            }

            public sealed override void SetNorthAndSouthBoundaries(Vector3 origin, float northAndSouthBoundaryDistanceFromOrigin)
            {
                parent.north = origin.z + northAndSouthBoundaryDistanceFromOrigin;
                parent.south = origin.z - northAndSouthBoundaryDistanceFromOrigin;
            }

            public sealed override void SetTopAndBottomBoundaries(Vector3 origin, float topAndBottomBoundaryDistanceFromOrigin)
            {
                return;
            }

            public sealed override void AdjustBoundaryByAmount(Vector3 amount)
            {
                parent.west += amount.x;
                parent.east += amount.x;
                parent.north += amount.z;
                parent.south += amount.z;
            }

            public sealed override void SetWestSouthBottomBoundaries(Vector3 positionOfCellToUseToSetBoundary)
            {
                parent.west = positionOfCellToUseToSetBoundary.x;
                parent.south = positionOfCellToUseToSetBoundary.z;
            }

            public sealed override void SetEastNorthTopBoundaries(Vector3 positionOfCellToUseToSetBoundary, CellDimensions dimensionsOfCellToUseToSetBoundary)
            {
                parent.east = positionOfCellToUseToSetBoundary.x + dimensionsOfCellToUseToSetBoundary.width;
                parent.north = positionOfCellToUseToSetBoundary.z + dimensionsOfCellToUseToSetBoundary.length;
            }

            public sealed override bool IsPositionNorthOfNorthBoundary(Vector3 position)
            {
                return position.z > parent.north;
            }

            public sealed override bool IsPositionSouthOfSouthBoundary(Vector3 position)
            {
                return position.z < parent.south;
            }

            public sealed override bool IsPositionAboveTopBoundary(Vector3 position)
            {
                return false;
            }

            public sealed override bool IsPositionBelowBottomBoundary(Vector3 position)
            {
                return false;
            }
        }

        class BoundaryXYZ : InternalBoundary
        {
            public BoundaryXYZ(Boundary parent) : base(parent) { }

            public sealed override BoundaryCrossed WasNorthOrSouthBoundaryCrossed(Vector3 position)
            {
                if (position.z > parent.north)
                    return BoundaryCrossed.North;
                else if (position.z < parent.south)
                    return BoundaryCrossed.South;
                else
                    return BoundaryCrossed.None;
            }

            public sealed override BoundaryCrossed WasTopOrBottomBoundaryCrossed(Vector3 position)
            {
                if (position.y > parent.top)
                    return BoundaryCrossed.Top;
                else if (position.y < parent.bottom)
                    return BoundaryCrossed.Bottom;
                else
                    return BoundaryCrossed.None;
            }

            public sealed override void SetNorthAndSouthBoundaries(Vector3 origin, float northAndSouthBoundaryDistanceFromOrigin)
            {
                parent.north = origin.z + northAndSouthBoundaryDistanceFromOrigin;
                parent.south = origin.z - northAndSouthBoundaryDistanceFromOrigin;
            }

            public sealed override void SetTopAndBottomBoundaries(Vector3 origin, float topAndBottomBoundaryDistanceFromOrigin)
            {
                parent.top = origin.y + topAndBottomBoundaryDistanceFromOrigin;
                parent.bottom = origin.y - topAndBottomBoundaryDistanceFromOrigin;
            }

            public sealed override void AdjustBoundaryByAmount(Vector3 amount)
            {
                parent.west += amount.x;
                parent.east += amount.x;
                parent.north += amount.z;
                parent.south += amount.z;
                parent.top += amount.y;
                parent.bottom += amount.y;
            }

            public sealed override void SetWestSouthBottomBoundaries(Vector3 positionOfCellToUseToSetBoundary)
            {
                parent.west = positionOfCellToUseToSetBoundary.x;
                parent.south = positionOfCellToUseToSetBoundary.z;
                parent.bottom = positionOfCellToUseToSetBoundary.y;
            }

            public sealed override void SetEastNorthTopBoundaries(Vector3 positionOfCellToUseToSetBoundary, CellDimensions dimensionsOfCellToUseToSetBoundary)
            {
                parent.east = positionOfCellToUseToSetBoundary.x + dimensionsOfCellToUseToSetBoundary.width;
                parent.north = positionOfCellToUseToSetBoundary.z + dimensionsOfCellToUseToSetBoundary.length;
                parent.top = positionOfCellToUseToSetBoundary.y + dimensionsOfCellToUseToSetBoundary.height;
            }

            public sealed override bool IsPositionNorthOfNorthBoundary(Vector3 position)
            {
                return position.z > parent.north;
            }

            public sealed override bool IsPositionSouthOfSouthBoundary(Vector3 position)
            {
                return position.z < parent.south;
            }

            public sealed override bool IsPositionAboveTopBoundary(Vector3 position)
            {
                return position.y > parent.top;
            }

            public sealed override bool IsPositionBelowBottomBoundary(Vector3 position)
            {
                return position.y < parent.bottom;
            }
        }
    }
}