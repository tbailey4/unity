﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Handles the registration of multiple users of any reference type. 
    /// </summary>
    /// <title>RegistrationHandler&lt;T&gt; Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>RegistrationHandler</navigationName>
    /// <fileName>RegistrationHandler.html</fileName>
    /// <syntax>public class RegistrationHandler&lt;T&gt; where T : class</syntax>
    public sealed class RegistrationHandler<T> where T : class
    {
        T[] registrantSlots;
        Stack<int> unusedRegistrationIDs;
        int registrantsRegistered;

        /// <summary>
        /// Initializes a new instance of the RegistrationHandler class, with a default capacity of 4.
        /// </summary>
        /// <displayName id = "RegistrationHandler1">RegistrationHandler()</displayName>
        /// <syntax>public RegistrationHandler()</syntax>
        public RegistrationHandler()
        {
            registrantSlots = new T[4];
            unusedRegistrationIDs = new Stack<int>();
            for (int i = 3; i >= 0; i--)
                unusedRegistrationIDs.Push(i);
        }

        /// <summary>
        /// Initializes a new instance of the RegistrationHandler class, with a capacity of intitialCapacity.
        /// </summary>
        /// <param name="intitialCapacity" type = "int">The initial capacity of the registration handler. If a user is registered
        /// when there is no more room, the capacity will be doubled.</param>
        /// <displayName id ="RegistrationHandler2">RegistrationHandler(int)</displayName>
        /// <syntax>public RegistrationHandler(int intitialCapacity)</syntax>
        public RegistrationHandler(int intitialCapacity)
        {
            registrantSlots = new T[intitialCapacity];
            unusedRegistrationIDs = new Stack<int>();
            for (int i = registrantSlots.Length - 1; i >= 0; i--)
                unusedRegistrationIDs.Push(i);
        }

        /// <type>int</type>
        /// <summary>
        /// Gets a value reflecting the last valid ID in the current registrar. Valid ID's range from 0 to LastValidID.
        /// Note that this is a reflection of the current possible registrants, not the max allowed registrants.
        /// The main use of this is for validating ID's you are not sure are valid, since trying to access a registrant with an invalid ID will
        /// cause all sorts of trouble.
        /// </summary>
        public int LastValidID { get { return registrantSlots.Length - 1; } }

        /// <type>T</type>
        /// <summary>
        /// Gets the user T associated with the specified registrationID.
        /// </summary>
        public T this[int registrationID]
        {
            get { return registrantSlots[registrationID]; }
        }

        /// <summary>
        /// Gets a value indicating whether any users are registered.
        /// </summary>
        /// <type>bool</type>
        public bool RegistrantsExists { get { return registrantsRegistered != 0; } }

        /// <summary>
        /// Gets a value indicating how many users are registered.
        /// </summary>
        /// <type>int</type>
        public int RegistrantsRegistered { get { return registrantsRegistered; } }

        /// <summary>
        /// Add a new registrant.
        /// </summary>
        /// <param name="newRegistrant" type = "T">The registrant to add.</param>
        /// <param name="registrationID" type = "out int">The ID assigned to the new registrant. Use this value when
        /// you wish to retrieve the registrant.</param>
        /// <displayName id = "AddRegistrant">AddRegistrant(T, out int)</displayName>
        /// <syntax>public void AddRegistrant(T newRegistrant, out int registrationID)</syntax>
        public void AddRegistrant(T newRegistrant, out int registrationID)
        {
            if (newRegistrant == null)
                throw new ArgumentNullException("Could not add registrant because the newRegistrant argument is null. Why would you want to add a null registrant?");

            registrantsRegistered++;

            if (unusedRegistrationIDs.Count == 0)
                ExpandRegistrationCapacity();

            registrationID = unusedRegistrationIDs.Pop();
            registrantSlots[registrationID] = newRegistrant;
        }

        /// <summary>
        /// Remove the registrant registered under registrationID.
        /// </summary>
        /// <param name="registrationID" type ="int">The ID of the registrant to remove.</param>
        /// <displayName id = "RemoveRegistrant">RemoveRegistrant(int)</displayName>
        /// <syntax>public void RemoveRegistrant(int registrationID)</syntax>
        public void RemoveRegistrant(int registrationID)
        {
            //If the registrant with this id has not already been removed
            if (registrantSlots[registrationID] != null)
            {
                registrantSlots[registrationID] = null;
                registrantsRegistered--;
                unusedRegistrationIDs.Push(registrationID);
            }
        }

        void ExpandRegistrationCapacity()
        {
            int previousCapacity = registrantSlots.Length;
            Array.Resize<T>(ref registrantSlots, previousCapacity * 2);
            for (int i = registrantSlots.Length - 1; i >= previousCapacity; i--)
                unusedRegistrationIDs.Push(i);
        }

        /// <summary>
        /// Gets all the users currently registered.
        /// </summary>
        /// <displayName id="GetAllRegistrants">GetAllRegistrants(List&lt;T&gt;)</displayName>
        /// <syntax>public void GetAllRegistrants(List&lt;T&gt; registrants)</syntax>
        /// <param name="registrants" type="List&lt;T&gt;">The list the registrants will be added to.</param>
        public void GetAllRegistrants(List<T> registrants)
        {
            for(int i = 0; i < registrantSlots.Length; i++)
            {
                if (registrantSlots[i] != null)
                    registrants.Add(registrantSlots[i]);
            }
        }

        /// <summary>
        /// Gets all the users currently registered of the type U specified.
        /// </summary>
        /// <typeparam name="U">The specific type of the registrant to get. Must be or derive from T</typeparam>
        /// <param name="registrants" type="List&lt;U&gt;">The list to add the registrants to.</param>
        /// <displayName id="GetAllRegistrantsOfType">GetAllRegistrantsOfType&lt;U&gt;(List&lt;U&gt;)</displayName>
        /// <syntax>public void GetAllRegistrantsOfType&lt;U&gt;(List&lt;U&gt; registrants) where U : T</syntax>
        public void GetAllRegistrantsOfType<U>(List<U> registrants) where U : T
        {
            for (int i = 0; i < registrantSlots.Length; i++)
            {
                if (registrantSlots[i] != null && registrantSlots[i] is U)
                    registrants.Add((U)registrantSlots[i]);
            }
        }

        /// <summary>
        /// Gets an enumerable collection of registered users. This can be used in a foreach.
        /// </summary>
        /// <returns type="IEnumerable&lt;T&gt;">An enumerable collection of the registered users.</returns>
        /// <example>
        /// <code>
        /// class IterateOverRegistrantsExample
        /// {
        ///     RegistrationHandler&lt;ActiveGrid&gt; activeGridUsers;
        ///     
        ///     public void Iterate()
        ///     {
        ///         foreach(ActiveGrid activeGrid in activeGridUsers.RegistrantEntries())
        ///             activeGrid.DoSomething();
        ///     }
        /// }
        /// </code>
        /// </example>
        /// <displayName id="RegistrantEntries">RegistrantEntries()</displayName>
        /// <syntax>public IEnumerable&lt;T&gt; RegistrantEntries()</syntax>
        public IEnumerable<T> RegistrantEntries()
        {
            for(int i = 0; i < registrantSlots.Length; i++)
            {
                if (registrantSlots[i] != null)
                    yield return registrantSlots[i];
            }
        }
    }
}