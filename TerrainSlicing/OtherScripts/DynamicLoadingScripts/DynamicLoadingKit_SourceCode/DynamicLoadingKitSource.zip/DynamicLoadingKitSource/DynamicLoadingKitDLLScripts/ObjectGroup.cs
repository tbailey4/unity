﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System;
    using UnityEngine;

    internal class ObjectGroupInternal : ICellObjectGroup
    {
        public int primaryCellObjectSubControllerID;
        ObjectGroup objectGroup;
        int cellsInEachLayer;

        public ObjectGroupInternal() { }

        public bool TryInitialize(ObjectGroup objectGroup, World baseWorldOfObjectGroup)
        {
            bool initializationCompleted = true;
            GroupName = objectGroup.GroupName;

            if(objectGroup.groupIs3D)
            {
                if(baseWorldOfObjectGroup.WorldGrid.WorldType != WorldType.Three_Dimensional)
                {
                    initializationCompleted = false;
                    Debug.LogError(string.Format("The Object Group with Group Name {0} could not be linked to the World with ID {1} because the object group has been set to 3D but the World is only 2D.", GroupName, baseWorldOfObjectGroup.ID));
                }
                else if(objectGroup.layers != baseWorldOfObjectGroup.WorldGrid.Layers)
                {
                    initializationCompleted = false;
                    Debug.LogError(string.Format("The Object Group with Group Name {0} could not be linked to the World with ID {1} because the number of layers on the object group ({2}) does not match the number of layers on the World ({3}).", GroupName, baseWorldOfObjectGroup.ID, objectGroup.layers, baseWorldOfObjectGroup.WorldGrid.Layers));
                }
            }
            else
            {
                if(baseWorldOfObjectGroup.WorldGrid.WorldType == WorldType.Three_Dimensional)
                {
                    initializationCompleted = false;
                    Debug.LogError(string.Format("The Object Group with Group Name {0} could not be linked to the World with ID {1} because the object group has been set to 2D but the World is 3D.", GroupName, baseWorldOfObjectGroup.ID));
                }
            }

            if(objectGroup.rows != baseWorldOfObjectGroup.WorldGrid.Rows)
            {
                initializationCompleted = false;
                Debug.LogError(string.Format("The Object Group with Group Name {0} could not be linked to the World with ID {1} because the number of rows on the object group ({2}) does not match the number of rows on the World ({3}).", GroupName, baseWorldOfObjectGroup.ID, objectGroup.rows, baseWorldOfObjectGroup.WorldGrid.Rows));
            }

            if(objectGroup.columns != baseWorldOfObjectGroup.WorldGrid.Columns)
            {
                initializationCompleted = false;
                Debug.LogError(string.Format("The Object Group with Group Name {0} could not be linked to the World with ID {1} because the number of columns on the object group ({2}) does not match the number of columns on the World ({3}).", GroupName, baseWorldOfObjectGroup.ID, objectGroup.columns, baseWorldOfObjectGroup.WorldGrid.Columns));
            }

            if(!initializationCompleted)
                return false;

            World = baseWorldOfObjectGroup;
            
            if(objectGroup.UseBaseWorldSettings)
            {
                NamingConvention = World.NamingConvention;
                OffsetCalculator = World.WorldGrid.OffsetCalculator;
                PrimaryCellObjectSubController = World.primaryCellObjectSubController;
            }
            else
            {
                if(objectGroup.PrimaryCellObjectSubController == null)
                {
                    initializationCompleted = false;
                    Debug.LogError("No Primary Cell Object Sub Controller found on Object Group with Group Name '" + GroupName + "'");
                }
                else
                {
                    //chance there is no naming convention set on the object group or it is invalid, in which case a default one will 
                    //need to be created.
                    NamingConvention = objectGroup.NamingConvention.GetCorrectNamingConvention(World.WorldGrid.WorldType == WorldType.Three_Dimensional);
                    OffsetCalculator = OffsetCalculatorCreator.CreateOffsetCalculator(World.WorldGrid.WorldType, objectGroup.PositionOffset);
                    PrimaryCellObjectSubController = objectGroup.PrimaryCellObjectSubController;
                }                
            }

            if (!initializationCompleted)
                return false;

            this.objectGroup = objectGroup;
            cellsInEachLayer = objectGroup.rows * objectGroup.columns;

            if (objectGroup.usedCells.DoAllValuesMatchInputVaue(true))
                IsCellUsedFunction = (cell) => true;
            else if (objectGroup.usedCells.DoAllValuesMatchInputVaue(false))
            {
                Debug.LogError("All cells are disabled on Object Group with Group Name '" + GroupName + "'. This makes the object group useless.");
                IsCellUsedFunction = (cell) => false;
            }
            else
            {
                if(objectGroup.groupIs3D)
                {
                    IsCellUsedFunction = (cell) => this.objectGroup.usedCells[(cellsInEachLayer * (cell.Layer-1)) + ((cell.Row-1) * this.objectGroup.columns + (cell.Column-1))];
                }
                else
                {
                    IsCellUsedFunction = (cell) => this.objectGroup.usedCells[((cell.Row-1) * this.objectGroup.columns + (cell.Column - 1))];
                }
            }

            return true;
        }
        
        public string GroupName { get; private set; }

        //This fnction is one baded (rather than 0 based)
        public Func<Cell, bool> IsCellUsedFunction { get; private set; }
        public INamingConvention NamingConvention { get; private set; }
        public World World { get; private set; }
        public PrimaryCellObjectSubController PrimaryCellObjectSubController { get; private set; }
        public IOffsetCalculator OffsetCalculator { get; private set; }
        
    }

    /// <summary>
    /// An Object Group can be used to load a group of secondary objects on top of your base world 
    /// (the terrain or meshes that serve as the foundation of your levels).
    /// <para>
    /// Previously the way to do this was to simply create a World and World Grid object for each group of secondary objects
    /// you wished to load. This had two issues.
    /// </para>
    /// <para>
    /// First, you'd end up with Worlds/World Grids with exactly the same data/settings, which was a waste of memory and a hinderance to efficiency. Second, there was no way to control the order that the secondary groups were loaded.
    /// </para>
    /// <para>
    /// Object Groups utilize most of the same information as whatever base World (and it's associated World Grid) they're assigned to,
    /// so you only need one World operating at a time. In addition, you have full control over the order in which object 
    /// groups are loaded (note, all groups are loaded after and removed before the main terrain/meshes of the World). 
    /// </para>
    /// <para>
    /// Simply place an object group first in the hierarchy if you want it to load before all other object groups. For instance, this 
    /// will allow you to load a house with a table in it before you load the miscellaneous plates/silverware/food that are placed 
    /// on top of the table.
    /// </para>
    /// <para>
    /// Note that this component is basically a data repository and does not implement the ICellObjectGroup interface. 
    /// An internal object group is created based on this data. This internal class is the one that implements the 
    /// ICellObjectGroup interface and is the one which is passed on the PrimaryCellObjectSubController at runtime. This allows you 
    /// to use a single Object Group component on several different Worlds at the same time.
    /// </para>
    /// </summary>
    /// <title>ObjectGroup Class</title>
    /// <category>Secondary Components</category>
    /// <navigationName>ObjectGroup</navigationName>
    /// <fileName>ObjectGroup.html</fileName>
    /// <syntax>public sealed class ObjectGroup : MonoBehaviour</syntax>
    /// 
    /// <inspector name ="Group Name" type="string">
    /// The Group Name of the object group, i.e., the name before the row/column/layer deliniation.
    /// </inspector>
    /// 
    /// <inspector name ="Naming Convention" type="NamingConvention" link="NamingConvention.html">
    /// The Naming Convention used to describe the row/column/layer of each object in the group. If null, 
    /// the default naming convention will be used.
    /// </inspector>
    /// 
    /// <inspector name ="Position Offset"
    /// type="Vector3">
    /// The position offset of the object group.
    /// </inspector>
    /// 
    /// <inspector name ="Primary Cell Object Sub Controller" 
    /// type="PrimaryCellObjectSubController" link="PrimaryCellObjectSubController.html">
    /// The Primary Cell Object Sub Controller used by the object group to manage the objects at runtime.
    /// </inspector>
    /// 
    /// <inspector name ="Use Base World Settings" 
    /// type="bool">
    /// Whether to use the base world's settings (when option is enabled) or specify them manually (when option is disabled).
    /// </inspector>
    /// 
    /// <inspector name ="Used Cells" 
    /// type="bool array">
    /// The cells in the World Grid that are being used by the object group.
    /// </inspector>
    [AddComponentMenu("Dynamic Loading Kit/Secondary Components/Object Group")]
    public sealed class ObjectGroup : MonoBehaviour
    {
        [SerializeField]
        internal string groupName;

        [SerializeField]
        internal bool useBaseWorldSettings, groupIs3D;

        [SerializeField]
        internal NamingConvention namingConvention;

        [SerializeField]
        internal PrimaryCellObjectSubController primaryCellObjectSubController;

        [SerializeField]
        internal Vector3 positionOffset;

        [SerializeField]
        internal bool[] usedCells;

        [SerializeField]
        internal int columns = 4, rows = 4, layers = 1, columnSelect, rowSelect, layerSelect;

        /// <summary>
        /// Gets the group name associated with the object group.
        /// </summary>
        /// <type>string</type>
        public string GroupName { get { return groupName; } }

        /// <summary>
        /// Gets the manually specified Naming Convention of the object group.
        /// </summary>
        /// <type>bool</type>
        public NamingConvention NamingConvention { get { return namingConvention; } }

        /// <summary>
        /// Gets the manually specified Position Offset of the object group.
        /// </summary>
        public Vector3 PositionOffset { get { return positionOffset; } }

        /// <summary>
        /// Gets the manually specified Primary Cell Object Sub Controller of the object group.
        /// </summary>
        public PrimaryCellObjectSubController PrimaryCellObjectSubController { get { return primaryCellObjectSubController; } }

        /// <summary>
        /// Gets a value that tells the World that is using this object group whether to use its own settings rather than the settings 
        /// found on the Object Group. This applies to all settings other than the Group Name.
        /// </summary>
        public bool UseBaseWorldSettings { get { return useBaseWorldSettings; } }

        /// <summary>
        /// 
        /// </summary>
        public bool[] UsedCells { get { return usedCells; } }
    }
}