//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
	using System.Collections.Generic;
    using System.Collections.ObjectModel;

    /// <summary>
    /// Provides a base implementation for Primary Cell Object Sub Controllers. These sub controllers are the main components responsible for 
    /// retrieving cell objects when the 
    /// <see cref="World" href="World.html">World</see> needs them, and handling deactivated cell objects when the World is done with them.
    /// <para>For instance, one sub controller might pool objects when they're not in use, while another might simply destroy them.</para>
    /// <para>The actual method of loading new objects into the scene is left up to the 
    /// <see cref="CellObjectLoader" href="CellObjectLoader.html">Cell Object Loader</see> you are using.</para>
    /// <para>Additional Note: This component contains its own special class (PrimaryCellObjectSubControllerUser) which enables multiple 
    /// users to use the sub controller at the same time. The data associated with each user is stored in this user object and retrieved
    /// using the primaryCellObjectSubControllerID passed into each method.</para>
    /// <para>This user object does not contain any data by default, though if creating your own custom sub controller, 
    /// you can and should create your own user object class that derives from 
    /// PrimaryCellObjectSubControllerUser, and use it to store data specific to your custom classes users. You can access the user object via the  
    /// <see cref="RegisteredUsers" href = "#RegisteredUsers">RegisteredUsers</see> property and primaryCellObjectSubControllerID, like so: RegisteredUsers[primaryCellObjectSubControllerID].</para>
    /// <para>You should never have to interact directly with this component, as the methods/properties are called/used
    /// as needed by the Dynamic Loading Kit.</para>
    /// </summary>
    /// <title>PrimaryCellObjectSubController Abstract Class</title>
    /// <category>Sub Controllers</category>
    /// <navigationName>PrimaryCellObjectSubController</navigationName>
    /// <fileName>PrimaryCellObjectSubController.html</fileName>
    /// <syntax>public abstract class PrimaryCellObjectSubController : MonoBehaviour</syntax>
    /// 
    /// <inspector name="Cell Object Destroyer" type="CellObjectDestroyer" link="CellObjectDestroyer.html">
    /// An optional Cell Object Destroyer that will be used by the sub controller to destroy objects when they need to be unloaded from 
    /// the scene. If no destroyer is provided, the root game object will be destroyed (along with its children) in a single frame. Depending on 
    /// the number of children the root object has, this operation may not be very performant (in which case, use a Cell Object Destroyer).</inspector>
    /// 
    /// <inspector name="Cell Object Loader" type="CellObjectLoader" link="CellObjectLoader.html">
    /// The Cell Object Loader that will be used by the sub controller to load new objects into the scene.</inspector>
    /// 
    /// <inspector name="Memory Freeing Strategy" type="MemoryFreeingStrategy" link="MemoryFreeingStrategy.html">
    /// Determines the memory freeing strategy to use after one or more game objects have been destroyed by the 
    /// Primary Cell Object Sub Controller. There may be a performance penalty when utilizing one of the 
    /// automatic stategies, so you may wish to set this to Manual and call the memory freeing methods 
    /// (Resources.UnloadUnusedAssets and System.GC.Collect) yourself at a time of your choosing.
    /// <para>
    /// Also note that Resources.UnloadUnusedAssets will usually free more memory than GC.Collect 
    /// (this method may actually be useless for your game, you will have to test this out yourself).
    /// </para>
    /// </inspector>
    /// <inspector name="Post Destroy Yield Time" type="float">When destroying objects, the sub controller will 
    /// need to destroy a list of root objects rather than just a single object. After each root object 
    /// is destroyed, the program will wait this amount of time (in seconds) before destroying the next 
    /// object(s). A value of 0 will destroy all root objects in a single frame (when not using a Cell 
    /// Object Destroyer) and is not recommended.
    /// </inspector>
    /// 
    /// <inspector name="Use Cell Actions" type="bool"><see cref="CellAction" href="CellAction.html">
    /// Cell Actions</see> can be attached to 
    /// cell objects in order to perform custom actions at key times. If none of your objects have Cell 
    /// Actions, however, the GetComponent call to 
    /// get the Cell Actions will create unnecessary garbage.
    /// <para>
    /// Enable this option only if you are using Cell Actions.
    /// </para>
    /// </inspector>
    public abstract class PrimaryCellObjectSubController : MonoBehaviour
    {
        [SerializeField]
        internal CellObjectLoader cellObjectLoader;

        [SerializeField]
        internal CellObjectDestroyer cellObjectDestroyer;

        [SerializeField]
        internal float timeToYieldForAfterDestroyingCellObject = .3f;

        [SerializeField]
        internal bool useCellActions;

        [SerializeField]
        internal MemoryFreeingStrategy memoryFreeingStrategy = MemoryFreeingStrategy.Auto_UnloadUnusedResourcesOnly;

        YieldInstruction yieldForTime;
        RegistrationHandler<PrimaryCellObjectSubControllerUser> registeredUsers;

        internal bool IsSingleFrameAttachmentPreloadingRequired { get { return cellObjectLoader.IsSingleFrameAttachmentPreloadRequired; } }
        
        /// <summary>
        /// Gets a value indicating whether Cell Actions are present on the objects.
        /// </summary>
        /// <type>bool</type>
        public bool ObjectsHaveCellActions { get { return useCellActions; } }

        /// <summary>
        /// Gets the Cell Object Loader associated with the sub controller.
        /// </summary>
        /// <type link="CellObjectLoader.html">CellObjectLoader (protected)</type>
        protected CellObjectLoader CellObjectLoader { get { return cellObjectLoader; } }

        /// <summary>
        /// Gets the users registered with the sub controller.
        /// </summary>
        /// <type link="RegistrationHandler.html">RegistrationHandler&lt;PrimaryCellObjectSubControllerUser&gt; (protected)</type>
        protected RegistrationHandler<PrimaryCellObjectSubControllerUser> RegisteredUsers { get { return registeredUsers; } }

        /// <summary>
        /// Gets the YieldInstruction that should be used to yield after a root object has been fully destroyed. If 
        /// Post Destroy Yield Time is 0, this will return null.
        /// </summary>
        /// <tyoe>YieldInstruction (protected)</tyoe>
        protected YieldInstruction YieldForTime { get { return yieldForTime; } }

        void Awake()
        {
            yieldForTime = timeToYieldForAfterDestroyingCellObject > 0f ? new WaitForSeconds(timeToYieldForAfterDestroyingCellObject) : null;
            AwakeExtended();
        }

        /// <summary>
        /// Because this base class utilizes Awake, it's imperative that sub classes do not. Instead, you can override this method 
        /// and it will be called when the base class's Awake method is called by Unity.
        /// </summary>
        /// <displayName id="AwakeExtended">AwakeExtended()</displayName>
        /// <syntax>protected virtual void AwakeExtended()</syntax>
        protected virtual void AwakeExtended() { }

        /// <summary>
        /// A user can call this method to register with the Primary Cell Object Sub Controller. The primaryCellObjectSubControllerID must be stored by the user
        /// and passed in when calling the methods of the Primary Cell Object Sub Controller.
        /// </summary>
        /// <param name="cellObjectGroup" type="ICellObjectGroup" link="ICellObjectGroup.html">The cell object group being registered.</param>
        /// <param name="primaryCellObjectSubControllerID" type="out int">An ID that is assigned to the user when this method is called. Each user has its
        /// own PrimaryCellObjectSubControllerUser object created for it.</param>
        /// <displayName id="Register">Register(ICellObjectGroup, out int)</displayName>
        /// <syntax>public void Register(ICellObjectGroup cellObjectGroup, out int primaryCellObjectSubControllerID)</syntax>
        public void Register(ICellObjectGroup cellObjectGroup, out int primaryCellObjectSubControllerID)
        {
            if (cellObjectLoader == null)
                throw new RequiredComponentNotFoundException("One of the Primary Cell Object Sub Controllers in the scene is missing a Cell Object Loader Component!");

            if (registeredUsers == null)
                registeredUsers = new RegistrationHandler<PrimaryCellObjectSubControllerUser>();

            int loaderID;
            cellObjectLoader.Register(cellObjectGroup, out loaderID);

            PrimaryCellObjectSubControllerUser user = CreateNewUser(cellObjectGroup, loaderID);
            registeredUsers.AddRegistrant(user, out primaryCellObjectSubControllerID);
        }

        /// <summary>
        /// A user can call this method to de register with the Primary Cell Object Sub Controller.
        /// </summary>
        /// <param name="primaryCellObjectSubControllerID" type="int">The ID of the user to de register.</param>
        /// <displayName id="DeRegister">DeRegister(int)</displayName>
        /// <syntax>public void DeRegister(int primaryCellObjectSubControllerID)</syntax>
        public void DeRegister(int primaryCellObjectSubControllerID)
        {
            cellObjectLoader.DeRegister(registeredUsers[primaryCellObjectSubControllerID].LoaderID);
            registeredUsers.RemoveRegistrant(primaryCellObjectSubControllerID);
        }

        /// <summary>
        /// Method used to create a new user object during user registration. This can be overridden to return
        /// a custom user object.
        /// </summary>
        /// <param name="cellObjectGroup" type="ICellObjectGroup" link="ICellObjectGroup.html">The cell object group being registered.</param>
        /// <param name="loaderID" type="int">The loaderID assigned to the sub controller when it registered with the Cell Object Loader it is using.</param>
        /// <returns type="PrimaryCellObjectSubControllerUser">A new user object created using the worldAssociatedWithUser and loaderID as input.</returns>
        /// <displayName id="CreateNewUser">CreateNewUser(ICellObjectGroup, int)</displayName>
        /// <syntax>protected virtual PrimaryCellObjectSubControllerUser CreateNewUser(ICellObjectGroup cellObjectGroup, int loaderID)</syntax>
        protected virtual PrimaryCellObjectSubControllerUser CreateNewUser(ICellObjectGroup cellObjectGroup, int loaderID)
        {
            return new PrimaryCellObjectSubControllerUser(cellObjectGroup, loaderID);
        }




        internal void PerformSingleFrameAttachmentPreloading<T>(List<T> cells, int primaryCellObjectSubControllerID) where T : IAttachableWorldCell
        {
            if (IsSingleFrameAttachmentPreloadingRequired)
                cellObjectLoader.PerformSingleFrameAttachmentPreload<T>(cells, registeredUsers[primaryCellObjectSubControllerID].LoaderID);
        }



        /// <summary>
        /// When overridden in a derived class, attaches the objects associated with the input cells to the cells in a single frame.
        /// <para>Note that T must implement the <see cref="IAttachableWorldCell" href = "IAttachableWorldCell.html">IAttachableWorldCell</see> interface.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="primaryCellObjectSubControllerID" type="int">The ID of the user requesting the attachment.</param>
        /// <displayName id="AttachCellObjectsToCellsInSingleFrame">AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public abstract void AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID) where T : IAttachableWorldCell</syntax>
        public abstract void AttachCellObjectsToCellsInSingleFrame<T>(List<T> cells, int primaryCellObjectSubControllerID) where T : IAttachableWorldCell;

        /// <summary>
        /// When overridden in a derived class, attaches the objects associated with the input cells to the cells over a period of frames.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="primaryCellObjectSubControllerID" type = "int">The ID of the user requesting the attachment.</param>
        /// <displayName id = "AttachCellObjectsToCells">AttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public abstract IEnumerator&lt;YieldInstruction&gt; AttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID) where T : IAttachableWorldCell</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public abstract IEnumerator<YieldInstruction> AttachCellObjectsToCells<T>(List<T> cells, int primaryCellObjectSubControllerID) where T : IAttachableWorldCell;

        /// <summary>
        /// When overridden in a derived class, detaches and processes the objects associated with the input cells over a period of frames.
        /// <para>Processing may include storing the objects in a pool or destroying them.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="deactivatedCells" type = "List&lt;T&gt;">The cells whose objects need to be detached and processed.</param>
        /// <param name="primaryCellObjectSubControllerID" type = "int">The ID of the user requesting the detachment and processing.</param>
        /// <displayName id = "DetachAndProcessCellObjectsFromDeactivatedCells">DetachAndProcessCellObjectsFromDeactivatedCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public abstract IEnumerator&lt;YieldInstruction&gt; DetachAndProcessCellObjectsFromDeactivatedCells&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID) where T : IAttachableWorldCell</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public abstract IEnumerator<YieldInstruction> DetachAndProcessCellObjectsFromDeactivatedCells<T>(List<T> deactivatedCells, int primaryCellObjectSubControllerID) where T : IDetachableWorldCell;

        protected void ApplyMemoryFreeingStrategy()
        {
            if (memoryFreeingStrategy == MemoryFreeingStrategy.Manual)
                return;
            else if (memoryFreeingStrategy == MemoryFreeingStrategy.Auto_UnloadUnusedResourcesOnly)
                Resources.UnloadUnusedAssets();
            else if (memoryFreeingStrategy == MemoryFreeingStrategy.Auto_GCCollectOnly)
                System.GC.Collect();
            else
            {
                Resources.UnloadUnusedAssets();
                System.GC.Collect();
            }
        }



        protected class PrimaryCellObjectSubControllerUser
        {
            public int LoaderID { get; private set; }

            public PrimaryCellObjectSubControllerUser(ICellObjectGroup cellObjectGroup, int loaderID)
            {
                LoaderID = loaderID;
            }
        }
    }
}