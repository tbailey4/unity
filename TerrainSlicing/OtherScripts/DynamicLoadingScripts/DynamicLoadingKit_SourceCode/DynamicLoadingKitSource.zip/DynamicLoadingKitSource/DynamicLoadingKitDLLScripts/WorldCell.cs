//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;

    /// <summary>
    /// Represents a cell on the <see cref="World" href="World.html">World</see>.
    /// </summary>
    /// <title>WorldCell Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>WorldCell</navigationName>
    /// <fileName>WorldCell.html</fileName>
    /// <syntax>public class WorldCell : <see cref="IAttachableWorldCell" href="IAttachableWorldCell.html">IAttachableWorldCell</see>, <see cref="IDetachableWorldCell" href="IDetachableWorldCell.html">IDetachableWorldCell</see></syntax>
    public class WorldCell : IAttachableWorldCell, IDetachableWorldCell
    {
        internal bool positioned;
        internal Cell zeroBasedCellOnEndlessGrid, oneBasedCellOnWorldGrid;
        internal CellAction[] cellActions;
        internal CellDimensions dimensions;
        internal GameObject primaryCellObject;
        internal Vector3 position, offset;
        internal ObjectGroupCell[] objectGroupCells;

        internal int users = 0;
        
        internal WorldCell(int numObjectGroupCells) 
        {
            if (numObjectGroupCells != 0) 
                objectGroupCells = new ObjectGroupCell[numObjectGroupCells];
        }

        /// <summary>
        /// Gets the position that the cell object should be placed at. You can position the object manually, or 
        /// let it be automatically positioned via AttachCellObjectToCell (by passing in false for 
        /// objectPositionedCorrectlyAlready).
        /// </summary>
        /// <type>bool</type>
        public Vector3 CellObjectPosition { get { return position + offset; } }

        /// <summary>
        /// Gets the cell's index on the World Grid associated with the World this cell belongs to.
        /// </summary>
        /// <type link="Cell.html">Cell</type>
        public Cell CellOnWorldGrid { get { return oneBasedCellOnWorldGrid; } }

        /// <summary>
        /// Gets the position of the cell in world space (note, this may be different than the position of the 
        /// cell object, since the cell object can be offset from the cell).
        /// </summary>
        /// <type>Vector3</type>
        public Vector3 CellPosition { get { return position; } }

        /// <summary>
        /// Gets the number of users of this World Cell.
        /// </summary>
        /// <type>int</type>
        public int CellUsers { get { return users; } }

        /// <summary>
        /// Gets a value indicating whether the World Cell currently has any users.
        /// </summary>
        /// <type>bool</type>
        public bool DoesCellHaveUsers { get { return users > 0; } }

        /// <summary>
        /// Gets the height of the cell.
        /// </summary>
        /// <type>float</type>
        public float Height { get { return dimensions.height; } }

        ///// <summary>
        ///// Gets the Cell Object associated with the World Cell.
        ///// <para>Explicit Interface Implementation for <see cref="IAttachableWorldCell" href="IAttachableWorldCell.html">IAttachableWorldCell</see></para>
        ///// </summary>
        ///// <type>GameObject</type>
        ///// <displayName>IAttachableWorldCell.CellObject</displayName>
        //GameObject IAttachableWorldCell.CellObject { get { return primaryCellObject; } }

        /// <summary>
        /// Gets the Cell Object associated with the World Cell.
        /// </summary>
        /// <type>GameObject</type>
        /// <displayName>CellObject</displayName>
        public GameObject CellObject { get { return primaryCellObject; } }

        /// <summary>
        /// Gets the length of the cell.
        /// </summary>
        /// <type>float</type>
        public float Length { get { return dimensions.length; } }

        /// <summary>
        /// Gets the width of the cell.
        /// </summary>
        /// <type>float</type>
        public float Width { get { return dimensions.width; } }


        /// <summary>
        /// Attaches a GameObject to the cell. If creating a custom Cell Object Loader or Primary Cell Object 
        /// Sub Controller class, you should either let the WorldCell position the cell object correctly by 
        /// passing in false for objectPositionedCorrectlyAlready, or position the object manually (or instantiate it 
        /// at the correct position) and pass in true. The correct position to manually position the object can be retrieved via 
        /// the CellObjectPosition property.
        /// <para>Explicit Interface Implementation for 
        /// <see cref="IAttachableWorldCell" href="IAttachableWorldCell.html">IAttachableWorldCell</see>
        /// </para>
        /// </summary>
        /// <param name="obj" type = "GameObject" link = "http://docs.unity3d.com/ScriptReference/GameObject.html">
        /// The object to attach to the cell.
        /// </param>
        /// <param name="objectPositionedCorrectlyAlready" type="bool">
        /// If false, the object will be moved to its correct position. If you've already positioned the object at the correct 
        /// location (CellObjectPosition), you must pass in true.
        /// </param>
        /// <displayName id = "AttachCellObjectToCell">IAttachableWorldCell.AttachCellObjectToCell(GameObject, bool)</displayName>
        /// <syntax>void IAttachableWorldCell.AttachCellObjectToCell(GameObject obj)</syntax>
        void IAttachableWorldCell.AttachCellObjectToCell(GameObject obj, bool objectPositionedCorrectlyAlready)
        {
            AttachCellObjectToCell(obj, objectPositionedCorrectlyAlready);
        }

        internal void AttachCellObjectToCell(GameObject obj, bool objectPositionedCorrectlyAlready)
        {
            primaryCellObject = obj;
            if (!objectPositionedCorrectlyAlready)
                obj.transform.position = CellObjectPosition;

            positioned = true;
        }

        /// <summary>
        /// Detaches a cell object from the World Cell. The object is returned and no longer associated with the World Cell.
        /// <para>Explicit Interface Implementation for <see cref="IDetachableWorldCell" href="IDetachableWorldCell.html">IDetachableWorldCell</see></para>
        /// </summary>
        /// <displayName id="DetachCellObjectFromCell">IDetachableWorldCell.DetachCellObjectFromCell()</displayName>
        /// <syntax>GameObject IDetachableWorldCell.DetachCellObjectFromCell()</syntax>
        /// <returns type="GameObject">The cell object that was detached from the World Cell.</returns>
        GameObject IDetachableWorldCell.DetachCellObjectFromCell()
        {
            return DetachCellObjectFromCell();
        }

        internal GameObject DetachCellObjectFromCell()
        {
            GameObject obj = primaryCellObject;
            primaryCellObject = null;
            return obj;
        }

        
        internal void RepositionPrimaryCellObject()
        {
            primaryCellObject.transform.position = CellObjectPosition;
            positioned = true;
        }

        internal void RemoveUsers(int numUsers)
        {
            users -= numUsers;
        }

        internal void AddUsers(int numUsers)
        {
            users += numUsers;
        }

        internal ObjectGroupCell RemoveObjectGroupCell(int objectGroupCellIndex)
        {
            ObjectGroupCell objectGroupCell = objectGroupCells[objectGroupCellIndex];
            objectGroupCells[objectGroupCellIndex] = null;
            return objectGroupCell;
        }
    }

    /// <summary>
    /// Represents a WorldCell whose Cell Object is a Unity Terrain.
    /// </summary>
    /// <title>WorldCellWithTerrain Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>WorldCellWithTerrain</navigationName>
    /// <fileName>WorldCellWithTerrain.html</fileName>
    /// <syntax>public class WorldCellWithTerrain : <see cref="WorldCell" href="WorldCell.html">WorldCell</see></syntax>
    public class WorldCellWithTerrain : WorldCell
    {
        internal WorldCellWithTerrain[] neighbors;

        internal Terrain terrain;

        internal WorldCellWithTerrain(int numObjectGroupCells)
            : base(numObjectGroupCells)
        {
            neighbors = new WorldCellWithTerrain[4];
        }

        internal void ClearNeighborsAndNullTerrain()
        {
            NullNeighbors();

            terrain.SetNeighbors(null, null, null, null);
            //terrain.Flush();
            terrain = null;
        }

        internal void NullNeighbors()
        {
            for (int i = 0; i < 4; i++)
                neighbors[i] = null;
        }

        internal void ResetNeighbors()
        {
            if (terrain != null)
            {
                Terrain leftTerrain = neighbors[0] != null ? neighbors[0].terrain : null;
                Terrain topTerrain = neighbors[1] != null ? neighbors[1].terrain : null;
                Terrain rightTerrain = neighbors[2] != null ? neighbors[2].terrain : null;
                Terrain bottomTerrain = neighbors[3] != null ? neighbors[3].terrain : null;

                terrain.SetNeighbors(leftTerrain, topTerrain, rightTerrain, bottomTerrain);
                terrain.Flush();
            }
        }

        /// <summary>
        /// Gets the WorldCellWithTerrain that neighbors this WorldCellWithTerrain on the left.
        /// </summary>
        /// <type link ="WorldCellWithTerrain.html">WorldCellWithTerrain</type>
        public WorldCellWithTerrain LeftNeighbor { get { return neighbors[0]; } internal set { neighbors[0] = value; } }

        /// <summary>
        /// Gets the WorldCellWithTerrain that neighbors this WorldCellWithTerrain on the top.
        /// </summary>
        /// <type link ="WorldCellWithTerrain.html">WorldCellWithTerrain</type>
        public WorldCellWithTerrain TopNeighbor { get { return neighbors[1]; } internal set { neighbors[1] = value; } }

        /// <summary>
        /// Gets the WorldCellWithTerrain that neighbors this WorldCellWithTerrain on the right.
        /// </summary>
        /// <type link ="WorldCellWithTerrain.html">WorldCellWithTerrain</type>
        public WorldCellWithTerrain RightNeighbor { get { return neighbors[2]; } internal set { neighbors[2] = value; } }

        /// <summary>
        /// Gets the WorldCellWithTerrain that neighbors this WorldCellWithTerrain on the bottom.
        /// </summary>
        /// <type link ="WorldCellWithTerrain.html">WorldCellWithTerrain</type>
        public WorldCellWithTerrain BottomNeighbor { get { return neighbors[3]; } internal set { neighbors[3] = value; } }

        /// <summary>
        /// Gets the Terrain associted with this WorldCellWithTerrain.
        /// </summary>
        /// <type>Terrain</type>
        public Terrain Terrain { get { return terrain; } }
    }
}