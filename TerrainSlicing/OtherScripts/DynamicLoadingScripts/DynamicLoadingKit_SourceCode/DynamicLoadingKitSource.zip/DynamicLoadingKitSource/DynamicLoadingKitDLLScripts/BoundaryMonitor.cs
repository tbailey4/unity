//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
	using System.Collections.Generic;
	using DynamicLoadingKit;
	using System;

    /// <summary>
    /// A component which actively monitors boundaries.
    /// <para>This component is not meant to be used outside of the Dynamic Loading Kit, and as such
    /// many of its members are hidden. Look at the source code provided with the kit if you wish to create
    /// your own boundary monitor based on this one for non DLK stuff.
    /// </para>
    /// <para>
    /// Each Boundary Monitor user can supply a dynamic and static boundary to monitor.
    /// </para>
    /// </summary>
    /// <title>BoundaryMonitor Class</title>
    /// <category>Secondary Components</category>
    /// <navigationName>BoundaryMonitor</navigationName>
    /// <fileName>BoundaryMonitor.html</fileName>
    /// <syntax>public class BoundaryMonitor : MonoBehaviour</syntax>
    /// <inspector name = "Detection Frequency" type = "float">The frequency at which the player's position
    /// will be checked to see if they've crossed a boundary.</inspector>
	[AddComponentMenu("Dynamic Loading Kit/Secondary Components/Boundary Monitor")]
	public class BoundaryMonitor : MonoBehaviour
	{		
		[SerializeField]
        internal float detectionFrequency = 2f;

        //User Registration stuff
        RegistrationHandler<BoundaryMonitorUser> registeredUsers;

        Action<BoundaryMonitorUser> StartMonitoringAction, CheckAllBoundariesAction, TimeOutAction;

        void Awake()
        {
            //Signifies awake has already been called
            if (registeredUsers != null)
                return;

            registeredUsers = new RegistrationHandler<BoundaryMonitorUser>();

            detectionFrequency = detectionFrequency < 0f ? 0f : detectionFrequency;
            SetupActions();
        }

        void SetupActions()
        {
            StartMonitoringAction = StartMonitoringAction_Internal;
            CheckAllBoundariesAction = CheckAllBoundariesAction_Internal;
            TimeOutAction = TimeOutAction_Internal;
        }

        internal void Register(Transform transformToMonitor, out int registrationID,
            Boundary dynamicBoundaryToMonitor = null, Action<BoundaryCrossed, BoundaryCrossed, BoundaryCrossed> MethodToCallWhenDynamicBoundaryCrossed = null,
            Boundary staticBoundaryToMonitor = null, Action<Transform> MethodToCallWhenStaticBoundaryCrossed = null)
        {
            Awake();

            BoundaryMonitorUser newUser = (BoundaryMonitorUser)gameObject.AddComponent(typeof(BoundaryMonitorUser));
            registeredUsers.AddRegistrant(newUser, out registrationID);

            newUser.dynamicBoundary = dynamicBoundaryToMonitor;
            newUser.staticBoundary = staticBoundaryToMonitor;
            newUser.MethodToCallWhenDynamicBoundaryCrossed = MethodToCallWhenDynamicBoundaryCrossed;
            newUser.MethodToCallWhenStaticBoundaryCrossed = MethodToCallWhenStaticBoundaryCrossed;
            newUser.transformToMonitor = transformToMonitor;
            newUser.UpdateAction = StartMonitoringAction;
        }


        internal void DeRegister(int registrationID)
        {
            BoundaryMonitorUser user = registeredUsers[registrationID];

            if (user != null)
            {
                user.stopMonitoring = true;
                user.NullOut();
                registeredUsers.RemoveRegistrant(registrationID);
                Destroy(user);
            }
        }



        internal void SetDynamicBoundaryMonitoringInfo(int registrationID, Boundary dynamicBoundary, Action<BoundaryCrossed, BoundaryCrossed, BoundaryCrossed> MethodToCallWhenDynamicBoundaryCrossed)
        {
            //CheckForSetExceptions(registrationID, dynamicBoundary != null, MethodToCallWhenDynamicBoundaryCrossed != null, "Dynamic");
            BoundaryMonitorUser user = registeredUsers[registrationID];
            user.dynamicBoundary = dynamicBoundary;
            user.MethodToCallWhenDynamicBoundaryCrossed = MethodToCallWhenDynamicBoundaryCrossed;
        }

        internal void SetStaticBoundaryMonitoringInfo(int registrationID, Boundary staticBoundary,
            Action<Transform> MethodToCallWhenStaticBoundaryCrossed)
        {
            //CheckForSetExceptions(registrationID, staticBoundary != null, MethodToCallWhenStaticBoundaryCrossed != null, "Static");
            BoundaryMonitorUser user = registeredUsers[registrationID];
            user.staticBoundary = staticBoundary;
            user.MethodToCallWhenStaticBoundaryCrossed = MethodToCallWhenStaticBoundaryCrossed;
        }




        internal void EnableDynamicBoundaryMonitoring(int registrationID)
        {
            registeredUsers[registrationID].monitorDynamicBoundary = true;
        }

        internal void DisableDynamicBoundaryMonitoring(int registrationID)
        {
            registeredUsers[registrationID].monitorDynamicBoundary = false;
        }

        internal void EnableStaticBoundaryMonitoring(int registrationID)
        {
            registeredUsers[registrationID].monitorStaticBoundary = true;
        }

        internal void DisableStaticBoundaryMonitoring(int registrationID)
        {
            registeredUsers[registrationID].monitorStaticBoundary = false;
        }




        /// <summary>
        /// Updates the frequency at which this Boundary Monitor checks to see if
        /// the player has crossed a boundary.
        /// </summary>
        /// <displayName id = "UpdateDetectionFrequency">UpdateDetectionFrequency(float)</displayName>
        /// <syntax>public void UpdateDetectionFrequency(float newDetectionFrequency)</syntax>
        /// <param name="newDetectionFrequency" type = "float">The new frequency, in seconds.</param>
        public void UpdateDetectionFrequency(float newDetectionFrequency)
        {
            detectionFrequency = newDetectionFrequency < 0f ? 0f : newDetectionFrequency;

            //if (detectionFrequency > 0f)
            //    yieldTimeBetweenBoundaryChecks = new WaitForSeconds(detectionFrequency);
            //else
            //    yieldTimeBetweenBoundaryChecks = null;
        }

        internal void MonitorNewTransform(Transform newTransformToMonitor, int registrationID)
        {
            registeredUsers[registrationID].transformToMonitor = newTransformToMonitor;
        }

        internal void StartMonitoring(int registrationID)
		{
            BoundaryMonitorUser user = registeredUsers[registrationID];

            if (!user.monitoringInProgress)
                user.enabled = true;
            else//Monitor already in progress
            {
                user.stopMonitoring = false;
            }
		}

        internal void StopMonitoring(int registrationID)
		{
            registeredUsers[registrationID].stopMonitoring = true;
		}

        

        //Actions
        void StartMonitoringAction_Internal(BoundaryMonitorUser user)
        {
            user.stopMonitoring = false;
            user.monitoringInProgress = true;
            user.UpdateAction = CheckAllBoundariesAction;
        }

        void CheckAllBoundariesAction_Internal(BoundaryMonitorUser user)
        {
            if(user.stopMonitoring)
            {
                DisableUser(user);
            }
            else
            {
                if(user.monitorDynamicBoundary)
                {
                    BoundaryCrossed eastOrWestBoundaryCrossed, northOrSouthBoundaryCrossed, topOrBottomBoundaryCrossed;
                    user.dynamicBoundary.WereBoundariesCrossed(user.transformToMonitor.position, out eastOrWestBoundaryCrossed, out northOrSouthBoundaryCrossed, out topOrBottomBoundaryCrossed);

                    if (eastOrWestBoundaryCrossed != BoundaryCrossed.None || northOrSouthBoundaryCrossed != BoundaryCrossed.None || topOrBottomBoundaryCrossed != BoundaryCrossed.None)
                    {
#if DEBUG_ON
                Debug.Log(string.Format("The following dynamic boundaries were detected as crossed:\nEast or West: {0}\nNorth or South: {1}\nTop or Bottom: {2}\nThe player's position is {3}", eastOrWestBoundaryCrossed, northOrSouthBoundaryCrossed, topOrBottomBoundaryCrossed, user.transformToMonitor.position));
#endif
                        user.MethodToCallWhenDynamicBoundaryCrossed(eastOrWestBoundaryCrossed, northOrSouthBoundaryCrossed, topOrBottomBoundaryCrossed);
                    }
                }

                if (user.monitorStaticBoundary)
                {
                    BoundaryCrossed eastOrWestBoundaryCrossed, northOrSouthBoundaryCrossed, topOrBottomBoundaryCrossed;
                    user.staticBoundary.WereBoundariesCrossed(user.transformToMonitor.position, out eastOrWestBoundaryCrossed, out northOrSouthBoundaryCrossed, out topOrBottomBoundaryCrossed);

                    if (eastOrWestBoundaryCrossed != BoundaryCrossed.None || northOrSouthBoundaryCrossed != BoundaryCrossed.None || topOrBottomBoundaryCrossed != BoundaryCrossed.None)
                    {
#if DEBUG_ON
                Debug.Log(string.Format("The following static boundaries were detected as crossed:\nEast or West: {0}\nNorth or South: {1}\nTop or Bottom: {2}\nThe player's position is {3}", eastOrWestBoundaryCrossed, northOrSouthBoundaryCrossed, topOrBottomBoundaryCrossed, user.transformToMonitor.position));
#endif
                        user.MethodToCallWhenStaticBoundaryCrossed(user.transformToMonitor);
                    }
                }               

                PutUserInTimeOut(user);
            }
        }
        
        void TimeOutAction_Internal(BoundaryMonitorUser user)
        {
            if (user.stopMonitoring)
                DisableUser(user);
            else if (Time.time - user.timeOutStart > detectionFrequency)
                user.UpdateAction = CheckAllBoundariesAction;
        }
        
        void PutUserInTimeOut(BoundaryMonitorUser user)
        {
            if (user.stopMonitoring)
                DisableUser(user);
            else
            {
                user.timeOutStart = Time.time;
                user.UpdateAction = TimeOutAction;
            }
        }

        void DisableUser(BoundaryMonitorUser user)
        {
            user.UpdateAction = StartMonitoringAction;
            user.monitoringInProgress = false;
            user.enabled = false;
        }
	}
}