//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using System.Collections.Generic;
	using UnityEngine;
	using System;

    internal abstract class ActiveGridCells
    {
        protected Cell[] cellsOnEndlessGrid;

        public Cell FirstCellInInnerArea { get { return cellsOnEndlessGrid[IndexOfFirstCellInInnerArea]; } }
        public Cell LastCellInInnerArea { get { return cellsOnEndlessGrid[IndexOfLastCellInInnerArea]; } }
        
        protected abstract int IndexOfFirstCellInInnerArea  { get; }
        protected abstract int IndexOfLastCellInInnerArea   { get; }

        public abstract void AssignIndexes(Cell firstCellInGroup);
        public abstract bool IsCellInInnerArea(Cell cell);

        public void GetAllCells(IList<Cell> buffer)
        {
            foreach (Cell cell in cellsOnEndlessGrid)
                buffer.Add(cell);
        }

        public void AddToAllCells(Cell add)
        {
            for (int i = 0; i < cellsOnEndlessGrid.Length; i++)
                cellsOnEndlessGrid[i] = cellsOnEndlessGrid[i] + add;
        }

        internal void Print()
        {
            string s = "";
            for (int i = 0; i < cellsOnEndlessGrid.Length; i++)
                s += cellsOnEndlessGrid[i].ToString() + "\n";

            Debug.Log(s);
        }
    }

    internal abstract class OuterRingActiveGridCells : ActiveGridCells
    {
        protected int rows, columns, outerRingWidth, cellsInEachLayer, innerAreaRowCutoff, innerAreaColumnCutoff;

        public OuterRingActiveGridCells(int innerRows, int innerColumns, int outerRingWidth)
        {
            this.outerRingWidth = outerRingWidth;

            rows = innerRows + 2 * outerRingWidth;
            columns = innerColumns + 2 * outerRingWidth;
            cellsInEachLayer = rows * columns;
            innerAreaColumnCutoff = outerRingWidth + columns - 1;
            innerAreaRowCutoff = outerRingWidth + rows - 1;
        }

        public int Rows { get { return rows; } }
        public int Columns { get { return columns; } }

        public Cell FirstCellInGroup { get { return cellsOnEndlessGrid[0]; } }
        public Cell LastCellInGroup { get { return cellsOnEndlessGrid[cellsOnEndlessGrid.Length - 1]; } }

        public abstract void CreateCellsUsingFirstCellInGroup(Cell firstCellInGroup, IList<Cell> bufferToAddCreatedCellsTo);

        public abstract void GetAllOuterRingCells(IList<Cell> buffer);

        public virtual void ShiftCellsEast()
        {
            for (int i = 0; i < cellsOnEndlessGrid.Length; i++)
                cellsOnEndlessGrid[i].column++;
        }

        public virtual void ShiftCellsWest()
        {
            for (int i = 0; i < cellsOnEndlessGrid.Length; i++)
                cellsOnEndlessGrid[i].column--;
        }

        public virtual void ShiftCellsNorth()
        {
            for (int i = 0; i < cellsOnEndlessGrid.Length; i++)
                cellsOnEndlessGrid[i].row++;
        }

        public virtual void ShiftCellsSouth()
        {
            for (int i = 0; i < cellsOnEndlessGrid.Length; i++)
                cellsOnEndlessGrid[i].row--;
        }

        public abstract void GetEastCells(IList<Cell> buffer);

        public abstract void GetWestCells(IList<Cell> buffer);

        public abstract void GetNorthCells(IList<Cell> buffer);

        public abstract void GetSouthCells(IList<Cell> buffer);

        protected void AddCellsToBuffer(int startIndex, int endIndex, int increment, IList<Cell> buffer)
        {
            for (int i = startIndex; i < endIndex; i += increment)
                buffer.Add(cellsOnEndlessGrid[i]);
        }
    }

    internal class OuterRingActive3DGridCells : OuterRingActiveGridCells
    {
        int layers, innerAreaLayerCutoff;
        public OuterRingActive3DGridCells(int innerLayers, int innerRows, int innerColumns, int outerRingWidth, Cell firstCellInGroup)
            : base(innerRows, innerColumns, outerRingWidth)
        {
            layers = innerLayers + 2 * outerRingWidth;
            cellsOnEndlessGrid = new Cell[layers * rows * columns];

            int larger = layers * rows > layers * columns ? layers * rows : layers * columns;
            int largest = larger > rows * columns ? larger : rows * columns;
            innerAreaLayerCutoff = outerRingWidth + layers - 1;
            AssignIndexes(firstCellInGroup);
        }

        public int Layers { get { return layers; } }

        public Cell this[int layer, int row, int column]
        { get { return cellsOnEndlessGrid[(row * columns + column) + (columns * rows * layer)]; } }

        public sealed override void GetAllOuterRingCells(IList<Cell> buffer)
        {
            for(int layer = 0; layer < layers; layer++)
            {
                for(int row = 0; row < rows; row++)
                {
                    for(int column = 0; column < columns; column++)
                    {
                        if (layer >= outerRingWidth && layer <= innerAreaLayerCutoff && row >= outerRingWidth && row <= innerAreaRowCutoff && column >= outerRingWidth && column <= innerAreaColumnCutoff)
                            buffer.Add(this[layer, row, column]);
                    }
                }
            }
        }

        protected sealed override int IndexOfFirstCellInInnerArea { get { return outerRingWidth * columns + outerRingWidth + (cellsInEachLayer * outerRingWidth); } }

        protected sealed override int IndexOfLastCellInInnerArea { get { return ((cellsOnEndlessGrid.Length - 1 - outerRingWidth) - (outerRingWidth * columns)) - (cellsInEachLayer * outerRingWidth); } }

        public sealed override bool IsCellInInnerArea(Cell cell)
        {
            Cell firstCellInInnerArea = FirstCellInInnerArea;
            Cell lastCellInInnerArea = LastCellInInnerArea;

            if (cell.column >= firstCellInInnerArea.column && cell.column <= lastCellInInnerArea.column
                && cell.row >= firstCellInInnerArea.row && cell.row <= lastCellInInnerArea.row
                && cell.layer >= firstCellInInnerArea.layer && cell.layer <= lastCellInInnerArea.layer)
            { return true; }
            else
                return false;
        }

        public sealed override void AssignIndexes(Cell firstCellInGroup)
        {
            for (int layer = 0, indexOfFirstCellOnThisLayer = 0; layer < layers; layer++, indexOfFirstCellOnThisLayer += cellsInEachLayer)
            {
                for (int row = 0, index = indexOfFirstCellOnThisLayer; row < rows; row++)
                    for (int column = 0; column < columns; column++, index++)
                        cellsOnEndlessGrid[index] = new Cell(firstCellInGroup.row + row, firstCellInGroup.column + column, firstCellInGroup.layer + layer);
            }
        }

        public sealed override void CreateCellsUsingFirstCellInGroup(Cell firstCellInGroup, IList<Cell> bufferToAddCreatedCellsTo)
        {
            for (int layer = 0, indexOfFirstCellOnThisLayer = 0; layer < layers; layer++, indexOfFirstCellOnThisLayer += cellsInEachLayer)
            {
                for (int row = 0, index = indexOfFirstCellOnThisLayer; row < rows; row++)
                    for (int column = 0; column < columns; column++, index++)
                        bufferToAddCreatedCellsTo.Add(new Cell(firstCellInGroup.row + row, firstCellInGroup.column + column, firstCellInGroup.layer + layer));
            }
        }

        public virtual void ShiftCellsUp()
        {
            for (int i = 0; i < cellsOnEndlessGrid.Length; i++)
                cellsOnEndlessGrid[i].layer++;
        }

        public virtual void ShiftCellsDown()
        {
            for (int i = 0; i < cellsOnEndlessGrid.Length; i++)
                cellsOnEndlessGrid[i].layer--;
        }

        public sealed override void GetEastCells(IList<Cell> buffer)
        {
            AddCellsToBuffer(columns - 1, rows * columns, layers, cellsInEachLayer, columns, buffer);
        }

        public sealed override void GetWestCells(IList<Cell> buffer)
        {
            AddCellsToBuffer(0, columns * rows, layers, cellsInEachLayer, columns, buffer);
        }

        public sealed override void GetNorthCells(IList<Cell> buffer)
        {
            AddCellsToBuffer((rows - 1) * columns, rows * columns, layers, cellsInEachLayer, 1, buffer);
        }

        public sealed override void GetSouthCells(IList<Cell> buffer)
        {
            AddCellsToBuffer(0, columns, layers, cellsInEachLayer, 1, buffer);
        }

        public void GetTopCells(IList<Cell> buffer)
        {
            int startIndexForFirstIteration = (layers - 1) * rows * columns;
            AddCellsToBuffer(startIndexForFirstIteration, startIndexForFirstIteration + columns, rows, columns, 1, buffer);
        }

        public void GetBottomCells(IList<Cell> buffer)
        {
            AddCellsToBuffer(0, columns, rows, columns, 1, buffer);
        }

        void AddCellsToBuffer(int startIndexForFirstIteration, int endIndexForFirstIteration, int iterations, int postIterationIncrement, int postSubIterationIncrement, IList<Cell> buffer)
        {
            for (int i = 0, startIndex = startIndexForFirstIteration, endIndex = endIndexForFirstIteration; i < iterations; i++, startIndex += postIterationIncrement, endIndex += postIterationIncrement)
            {
                AddCellsToBuffer(startIndex, endIndex, postSubIterationIncrement, buffer);
            }
        }
    }

    internal class OuterRingActive2DGridCells : OuterRingActiveGridCells
    {
        public OuterRingActive2DGridCells(int innerRows, int innerColumns, int outerRingWidth, Cell firstCellInGroup)
            : base(innerRows, innerColumns, outerRingWidth)
        {
            cellsOnEndlessGrid = new Cell[rows * columns];
            AssignIndexes(firstCellInGroup);
        }

        public Cell this[int row, int column]
        { get { return cellsOnEndlessGrid[row * columns + column]; } }

        public sealed override void GetAllOuterRingCells(IList<Cell> buffer)
        {
            for (int row = 0; row < rows; row++)
            {
                for (int column = 0; column < columns; column++)
                {
                    if (row >= outerRingWidth && row <= innerAreaRowCutoff && column >= outerRingWidth && column <= innerAreaColumnCutoff)
                        buffer.Add(this[row, column]);
                }
            }
        }

        protected sealed override int IndexOfFirstCellInInnerArea { get { return outerRingWidth * columns + outerRingWidth; } }

        protected sealed override int IndexOfLastCellInInnerArea { get { return (cellsOnEndlessGrid.Length - 1 - outerRingWidth) - (outerRingWidth * columns); } }

        public sealed override void AssignIndexes(Cell firstCellInGroup)
        {
            for (int row = 0, index = 0; row < rows; row++)
                for (int column = 0; column < columns; column++, index++)
                    cellsOnEndlessGrid[index] = new Cell(firstCellInGroup.row + row, firstCellInGroup.column + column);
        }

        public sealed override void CreateCellsUsingFirstCellInGroup(Cell firstCellInGroup, IList<Cell> bufferToAddCreatedCellsTo)
        {
            for (int row = 0, index = 0; row < rows; row++)
                for (int column = 0; column < columns; column++, index++)
                    bufferToAddCreatedCellsTo.Add(new Cell(firstCellInGroup.row + row, firstCellInGroup.column + column));
        }

        public sealed override bool IsCellInInnerArea(Cell cell)
        {
            Cell firstCellInInnerArea = FirstCellInInnerArea;
            Cell lastCellInInnerArea = LastCellInInnerArea;

            if (cell.column >= firstCellInInnerArea.column && cell.column <= lastCellInInnerArea.column
                && cell.row >= firstCellInInnerArea.row && cell.row <= lastCellInInnerArea.row)
            { return true; }
            else
                return false;
        }

        

        public sealed override void GetEastCells(IList<Cell> buffer)
        {
            AddCellsToBuffer(columns - 1, rows * columns, columns, buffer);
        }

        public sealed override void GetWestCells(IList<Cell> buffer)
        {
            AddCellsToBuffer(0, rows * columns, columns, buffer);
        }

        public sealed override void GetNorthCells(IList<Cell> buffer)
        {
            AddCellsToBuffer((rows - 1) * columns, rows * columns, 1, buffer);
        }

        public sealed override void GetSouthCells(IList<Cell> buffer)
        {
            AddCellsToBuffer(0, columns, 1, buffer);
        }
    }


    /* Special Note about Sectioned Grid Cells
     * 
     * The "Inner Area Cell" is always the cell that the player is in.
     * The makup of the cell array matches the real world representation of the cells,
     * which is dependent upon the location of the active section. This array always contains 4 
     * cells for 2D worlds and 8 cells for 3D worlds.
     * 
     * For instance, if the active section (for a 2D world) is the top right section of the cell,
     * then a cell above the inner area cell, to the right of the inner area cell, and above and 
     * to the right of the inner area cell will be loaded, becuase these are the cells that 
     * are touching the active section.
     * 
     * In this configuration, the Inner Area Cell is the Bottom Left cell in the group of four, or the 
     * element at index 0 in a one dimensional array.
     * 
     * If you draw out all the other active section possibilities and the resulting cell array makeup, you'll 
     * notice a pattern. The Inner Area Cell's location in the cell array will always be oppositie the active 
     * section.
     * 
     * So if the Active Section is the Bottom Left portition of a cell, the Inner Area Cell will be in the 
     * Top Right of the cell array.
     * 
     * This works for 3D worlds as well, with the added layer dimension.
     */

    internal abstract class SectionedGridCells : ActiveGridCells
    {
        protected int indexOfInnerAreaCell, rowOfSection, columnOfSection;
        public SectionedGridCells(Cell firstCellInGroup, int numCells, int rowOfSection, int columnOfSection, int indexOfInnerAreaCell)
            : base()
        {
            cellsOnEndlessGrid = new Cell[numCells];
            AssignIndexes(firstCellInGroup);
            this.indexOfInnerAreaCell = indexOfInnerAreaCell;
            this.rowOfSection = rowOfSection;
            this.columnOfSection = columnOfSection;
        }

        public int RowOfSection { get { return rowOfSection; } }
        public int ColumnOfSection { get { return columnOfSection; } }

        protected sealed override int IndexOfFirstCellInInnerArea { get { return indexOfInnerAreaCell; } }
        protected sealed override int IndexOfLastCellInInnerArea { get { return indexOfInnerAreaCell; } }

        protected bool SectionEastOfInnerAreaCell { get { return columnOfSection == 2; } }
        protected bool SectionWestOfInnerAreaCell { get { return columnOfSection == -1; } }
        protected bool SectionNorthOfInnerAreaCell { get { return rowOfSection == 2; } }
        protected bool SectionSouthOfInnerAreaCell { get { return rowOfSection == -1; } }

        public abstract void AssignIndexes(Cell innerAreaCell, int layerOfSection, int rowOfSection, int columnOfSection);

        public abstract void CreateCellsUsingInnerAreaCell(Cell innerAreaCell, int layerOfSection, int rowOfSection, int columnOfSection, IList<Cell> bufferToAddCreatedCellsTo);

        public abstract void ShiftSectionEast(out bool innerAreaColumnChanged);
        public abstract void ShiftSectionEast(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaColumnChanged);

        public abstract void ShiftSectionWest(out bool innerAreaColumnChanged);
        public abstract void ShiftSectionWest(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaColumnChanged);

        public abstract void ShiftSectionNorth(out bool innerAreaRowChanged);
        public abstract void ShiftSectionNorth(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaRowChanged);

        public abstract void ShiftSectionSouth(out bool innerAreaRowChanged);
        public abstract void ShiftSectionSouth(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaRowChanged);

        public abstract void SetSectionBoundary(Boundary boundary, Vector3 positionOfInnerAreaCell, CellDimensions dimensionsofInnerAreaCell);
    }

    internal abstract class Sectioned2DGridCells : SectionedGridCells
    {
        const int BottomLeftCellIndex = 0;
        const int BottomRightCellIndex = 1;
        const int TopLeftCellIndex = 2;
        const int TopRightCellIndex = 3;

        public Sectioned2DGridCells(Cell innerAreaCell, int rowOfSection, int columnOfSection)
            : base(GetFirstCellInGroup(innerAreaCell, rowOfSection, columnOfSection), 4, rowOfSection, columnOfSection,
            GetIndexOfInnerAreaCell(rowOfSection, columnOfSection)) { }

        public Cell this[int row, int column]
        { 
            get 
            { 
                return cellsOnEndlessGrid[row * 2 + column]; 
            } 
        }

        //When the row of section is 0 or column of section is 0, the row and column of the inner area cell
        //(within the endless grid array) has to be the top or right most cell (i.e., row = 1, column = 1).
        //Therefore, when row of section or column of section is 0, we need to subtract 1 from the inner area cells
        //row or column value to get the correct value of the first cell in the group.
        static Cell GetFirstCellInGroup(Cell innerAreaCell, int rowOfSection, int columnOfSection)
        {
            int firstCellInGroupRow = rowOfSection == 0 ? innerAreaCell.row - 1 : innerAreaCell.row;

            int firstCellInGroupColumn = columnOfSection == 0 ? innerAreaCell.column - 1 : innerAreaCell.column;

            return new Cell(firstCellInGroupRow, firstCellInGroupColumn);
        }

        //Since there are two columns in our cell array, each additional row requires us to add 2 to the index.
        //Note that only 1 needs to be added to the index for each additonal column.
        //When the row of section is 0 or column of section is 0, the row and column of the inner area cell
        //(within the endless grid array) has to be the top or right most cell (i.e., row = 1, column = 1).
        //Since we have one additional row and one additional column in these cases, we add 2 and 1 respectively
        //to the index.
        static int GetIndexOfInnerAreaCell(int rowOfSection, int columnOfSection)
        {
            int index = 0;

            if (rowOfSection == 0)
                index += 2;

            if (columnOfSection == 0)
                index += 1;

            return index;
        }

        public sealed override void AssignIndexes(Cell innerAreaCell, int layerOfSection, int rowOfSection, int columnOfSection)
        {
            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
            this.rowOfSection = rowOfSection;
            this.columnOfSection = columnOfSection;
            AssignIndexes(GetFirstCellInGroup(innerAreaCell, rowOfSection, columnOfSection));
        }

        public sealed override void AssignIndexes(Cell firstCellInGroup)
        {
            for (int row = 0, index = 0; row < 2; row++)
                for (int column = 0; column < 2; column++, index++)
                    cellsOnEndlessGrid[index] = new Cell(firstCellInGroup.row + row, firstCellInGroup.column + column);
        }

        public sealed override void CreateCellsUsingInnerAreaCell(Cell innerAreaCell, int layerOfSection, int rowOfSection, int columnOfSection, IList<Cell> bufferToAddCreatedCellsTo)
        {
            Cell firstCellInGroup = GetFirstCellInGroup(innerAreaCell, rowOfSection, columnOfSection);
            for (int row = 0, index = 0; row < 2; row++)
                for (int column = 0; column < 2; column++, index++)
                    bufferToAddCreatedCellsTo.Add(new Cell(firstCellInGroup.row + row, firstCellInGroup.column + column));
        }

        public sealed override bool IsCellInInnerArea(Cell cell)
        {
            return cell.row == FirstCellInInnerArea.row && cell.column == FirstCellInInnerArea.column;
        }




        public sealed override void ShiftSectionEast(out bool innerAreaColumnChanged)
        {
            columnOfSection++;
            if (SectionEastOfInnerAreaCell)
            {
                columnOfSection = 0;
                innerAreaColumnChanged = true;
            }
            else
            {
                UpdateCellsForEastSectionShiftWithinSameInnerCell();
                innerAreaColumnChanged = false;
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
        }

        public sealed override void ShiftSectionEast(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaColumnChanged)
        {
            columnOfSection++;
            if(SectionEastOfInnerAreaCell)
            {
                columnOfSection = 0;
                innerAreaColumnChanged = true;
            }
            else
            {
                innerAreaColumnChanged = false;

                //Remove two cells in first column
                cellsToRemove.Add(cellsOnEndlessGrid[BottomLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[TopLeftCellIndex]);

                UpdateCellsForEastSectionShiftWithinSameInnerCell();

                //Add two cells in second column
                cellsToAdd.Add(cellsOnEndlessGrid[BottomRightCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[TopRightCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
        }

        void UpdateCellsForEastSectionShiftWithinSameInnerCell()
        {
            //Replace two cells in first column with two cells from second column
            cellsOnEndlessGrid[BottomLeftCellIndex] = cellsOnEndlessGrid[BottomRightCellIndex];
            cellsOnEndlessGrid[TopLeftCellIndex] = cellsOnEndlessGrid[TopRightCellIndex];

            //Increment column of cells in second column
            cellsOnEndlessGrid[BottomRightCellIndex].column++;
            cellsOnEndlessGrid[TopRightCellIndex].column++;
        }

        public sealed override void ShiftSectionWest(out bool innerAreaColumnChanged)
        {
            columnOfSection--;
            if (SectionWestOfInnerAreaCell)
            {
                columnOfSection = 1;
                innerAreaColumnChanged = true;
            }
            else
            {
                UpdateCellsForWestSectionShiftWithinSameInnerCell();
                innerAreaColumnChanged = false;
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
        }

        public sealed override void ShiftSectionWest(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaColumnChanged)
        {
            columnOfSection--;
            if (SectionWestOfInnerAreaCell)
            {
                columnOfSection = 1;
                innerAreaColumnChanged = true;
            }
            else
            {
                innerAreaColumnChanged = false;
                //Remove two cells in second column
                cellsToRemove.Add(cellsOnEndlessGrid[BottomRightCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[TopRightCellIndex]);

                UpdateCellsForWestSectionShiftWithinSameInnerCell();

                //Add two cells in second column
                cellsToAdd.Add(cellsOnEndlessGrid[BottomLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[TopLeftCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
        }

        void UpdateCellsForWestSectionShiftWithinSameInnerCell()
        {
            //Replace two cells in second column with two cells from first column
            cellsOnEndlessGrid[BottomRightCellIndex] = cellsOnEndlessGrid[BottomLeftCellIndex];
            cellsOnEndlessGrid[TopRightCellIndex] = cellsOnEndlessGrid[TopLeftCellIndex];

            //Decrement column of cells in first column
            cellsOnEndlessGrid[BottomLeftCellIndex].column--;
            cellsOnEndlessGrid[TopLeftCellIndex].column--;
        }





        public sealed override void ShiftSectionNorth(out bool innerAreaRowChanged)
        {
            rowOfSection++;
            if (SectionNorthOfInnerAreaCell)
            {
                rowOfSection = 0;
                innerAreaRowChanged = true;
            }
            else
            {
                UpdateCellsForNorthSectionShiftWithinSameInnerCell();
                innerAreaRowChanged = false;
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
        }

        public sealed override void ShiftSectionNorth(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaRowChanged)
        {
            rowOfSection++;
            if (SectionNorthOfInnerAreaCell)
            {
                rowOfSection = 0;
                innerAreaRowChanged = true;
            }
            else
            {
                innerAreaRowChanged = false;

                //Remove two cells in first row
                cellsToRemove.Add(cellsOnEndlessGrid[BottomLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[BottomRightCellIndex]);

                UpdateCellsForNorthSectionShiftWithinSameInnerCell();

                //Add two cells in second row
                cellsToAdd.Add(cellsOnEndlessGrid[TopLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[TopRightCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
        }

        void UpdateCellsForNorthSectionShiftWithinSameInnerCell()
        {
            //Replace two cells in first row with two cells from second row
            cellsOnEndlessGrid[BottomLeftCellIndex] = cellsOnEndlessGrid[TopLeftCellIndex];
            cellsOnEndlessGrid[BottomRightCellIndex] = cellsOnEndlessGrid[TopRightCellIndex];

            //Increment row of cells in second row
            cellsOnEndlessGrid[TopLeftCellIndex].row++;
            cellsOnEndlessGrid[TopRightCellIndex].row++;
        }

        public sealed override void ShiftSectionSouth(out bool innerAreaRowChanged)
        {
            rowOfSection--;
            if (SectionSouthOfInnerAreaCell)
            {
                rowOfSection = 1;
                innerAreaRowChanged = true;
            }
            else
            {
                UpdateCellsForSouthSectionShiftWithinSameInnerCell();
                innerAreaRowChanged = false;
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
        }

        public sealed override void ShiftSectionSouth(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaRowChanged)
        {
            rowOfSection--;
            if (SectionSouthOfInnerAreaCell)
            {
                rowOfSection = 1;
                innerAreaRowChanged = true;
            }
            else
            {
                innerAreaRowChanged = false;
                //Remove two cells in secondRow
                cellsToRemove.Add(cellsOnEndlessGrid[TopLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[TopRightCellIndex]);

                UpdateCellsForSouthSectionShiftWithinSameInnerCell();

                //Add two cells in first row
                cellsToAdd.Add(cellsOnEndlessGrid[BottomLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[BottomRightCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection);
        }

        void UpdateCellsForSouthSectionShiftWithinSameInnerCell()
        {
            //Replace two cells in second row with two cells from first row
            cellsOnEndlessGrid[TopLeftCellIndex] = cellsOnEndlessGrid[BottomLeftCellIndex];
            cellsOnEndlessGrid[TopRightCellIndex] = cellsOnEndlessGrid[BottomRightCellIndex];

            //Decrement row of cells in first row
            cellsOnEndlessGrid[BottomLeftCellIndex].row--;
            cellsOnEndlessGrid[BottomRightCellIndex].row--;
        }
    }

    internal class Sectioned2DXZGridCells : Sectioned2DGridCells
    {
        public Sectioned2DXZGridCells(Cell innerAreaCell, int rowOfSection, int columnOfSection)
            : base(innerAreaCell, rowOfSection, columnOfSection) { }

        public sealed override void SetSectionBoundary(Boundary boundary, Vector3 positionOfInnerAreaCell, CellDimensions dimensionsofInnerAreaCell)
        {
            CellDimensions sectionDimensions = new CellDimensions(dimensionsofInnerAreaCell.length * .5f, dimensionsofInnerAreaCell.width * .5f);

            float sectionXPosition = columnOfSection == 0 ? positionOfInnerAreaCell.x : positionOfInnerAreaCell.x + sectionDimensions.width;
            float sectionZPosition = rowOfSection == 0 ? positionOfInnerAreaCell.z : positionOfInnerAreaCell.z + sectionDimensions.length;


            Vector3 sectionPosition = new Vector3(sectionXPosition, positionOfInnerAreaCell.y, sectionZPosition);
            boundary.SetEastNorthAndTopBoundaries(sectionPosition, sectionDimensions);
            boundary.SetWestSouthAndBottomBoundaries(sectionPosition);
        }
    }

    internal class Sectioned2DXYGridCells : Sectioned2DGridCells
    {
        public Sectioned2DXYGridCells(Cell innerAreaCell, int rowOfSection, int columnOfSection)
            : base(innerAreaCell, rowOfSection, columnOfSection) { }

        public sealed override void SetSectionBoundary(Boundary boundary, Vector3 positionOfInnerAreaCell, CellDimensions dimensionsofInnerAreaCell)
        {
            CellDimensions sectionDimensions = new CellDimensions(dimensionsofInnerAreaCell.length * .5f, dimensionsofInnerAreaCell.width * .5f);

            float sectionXPosition = columnOfSection == 0 ? positionOfInnerAreaCell.x : positionOfInnerAreaCell.x + sectionDimensions.width;
            float sectionYPosition = rowOfSection == 0 ? positionOfInnerAreaCell.y : positionOfInnerAreaCell.y + sectionDimensions.length;


            Vector3 sectionPosition = new Vector3(sectionXPosition, sectionYPosition, positionOfInnerAreaCell.z);
            boundary.SetEastNorthAndTopBoundaries(sectionPosition, sectionDimensions);
            boundary.SetWestSouthAndBottomBoundaries(sectionPosition);
        }
    }

    internal class Sectioned3DGridCells : SectionedGridCells
    {
        //Lower/Upper refers to layer (0 or 1)
        //Bottom/Top refers to row (0 or 1)
        //Left/Right refers to columns (0 or 1)
        const int LowerBottomLeftCellIndex = 0;
        const int LowerBottomRightCellIndex = 1;
        const int LowerTopLeftCellIndex = 2;
        const int LowerTopRightCellIndex = 3;

        const int UpperBottomLeftCellIndex = 4;
        const int UpperBottomRightCellIndex = 5;
        const int UpperTopLeftCellIndex = 6;
        const int UpperTopRightCellIndex = 7;

        int layerOfSection;

        public Sectioned3DGridCells(Cell innerAreaCell, int rowOfSection, int columnOfSection, int layerOfSection)
            : base(GetFirstCellInGroup(innerAreaCell, rowOfSection, columnOfSection, layerOfSection), 8, rowOfSection, columnOfSection,
            GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection)) 
        {
            this.layerOfSection = layerOfSection;
        }

        public int LayerOfSection { get { return layerOfSection; } }

        bool SectionAboveInnerAreaCell { get { return layerOfSection == 2; } }
        bool SectionBelowInnerAreaCell { get { return layerOfSection == -1; } }
        

        public Cell this[int layer, int row, int column]
        { 
            get 
            { 
                return cellsOnEndlessGrid[(row * 2 + column) + (4 * layer)]; 
            } 
        }

        //See explanation in ActiveSectioned2DGridCells
        static Cell GetFirstCellInGroup(Cell innerAreaCell, int rowOfSection, int columnOfSection, int layerOfSection)
        {
            int firstCellInGroupRow = rowOfSection == 0 ? innerAreaCell.row - 1 : innerAreaCell.row;

            int firstCellInGroupColumn = columnOfSection == 0 ? innerAreaCell.column - 1 : innerAreaCell.column;

            int firstCellInGroupLayer = layerOfSection == 0 ? innerAreaCell.layer - 1: innerAreaCell.layer;

            return new Cell(firstCellInGroupRow, firstCellInGroupColumn, firstCellInGroupLayer);
        }

        //See explanation in ActiveSectioned2DGridCells
        static int GetIndexOfInnerAreaCell(int rowOfSection, int columnOfSection, int layerOfSection)
        {
            int index = 0;
            if (layerOfSection == 0)
                index += 4;

            if (rowOfSection == 0)
                index += 2;

            if (columnOfSection == 0)
                index += 1;

            return index;
        }

        public sealed override void AssignIndexes(Cell innerAreaCell, int layerOfSection, int rowOfSection, int columnOfSection)
        {
            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
            this.rowOfSection = rowOfSection;
            this.columnOfSection = columnOfSection;
            this.layerOfSection = layerOfSection;
            AssignIndexes(GetFirstCellInGroup(innerAreaCell, rowOfSection, columnOfSection, layerOfSection));
        }

        public sealed override void AssignIndexes(Cell firstCellInGroup)
        {
            for (int layer = 0, index = 0; layer < 2; layer++)
            {
                for (int row = 0; row < 2; row++)
                {
                    for (int column = 0; column < 2; column++, index++)
                    {
                        cellsOnEndlessGrid[index] = new Cell(firstCellInGroup.row + row, firstCellInGroup.column + column, firstCellInGroup.layer + layer);
                    }
                }
            }
        }

        public sealed override void CreateCellsUsingInnerAreaCell(Cell innerAreaCell, int layerOfSection, int rowOfSection, int columnOfSection, IList<Cell> bufferToAddCreatedCellsTo)
        {
            Cell firstCellInGroup = GetFirstCellInGroup(innerAreaCell, rowOfSection, columnOfSection, layerOfSection);

            for (int layer = 0; layer < 2; layer++)
            {
                for (int row = 0; row < 2; row++)
                {
                    for (int column = 0; column < 2; column++)
                    {
                        bufferToAddCreatedCellsTo.Add(new Cell(firstCellInGroup.row + row, firstCellInGroup.column + column, firstCellInGroup.layer + layer));
                    }
                }
            }
        }

        public sealed override bool IsCellInInnerArea(Cell cell)
        {
            return cell.row == FirstCellInInnerArea.row && cell.column == FirstCellInInnerArea.column && cell.layer == FirstCellInInnerArea.layer;
        }

        public sealed override void ShiftSectionEast(out bool innerAreaColumnChanged) 
        {
            columnOfSection++;
            if (SectionEastOfInnerAreaCell)
            {
                columnOfSection = 0;
                innerAreaColumnChanged = true;
            }
            else
            {
                UpdateCellsForEastSectionShiftWithinSameInnerCell();
                innerAreaColumnChanged = false;
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        public sealed override void ShiftSectionEast(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaColumnChanged)
        {
            columnOfSection++;
            if (SectionEastOfInnerAreaCell)
            {
                columnOfSection = 0;
                innerAreaColumnChanged = true;
            }
            else
            {
                innerAreaColumnChanged = false;
                //Remove four cells in first column
                cellsToRemove.Add(cellsOnEndlessGrid[LowerBottomLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[LowerTopLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperBottomLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperTopLeftCellIndex]);

                UpdateCellsForEastSectionShiftWithinSameInnerCell();

                //Add four cells in second column
                cellsToAdd.Add(cellsOnEndlessGrid[LowerBottomRightCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[LowerTopRightCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperBottomRightCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperTopRightCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        void UpdateCellsForEastSectionShiftWithinSameInnerCell()
        {
            //Replace four cells in first column with four cells from second column
            cellsOnEndlessGrid[LowerBottomLeftCellIndex] = cellsOnEndlessGrid[LowerBottomRightCellIndex];
            cellsOnEndlessGrid[LowerTopLeftCellIndex] = cellsOnEndlessGrid[LowerTopRightCellIndex];
            cellsOnEndlessGrid[UpperBottomLeftCellIndex] = cellsOnEndlessGrid[UpperBottomRightCellIndex];
            cellsOnEndlessGrid[UpperTopLeftCellIndex] = cellsOnEndlessGrid[UpperTopRightCellIndex];

            //Increment column of cells in second column
            cellsOnEndlessGrid[LowerBottomRightCellIndex].column++;
            cellsOnEndlessGrid[LowerTopRightCellIndex].column++;
            cellsOnEndlessGrid[UpperBottomRightCellIndex].column++;
            cellsOnEndlessGrid[UpperTopRightCellIndex].column++;
        }

        public sealed override void ShiftSectionWest(out bool innerAreaColumnChanged)
        {
            columnOfSection--;
            if (SectionWestOfInnerAreaCell)
            {
                columnOfSection = 1;
                innerAreaColumnChanged = true;
            }
            else
            {
                UpdateCellsForWestSectionShiftWithinSameInnerCell();
                innerAreaColumnChanged = false;
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        public sealed override void ShiftSectionWest(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaColumnChanged)
        {
            columnOfSection--;
            if (SectionWestOfInnerAreaCell)
            {
                columnOfSection = 1;
                innerAreaColumnChanged = true;
            }
            else
            {
                innerAreaColumnChanged = false;

                //Remove four cells in second column
                cellsToRemove.Add(cellsOnEndlessGrid[LowerBottomRightCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[LowerTopRightCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperBottomRightCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperTopRightCellIndex]);

                UpdateCellsForWestSectionShiftWithinSameInnerCell();

                //Add four cells in second column
                cellsToAdd.Add(cellsOnEndlessGrid[LowerBottomLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[LowerTopLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperBottomLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperTopLeftCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        void UpdateCellsForWestSectionShiftWithinSameInnerCell()
        {
            //Replace four cells in second column with four cells from first column
            cellsOnEndlessGrid[LowerBottomRightCellIndex] = cellsOnEndlessGrid[LowerBottomLeftCellIndex];
            cellsOnEndlessGrid[LowerTopRightCellIndex] = cellsOnEndlessGrid[LowerTopLeftCellIndex];
            cellsOnEndlessGrid[UpperBottomRightCellIndex] = cellsOnEndlessGrid[UpperBottomLeftCellIndex];
            cellsOnEndlessGrid[UpperTopRightCellIndex] = cellsOnEndlessGrid[UpperTopLeftCellIndex];

            //Decrement column of cells in first column
            cellsOnEndlessGrid[LowerBottomLeftCellIndex].column--;
            cellsOnEndlessGrid[LowerTopLeftCellIndex].column--;
            cellsOnEndlessGrid[UpperBottomLeftCellIndex].column--;
            cellsOnEndlessGrid[UpperTopLeftCellIndex].column--;
        }

        public sealed override void ShiftSectionNorth(out bool innerAreaRowChanged)
        {
            rowOfSection++;
            if (SectionNorthOfInnerAreaCell)
            {
                rowOfSection = 0;
                innerAreaRowChanged = true;
            }
            else
            {
                innerAreaRowChanged = false;
                UpdateCellsForNorthSectionShiftWithinSameInnerCell();
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        public sealed override void ShiftSectionNorth(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaRowChanged)
        {
            rowOfSection++;
            if (SectionNorthOfInnerAreaCell)
            {
                rowOfSection = 0;
                innerAreaRowChanged = true;
            }
            else
            {
                innerAreaRowChanged = false;
                //Remove four cells in first row
                cellsToRemove.Add(cellsOnEndlessGrid[LowerBottomLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[LowerBottomRightCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperBottomLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperBottomRightCellIndex]);

                UpdateCellsForNorthSectionShiftWithinSameInnerCell();

                //Add four cells in second row
                cellsToAdd.Add(cellsOnEndlessGrid[LowerTopLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[LowerTopRightCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperTopLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperTopRightCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        void UpdateCellsForNorthSectionShiftWithinSameInnerCell()
        {
            //Replace four cells in first row with four cells from second row
            cellsOnEndlessGrid[LowerBottomLeftCellIndex] = cellsOnEndlessGrid[LowerTopLeftCellIndex];
            cellsOnEndlessGrid[LowerBottomRightCellIndex] = cellsOnEndlessGrid[LowerTopRightCellIndex];
            cellsOnEndlessGrid[UpperBottomLeftCellIndex] = cellsOnEndlessGrid[UpperTopLeftCellIndex];
            cellsOnEndlessGrid[UpperBottomRightCellIndex] = cellsOnEndlessGrid[UpperTopRightCellIndex];


            //Increment row of cells in second row
            cellsOnEndlessGrid[LowerTopLeftCellIndex].row++;
            cellsOnEndlessGrid[LowerTopRightCellIndex].row++;
            cellsOnEndlessGrid[UpperTopLeftCellIndex].row++;
            cellsOnEndlessGrid[UpperTopRightCellIndex].row++;
        }

        public sealed override void ShiftSectionSouth(out bool innerAreaRowChanged)
        {
            rowOfSection--;
            if (SectionSouthOfInnerAreaCell)
            {
                rowOfSection = 1;
                innerAreaRowChanged = true;
            }
            else
            {
                innerAreaRowChanged = false;
                UpdateCellsForSouthSectionShiftWithinSameInnerCell();
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        public sealed override void ShiftSectionSouth(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaRowChanged)
        {
            rowOfSection--;
            if (SectionSouthOfInnerAreaCell)
            {
                rowOfSection = 1;
                innerAreaRowChanged = true;
            }
            else
            {
                innerAreaRowChanged = false;
                //Remove four cells in secondRow
                cellsToRemove.Add(cellsOnEndlessGrid[LowerTopLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[LowerTopRightCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperTopLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperTopRightCellIndex]);

                UpdateCellsForSouthSectionShiftWithinSameInnerCell();

                //Add four cells in first row
                cellsToAdd.Add(cellsOnEndlessGrid[LowerBottomLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[LowerBottomRightCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperBottomLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperBottomRightCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        void UpdateCellsForSouthSectionShiftWithinSameInnerCell()
        {
            //Replace four cells in second row with four cells from first row
            cellsOnEndlessGrid[LowerTopLeftCellIndex] = cellsOnEndlessGrid[LowerBottomLeftCellIndex];
            cellsOnEndlessGrid[LowerTopRightCellIndex] = cellsOnEndlessGrid[LowerBottomRightCellIndex];
            cellsOnEndlessGrid[UpperTopLeftCellIndex] = cellsOnEndlessGrid[UpperBottomLeftCellIndex];
            cellsOnEndlessGrid[UpperTopRightCellIndex] = cellsOnEndlessGrid[UpperBottomRightCellIndex];

            //Decrement row of cells in first row
            cellsOnEndlessGrid[LowerBottomLeftCellIndex].row--;
            cellsOnEndlessGrid[LowerBottomRightCellIndex].row--;
            cellsOnEndlessGrid[UpperBottomLeftCellIndex].row--;
            cellsOnEndlessGrid[UpperBottomRightCellIndex].row--;
        }

        public void ShiftSectionUp(out bool innerAreaLayerChanged)
        {
            layerOfSection++;
            if (SectionAboveInnerAreaCell)
            {
                layerOfSection = 0;
                innerAreaLayerChanged = true;
            }
            else
            {
                UpdateCellsForUpSectionShiftWithinSameInnerCell();
                innerAreaLayerChanged = false;
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        public void ShiftSectionUp(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaLayerChanged)
        {
            layerOfSection++;
            if (SectionAboveInnerAreaCell)
            {
                layerOfSection = 0;
                innerAreaLayerChanged = true;
            }
            else
            {
                innerAreaLayerChanged = false;

                //Remove four cells in first layer
                cellsToRemove.Add(cellsOnEndlessGrid[LowerBottomLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[LowerBottomRightCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[LowerTopLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[LowerTopRightCellIndex]);

                UpdateCellsForUpSectionShiftWithinSameInnerCell();

                //Add four cells in second layer
                cellsToAdd.Add(cellsOnEndlessGrid[UpperBottomLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperBottomRightCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperTopLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[UpperTopRightCellIndex]);

            }
            
            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        void UpdateCellsForUpSectionShiftWithinSameInnerCell()
        {
            //Replace the cells in the first layer with the cells in the second layer
            cellsOnEndlessGrid[LowerBottomLeftCellIndex] = cellsOnEndlessGrid[UpperBottomLeftCellIndex];
            cellsOnEndlessGrid[LowerBottomRightCellIndex] = cellsOnEndlessGrid[UpperBottomRightCellIndex];
            cellsOnEndlessGrid[LowerTopLeftCellIndex] = cellsOnEndlessGrid[UpperTopLeftCellIndex];
            cellsOnEndlessGrid[LowerTopRightCellIndex] = cellsOnEndlessGrid[UpperTopRightCellIndex];

            //Add 1 to layer of cells on second layer.
            cellsOnEndlessGrid[UpperBottomLeftCellIndex].layer++;
            cellsOnEndlessGrid[UpperBottomRightCellIndex].layer++;
            cellsOnEndlessGrid[UpperTopLeftCellIndex].layer++;
            cellsOnEndlessGrid[UpperTopRightCellIndex].layer++;
        }

        public void ShiftSectionDown(out bool innerAreaLayerChanged)
        {
            layerOfSection--;
            if (SectionBelowInnerAreaCell)
            {
                layerOfSection = 1;
                innerAreaLayerChanged = true;
            }
            else
            {
                innerAreaLayerChanged = false;
                UpdateCellsForDownSectionShiftWithinSameInnerCell();
            }
                
            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        public void ShiftSectionDown(IList<Cell> cellsToRemove, IList<Cell> cellsToAdd, out bool innerAreaLayerChanged)
        {
            layerOfSection--;
            if (SectionBelowInnerAreaCell)
            {
                layerOfSection = 1;
                innerAreaLayerChanged = true;
            }
            else
            {
                innerAreaLayerChanged = false;

                //Remove four cells in second layer
                cellsToRemove.Add(cellsOnEndlessGrid[UpperBottomLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperBottomRightCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperTopLeftCellIndex]);
                cellsToRemove.Add(cellsOnEndlessGrid[UpperTopRightCellIndex]);

                UpdateCellsForDownSectionShiftWithinSameInnerCell();

                //Add four cells in first layer
                cellsToAdd.Add(cellsOnEndlessGrid[LowerBottomLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[LowerBottomRightCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[LowerTopLeftCellIndex]);
                cellsToAdd.Add(cellsOnEndlessGrid[LowerTopRightCellIndex]);
            }

            indexOfInnerAreaCell = GetIndexOfInnerAreaCell(rowOfSection, columnOfSection, layerOfSection);
        }

        void UpdateCellsForDownSectionShiftWithinSameInnerCell()
        {
            //Replace the cells in the first layer with the cells in the second layer
            cellsOnEndlessGrid[UpperBottomLeftCellIndex] = cellsOnEndlessGrid[LowerBottomLeftCellIndex];
            cellsOnEndlessGrid[UpperBottomRightCellIndex] = cellsOnEndlessGrid[LowerBottomRightCellIndex];
            cellsOnEndlessGrid[UpperTopLeftCellIndex] = cellsOnEndlessGrid[LowerTopLeftCellIndex];
            cellsOnEndlessGrid[UpperTopRightCellIndex] = cellsOnEndlessGrid[LowerTopRightCellIndex];

            //Add 1 to layer of cells on second layer.
            cellsOnEndlessGrid[LowerBottomLeftCellIndex].layer--;
            cellsOnEndlessGrid[LowerBottomRightCellIndex].layer--;
            cellsOnEndlessGrid[LowerTopLeftCellIndex].layer--;
            cellsOnEndlessGrid[LowerTopRightCellIndex].layer--;
        }

        public sealed override void SetSectionBoundary(Boundary boundary, Vector3 positionOfInnerAreaCell, CellDimensions dimensionsofInnerAreaCell)
        {
            CellDimensions sectionDimensions = new CellDimensions(dimensionsofInnerAreaCell.height * .5f, dimensionsofInnerAreaCell.length * .5f, dimensionsofInnerAreaCell.width * .5f);

            float sectionXPosition = columnOfSection == 0 ? positionOfInnerAreaCell.x : positionOfInnerAreaCell.x + sectionDimensions.width;

            float sectionYPosition = layerOfSection == 0 ? positionOfInnerAreaCell.y : positionOfInnerAreaCell.y + sectionDimensions.height;

            float sectionZPosition = rowOfSection == 0 ? positionOfInnerAreaCell.z : positionOfInnerAreaCell.z + sectionDimensions.length;


            Vector3 sectionPosition = new Vector3(sectionXPosition, sectionYPosition, sectionZPosition);
            boundary.SetEastNorthAndTopBoundaries(sectionPosition, sectionDimensions);
            boundary.SetWestSouthAndBottomBoundaries(sectionPosition);
        }
    }
}