//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
	using System.Collections;
	using System.Collections.Generic;
#if !UNITY_4
    using UnityEngine.SceneManagement;
#endif

    /// <summary>
    /// A Cell Object Loader component which loads objects via scenes. This is similar to the 
    /// <see cref = "AsyncSceneLoader" href="AsyncSceneLoader.html">AsyncSceneLoader</see> component, except this version uses 
    /// <see href="http://docs.unity3d.com/ScriptReference/Application.LoadLevelAdditive.html">Application.LoadLevelAdditive</see> to load the scenes.
    /// <para>This means the main Unity thread will be blocked while the objects in the scene are loaded.</para>
    /// <para>You should never have to interact directly with this component, as the methods/properties are called/used
    /// as needed by the Dynamic Loading Kit.</para>
    /// </summary>
    /// <title>SceneLoader Class</title>
    /// <category>Cell Object Loaders</category>
    /// <navigationName>SceneLoader</navigationName>
    /// <fileName>SceneLoader.html</fileName>
    /// <syntax>public sealed class SceneLoader : <see cref = "BaseSceneLoader" href = "BaseSceneLoader.html">BaseSceneLoader</see></syntax>
    /// <inspector name = "Time To Wait Between Loads" type = "float">The amount of time to yield (in seconds) between scene loads. For instance, a value of .3 will result in a scene being fully loaded, followed by
    /// the scene loader yielding for .3 seconds, followed by the second scene being fully loaded, and so on.
    /// <para>A value of 0 will result in no yielding between scene loads, but will most likely hinder performance.</para></inspector>
    [AddComponentMenu("Dynamic Loading Kit/Cell Object Loaders/Scene Loader")]
    public sealed class SceneLoader : BaseSceneLoader
    {
        [SerializeField]
        internal float timeToWaitBetweenLoads = .3f;

        bool shouldYieldForTime;
        WaitForSeconds yieldTime;

        void Awake()
        {
            if (timeToWaitBetweenLoads.LessThanOrEqualToZero())
                shouldYieldForTime = false;
            else
                shouldYieldForTime = true;

            if(shouldYieldForTime)
                yieldTime = new WaitForSeconds(timeToWaitBetweenLoads);
        }

        /// <summary>
        /// Loads the scene/objects with the name objectName into the current scene via <see href="http://docs.unity3d.com/ScriptReference/Application.LoadLevelAdditive.html">Application.LoadLevelAdditive</see>.
        /// </summary>
        /// <param name="objectName" type = "string">The name of the object/scene to load.</param>
        /// <displayName id = "LoadCellObjectIntoLevel">LoadCellObjectIntoLevel(string)</displayName>
        /// <syntax>protected sealed override YieldInstruction LoadCellObjectIntoLevel(string objectName)</syntax>
        /// <returns type = "YieldInstruction" link = "http://docs.unity3d.com/ScriptReference/YieldInstruction.html">If "Time To Wait Between Loads" is greater
        /// than 0, returns a WaitForSeconds object. Otherwise, null.</returns>
        protected sealed override YieldInstruction LoadCellObjectIntoLevel(string objectName)
        {
#if UNITY_4
            Application.LoadLevelAdditive(objectName);
#else
            SceneManager.LoadScene(objectName, LoadSceneMode.Additive);
#endif
            if (shouldYieldForTime)
                return yieldTime;
            else
                return null;
        }
    }
}