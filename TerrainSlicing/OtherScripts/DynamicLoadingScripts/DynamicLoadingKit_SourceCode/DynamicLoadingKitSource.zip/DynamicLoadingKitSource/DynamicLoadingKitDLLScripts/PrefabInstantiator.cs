//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System.Collections.Generic;

    /// <summary>
    /// A Cell Object Loader which loads cell object prefabs into the scene via the 
    /// <see href="http://docs.unity3d.com/ScriptReference/Resources.Load.html">Resources.Load</see> and 
    /// <see href="http://docs.unity3d.com/ScriptReference/Object.Instantiate.html">Object.Instantiate</see>
    /// methods.
    /// <para>
    /// When using this component, it's imperative that your prefabs be located directly in a 
    /// folder named "Resources" (can't be in subfolders).
    /// </para>
    /// <para>
    /// You should never have to interact directly with this component, as the methods/properties are called/used
    /// as needed by the Dynamic Loading Kit.
    /// </para>
    /// </summary>
    /// <title>PrefabInstantiator Class</title>
    /// <category>Cell Object Loaders</category>
    /// <navigationName>PrefabInstantiator</navigationName>
    /// <fileName>PrefabInstantiator.html</fileName>
    /// <syntax>public class PrefabInstantiator : <see cref = "CellObjectLoader" href = "CellObjectLoader.html">CellObjectLoader</see></syntax>
    /// <inspector name = "Time To Yield Between Instantiates" type = "float">Each method call will attempt to instantiate multiple objects. This instantiation process is carried out
    /// over a period of time for performance reasons. This value sets the amount of time to wait between calls of Instantiate.
    /// <para>A value of 0 will cause all objects to be Instantiated in a single frame and is not recommended.</para></inspector>
    [AddComponentMenu("Dynamic Loading Kit/Cell Object Loaders/Prefab Loader")]
    public sealed class PrefabInstantiator : CellObjectLoader
    {
        [SerializeField]
	    internal float timeToYieldBetweenInstantiates = .3f;

	    YieldInstruction yieldForTime;

        /// <summary>
        /// Because Instantiated prefabs do not need a frame to "process", pre-loading is not required, and so this
        /// property is overridden to return false.
        /// </summary>
        /// <type>bool</type>
        public sealed override bool IsSingleFrameAttachmentPreloadRequired { get { return false; } }

	    void Awake()
        {
            yieldForTime = timeToYieldBetweenInstantiates > 0f ? new WaitForSeconds(timeToYieldBetweenInstantiates) : null;
        }

        /// <summary>
        /// Instantiates and attaches all cell objects to the input cells in a single frame. This is not very performant and so should only
        /// be used in Awake or Start.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the attached.</param>
        /// <displayName id = "AttachCellObjectsToCellsInSingleFrame">AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override void AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int loaderID)</syntax>
        public sealed override void AttachCellObjectsToCellsInSingleFrame<T>(List<T> cells, int loaderID)
	    {
            CellString cellString = RegisteredUsers[loaderID].CellString;
            foreach(T cell in cells)
		    {
                cellString.MatchStringToCell(cell.CellOnWorldGrid);
			    string objName = cellString.ToString();
			    GameObject obj = (GameObject)GameObject.Instantiate(Resources.Load(objName), cell.CellObjectPosition, Quaternion.identity);
			    obj.name = objName;
                cell.AttachCellObjectToCell(obj, true);
		    }
	    }

        /// <summary>
        /// Loads and attaches the objects associated with the input cells to the cells over a period of frames.
        /// After each Instantiation, if "Time To Yield Between Instantiates" is greater than 0, that amount of time is yielded.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be loaded and attached.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the load and attachment.</param>
        /// <displayName id = "AttachCellObjectsToCellsInSingleFrame">LoadAndAttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int loaderID)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> LoadAndAttachCellObjectsToCells<T>(List<T> cells, int loaderID)
	    {
            CellString cellString = RegisteredUsers[loaderID].CellString;
            foreach(T cell in cells)
            {
                cellString.MatchStringToCell(cell.CellOnWorldGrid);
			    string objName = cellString.ToString();
                GameObject obj = (GameObject)GameObject.Instantiate(Resources.Load(objName), cell.CellObjectPosition, Quaternion.identity);
			    obj.name = objName;
                cell.AttachCellObjectToCell(obj, true);
                if (yieldForTime != null)
				    yield return yieldForTime;
		    }
	    }
    }
}