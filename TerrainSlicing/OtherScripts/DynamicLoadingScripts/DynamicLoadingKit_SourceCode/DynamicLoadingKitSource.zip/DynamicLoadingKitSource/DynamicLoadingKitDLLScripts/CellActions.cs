﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System.Collections.Generic;

    /// <summary>
    /// Provides a base implementation for Cell Actions.
    /// <para>Cell Actions can be attached to the main objects (cell objects) used in the DLK to perform
    /// custom actions either before a cell is deactivated or after a cell is activated.</para>
    /// <para>Note that you do not need to call the methods of the Cell Actions yourself. This is done automatically by the
    /// DLK, although you will need to make sure the "Use Cell Actions" option is checked in the inspector of whatever
    /// <see cref="PrimaryCellObjectSubController" href = "PrimaryCellObjectSubController.html">PrimaryCellObjectSubController</see> Component you are using.</para>
    /// </summary>
    /// <title>CellAction Abstract Class</title>
    /// <category>Secondary Components</category>
    /// <navigationName>CellAction</navigationName>
    /// <fileName>CellAction.html</fileName>
    /// <syntax>public abstract class CellAction : MonoBehaviour</syntax>
    public abstract class CellAction : MonoBehaviour
    {
        /// <summary>
        /// When overridden by a derived class, performs an action or actions before a cell is deactivated.
        /// </summary>
        /// <param name="worldCell" type = "IWorldCell" link = "IWorldCell.html">The world cell (who's associated cell object
        /// has the Cell Action attached to it) that is about to be deactivated.</param>
        /// <displayName id="DoStuffBeforeCellIsDeactivated">DoStuffBeforeCellIsDeactivated(IWorldCell)</displayName>
        /// <syntax>public virtual IEnumerator&lt;YieldInstruction&gt; DoStuffBeforeCellIsDeactivated(IWorldCell worldCell)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public virtual IEnumerator<YieldInstruction> DoStuffBeforeCellIsDeactivated(IWorldCell worldCell) { yield break; }

        /// <summary>
        /// When overridden by a derived class, performs an action or actions after a cell is activated.
        /// </summary>
        /// <param name="worldCell" type = "IWorldCell" link = "IWorldCell.html">The world cell (who's associated cell object
        /// has the Cell Action attached to it) that was just activated.</param>
        /// <displayName id="DoStuffAfterCellIsActivated">DoStuffAfterCellIsActivated(IWorldCell)</displayName>
        /// <syntax>public virtual IEnumerator&lt;YieldInstruction&gt; DoStuffAfterCellIsActivated(IWorldCell worldCell)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public virtual IEnumerator<YieldInstruction> DoStuffAfterCellIsActivated(IWorldCell worldCell) { yield break; }
    }
}