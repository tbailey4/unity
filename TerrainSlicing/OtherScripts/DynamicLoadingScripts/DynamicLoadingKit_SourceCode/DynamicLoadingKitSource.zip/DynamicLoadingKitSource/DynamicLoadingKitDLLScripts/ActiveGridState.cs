﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System;
    using System.Text;
    using UnityEngine;

    [Serializable]
    internal class ActiveGridState
    {
        //cellObjectsEnabled and cellObjectLoaded are similar but not quite
        //cellObjectsEnabled controls whether most operations will attempt to load cell objects.
        //If it's false, they will not. Only a TryLoadCellObjects call will enable and load the cell objects.
        //cellObjectLoaded stores whether the cell objects are actually loaded into the scene at the current moment
        public bool cellObjectsEnabled = true, isWorldToSyncToPersistent, playerMovedDuringMultiFrameAction;
        public bool monitorInnerAreaBoundaries = true, monitorWorldShiftBoundaries = true;

        //the primary cell is the first cell in the grid when the Active Grid Type is Outer_Ring_Grid, or the 
        //inner area cell which the player is in when the grid type is Sectioned_Grid
        public int innerLayers = 1, innerRows = 1, innerColumns = 1, outerRingWidth = 1, idOfSyncedToWorld,
                   primaryCellLayer = 1, primaryCellRow = 1, primaryCellColumn = 1, rowOfSection, columnOfSection, layerOfSection, 
                   rowOfSectionAfterActionCompletes, columnOfSectionAfterActionCompletes, layerOfSectionAfterActionCompletes;

        public bool multiFrameActionExecuting, completeActionNextSessionIfGameExitsBeforeActionCompletes, delayMove, ignoreWorldInPersistentData, cellObjectsLoaded, setPlayerYPositionUsingTerrainHeight, waitingOnCellOriginUpdate;

        internal MultiFrameActionType multiFrameActionType;

        public float playerYOffsetWhenSettingBasedOnTerrainHeight;
        public Vector3 amountToMoveGridOrPositionToMoveGridTo;
        public Cell primaryCellOfGridAfterActionCompletes;
        public World worldToSyncTo;

        public Cell firstCellInInnerArea, lastCellInInnerArea;

        public ActiveGridState() { }

        public ActiveGridState(ActiveGridState activeGridStateToStartIn)
        {
            cellObjectsEnabled = activeGridStateToStartIn.cellObjectsEnabled;
            monitorInnerAreaBoundaries = activeGridStateToStartIn.monitorInnerAreaBoundaries;
            monitorWorldShiftBoundaries = activeGridStateToStartIn.monitorWorldShiftBoundaries;

            innerLayers = activeGridStateToStartIn.innerLayers;
            innerRows = activeGridStateToStartIn.innerRows;
            innerColumns = activeGridStateToStartIn.innerColumns;
            outerRingWidth = activeGridStateToStartIn.outerRingWidth;
            idOfSyncedToWorld = activeGridStateToStartIn.idOfSyncedToWorld;

            primaryCellLayer = activeGridStateToStartIn.primaryCellLayer;
            primaryCellRow = activeGridStateToStartIn.primaryCellRow;
            primaryCellColumn = activeGridStateToStartIn.primaryCellColumn;

            layerOfSection = activeGridStateToStartIn.layerOfSection;
            rowOfSection = activeGridStateToStartIn.rowOfSection;
            columnOfSection = activeGridStateToStartIn.columnOfSection;

            setPlayerYPositionUsingTerrainHeight = activeGridStateToStartIn.setPlayerYPositionUsingTerrainHeight;
            playerYOffsetWhenSettingBasedOnTerrainHeight = activeGridStateToStartIn.playerYOffsetWhenSettingBasedOnTerrainHeight;
        }
        
        public void AppendDataToStringBuilder(StringBuilder stringBuilder, bool isWorldPersistent)
        {
            AppendGridDimensions(stringBuilder);
            stringBuilder.Append('/');
            AppendPrimaryCellOfActiveGrid(stringBuilder);
            stringBuilder.Append('/');
            AppendIDOfWorldToSyncTo(stringBuilder, isWorldPersistent);
            stringBuilder.Append('/');
            AppendSectionData(stringBuilder);
            stringBuilder.Append('/');
            AppendBooleanStateData(stringBuilder);
            stringBuilder.Append('/');
            AppendPlayerYPositionSetInstructions(stringBuilder);
        }

        void AppendGridDimensions(StringBuilder stringBuilder)
        {
            stringBuilder.Append(innerLayers);
            stringBuilder.Append('/');
            stringBuilder.Append(innerRows);
            stringBuilder.Append('/');
            stringBuilder.Append(innerColumns);
            stringBuilder.Append('/');
            stringBuilder.Append(outerRingWidth);
        }

        void AppendPrimaryCellOfActiveGrid(StringBuilder stringBuilder)
        {
            if (multiFrameActionExecuting && multiFrameActionType > MultiFrameActionType.Desync 
                && (completeActionNextSessionIfGameExitsBeforeActionCompletes || playerMovedDuringMultiFrameAction))
            {
                AppendFirstCellOfActiveGrid(stringBuilder, primaryCellOfGridAfterActionCompletes.layer + 1,
                                                           primaryCellOfGridAfterActionCompletes.row + 1,
                                                           primaryCellOfGridAfterActionCompletes.column + 1);
            }
            else
                AppendFirstCellOfActiveGrid(stringBuilder, primaryCellLayer, primaryCellRow, primaryCellColumn);
            
        }

        void AppendFirstCellOfActiveGrid(StringBuilder stringBuilder, int layer, int row, int column)
        {
            stringBuilder.Append(layer);
            stringBuilder.Append('/');
            stringBuilder.Append(row);
            stringBuilder.Append('/');
            stringBuilder.Append(column);
        }

        void AppendIDOfWorldToSyncTo(StringBuilder stringBuilder, bool isWorldPersistent)
        {
            if (multiFrameActionExecuting 
                && (completeActionNextSessionIfGameExitsBeforeActionCompletes || playerMovedDuringMultiFrameAction)
                && (multiFrameActionType == MultiFrameActionType.Desync || multiFrameActionType > MultiFrameActionType.MoveToLocation))
            {
                if (worldToSyncTo != null && isWorldToSyncToPersistent)
                    stringBuilder.Append(worldToSyncTo.worldID);
                else
                    stringBuilder.Append("X");
            }
            else
            {
                if(isWorldPersistent)
                    stringBuilder.Append(idOfSyncedToWorld);
                else
                    stringBuilder.Append("X");
            }
        }

        //not used anymore, we'll keep it around to not conflict with existing
        //save data.
        void AppendSectionData(StringBuilder stringBuilder)
        {
            if (multiFrameActionExecuting && multiFrameActionType > MultiFrameActionType.Desync 
                && (completeActionNextSessionIfGameExitsBeforeActionCompletes || playerMovedDuringMultiFrameAction))
            {
                AppendSectionData(stringBuilder, layerOfSectionAfterActionCompletes,
                                                 rowOfSectionAfterActionCompletes,
                                                 columnOfSectionAfterActionCompletes);
            }
            else
                AppendSectionData(stringBuilder, layerOfSection, rowOfSection, columnOfSection);
        }

        void AppendSectionData(StringBuilder stringBuilder, int layerOfSectionToSave, int rowOfSectionToSave, int columnOfSectionToSave)
        {
            stringBuilder.Append(layerOfSectionToSave);
            stringBuilder.Append('/');
            stringBuilder.Append(rowOfSectionToSave);
            stringBuilder.Append('/');
            stringBuilder.Append(columnOfSectionToSave);
        }

        void AppendBooleanStateData(StringBuilder stringBuilder)
        {
            stringBuilder.Append(cellObjectsEnabled);
            stringBuilder.Append('/');
            stringBuilder.Append(monitorInnerAreaBoundaries);
            stringBuilder.Append('/');
            stringBuilder.Append(monitorWorldShiftBoundaries);
        }

        void AppendPlayerYPositionSetInstructions(StringBuilder stringBuilder)
        {
            if (multiFrameActionExecuting && completeActionNextSessionIfGameExitsBeforeActionCompletes && 
                !playerMovedDuringMultiFrameAction && (multiFrameActionType == MultiFrameActionType.MoveToLocation || multiFrameActionType >= MultiFrameActionType.SyncToNewWorldAroundPlayer))
            {
                stringBuilder.Append(setPlayerYPositionUsingTerrainHeight);
                stringBuilder.Append('/');
                stringBuilder.Append(playerYOffsetWhenSettingBasedOnTerrainHeight);
            }
            else
            {
                stringBuilder.Append(false);
                stringBuilder.Append('/');
                stringBuilder.Append(0f);
            }
        }


        public void SetStateFromStringData(string data, out bool foundWorldInSaveData)
        {
            string[] individualData = data.Split('/');
            innerLayers = int.Parse(individualData[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            innerRows = int.Parse(individualData[1], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            innerColumns = int.Parse(individualData[2], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            outerRingWidth = int.Parse(individualData[3], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            primaryCellLayer = int.Parse(individualData[4], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            primaryCellRow = int.Parse(individualData[5], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            primaryCellColumn = int.Parse(individualData[6], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);

            if (ignoreWorldInPersistentData || individualData[7] == "X")
                foundWorldInSaveData = false;
            else
            {
                foundWorldInSaveData = true;
                idOfSyncedToWorld = int.Parse(individualData[7], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            }

            //Data 8, 9, and 10 is the section data, but may be in invalid format as it was previously used 
            //for different data
            layerOfSection = int.Parse(individualData[8]);
            if (layerOfSection < 0 || layerOfSection > 1)
                layerOfSection = 0;

            rowOfSection = int.Parse(individualData[9]);
            if (rowOfSection < 0 || rowOfSection > 1)
                rowOfSection = 0;

            columnOfSection = int.Parse(individualData[10]);
            if (columnOfSection < 0 || columnOfSection > 1)
                columnOfSection = 0;

            cellObjectsEnabled = bool.Parse(individualData[11]);
            monitorInnerAreaBoundaries = bool.Parse(individualData[12]);
            monitorWorldShiftBoundaries = bool.Parse(individualData[13]);

            if(individualData.Length > 14)
            {
                setPlayerYPositionUsingTerrainHeight = bool.Parse(individualData[14]);
                playerYOffsetWhenSettingBasedOnTerrainHeight = float.Parse(individualData[15]);
            }
        }
    }
}