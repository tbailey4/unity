﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System.Collections.Generic;

    /// <summary>
    /// Provides a base implementation for Player Movers.
    /// <para>
    /// Player Movers are used when an Active Grid needs to move the player associated with it, for instance when
    /// the grid is moved in response to a World Shift or when 
    /// <see cref="ActiveGrid.TryMovePlayerToLocation" href="ActiveGrid.html#TryMovePlayerToLocation">TryMovePlayerToLocation</see> 
    /// is called.
    /// </para>
    /// <para>
    /// If no PlayerMover is provided to the Active Grid, then the player is moved by simply adjusting its Transform.position. 
    /// Depending on your movement system, however, it may be unwise to move the player in this way, as it can de-sync the player 
    /// from the physics system and cause issues (such as the player falling through the world).
    /// </para>
    /// <para>
    /// For this reason, you can create a custom script or modify an existing script to derive from PlayerMover and implement 
    /// the required methods in a way that works with your movement scheme.
    /// </para>
    /// <para>
    /// For instance, a sample script is provided in the "TerrainSlicing/OtherScripts/DynamicLoadingScripts/PlayerMoverControllers" 
    /// folder called PlayerMoverCharacterMotor. This script is an extended version of the default CharacterMotor script 
    /// included with Unity's Standard Assets, and can be used with a CharacterController component. In fact, if 
    /// using a CharacterController component in your movement scheme, it is imperative that you use this custom script, 
    /// as the player WILL fall through the world otherwise. A PlayerMoverFPSInputController script is also provided, 
    /// which was adjusted to use the PlayerMoverCharacterMotor script rather than the default CharacterMotor script.
    /// </para>
    /// <para>
    /// In order to save the player's position correctly, the Active Grid needs to know exactly when the player's position has been changed 
    /// by your implementation. Please refer to the PlayerMoved property for more information.
    /// </para>
    /// </summary>
    /// <title>PlayerMover Abstract Class</title>
    /// <category>Secondary Components</category>
    /// <navigationName>PlayerMover</navigationName>
    /// <fileName>PlayerMover.html</fileName>
    /// <syntax>public abstract class PlayerMover : MonoBehaviour</syntax>
    public abstract class PlayerMover : MonoBehaviour
    {
        /// <summary>
        /// When implemented in a derived class, should return a value indicating whether the Player Mover has successfully moved 
        /// the player. If your MovePlayerByAmount or MovePlayerToPosition method is running and the player has not been moved yet, 
        /// this property should return false. Once you move the player, it should return true.
        /// <para>
        /// If you end your method (yield break) IMMEDIATELY after changing the player's position, then this property should always return false.
        /// </para>
        /// <para>
        /// If you change the player's position immediately after the coroutine starts (i.e., before the first yield return statement), 
        /// you can have this property always return true.
        /// </para>
        /// </summary>
        /// <type>bool</type>
        public abstract bool PlayerMoved { get; }

        /// <summary>
        /// When override in a derived class, moves the player transform specified by the Vector3 amount. That is, the amountToMovePlayer is
        /// simply added to the existing player's position.
        /// </summary>
        /// <param name="player" type="Transform">The player transform that will be moved.</param>
        /// <param name="amountToMovePlayer" type="Vector3">The amount the player will be moved (the amount to add to the player's current position).</param>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        /// <displayName id="MovePlayerByAmount">MovePlayerByAmount(Transform, Vector3)</displayName>
        /// <syntax>public abstract IEnumerator&lt;YieldInstruction&gt; MovePlayerByAmount(Transform player, Vector3 amountToMovePlayer)</syntax>
        public abstract IEnumerator<YieldInstruction> MovePlayerByAmount(Transform player, Vector3 amountToMovePlayer);

        /// <summary>
        /// When override in a derived class, moves the player transform specified to the specified position in world space.
        /// </summary>
        /// <param name="player" type="Transform">The player transform that will be moved.</param>
        /// <param name="position" type="Vector3">The position the player will be moved to.</param>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        /// <displayName id="MovePlayerToPosition">MovePlayerToPosition(Transform, Vector3)</displayName>
        /// <syntax>public abstract IEnumerator&lt;YieldInstruction&gt; MovePlayerToPosition(Transform player, Vector3 position)</syntax>
        public abstract IEnumerator<YieldInstruction> MovePlayerToPosition(Transform player, Vector3 position);
    }
}