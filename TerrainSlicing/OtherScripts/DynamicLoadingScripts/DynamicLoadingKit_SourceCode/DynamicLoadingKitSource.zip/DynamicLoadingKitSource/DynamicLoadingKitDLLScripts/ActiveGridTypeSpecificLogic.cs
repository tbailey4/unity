﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System;
    using System.Text;
    using System.Collections.Generic;

    public partial class ActiveGrid
    {
        interface IActiveGridTypeSpecificLogic
        {
            ActiveGridCells CreateActiveGridCells(Cell firstCell, WorldType worldType, int layerOfSection, int rowOfSection, int columnOfSection);
            Cell FindPrimaryCellInGridUsingFirstCellInInnerAreaOfGrid(World worldToUse, Cell firstCellInInnerAreaOfGrid);

            void CalculateInnerAreaBoundaries();
            void CreateCellsForCurrentAction();
            void GetAllCellsThatNeedOrHaveObjects(List<Cell> addCellsTo);
            void ReassignActiveGridCellIndexesUsingCellPlayerIsIn(Cell cellPlayerIsIn);
            void ReassignActiveGridCellIndexesUsingPrimaryCell(Cell primaryCell);

            void ShiftActiveGridWest();
            void ShiftActiveGridEast();
            void ShiftActiveGridNorth();
            void ShiftActiveGridSouth();
            void ShiftActiveGridUp();
            void ShiftActiveGridDown();
        }

        class OuterRingGridLogic : IActiveGridTypeSpecificLogic
        {
            ActiveGrid parent;

            public OuterRingGridLogic(ActiveGrid parent)
            {
                this.parent = parent;
            }

            public ActiveGridCells CreateActiveGridCells(Cell firstCell, WorldType worldType, int layerOfSection, int rowOfSection, int columnOfSection)
            {
                ActiveGridDimensions gridDimensions = GetDimensions();
                if (worldType == WorldType.Three_Dimensional)
                    return new OuterRingActive3DGridCells(gridDimensions.innerAreaLayers, gridDimensions.innerAreaRows, gridDimensions.innerAreaColumns, gridDimensions.outerRingWidth, firstCell);
                else
                    return new OuterRingActive2DGridCells(gridDimensions.innerAreaRows, gridDimensions.innerAreaColumns, gridDimensions.outerRingWidth, firstCell);
            }

            ActiveGridDimensions GetDimensions()
            {
                return new ActiveGridDimensions(parent.activeGridState.innerLayers, parent.activeGridState.innerRows, parent.activeGridState.innerColumns, parent.activeGridState.outerRingWidth);
            }

            //in this case the primary cell is the lower left cell in the group
            public Cell FindPrimaryCellInGridUsingFirstCellInInnerAreaOfGrid(World worldToUse, Cell firstCellInInnerAreaOfGrid)
            {
                int firstLayerInGrid;
                if (worldToUse.WorldGrid.WorldType == WorldType.Three_Dimensional)
                    firstLayerInGrid = firstCellInInnerAreaOfGrid.layer - parent.activeGridState.outerRingWidth;
                else
                    firstLayerInGrid = 0;

                int firstRowInGrid = firstCellInInnerAreaOfGrid.row - parent.activeGridState.outerRingWidth;
                int firstColumnInGrid = firstCellInInnerAreaOfGrid.column - parent.activeGridState.outerRingWidth;

                return new Cell(firstRowInGrid, firstColumnInGrid, firstLayerInGrid);
            }
            
            public void CalculateInnerAreaBoundaries()
            {
                CalculateInnerAreaBoundariesFromFirstAndLastCellInInnerArea();
            }

            void CalculateInnerAreaBoundariesFromFirstAndLastCellInInnerArea()
            {
                Vector3 positionOfCellToUseToSetWestSouthAndBottomBoundaries = parent.world.GetPositionOfEndlessGridCell_ZeroBased(parent.activeGridState.firstCellInInnerArea);

                parent.innerAreaBoundary.SetWestSouthAndBottomBoundaries(positionOfCellToUseToSetWestSouthAndBottomBoundaries);

                Vector3 positionOfCellToUseToSetEastNorthAndTopBoundaries;
                CellDimensions dimensionsOfCellToUseToSetEastNorthAndTopBoundaries;

                parent.world.GetPositionAndDimensionsOfEndlessGridCell_ZeroBased(
                    parent.activeGridState.lastCellInInnerArea,
                    out positionOfCellToUseToSetEastNorthAndTopBoundaries,
                    out dimensionsOfCellToUseToSetEastNorthAndTopBoundaries);

                parent.innerAreaBoundary.SetEastNorthAndTopBoundaries(positionOfCellToUseToSetEastNorthAndTopBoundaries, dimensionsOfCellToUseToSetEastNorthAndTopBoundaries);
            }

            public void CreateCellsForCurrentAction()
            {
                ((OuterRingActiveGridCells)parent.activeGridCells).CreateCellsUsingFirstCellInGroup(parent.activeGridState.primaryCellOfGridAfterActionCompletes, parent.cellsToAddUsersTo);
            }

            public void GetAllCellsThatNeedOrHaveObjects(List<Cell> addCellsTo)
            {
                ((OuterRingActiveGridCells)parent.activeGridCells).GetAllCells(addCellsTo);
            }
            
#if DEBUG_ON
            void OnShiftDebug(string direction)
            {
                Debug.Log(string.Format("Shifting the Active Grid {0}.", direction));
            }
#endif

#if DEBUG_ON
            void OnShiftPrintBoundaries(string boundaryType)
            {
                Debug.Log(string.Format("{0} Boundaries are West = {1} | East = {2} | South = {3} | North = {4}", boundaryType, parent.innerAreaBoundary.west, parent.innerAreaBoundary.east, parent.innerAreaBoundary.south, parent.innerAreaBoundary.north));
            }
#endif
            public void ShiftActiveGridEast()
            {
#if DEBUG_ON
                OnShiftDebug("East");
#endif
                OuterRingActiveGridCells gridCells = (OuterRingActiveGridCells)parent.activeGridCells;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.GetWestCells(parent.cellsToRemoveUsersFrom);
                    gridCells.ShiftCellsEast();
                    gridCells.GetEastCells(parent.cellsToAddUsersTo);

                    parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                    parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);

                    parent.cellsToAddUsersTo.Clear();
                    parent.cellsToRemoveUsersFrom.Clear();
                }
                else
                    gridCells.ShiftCellsEast();

                parent.activeGridState.primaryCellColumn++;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
#if DEBUG_ON
                    OnShiftPrintBoundaries("Pre Shift ");
#endif
                    parent.activeGridState.firstCellInInnerArea.column++;
                    parent.activeGridState.lastCellInInnerArea.column++;
                    parent.innerAreaBoundary.west += parent.world.WorldGrid.GetWidthOfEndlessGridColumn_ZeroBased(parent.activeGridState.firstCellInInnerArea.column - 1);
                    parent.innerAreaBoundary.east += parent.world.WorldGrid.GetWidthOfEndlessGridColumn_ZeroBased(parent.activeGridState.lastCellInInnerArea.column);
#if DEBUG_ON
                    OnShiftPrintBoundaries("Post Shift ");
#endif
                }
            }

            public void ShiftActiveGridWest()
            {
#if DEBUG_ON
                OnShiftDebug("West");
#endif
                OuterRingActiveGridCells gridCells = (OuterRingActiveGridCells)parent.activeGridCells;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.GetEastCells(parent.cellsToRemoveUsersFrom);
                    gridCells.ShiftCellsWest();
                    gridCells.GetWestCells(parent.cellsToAddUsersTo);

                    parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                    parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);

                    parent.cellsToAddUsersTo.Clear();
                    parent.cellsToRemoveUsersFrom.Clear();
                }
                else
                    gridCells.ShiftCellsWest();

                parent.activeGridState.primaryCellColumn--;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    parent.activeGridState.firstCellInInnerArea.column--;
                    parent.activeGridState.lastCellInInnerArea.column--;
#if DEBUG_ON
                    OnShiftPrintBoundaries("Pre Shift ");
#endif
                    parent.innerAreaBoundary.west -= parent.world.WorldGrid.GetWidthOfEndlessGridColumn_ZeroBased(parent.activeGridState.firstCellInInnerArea.column);
                    parent.innerAreaBoundary.east -= parent.world.WorldGrid.GetWidthOfEndlessGridColumn_ZeroBased(parent.activeGridState.lastCellInInnerArea.column + 1);
#if DEBUG_ON
                    OnShiftPrintBoundaries("Post Shift ");
#endif
                }
            }

            public void ShiftActiveGridNorth()
            {
#if DEBUG_ON
                OnShiftDebug("North");
#endif
                OuterRingActiveGridCells gridCells = (OuterRingActiveGridCells)parent.activeGridCells;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.GetSouthCells(parent.cellsToRemoveUsersFrom);
                    gridCells.ShiftCellsNorth();
                    gridCells.GetNorthCells(parent.cellsToAddUsersTo);

                    parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                    parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);

                    parent.cellsToAddUsersTo.Clear();
                    parent.cellsToRemoveUsersFrom.Clear();
                }
                else
                    gridCells.ShiftCellsNorth();

                parent.activeGridState.primaryCellRow++;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
#if DEBUG_ON
                    OnShiftPrintBoundaries("Pre Shift ");
#endif
                    parent.activeGridState.firstCellInInnerArea.row++;
                    parent.activeGridState.lastCellInInnerArea.row++;
                    parent.innerAreaBoundary.south += parent.world.WorldGrid.GetLengthOfEndlessGridRow_ZeroBased(parent.activeGridState.firstCellInInnerArea.row - 1);
                    parent.innerAreaBoundary.north += parent.world.WorldGrid.GetLengthOfEndlessGridRow_ZeroBased(parent.activeGridState.lastCellInInnerArea.row);
#if DEBUG_ON
                    OnShiftPrintBoundaries("Post Shift ");
#endif
                }
            }

            public void ShiftActiveGridSouth()
            {
#if DEBUG_ON
                OnShiftDebug("South");
#endif
                OuterRingActiveGridCells gridCells = (OuterRingActiveGridCells)parent.activeGridCells;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.GetNorthCells(parent.cellsToRemoveUsersFrom);
                    gridCells.ShiftCellsSouth();
                    gridCells.GetSouthCells(parent.cellsToAddUsersTo);

                    parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                    parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);

                    parent.cellsToAddUsersTo.Clear();
                    parent.cellsToRemoveUsersFrom.Clear();
                }
                else
                    gridCells.ShiftCellsSouth();

                parent.activeGridState.primaryCellRow--;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
#if DEBUG_ON
                    OnShiftPrintBoundaries("Pre Shift ");
#endif
                    parent.activeGridState.firstCellInInnerArea.row--;
                    parent.activeGridState.lastCellInInnerArea.row--;
                    parent.innerAreaBoundary.south -= parent.world.WorldGrid.GetLengthOfEndlessGridRow_ZeroBased(parent.activeGridState.firstCellInInnerArea.row);
                    parent.innerAreaBoundary.north -= parent.world.WorldGrid.GetLengthOfEndlessGridRow_ZeroBased(parent.activeGridState.lastCellInInnerArea.row + 1);
#if DEBUG_ON
                    OnShiftPrintBoundaries("Post Shift ");
#endif
                }
            }

            public void ShiftActiveGridUp()
            {
#if DEBUG_ON
                OnShiftDebug("Up");
#endif
                OuterRingActive3DGridCells gridCells = (OuterRingActive3DGridCells)parent.activeGridCells;

                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.GetBottomCells(parent.cellsToRemoveUsersFrom);
                    gridCells.ShiftCellsUp();
                    gridCells.GetTopCells(parent.cellsToAddUsersTo);

                    parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                    parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);

                    parent.cellsToAddUsersTo.Clear();
                    parent.cellsToRemoveUsersFrom.Clear();
                }
                else
                    gridCells.ShiftCellsUp();

                parent.activeGridState.primaryCellLayer++;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    parent.activeGridState.firstCellInInnerArea.layer++;
                    parent.activeGridState.lastCellInInnerArea.layer++;
                    parent.innerAreaBoundary.bottom += parent.world.WorldGrid.GetHeightOfEndlessGridLayer_ZeroBased(parent.activeGridState.firstCellInInnerArea.layer - 1);
                    parent.innerAreaBoundary.top += parent.world.WorldGrid.GetHeightOfEndlessGridLayer_ZeroBased(parent.activeGridState.lastCellInInnerArea.layer);
                }
            }

            public void ShiftActiveGridDown()
            {
#if DEBUG_ON
                OnShiftDebug("Down");
#endif
                OuterRingActive3DGridCells gridCells = (OuterRingActive3DGridCells)parent.activeGridCells;

                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.GetTopCells(parent.cellsToRemoveUsersFrom);
                    gridCells.ShiftCellsDown();
                    gridCells.GetBottomCells(parent.cellsToAddUsersTo);

                    parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                    parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);

                    parent.cellsToAddUsersTo.Clear();
                    parent.cellsToRemoveUsersFrom.Clear();
                }
                else
                    gridCells.ShiftCellsDown();

                parent.activeGridState.primaryCellLayer--;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    parent.activeGridState.firstCellInInnerArea.layer--;
                    parent.activeGridState.lastCellInInnerArea.layer--;
                    parent.innerAreaBoundary.bottom -= parent.world.WorldGrid.GetHeightOfEndlessGridLayer_ZeroBased(parent.activeGridState.firstCellInInnerArea.layer);
                    parent.innerAreaBoundary.top -= parent.world.WorldGrid.GetHeightOfEndlessGridLayer_ZeroBased(parent.activeGridState.lastCellInInnerArea.layer + 1);
                }
            }

            public void ReassignActiveGridCellIndexesUsingCellPlayerIsIn(Cell cellPlayerIsIn)
            {
                Cell primaryCellInGridAtNewLocation = FindPrimaryCellInGridUsingFirstCellInInnerAreaOfGrid(parent.world, cellPlayerIsIn);

                ReassignActiveGridCellIndexesUsingPrimaryCell(primaryCellInGridAtNewLocation);
            }

            public void ReassignActiveGridCellIndexesUsingPrimaryCell(Cell primaryCell)
            {
                ((OuterRingActiveGridCells)parent.activeGridCells).AssignIndexes(primaryCell);
            }

            public void SetAdditionalDataToCompleteAction() { }
        }

        class SectionedGridLogic : IActiveGridTypeSpecificLogic
        {
            ActiveGrid parent;
            public SectionedGridLogic(ActiveGrid parent)
            {
                this.parent = parent;
            }

            public ActiveGridCells CreateActiveGridCells(Cell firstCell, WorldType worldType, int layerOfSection, int rowOfSection, int columnOfSection)
            {
                if (worldType == WorldType.Three_Dimensional)
                    return new Sectioned3DGridCells(firstCell, rowOfSection, columnOfSection, layerOfSection);
                else if (worldType == WorldType.Two_Dimensional_On_XZ_Axes)
                    return new Sectioned2DXZGridCells(firstCell, rowOfSection, columnOfSection);
                else
                    return new Sectioned2DXYGridCells(firstCell, rowOfSection, columnOfSection);
            }

            //in this case the primary clel is the first cell in the inner area of the grid
            public Cell FindPrimaryCellInGridUsingFirstCellInInnerAreaOfGrid(World worldToUse, Cell firstCellInInnerAreaOfGrid)
            {
                return firstCellInInnerAreaOfGrid;
            }

            public void CalculateInnerAreaBoundaries()
            {
                Vector3 positionOfInnerAreaCell;
                CellDimensions dimensionsofInnerAreaCell;

                parent.world.GetPositionAndDimensionsOfEndlessGridCell_ZeroBased(parent.activeGridState.firstCellInInnerArea,
                                                                out positionOfInnerAreaCell,
                                                                out dimensionsofInnerAreaCell);

                ((SectionedGridCells)parent.activeGridCells).SetSectionBoundary(parent.innerAreaBoundary, positionOfInnerAreaCell, dimensionsofInnerAreaCell);
            }

            public void CreateCellsForCurrentAction()
            {
                ((SectionedGridCells)parent.activeGridCells).CreateCellsUsingInnerAreaCell(parent.activeGridState.primaryCellOfGridAfterActionCompletes, parent.activeGridState.layerOfSectionAfterActionCompletes, parent.activeGridState.rowOfSectionAfterActionCompletes, parent.activeGridState.columnOfSectionAfterActionCompletes, parent.cellsToAddUsersTo);
            }

            public void GetAllCellsThatNeedOrHaveObjects(List<Cell> addCellsTo)
            {
                parent.activeGridCells.GetAllCells(addCellsTo);
            }

            public void ShiftActiveGridEast()
            {
                SectionedGridCells gridCells = (SectionedGridCells)parent.activeGridCells;
                bool innerAreaColumnChanged;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.ShiftSectionEast(parent.cellsToRemoveUsersFrom, parent.cellsToAddUsersTo, out innerAreaColumnChanged);

                    if (parent.cellsToRemoveUsersFrom.Count > 0)
                    {
                        parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                        parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);
                        parent.cellsToAddUsersTo.Clear();
                        parent.cellsToRemoveUsersFrom.Clear();
                    }
                }
                else
                    gridCells.ShiftSectionEast(out innerAreaColumnChanged);

                if (innerAreaColumnChanged)
                    parent.activeGridState.primaryCellColumn++;

                parent.activeGridState.columnOfSection = gridCells.ColumnOfSection;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    if (innerAreaColumnChanged)
                    {
                        parent.activeGridState.firstCellInInnerArea.column++;
                        parent.activeGridState.lastCellInInnerArea.column++;
                    }

                    parent.innerAreaBoundary.west = parent.innerAreaBoundary.east;
                    parent.innerAreaBoundary.east += (parent.world.WorldGrid.GetWidthOfEndlessGridColumn_ZeroBased(parent.activeGridState.firstCellInInnerArea.column) * .5f);
                }
            }

            public void ShiftActiveGridWest()
            {
                SectionedGridCells gridCells = (SectionedGridCells)parent.activeGridCells;
                bool innerAreaColumnChanged;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.ShiftSectionWest(parent.cellsToRemoveUsersFrom, parent.cellsToAddUsersTo, out innerAreaColumnChanged);

                    if (parent.cellsToRemoveUsersFrom.Count > 0)
                    {
                        parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                        parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);
                        parent.cellsToAddUsersTo.Clear();
                        parent.cellsToRemoveUsersFrom.Clear();
                    }
                }
                else
                    gridCells.ShiftSectionWest(out innerAreaColumnChanged);

                if (innerAreaColumnChanged)
                    parent.activeGridState.primaryCellColumn--;

                parent.activeGridState.columnOfSection = gridCells.ColumnOfSection;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    if (innerAreaColumnChanged)
                    {
                        parent.activeGridState.firstCellInInnerArea.column--;
                        parent.activeGridState.lastCellInInnerArea.column--;
                    }
                    
                    parent.innerAreaBoundary.east = parent.innerAreaBoundary.west;
                    parent.innerAreaBoundary.west -= (parent.world.WorldGrid.GetWidthOfEndlessGridColumn_ZeroBased(parent.activeGridState.firstCellInInnerArea.column) * .5f);
                }
            }

            public void ShiftActiveGridNorth()
            {
                SectionedGridCells gridCells = (SectionedGridCells)parent.activeGridCells;
                bool innerAreaRowChanged;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.ShiftSectionNorth(parent.cellsToRemoveUsersFrom, parent.cellsToAddUsersTo, out innerAreaRowChanged);

                    if (parent.cellsToRemoveUsersFrom.Count > 0)
                    {
                        parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                        parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);
                        parent.cellsToAddUsersTo.Clear();
                        parent.cellsToRemoveUsersFrom.Clear();
                    }
                }
                else
                    gridCells.ShiftSectionNorth(out innerAreaRowChanged);

                if (innerAreaRowChanged)
                    parent.activeGridState.primaryCellRow++;

                parent.activeGridState.rowOfSection = gridCells.RowOfSection;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    if (innerAreaRowChanged)
                    {
                        parent.activeGridState.firstCellInInnerArea.row++;
                        parent.activeGridState.lastCellInInnerArea.row++;
                    }

                    parent.innerAreaBoundary.south = parent.innerAreaBoundary.north;
                    parent.innerAreaBoundary.north += (parent.world.WorldGrid.GetLengthOfEndlessGridRow_ZeroBased(parent.activeGridState.firstCellInInnerArea.row) * .5f);
                }
            }

            public void ShiftActiveGridSouth()
            {
                SectionedGridCells gridCells = (SectionedGridCells)parent.activeGridCells;
                bool innerAreaRowChanged;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.ShiftSectionSouth(parent.cellsToRemoveUsersFrom, parent.cellsToAddUsersTo, out innerAreaRowChanged);

                    if (parent.cellsToRemoveUsersFrom.Count > 0)
                    {
                        parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                        parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);
                        parent.cellsToAddUsersTo.Clear();
                        parent.cellsToRemoveUsersFrom.Clear();
                    }
                }
                else
                    gridCells.ShiftSectionSouth(out innerAreaRowChanged);

                if (innerAreaRowChanged)
                    parent.activeGridState.primaryCellRow--;

                parent.activeGridState.rowOfSection = gridCells.RowOfSection;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    if (innerAreaRowChanged)
                    {
                        parent.activeGridState.firstCellInInnerArea.row--;
                        parent.activeGridState.lastCellInInnerArea.row--;
                    }

                    parent.innerAreaBoundary.north = parent.innerAreaBoundary.south;
                    parent.innerAreaBoundary.south -= (parent.world.WorldGrid.GetLengthOfEndlessGridRow_ZeroBased(parent.activeGridState.firstCellInInnerArea.row) * .5f);
                }
            }

            public void ShiftActiveGridUp()
            {
                Sectioned3DGridCells gridCells = (Sectioned3DGridCells)parent.activeGridCells;
                bool innerAreaLayerChanged;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.ShiftSectionUp(parent.cellsToRemoveUsersFrom, parent.cellsToAddUsersTo, out innerAreaLayerChanged);

                    if (parent.cellsToRemoveUsersFrom.Count > 0)
                    {
                        parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                        parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);
                        parent.cellsToAddUsersTo.Clear();
                        parent.cellsToRemoveUsersFrom.Clear();
                    }
                }
                else
                    gridCells.ShiftSectionUp(out innerAreaLayerChanged);

                if (innerAreaLayerChanged)
                    parent.activeGridState.primaryCellLayer++;

                parent.activeGridState.rowOfSection = gridCells.RowOfSection;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    if (innerAreaLayerChanged)
                    {
                        parent.activeGridState.firstCellInInnerArea.layer++;
                        parent.activeGridState.lastCellInInnerArea.layer++;
                    }

                    parent.innerAreaBoundary.bottom = parent.innerAreaBoundary.top;
                    parent.innerAreaBoundary.top += (parent.world.WorldGrid.GetHeightOfEndlessGridLayer_ZeroBased(parent.activeGridState.firstCellInInnerArea.layer) * .5f);
                }
            }

            public void ShiftActiveGridDown()
            {
                Sectioned3DGridCells gridCells = (Sectioned3DGridCells)parent.activeGridCells;
                bool innerAreaLayerChanged;
                if (parent.activeGridState.cellObjectsLoaded)
                {
                    gridCells.ShiftSectionDown(parent.cellsToRemoveUsersFrom, parent.cellsToAddUsersTo, out innerAreaLayerChanged);

                    if (parent.cellsToRemoveUsersFrom.Count > 0)
                    {
                        parent.world.AddCellUsers_ZeroBased(parent.cellsToAddUsersTo);
                        parent.world.RemoveCellUsers_ZeroBased(parent.cellsToRemoveUsersFrom);
                        parent.cellsToAddUsersTo.Clear();
                        parent.cellsToRemoveUsersFrom.Clear();
                    }
                }
                else
                    gridCells.ShiftSectionDown(out innerAreaLayerChanged);

                if (innerAreaLayerChanged)
                    parent.activeGridState.primaryCellLayer--;

                parent.activeGridState.rowOfSection = gridCells.RowOfSection;
                if (parent.activeGridState.monitorInnerAreaBoundaries)
                {
                    if (innerAreaLayerChanged)
                    {
                        parent.activeGridState.firstCellInInnerArea.layer--;
                        parent.activeGridState.lastCellInInnerArea.layer--;
                    }

                    parent.innerAreaBoundary.top = parent.innerAreaBoundary.bottom;
                    parent.innerAreaBoundary.bottom -= (parent.world.WorldGrid.GetHeightOfEndlessGridLayer_ZeroBased(parent.activeGridState.firstCellInInnerArea.layer) * .5f);
                }
            }

            public void ReassignActiveGridCellIndexesUsingCellPlayerIsIn(Cell cellPlayerIsIn)
            {
                parent.SetSectionPlayerIsIn(cellPlayerIsIn);
                ReassignActiveGridCellIndexesUsingPrimaryCell(cellPlayerIsIn);        
            }

            public void ReassignActiveGridCellIndexesUsingPrimaryCell(Cell primaryCell)
            {
                ((SectionedGridCells)parent.activeGridCells).AssignIndexes(primaryCell, parent.activeGridState.layerOfSection, parent.activeGridState.rowOfSection, parent.activeGridState.columnOfSection);
            }
        }
    }
}