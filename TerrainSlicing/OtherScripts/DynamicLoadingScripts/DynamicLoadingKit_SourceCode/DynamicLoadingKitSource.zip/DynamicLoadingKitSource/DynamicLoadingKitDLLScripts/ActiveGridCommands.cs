﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System;
    using System.Text;
    using System.Collections.Generic;

    public partial class ActiveGrid
    {
        #region Methods that shift the grid
        void OnInnerAreaBoundaryCrossed(BoundaryCrossed eastOrWestBoundaryCrossed, BoundaryCrossed northOrSouthBoundaryCrossed, BoundaryCrossed topOrBottomBoundaryCrossed)
        {
            bool rebuildGridAroundPlayer = false;
            if (eastOrWestBoundaryCrossed != BoundaryCrossed.None)
            {
                if (eastOrWestBoundaryCrossed == BoundaryCrossed.West)
                {
                    activeGridTypeSpecificLogic.ShiftActiveGridWest();
                    if (innerAreaBoundary.IsPositionWestOfWestBoundary(player.position))
                        rebuildGridAroundPlayer = true;
                }
                else
                {
                    activeGridTypeSpecificLogic.ShiftActiveGridEast();
                    if (innerAreaBoundary.IsPositionEastOfEastBoundary(player.position))
                        rebuildGridAroundPlayer = true;
                }
            }

            if (northOrSouthBoundaryCrossed != BoundaryCrossed.None)
            {
                if (northOrSouthBoundaryCrossed == BoundaryCrossed.North)
                {
                    activeGridTypeSpecificLogic.ShiftActiveGridNorth();
                    if (innerAreaBoundary.IsPositionNorthOfNorthBoundary(player.position))
                        rebuildGridAroundPlayer = true;
                }
                else
                {
                    activeGridTypeSpecificLogic.ShiftActiveGridSouth();
                    if (innerAreaBoundary.IsPositionSouthOfSouthBoundary(player.position))
                        rebuildGridAroundPlayer = true;
                }
            }

            if (topOrBottomBoundaryCrossed != BoundaryCrossed.None)
            {
                if (topOrBottomBoundaryCrossed == BoundaryCrossed.Top)
                {
                    activeGridTypeSpecificLogic.ShiftActiveGridUp();
                    if (innerAreaBoundary.IsPositionAboveTopBoundary(player.position))
                        rebuildGridAroundPlayer = true;
                }
                else
                {
                    activeGridTypeSpecificLogic.ShiftActiveGridDown();
                    if (innerAreaBoundary.IsPositionBelowBottomBoundary(player.position))
                        rebuildGridAroundPlayer = true;
                }
            }

            if (rebuildGridAroundPlayer)
                RebuildGridAroundPlayer();
        }

        /// <summary>
        /// Try to shift the Active Grid in the <see cref="Direction" href = "Direction.html">Direction</see> 
        /// specified. Only use this if no player is assigned to the grid (if there is a player, you should 
        /// allow the Active Grid to automatically shift on its own).
        /// <para>
        /// The shift will also fail to execute if the grid is already busy executing a multi frame action 
        /// (coroutine starting with Try), in which case an exception is thrown.
        /// </para>
        /// <para>
        /// It's unlikely you will need to call this method manually. 
        /// Usually, you will have a Boundary Monitor that tracks 
        /// the player's position, forcing the grid to shift when the 
        /// player crosses specific boundaries of the Active Grid. 
        /// If you do plan on manually shifting the grid, disable or remove the boundary monitor and player.
        /// </para>
        /// <para>
        /// If the Grid Type is set to Sectioned, this will shift the 
        /// active section in the direction specified, which 
        /// may or may not change the cells that are currently loaded.
        /// </para>
        /// </summary>
        /// <param name="directionToShiftGrid" type = "Direction" link = "Direction.html">
        /// The direction to shift the grid.
        /// </param>
        /// <displayName id = "TryShiftGrid">
        /// TryShiftGrid(Direction)
        /// </displayName>
        /// <syntax>
        /// public void TryShiftGrid(Direction directionToShiftGrid)
        /// </syntax>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the grid has been initialized or while the Active Grid is busy executing a 
        /// multi frame action. Check IsBusy before 
        /// calling methods that begin with "Try".
        /// </exception>
        /// <exception name="MissingComponentException">
        /// Thrown when this method is called while the Active Grid is not synced to a 
        /// <see cref="World" href="World.html">World</see>.
        /// </exception>
        public void TryShiftGrid(Direction directionToShiftGrid)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryShiftGrid call on Active Grid with ID {0} failed. The Active Grid was has not been initialized. If the Active Grid was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this Active Grid) before calling this method.", ID));

            if (player != null)
                throw new InvalidOperationException(string.Format("TryShiftGrid call on Active Grid with ID { 0 } failed.The Active Grid has a player assigned. Either remove the player or let the Active Grid auto shift itself.", ID));

            if (world == null)
                throw new MissingComponentException(string.Format("TryShiftGrid call on Active Grid with ID {0} failed. The Active Grid is not currently synced to a World.", ID));

            if (IsBusy)
                throw new InvalidOperationException(string.Format("TryShiftGrid call on Active Grid with ID {0} failed. Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", ID));

            if (directionToShiftGrid == Direction.West)
                activeGridTypeSpecificLogic.ShiftActiveGridWest();
            else if (directionToShiftGrid == Direction.East)
                activeGridTypeSpecificLogic.ShiftActiveGridEast();
            else if (directionToShiftGrid == Direction.North)
                activeGridTypeSpecificLogic.ShiftActiveGridNorth();
            else if (directionToShiftGrid == Direction.South)
                activeGridTypeSpecificLogic.ShiftActiveGridSouth();
            else if (directionToShiftGrid == Direction.Up)
                activeGridTypeSpecificLogic.ShiftActiveGridUp();
            else
                activeGridTypeSpecificLogic.ShiftActiveGridDown();
        }

        #endregion

        #region World Origin Cell Update Methods
        internal void BlockOtherActionsUntilWorldShiftCompletes()
        {
            activeGridState.multiFrameActionType = MultiFrameActionType.WorldShift;
            activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes = false;
            activeGridState.multiFrameActionExecuting = true;
            StopAllBoundaryMonitoring();
        }

        internal void WorldShiftCommencing(Vector3 amountOfShift)
        {
            activeGridState.amountToMoveGridOrPositionToMoveGridTo = amountOfShift;
        }

        internal IEnumerator<YieldInstruction> WorldShiftComplete(Cell endlessGridResetAddition)
        {
            AdjustForEndlessCellReset(endlessGridResetAddition);

            if (player != null)
            {
                if (playerMover != null)
                {
                    activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes = true;
                    IEnumerator<YieldInstruction> movePlayerEnumerator;
                    movePlayerEnumerator = playerMover.MovePlayerByAmount(player, activeGridState.amountToMoveGridOrPositionToMoveGridTo);

                    while (movePlayerEnumerator.MoveNext())
                    {
                        if (playerMover.PlayerMoved)
                        {
                            activeGridState.playerMovedDuringMultiFrameAction = true;
                            OnPlayerMoved();
                            yield return movePlayerEnumerator.Current;
                            goto DoNotCheckIfPlayerMoved;
                        }
                        yield return movePlayerEnumerator.Current;
                    }

                    OnPlayerMoved();
                    goto End;

                    DoNotCheckIfPlayerMoved:

                    while (movePlayerEnumerator.MoveNext())
                        yield return movePlayerEnumerator.Current;
                }
                else
                {
                    player.position += activeGridState.amountToMoveGridOrPositionToMoveGridTo;
                    OnPlayerMoved();
                }
            }

            End:
            
            activeGridState.multiFrameActionExecuting = false;
            activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes = false;
            activeGridState.playerMovedDuringMultiFrameAction = false;
            StartMonitoringIfNecessary();
        }

        void AdjustForEndlessCellReset(Cell endlessGridResetAddition)
        {
            activeGridCells.AddToAllCells(endlessGridResetAddition);
            SetFirstAndLastCellInInnerArea();

            activeGridState.primaryCellColumn = activeGridState.primaryCellColumn + endlessGridResetAddition.Column;
            activeGridState.primaryCellLayer = activeGridState.primaryCellLayer + endlessGridResetAddition.Layer;
            activeGridState.primaryCellRow = activeGridState.primaryCellRow + endlessGridResetAddition.Row;

            if (innerAreaBoundary != null)
                innerAreaBoundary.AdjustBoundaryByAmount(activeGridState.amountToMoveGridOrPositionToMoveGridTo);

            CheckIfActiveCellChangedAndReactAccordingly(activeCell + endlessGridResetAddition);
        }

        #endregion

        #region Boundary Pause/Resume Methods
        void StopAllBoundaryMonitoring()
        {
            if (boundaryMonitor != null)
            {
                StopMonitoringOfInnerAreaAndWorldShiftBoundaries();
                StopMonitoringOfActiveCellBoundary();
            }
        }

        void StartMonitoringOfInnerAreaAndWorldShiftBoundaries()
        {
            boundaryMonitor.StartMonitoring(activeCellBoundaryMonitorID);
        }

        void StopMonitoringOfInnerAreaAndWorldShiftBoundaries()
        {
            boundaryMonitor.StopMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
        }

        void StartMonitoringOfActiveCellBoundary()
        {
            boundaryMonitor.StartMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
        }

        void StopMonitoringOfActiveCellBoundary()
        {
            boundaryMonitor.StopMonitoring(activeCellBoundaryMonitorID);
        }

        #endregion

        #region Public methods for moving the player and changing worlds

        /// <summary>
        /// Tries to make the passed in cell the origin cell of the world the Active Grid is currently synced to.
        /// This is useful if you want to move the player to a cell but want to keep the player and 
        /// world close to the origin, as this method will set the passed in cell so it's location 
        /// is the origin of the world. This may be necessary to avoid floating point errors.
        /// It's important that if movePlayerAfterChange is true, the playerPositionAfterChange 
        /// you pass in falls within the cell at the world's origin after this cell is made to be the origin cell.
        /// </summary>
        /// <param name="cell" type="Cell" link="Cell.html">
        /// The cell which will become the origin cell of the World the Active Grid is currently synced to.
        /// </param>
        /// <param name="disablePlayerDuringChange" type="bool">
        /// If true, the game object the player transform is on will be deactivated while the origin 
        /// cell is changed, and activated once the process has finished (and the player has been moved if movePlayerAfterChange is true).
        /// <para>
        /// If you don't want the player to be deactivated, pass in false, but keep in mind 
        /// that you will need to freeze the player's movement in some way before running this 
        /// method, as the terrain the player is on will likely be removed in the process.
        /// </para>
        /// </param>
        /// <param name="movePlayerAfterChange" type="bool">
        /// If true, the player will be moved after the origin cell has been changed.
        /// </param>
        /// <param name="playerPositionAfterChange" type="Vector3">
        /// If movePlayerAfterChange is true, the player will be moved to this location.
        /// </param>
        /// <param name="setPlayerYPositionBasedOnTerrain" type="bool">
        /// If movePlayerAfterChange and setPlayerYPositionBasedOnTerrain are true, the player's y location will be 
        /// set based on the terrain at the x and z location (i.e, the y location in playerPositionAfterChange 
        /// will be ignored).
        /// </param>
        /// <param name="playerYOffset" type="float">
        /// If movePlayerAfterChange and setPlayerYPositionBasedOnTerrain are true, 
        /// you can pass in an offset value which will be added to the player's calculated 
        /// position (based on the terrain). This is necessary since setting the player's 
        /// y position to the calculated position would likely cause the player to 
        /// overlap the terrain, which is not ideal.
        /// </param>
        /// <param name="positionRelativeToOriginCell" type="bool">
        /// Is the playerPositionAfterChange relative to world space (false) or the new origin cell (true). If 
        /// setPlayerYPositionBasedOnTerrain is false, this also dictates whether the y value of 
        /// playerPositionAfterChange is relative to the world or origin cell.
        /// <para>
        /// If the position is relative 
        /// to the origin cell, then the final position the player will be moved to is 
        /// playerPositionAfterChange + OriginCell.position. If the position is relative to world space, then 
        /// playerPositionAfterChange is the position the player will be moved to.
        /// </para>
        /// <para>
        /// Note, if the Origin Cell's position is x = 0, y = 0, and z = 0, then the player's position after the change will be the same regardless of this value.
        /// </para>
        /// </param>
        /// <syntax>
        /// public IEnumerator&lt;YieldInstruction&gt; TryMakeCellOriginCell(Cell cell, bool disablePlayerDuringChange, bool movePlayerAfterChange = false, Vector3? playerPositionAfterChange = null, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f, bool positionRelativeToOriginCell = false)
        /// </syntax>
        /// <displayName id = "TryMakeCellOriginCell">
        /// TryMakeCellOriginCell(Cell, bool, [bool], [?Vector3], [bool], [float], [bool])
        /// </displayName>
        /// <returns>
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when a world is not associated with the grid, when the Active Grid has not been initialized yet, 
        /// when this method is called while the 
        /// Active Grid is busy executing a multi frame action (check IsBusy before calling ActiveGrid methods that begin with 
        /// "Try"), when setPlayerYPositionBasedOnTerrain is true but the current world does not use Unity Terrain or cell objects 
        /// are not enabled on the Active Grid, or when a player is not associated with the grid but movePlayerAfterChange is true.
        /// </exception>
        public IEnumerator<YieldInstruction> TryMakeCellOriginCell(Cell cell, bool disablePlayerDuringChange, bool movePlayerAfterChange = false, Vector3? playerPositionAfterChange = null, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f, bool positionRelativeToOriginCell = false)
        {            
            CheckForCommonExceptions("TryMakeCellOriginCell", movePlayerAfterChange, "movePlayerAfterChange cannot be true", setPlayerYPositionBasedOnTerrain);

            Cell zeroBasedOriginCell = cell.ConvertTo0Based(world.IsWorld3D);
            activeGridState.waitingOnCellOriginUpdate = true;

            Vector3 positionOfPlayerAfterOriginCellChange = GetPositionOfPlayerAfterOriginCellChange(movePlayerAfterChange, positionRelativeToOriginCell, playerPositionAfterChange);
            
            Cell endlessGridCellPlayerWillBeInAfterChange = world.FindEndlessGridCellPositionIsInUsingTheoreticalOriginCell_ZeroBased(positionOfPlayerAfterOriginCellChange, zeroBasedOriginCell);

            SetStandardPreActionData(endlessGridCellPlayerWillBeInAfterChange, MultiFrameActionType.OriginCellChange, false, world);

            SetPostActionSection(zeroBasedOriginCell, endlessGridCellPlayerWillBeInAfterChange, disablePlayerDuringChange, positionOfPlayerAfterOriginCellChange);
            
            StopAllBoundaryMonitoring();
            
            RemoveAllCellsInGridFromCurrentWorld();
            GetCellsInGridForNewFirstCellInInnerArea(endlessGridCellPlayerWillBeInAfterChange.ConvertTo1Based(world.IsWorld3D), cellsToAddUsersTo);

            IEnumerator<YieldInstruction> updateOriginCellEnumerator = UpdateOriginCellOnWorld(cell, zeroBasedOriginCell);
            while (updateOriginCellEnumerator.MoveNext())
                yield return updateOriginCellEnumerator.Current;
            
            FindAndSetPrimaryCell(endlessGridCellPlayerWillBeInAfterChange);

            //Re setup the active grid cells utilizing the new primary cell
            SetupActiveGridCells();

            //Re setup the inner area boundary
            if (activeGridState.monitorInnerAreaBoundaries)
                SetupInnerAreaBoundary();

            //Move the player if needed
            if (movePlayerAfterChange)
                MovePlayer((Vector3)playerPositionAfterChange, setPlayerYPositionBasedOnTerrain, playerYOffset, positionRelativeToOriginCell);

            if (player != null)
            {
                if(disablePlayerDuringChange)
                    player.gameObject.SetActive(true);
                
                CheckIfActiveCellChangedAndReactAccordingly(endlessGridCellPlayerWillBeInAfterChange);
            }
            
            ResetPostActionData();
            StartMonitoringIfNecessary();
        }

        void RemoveAllCellsInGridFromCurrentWorld()
        {
            activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);
            world.RemoveCellUsers_ZeroBased(cellsToRemoveUsersFrom);
            cellsToRemoveUsersFrom.Clear();
        }

        void GetCellsInGridForNewFirstCellInInnerArea(Cell newFirstCellInInnerArea_OneBased, List<Cell> listToAddCellsTo)
        {
            if (activeGridType == ActiveGridType.Outer_Ring_Grid)
            {
                //the extra one added onto subtract helps to give us a zero based 
                //firstCellInGroup
                int subtract = activeGridState.outerRingWidth + 1;
                Cell firstCellInGroup = new Cell(newFirstCellInInnerArea_OneBased.row - subtract, newFirstCellInInnerArea_OneBased.column - subtract, world.IsWorld3D ? newFirstCellInInnerArea_OneBased.layer - subtract : 0);
                ((OuterRingActiveGridCells)activeGridCells).CreateCellsUsingFirstCellInGroup(firstCellInGroup, listToAddCellsTo);
            }
            else
            {
                Cell innerAreaCell = new Cell(newFirstCellInInnerArea_OneBased.row - 1, newFirstCellInInnerArea_OneBased.column - 1, world.IsWorld3D ? newFirstCellInInnerArea_OneBased.layer - 1 : 0);
                ((SectionedGridCells)activeGridCells).CreateCellsUsingInnerAreaCell(innerAreaCell, activeGridState.layerOfSectionAfterActionCompletes, activeGridState.rowOfSectionAfterActionCompletes, activeGridState.columnOfSectionAfterActionCompletes, listToAddCellsTo);
            }
        }

        void FindAndSetPrimaryCell(Cell firstCellInInnerAreaOfGrid)
        {
            Cell primaryCell = activeGridTypeSpecificLogic.FindPrimaryCellInGridUsingFirstCellInInnerAreaOfGrid(world, firstCellInInnerAreaOfGrid).ConvertTo1Based(world.IsWorld3D);

            activeGridState.primaryCellColumn = primaryCell.column;
            activeGridState.primaryCellRow = primaryCell.row;
            activeGridState.primaryCellLayer = primaryCell.layer;
        }

        IEnumerator<YieldInstruction> UpdateOriginCellOnWorld(Cell newOriginCell_OneBased, Cell newOriginCell_ZeroBased)
        {
            if (world.OriginCell == newOriginCell_OneBased)
            {
                IEnumerator<YieldInstruction> waitOnCellObjectsToLoad = world.AddCellUsers_ZeroBasedAndWaitForCellObjectsToBeLoaded(cellsToAddUsersTo);
                while (waitOnCellObjectsToLoad.MoveNext())
                    yield return waitOnCellObjectsToLoad.Current;

                cellsToAddUsersTo.Clear();
            }
            else
            {
                world.AddCellUsers_ZeroBased(cellsToAddUsersTo);

                cellsToAddUsersTo.Clear();

                //Update origin cell on world here
                world.UpdateOriginCell(newOriginCell_ZeroBased);

                //Now wait for the world to update its origin cell during it's update cycle
                while (activeGridState.waitingOnCellOriginUpdate)
                    yield return null;
            }
        }

        void MovePlayer(Vector3 playerPositionAfterChange, bool setPlayerYPositionBasedOnTerrain, float playerYOffset, bool positionRelativeToOriginCell)
        {
            Vector3 locationToMovePlayerTo;
            if (positionRelativeToOriginCell)
            {
                locationToMovePlayerTo = (Vector3)playerPositionAfterChange + world.OriginCellPosition;
            }
            else
                locationToMovePlayerTo = (Vector3)playerPositionAfterChange;

            locationToMovePlayerTo = new Vector3(
               locationToMovePlayerTo.x,
                GetYPositionToMovePlayerTo(locationToMovePlayerTo, setPlayerYPositionBasedOnTerrain, playerYOffset),
                locationToMovePlayerTo.z);

            player.position = locationToMovePlayerTo;
            OnPlayerMoved();
        }
        
        void SetPostActionSection(Cell newZeroBasedOriginCell, Cell endlessGridCellPlayerWillBeInAfterChange, bool disablePlayerDuringChange, Vector3 playerPosition)
        {
            if (player != null)
            {
                if (disablePlayerDuringChange)
                    player.gameObject.SetActive(false);
                
                SetPostActionSectionBasedOnNewOriginCellAndPostActionPlayerLocation(endlessGridCellPlayerWillBeInAfterChange, newZeroBasedOriginCell, playerPosition);
            }
            else
                SetPostActionSectionTo0();
        }

        Vector3 GetPositionOfPlayerAfterOriginCellChange(bool movePlayerAfterChange, bool positionRelativeToOriginCell, Vector3? playerPositionAfterChange)
        {
            if (movePlayerAfterChange)
            {
                if (positionRelativeToOriginCell)
                    return (Vector3)playerPositionAfterChange + world.OriginCellPosition;
                else
                    return (Vector3)playerPositionAfterChange;
            }
            else
                return player.position;
        }

        void SetPostActionSectionBasedOnNewOriginCellAndPostActionPlayerLocation(Cell endlessGridCellPlayerWillBeInAfterChange, Cell newOriginCell, Vector3 postActionPlayerLocation)
        {
            //We'll use the dimension of the new origin cell to find the section the player will be in
            CellDimensions cellPlayerWillBeInAfterChangeDimensions = world.GetDimensionsOfEndlessGridCell_ZeroBased(endlessGridCellPlayerWillBeInAfterChange);

            Vector3 positionOfCellPlayerWillBeInAfterChange = world.GetPositionOfEndlessGridCellUsingTheoreticalOriginCell_ZeroBased(endlessGridCellPlayerWillBeInAfterChange, newOriginCell);
            
            //the column position will always use the x value
            float columnPosition = positionOfCellPlayerWillBeInAfterChange.x;

            activeGridState.columnOfSectionAfterActionCompletes = postActionPlayerLocation.x < columnPosition + (.5f * cellPlayerWillBeInAfterChangeDimensions.width) ? 0 : 1;

            //row and layer position depend on world type, but we can use handy function in world class 
            //to get them easily
            float rowPosition;
            float layerPosition;
            world.GetRowAndLayerPositionOfCell(positionOfCellPlayerWillBeInAfterChange, out rowPosition, out layerPosition);

            if (world.WorldGrid.WorldType == WorldType.Three_Dimensional)
            {
                activeGridState.rowOfSectionAfterActionCompletes = postActionPlayerLocation.z < rowPosition + (.5f * cellPlayerWillBeInAfterChangeDimensions.length) ? 0 : 1;

                activeGridState.layerOfSectionAfterActionCompletes = postActionPlayerLocation.y < layerPosition + (.5f * cellPlayerWillBeInAfterChangeDimensions.height) ? 0 : 1;
            }
            else if (world.WorldGrid.WorldType == WorldType.Two_Dimensional_On_XY_Axes)
            {
                activeGridState.rowOfSectionAfterActionCompletes = postActionPlayerLocation.y < rowPosition + (.5f * cellPlayerWillBeInAfterChangeDimensions.length) ? 0 : 1;
                activeGridState.layerOfSectionAfterActionCompletes = 0;
            }
            else
            {
                activeGridState.rowOfSectionAfterActionCompletes = postActionPlayerLocation.z < rowPosition + (.5f * cellPlayerWillBeInAfterChangeDimensions.length) ? 0 : 1;
                activeGridState.layerOfSectionAfterActionCompletes = 0;
            }
        }

        void SetPostActionSectionTo0()
        {
            activeGridState.layerOfSectionAfterActionCompletes = 0;
            activeGridState.rowOfSectionAfterActionCompletes = 0;
            activeGridState.columnOfSectionAfterActionCompletes = 0;
        }
        
        void CheckForCommonExceptions(string mainMethod, bool movePlayerAfterChange, string playerIsNotPresentErrorMessage, bool setPlayerYPositionBasedOnTerrain)
        {
            MakeSureGridIsInitialized(mainMethod);
            MakeSureGridIsNotBusy(mainMethod);
            MakeSureWorldIsNotNull(mainMethod);

            if (movePlayerAfterChange)
                MakeSurePlayerIsPresent(mainMethod, playerIsNotPresentErrorMessage);

            if (setPlayerYPositionBasedOnTerrain)
                MakeSurePlayerYPositionCanBeSetBasedOnTerrain(mainMethod);

            //Make sure this active grid is the only user of the world
            if (world.GetNumberOfUsersRegistered() > 1)
                throw new InvalidOperationException("TryMakeCellOriginCell on Active Grid with ID " + ID + " failed. The world the Active Grid is synced to has more than 1 user registered. This method is only useable when the Active Grid is the only user registered with the World.");
        }



        /// <summary>
        /// Tries to move the player associated with this Active Grid to the location specified.
        /// <para>
        /// This method fully loads the cells (and objects if necessary) around the target location before 
        /// moving the player (this occurs over several frames).
        /// </para>
        /// <para>
        /// Once loaded, if waitForCommandBeforeMovingPlayer is true, this method will yield until 
        /// <see cref="InitiatePendingMove" href="#InitiatePendingMove">InitiatePendingMove</see> is called. If false, this method
        /// will move the player immediately after the objects at the new location are loaded.
        /// </para>
        /// <para>
        /// If waitForCommandBeforeMovingPlayer is true, you can query the PlayerReadyToBeMoved property to make sure the 
        /// Active Grid has loaded the new area before calling InitiatePendingMove (otherwise, there is no guarantee the player 
        /// will be moved immediately after calling InitiatePendingMove).
        /// </para>
        /// <para>
        /// If waitForCommandBeforeMovingPlayer is true, it's a good idea to pass in false for 
        /// completeMoveOnLoad.
        /// </para>
        /// <para>
        /// Depending on the <see cref="PlayerMover" href = "PlayerMover.html">PlayerMover</see>
        /// used by this Active Grid, the actual move operation may also take several frames.
        /// </para>
        /// <para
        /// >This method, like all Try methods in this API, will throw an exception when
        /// a coroutine operation is currently being executed by this Active Grid. The best way to account for this possibility is to simply
        /// check to make sure the Active Grid is not busy before calling this move method, which you can do by checking
        /// the Active Grid's <see cref="IsBusy" href = "#IsBusy">IsBusy</see> property.
        /// </para>
        /// </summary>
        /// <param name="location" type = "Vector3">
        /// The location to move the player to.
        /// </param>
        /// <param name="completeMoveOnLoad" type = "bool">
        /// If a save occurs while the move is under way, should the move be completed when that save is loaded next session? 
        /// If false, the move operation will effectively be cancelled when the save is loaded, in which case it is the 
        /// caller of this method's responsibility to resume it when the save is loaded.
        /// </param>
        /// <param name="waitForCommandBeforeMovingPlayer" type = "bool">
        /// If true, the new area that the player will be moved to will be loaded, but the actual move operation will
        /// be delayed until the <see cref="InitiatePendingMove" href = "#InitiatePendingMove">InitiatePendingMove</see> 
        /// Method is called. If false, the move will be performed immediately after the new area is loaded.
        /// </param>
        /// <param name="waitForOldObjectsToBeRemoved" type="bool">
        /// If true, the coroutine will not exit/yield break until the pre move objects that are no longer needed are removed.
        /// <para>
        /// This is mostly useful if displaying a loading screen and you only want to remove the loading screen when the world 
        /// is completely up to date.
        /// </para>
        /// </param>
        /// <param name="setPlayerYPositionBasedOnTerrain" type="bool">
        /// If true, the y value in location will be ignored and the y position to move the player to will be calculated based on the 
        /// height of the terrain at the location to move the player to. Only set this to true if you know the Active Grid is synced 
        /// to a world that is using Terrains. If there is no terrain at the location, the location's y value will be used.
        /// </param>
        /// <param name="playerYOffset" type="float">
        /// When setPlayerYPositionBasedOnTerrain is true, this value can be used to ensure the player does not overlap the terrain. A value of 1, for instance, 
        /// will place the player 1 unit above the terrain's height. You will need to experiment to find the best value, as it will depend largely upon the 
        /// shape and height of your player's collider.
        /// </param>
        /// <syntax>
        /// public IEnumerator&lt;YieldInstruction&gt; TryMovePlayerToLocation(Vector3 location, bool completeMoveOnLoad, bool waitForCommandBeforeMovingPlayer, bool waitForOldObjectsToBeRemoved, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f)
        /// </syntax>
        /// <displayName id = "TryMovePlayerToLocation">
        /// TryMovePlayerToLocation(Vector3, bool, bool, bool, [bool], [float])
        /// </displayName>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when no player or world is associated with the grid, when the Active Grid has not been initialized yet, 
        /// or when this method is called while the 
        /// Active Grid is busy executing a multi frame action (check IsBusy before calling ActiveGrid methods that begin with 
        /// "Try"), or when setPlayerYPositionBasedOnTerrain is true but the current world does not use Unity Terrain or cell objects 
        /// are not enabled on the Active Grid.
        /// </exception>
        public IEnumerator<YieldInstruction> TryMovePlayerToLocation(Vector3 location,
            bool completeMoveOnLoad, bool waitForCommandBeforeMovingPlayer, bool waitForOldObjectsToBeRemoved, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f)
        {
            CheckForCommonExceptions("TryMovePlayerToLocation", true, "it is not possible to move the player", setPlayerYPositionBasedOnTerrain);

            Cell firstCellInInnerAreaOfGridAtNewLocation = world.FindEndlessGridCellPositionIsIn_ZeroBased(location);

            SetStandardPreActionData(firstCellInInnerAreaOfGridAtNewLocation, MultiFrameActionType.MoveToLocation, completeMoveOnLoad, world);

            activeGridState.amountToMoveGridOrPositionToMoveGridTo = location;
            activeGridState.setPlayerYPositionUsingTerrainHeight = setPlayerYPositionBasedOnTerrain;

            if (setPlayerYPositionBasedOnTerrain)
                activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = playerYOffset;
            else
                activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = 0f;

            SetPostActionSection(firstCellInInnerAreaOfGridAtNewLocation, location, world);

            StopAllBoundaryMonitoring();

            if (waitForCommandBeforeMovingPlayer)
                activeGridState.delayMove = true;

            bool needToRemoveOldObjects = activeGridState.cellObjectsLoaded;
            if (activeGridState.cellObjectsEnabled)
            {
                activeGridTypeSpecificLogic.CreateCellsForCurrentAction();
                activeGridState.cellObjectsLoaded = true;

                IEnumerator<YieldInstruction> addCellsAndWaitEnumerator = world.AddCellUsers_ZeroBasedAndWaitForCellObjectsToBeLoaded(cellsToAddUsersTo);
                while (addCellsAndWaitEnumerator.MoveNext())
                    yield return addCellsAndWaitEnumerator.Current;

                cellsToAddUsersTo.Clear();
            }
            else
                activeGridState.cellObjectsLoaded = false;

            IEnumerator<YieldInstruction> movePlayerAndRemoveOldObjectsEnumerator = MovePlayerToLocationAndRemoveOldObjectsIfNeeded(waitForCommandBeforeMovingPlayer, needToRemoveOldObjects, waitForOldObjectsToBeRemoved, false, setPlayerYPositionBasedOnTerrain, playerYOffset);

            while (movePlayerAndRemoveOldObjectsEnumerator.MoveNext())
                yield return movePlayerAndRemoveOldObjectsEnumerator.Current;

            activeGridState.layerOfSection = activeGridState.layerOfSectionAfterActionCompletes;
            activeGridState.rowOfSection = activeGridState.rowOfSectionAfterActionCompletes;
            activeGridState.columnOfSection = activeGridState.columnOfSectionAfterActionCompletes;

            activeGridTypeSpecificLogic.ReassignActiveGridCellIndexesUsingPrimaryCell(activeGridState.primaryCellOfGridAfterActionCompletes);

            if (activeGridState.monitorInnerAreaBoundaries)
            {
                SetFirstAndLastCellInInnerArea();
                activeGridTypeSpecificLogic.CalculateInnerAreaBoundaries();
            }

            CheckIfActiveCellChangedAndReactAccordingly(FindCellPlayerIsIn(world));

            ResetPrimaryCellIndexes();
            StartMonitoringIfNecessary();
            activeGridState.multiFrameActionExecuting = false;
            activeGridState.setPlayerYPositionUsingTerrainHeight = false;
            activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = 0f;
            activeGridState.playerMovedDuringMultiFrameAction = false;
            activeGridState.worldToSyncTo = null;
        }





        /// <summary>
        /// Tries to move the player associated with this Active Grid to the location specified on the new World, 
        /// and if the move is successful, syncs the Active Grid to this new World.
        /// <para>
        /// This method fully loads the cells (and objects if necessary) around the target location before 
        /// moving the player (this occurs over several frames).
        /// </para>
        /// <para>
        /// Once loaded, if waitForCommandBeforeMovingPlayer is true, this method will yield until 
        /// <see cref="InitiatePendingMove" href="#InitiatePendingMove">InitiatePendingMove</see> is called. If false, this method
        /// will move the player immediately after the objects at the new location are loaded.
        /// </para>
        /// <para>
        /// If waitForCommandBeforeMovingPlayer is true, you can query the PlayerReadyToBeMoved property to make sure the 
        /// Active Grid has loaded the new area before calling InitiatePendingMove (otherwise, there is no guarantee the player 
        /// will be moved immediately after calling InitiatePendingMove).
        /// </para>
        /// <para>
        /// If waitForCommandBeforeMovingPlayer is true, it's a good idea to pass in false for 
        /// completeMoveOnLoad.
        /// </para>
        /// <para>
        /// Depending on the <see cref="PlayerMover" href = "PlayerMover.html">PlayerMover</see>
        /// used by this Active Grid, the actual move operation may also take several frames.
        /// </para>
        /// <para>
        /// This method, like all Try methods in this API, will throw an exception when
        /// a coroutine operation is currently being executed by this Active Grid. The best way to account for this possibility is to simply
        /// check to make sure the Active Grid is not busy before calling this method, which you can do by checking
        /// the Active Grid's <see cref="IsBusy" href = "#IsBusy">IsBusy</see> property.
        /// </para>
        /// </summary>
        /// <param name="location" type = "Vector3">
        /// The location to move the player to.
        /// </param>
        /// <param name = "newWorldToSyncTo" type = "World" link = "World.html">
        /// The new World to sync to.
        /// </param>
        /// <param name="completeMoveOnLoad" type = "bool">
        /// If a save occurs while the move is under way, should the move be completed when that save is loaded next 
        /// session? If false, the move operation will effectively be cancelled when the save is loaded, in which case it is the 
        /// caller of this method's responsibility to resume it when the save is loaded.
        /// </param>
        /// <param name="waitForCommandBeforeMovingPlayer" type = "bool">
        /// If true, the new area that the player will be moved to will be loaded, but the actual move operation will
        /// be delayed until the <see cref="InitiatePendingMove" href = "#InitiatePendingMove">InitiatePendingMove</see> Method 
        /// is called. If false, the move will be performed immediately after the new area is loaded.
        /// </param>
        /// <param name = "allowGridToForceWorldShifts" type = "bool">
        /// If true, the grid will be permitted to force shifts in the new World (only applies to origin centered worlds).
        /// </param>
        /// <param name="waitForOldObjectsToBeRemoved" type="bool">
        /// If true, the coroutine will not exit/yield break until the pre sync/move objects that are no longer needed are removed.
        /// <para>
        /// This is mostly useful if displaying a loading screen and you only want to remove the loading screen when the world 
        /// is completely up to date.
        /// </para>
        /// </param>
        /// <param name="setPlayerYPositionBasedOnTerrain" type="bool">
        /// If true, the y value in location will be ignored and the y position to move the player to will be calculated based on the 
        /// height of the terrain at the location to move the player to. Only set this to true if you know the newWorldToSyncTo uses Terrain. 
        /// If there is no terrain at the location, the location's y value will be used.
        /// </param>
        /// <param name="playerYOffset" type="float">
        /// When setPlayerYPositionBasedOnTerrain is true, this value can be used to ensure the player does not overlap the terrain. 
        /// A value of 1, for instance, 
        /// will place the player 1 unit above the terrain's height. You will need to experiment to find the best value, as it 
        /// will depend largely upon the shape and height of your player's collider.
        /// </param>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when no player is associated with the grid, when the Active Grid has not been initialized yet, or when this 
        /// method is called while the Active Grid is busy 
        /// executing a multi frame action (check IsBusy before calling ActiveGrid methods that begin with "Try"), or 
        /// when setPlayerYPositionBasedOnTerrain is true but the new world to sync to does not use Unity Terrain or cell objects 
        /// are not enabled on the Active Grid.
        /// </exception>
        /// <syntax>
        /// public IEnumerator&lt;YieldInstruction&gt; TryMovePlayerToLocationOnNewWorld(Vector3 location, World newWorldToSyncTo, bool completeMoveOnLoad, bool waitForCommandBeforeMovingPlayer, bool allowGridToForceWorldShifts, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f)
        /// </syntax>
        /// <displayName id = "TryMovePlayerToLocationOnNewWorld">
        /// TryMovePlayerToLocationOnNewWorld(Vector3, World, bool, bool, bool, [bool], [float])
        /// </displayName>
        public IEnumerator<YieldInstruction> TryMovePlayerToLocationOnNewWorld(Vector3 location, World newWorldToSyncTo,
            bool completeMoveOnLoad, bool waitForCommandBeforeMovingPlayer,
            bool allowGridToForceWorldShifts, bool waitForOldObjectsToBeRemoved, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f)
        {
            string methodName = "TryMovePlayerToLocationOnNewWorld";
            MakeSureGridIsInitialized(methodName);

            //If new world is same as current world, use TryMovePlayerToLocation method instead.
            if (newWorldToSyncTo == world)
            {
                IEnumerator<YieldInstruction> e = TryMovePlayerToLocation(location, completeMoveOnLoad,
                    waitForCommandBeforeMovingPlayer, waitForOldObjectsToBeRemoved);

                while (e.MoveNext())
                    yield return e.Current;

                yield break;
            }
            if (newWorldToSyncTo == null)
                throw new ArgumentNullException(string.Format("TryMovePlayerToLocationOnNewWorld call on Active Grid with ID {0} failed. The new world to sync to is null.", ID, world.ID));

            if (persistent && !newWorldToSyncTo.IsWorldPersistent)
                throw new InvalidPersistenceException(string.Format("TryMovePlayerToLocationOnNewWorld call on Active Grid with ID {0} failed. The Active Grid is persistent, but the World you are trying to sync to (ID = {1}) is not. This is not allowed.", ID, world.ID));

            MakeSurePlayerIsPresent(methodName, "the player cannot be moved");
            MakeSureGridIsNotBusy(methodName);

            if (setPlayerYPositionBasedOnTerrain)
                MakeSurePlayerYPositionCanBeSetBasedOnTerrain(methodName);

            int oldWorldID = world != null ? worldRegistrationID : -1;

            newWorldToSyncTo.Register(this, out worldRegistrationID);

            Cell firstCellInInnerAreaOfGridAtNewLocation = newWorldToSyncTo.FindEndlessGridCellPositionIsIn_ZeroBased(location);

            SetStandardPreActionData(firstCellInInnerAreaOfGridAtNewLocation, MultiFrameActionType.MoveToLocationAndSyncToNewWorld, completeMoveOnLoad, newWorldToSyncTo);

            activeGridState.amountToMoveGridOrPositionToMoveGridTo = location;
            activeGridState.isWorldToSyncToPersistent = newWorldToSyncTo.IsWorldPersistent;

            activeGridState.setPlayerYPositionUsingTerrainHeight = setPlayerYPositionBasedOnTerrain;

            if (setPlayerYPositionBasedOnTerrain)
                activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = playerYOffset;
            else
                activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = 0f;

            SetPostActionSection(firstCellInInnerAreaOfGridAtNewLocation, location, newWorldToSyncTo);

            StopAllBoundaryMonitoring();

            if (waitForCommandBeforeMovingPlayer)
                activeGridState.delayMove = true;

            yield return null;

            ActiveGridCells postMoveAndSyncActiveCellGroup = activeGridTypeSpecificLogic.CreateActiveGridCells(activeGridState.primaryCellOfGridAfterActionCompletes, newWorldToSyncTo.WorldGrid.WorldType, activeGridState.layerOfSectionAfterActionCompletes, activeGridState.rowOfSectionAfterActionCompletes, activeGridState.columnOfSectionAfterActionCompletes);

            bool needToRemoveOldObjects = activeGridState.cellObjectsLoaded;
            if (activeGridState.cellObjectsEnabled)
            {
                postMoveAndSyncActiveCellGroup.GetAllCells(cellsToAddUsersTo);
                activeGridState.cellObjectsLoaded = true;

                IEnumerator<YieldInstruction> addCellsAndWaitEnumerator = activeGridState.worldToSyncTo.AddCellUsers_ZeroBasedAndWaitForCellObjectsToBeLoaded(cellsToAddUsersTo);
                while (addCellsAndWaitEnumerator.MoveNext())
                    yield return addCellsAndWaitEnumerator.Current;

                cellsToAddUsersTo.Clear();
            }
            else
                activeGridState.cellObjectsLoaded = false;


            IEnumerator<YieldInstruction> movePlayerAndRemoveOldObjectsEnumerator = MovePlayerToLocationAndRemoveOldObjectsIfNeeded(waitForCommandBeforeMovingPlayer, needToRemoveOldObjects, waitForOldObjectsToBeRemoved, true, setPlayerYPositionBasedOnTerrain, playerYOffset);

            while (movePlayerAndRemoveOldObjectsEnumerator.MoveNext())
                yield return movePlayerAndRemoveOldObjectsEnumerator.Current;

            PostSyncRoutine(postMoveAndSyncActiveCellGroup, allowGridToForceWorldShifts, oldWorldID);
        }








        IEnumerator<YieldInstruction> MovePlayerToLocationAndRemoveOldObjectsIfNeeded(bool waitForCommandBeforeMovingPlayer, bool needToRemoveOldObjects, bool waitForOldObjectsToBeRemoved, bool fireWorldSyncEventOnMove = false, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f)
        {
            if (waitForCommandBeforeMovingPlayer && activeGridState.delayMove)
            {
                IEnumerator<YieldInstruction> wait = WaitForMoveCommand();
                while (wait.MoveNext())
                    yield return wait.Current;
            }

            Vector3 locationToMovePlayerTo = new Vector3(
                activeGridState.amountToMoveGridOrPositionToMoveGridTo.x,
                GetYPositionToMovePlayerTo(activeGridState.amountToMoveGridOrPositionToMoveGridTo, setPlayerYPositionBasedOnTerrain, playerYOffset),
                activeGridState.amountToMoveGridOrPositionToMoveGridTo.z);

            if (playerMover != null)
            {
                IEnumerator<YieldInstruction> movePlayerViaPlayerMoverEnumerator = MovePlayerViaPlayerMover(locationToMovePlayerTo, fireWorldSyncEventOnMove);
                while (movePlayerViaPlayerMoverEnumerator.MoveNext())
                    yield return movePlayerViaPlayerMoverEnumerator.Current;
            }
            else
            {
                player.position = locationToMovePlayerTo;
                OnPlayerMoved();
                if (fireWorldSyncEventOnMove)
                    OnSyncedToNewWorld(activeGridState.worldToSyncTo);
            }

            PlayerReadyToBeMoved = false;

            if (needToRemoveOldObjects)
            {
                IEnumerator<YieldInstruction> removeOldObjectsEnumerator = RemoveOldObject(waitForOldObjectsToBeRemoved);
                while (removeOldObjectsEnumerator.MoveNext())
                    yield return removeOldObjectsEnumerator.Current;
            }
        }

        





        /// <summary>
        /// Tries to sync to the new world at the player's current position.
        /// <para>
        /// This method fully loads the cells (and objects if necessary) of the new world, and then removes the 
        /// cells (and objects) of the old world.
        /// </para>
        /// <para>
        /// This method, like all Try methods in this API, will throw an exception when
        /// a coroutine operation is currently being executed by this Active Grid. The best way to account for this possibility is to simply
        /// check to make sure the Active Grid is not busy before calling this method, which you can do by checking
        /// the Active Grid's <see cref="IsBusy" href = "#IsBusy">IsBusy</see> property.
        /// </para>
        /// </summary>
        /// <param name = "newWorldToSyncTo" type = "World" link = "World.html">
        /// The new World to sync to.
        /// </param>
        /// <param name="completeSyncOnLoad" type = "bool">
        /// If a save occurs while the sync is under way, should the sync be completed when that save is loaded next 
        /// session? If false, the sync operation will effectively be cancelled when the save is loaded, in which case it is the 
        /// caller of this method's responsibility to resume it when the save is loaded.
        /// </param>
        /// <param name = "allowGridToForceWorldShifts" type = "bool">
        /// If true, the grid will be permitted to force shifts in the new World (only applies to origin centered worlds).
        /// </param>
        /// <param name="waitForOldObjectsToBeRemoved" type="bool">
        /// If true, the coroutine will not exit/yield break until the pre sync objects that are no longer needed are removed.
        /// <para>
        /// This is mostly useful if displaying a loading screen and you only want to remove the loading screen when the world 
        /// is completely up to date.
        /// </para>
        /// </param>
        /// <param name="setPlayerYPositionBasedOnTerrain" type="bool">
        /// If true, once the new world is loaded, the y position of the player will be adjusted to that of the terrain the player is on (plus the playerYOffset).
        /// If a Player Mover exist on the Active Grid, it will be used to move the player.
        /// </param>
        /// <param name="playerYOffset" type="float">
        /// When setPlayerYPositionBasedOnTerrain is true, this value can be used to ensure the player does not overlap the terrain. A value of 1, for instance, 
        /// will place the player 1 unit above the terrain's height. You will need to experiment to find the best value, as it will depend largely upon the 
        /// shape and height of your player's collider.
        /// </param>
        /// <syntax>
        /// public IEnumerator&lt;YieldInstruction&gt; TrySyncToNewWorldAroundPlayer(World newWorldToSyncTo, bool completeSyncOnLoad, bool allowGridToForceWorldShifts, bool waitForOldObjectsToBeRemoved, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f)
        /// </syntax>
        /// <displayName id = "TrySyncToNewWorldAroundPlayer">
        /// TrySyncToNewWorldAroundPlayer(World, bool, bool, bool, [bool], [float])
        /// </displayName>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <exception name = "RequiredComponentNotFoundException" link = "RequiredComponentNotFoundException.html">
        /// Thrown when a Player Transform has not been supplied to the Active Grid.
        /// </exception>
        /// <exception name="InvalidOperationException">
        /// Thrown when no player is associated with the grid, when the Active Grid has not been initialized yet, when this 
        /// method is called while the Active Grid is busy
        /// executing a multi frame action (check IsBusy before calling ActiveGrid methods that begin with "Try"), or 
        /// when setPlayerYPositionBasedOnTerrain is true but the new world to sync to does not use Unity Terrain or cell objects 
        /// are not enabled on the Active Grid.
        /// </exception>
        public IEnumerator<YieldInstruction> TrySyncToNewWorldAroundPlayer(World newWorldToSyncTo,
            bool completeSyncOnLoad, bool allowGridToForceWorldShifts, bool waitForOldObjectsToBeRemoved, bool setPlayerYPositionBasedOnTerrain = false, float playerYOffset = 1f)
        {
            string methodName = "TrySyncToNewWorldAroundPlayer";
            MakeSureGridIsInitialized(methodName);

            //Make sure new world does not equal current world
            if (newWorldToSyncTo == world)
            {
                Debug.Log("The new world passed into the TrySyncToNewWorldAroundPlayer method is the same as the current world. No action will be taken");

                yield break;
            }
            
            if (newWorldToSyncTo == null)
                throw new ArgumentNullException(string.Format("TrySyncToNewWorldAroundPlayer call on Active Grid with ID {0} failed. The new world to sync to is null.", ID, world.ID));

            if (persistent && !newWorldToSyncTo.IsWorldPersistent)
                throw new InvalidPersistenceException(string.Format("TrySyncToNewWorldAroundPlayer call on Active Grid with ID {0} failed. The Active Grid is persistent, but the World you are trying to sync to (ID = {1}) is not. This is not allowed.", ID, world.ID));

            MakeSurePlayerIsPresent(methodName, "the world cannot be synced");
            MakeSureGridIsNotBusy(methodName);

            if (setPlayerYPositionBasedOnTerrain)
                MakeSurePlayerYPositionCanBeSetBasedOnTerrain(methodName);

            int oldWorldID = world != null ? worldRegistrationID : -1;

            newWorldToSyncTo.Register(this, out worldRegistrationID);

            Cell firstCellInInnerAreaOfGridOnNewWorld = newWorldToSyncTo.FindEndlessGridCellPositionIsIn_ZeroBased(player.position);

            SetStandardPreActionData(firstCellInInnerAreaOfGridOnNewWorld, MultiFrameActionType.SyncToNewWorldAroundPlayer, completeSyncOnLoad, newWorldToSyncTo);

            activeGridState.isWorldToSyncToPersistent = newWorldToSyncTo.IsWorldPersistent;

            activeGridState.setPlayerYPositionUsingTerrainHeight = setPlayerYPositionBasedOnTerrain;

            if (setPlayerYPositionBasedOnTerrain)
                activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = playerYOffset;
            else
                activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = 0f;

            SetPostActionSection(firstCellInInnerAreaOfGridOnNewWorld, player.position, newWorldToSyncTo);

            while (newWorldToSyncTo.IsOriginCellUpdateInProgress)
                yield return null;

            IEnumerator<YieldInstruction> syncToWorldEnumerator = SyncToNewWorld(allowGridToForceWorldShifts, oldWorldID, waitForOldObjectsToBeRemoved, setPlayerYPositionBasedOnTerrain, playerYOffset);
            while (syncToWorldEnumerator.MoveNext())
                yield return syncToWorldEnumerator.Current;
        }






        /// <summary>
        /// Tries to sync to the new world using the specified <see cref="Cell" href = "Cell.html">Cell</see> 
        /// to construct the new Active Grid.
        /// <para>
        /// Note that the player is not moved with this method, so the Active Grid may be updated 
        /// immediately after this coroutine finishes running (depending on the player's position 
        /// in relation to the new Active Grid). For this reason, it is recommended to use one of 
        /// the other methods (such as 
        /// <see cref="TrySyncToNewWorldAroundPlayer" href="#TrySyncToNewWorldAroundPlayer">
        /// TrySyncToNewWorldAroundPlayer
        /// </see>). 
        /// Generally, this method should only be used in the unlikely case that you are not 
        /// using a Player with your Active Grid.
        /// </para>
        /// <para>
        /// This method fully loads the cells (and objects if necessary) of the new world, 
        /// and then removes the cells (and objects) of the old world.
        /// </para>
        /// <para>
        /// This method, like all Try methods in this API, will throw an exception when
        /// a coroutine operation is currently being executed by this Active Grid. 
        /// The best way to account for this possibility is to simply
        /// check to make sure the Active Grid is not busy before calling this method, which you can do by checking
        /// the Active Grid's <see cref="IsBusy" href = "#IsBusy">IsBusy</see> property.
        /// </para>
        /// </summary>
        /// <param name = "newWorldToSyncTo" type = "World" link = "World.html">
        /// The new World to sync to.
        /// </param>
        /// <param name="completeSyncOnLoad" type = "bool">
        /// If a save occurs while the sync is under way, should the sync be completed when that 
        /// save is loaded next session? If false, the sync operation will effectively be 
        /// cancelled when the save is loaded, in which case it is the 
        /// caller of this method's responsibility to resume it when the save is loaded.
        /// </param>
        /// <param name = "primaryCellOfGridOnNewWorld" type = "Cell" link = "Cell.html">
        /// The bottom left most cell of the new Active Grid when the Active Grid type is set to 
        /// Outer_Ring_Grid, or the cell with the active section when the type is Sectioned_Grid.
        /// </param>
        /// <param name = "allowGridToForceWorldShifts" type = "bool">
        /// If true, the grid will be permitted to force shifts in the new World 
        /// (only applies to origin centered worlds).
        /// </param>
        /// <param name="waitForOldObjectsToBeRemoved" type="bool">
        /// If true, the coroutine will not exit/yield break until the pre sync objects that 
        /// are no longer needed are removed.
        /// <para>
        /// This is mostly useful if displaying a loading screen and you only want to remove the 
        /// loading screen when the world 
        /// is completely up to date.
        /// </para>
        /// </param>
        /// <param name="layerOfSection" type="int">
        /// The layer of the active section. Can be 0 (bottom half of cell) or 1 (top half of cell). 
        /// This is only used when the Active Grid Type is set to Sectioned_Grid and the grid is 
        /// synced to a 3D world.
        /// </param>
        /// <param name="rowOfSection" type="int">
        /// The row of the active section. Can be 0 (lower half of cell) or 1 (upper half of cell). 
        /// This is only used when the Active Grid Type is set to Sectioned_Grid.
        /// </param>
        /// <param name="columnOfSection" type="int">
        /// The column of the active section. Can be 0 (left half of cell) or 1 (right half of cell). 
        /// This is only used when the Active Grid Type is set to Sectioned_Grid.
        /// </param>
        /// <syntax>
        /// public IEnumerator&lt;YieldInstruction&gt; TrySyncToNewWorld(World newWorldToSyncTo, bool completeSyncOnLoad, Cell firstCellOfGridOnNewWorld, bool allowGridToForceWorldShifts, bool waitForOldObjectsToBeRemoved, int layerOfSection = 0, int rowOfSection = 0, int columnOfSection = 0)
        /// </syntax>
        /// <displayName id = "TrySyncToNewWorld">
        /// TrySyncToNewWorld(World, bool, Cell, bool, bool, [int], [int], [int])
        /// </displayName>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the grid has been initialized or 
        /// while the Active Grid is busy executing a multi frame action. 
        /// Check IsBusy before calling ActiveGrid methods that begin with "Try".
        /// </exception>
        public IEnumerator<YieldInstruction> TrySyncToNewWorld(World newWorldToSyncTo,
            bool completeSyncOnLoad, Cell primaryCellOfGridOnNewWorld, bool allowGridToForceWorldShifts, bool waitForOldObjectsToBeRemoved, int layerOfSection = 0, int rowOfSection = 0, int columnOfSection = 0)
        {
            string methodName = "TrySyncToNewWorld";

            MakeSureGridIsInitialized(methodName);

            if (newWorldToSyncTo == world)
            {
                Debug.Log("The new world passed into the TrySyncToNewWorld method is the same as the current world. No action will be taken");
                yield break;
            }

            if (newWorldToSyncTo == null)
                throw new ArgumentNullException(string.Format("TrySyncToNewWorld call on Active Grid with ID {0} failed. The new world to sync to is null.", ID, world.ID));

            if (persistent && !newWorldToSyncTo.IsWorldPersistent)
                throw new InvalidPersistenceException(string.Format("TrySyncToNewWorld call on Active Grid with ID {0} failed. The Active Grid is persistent, but the World you are trying to sync to (ID = {1}) is not. This is not allowed.", ID, world.ID));

            MakeSureGridIsNotBusy(methodName);

            int oldWorldID = world != null ? worldRegistrationID : -1;

            newWorldToSyncTo.Register(this, out worldRegistrationID);

            activeGridState.primaryCellOfGridAfterActionCompletes = primaryCellOfGridOnNewWorld.ConvertTo0Based(newWorldToSyncTo.IsWorld3D);
            activeGridState.multiFrameActionType = MultiFrameActionType.SyncToNewWorld;
            activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes = completeSyncOnLoad;
            activeGridState.worldToSyncTo = newWorldToSyncTo;
            activeGridState.isWorldToSyncToPersistent = newWorldToSyncTo.IsWorldPersistent;
            activeGridState.multiFrameActionExecuting = true;
            
            if (layerOfSection < 0)
                layerOfSection = 0;
            else if (layerOfSection > 1)
                layerOfSection = 1;
            activeGridState.layerOfSectionAfterActionCompletes = layerOfSection;

            if (rowOfSection < 0)
                rowOfSection = 0;
            else if (rowOfSection > 1)
                rowOfSection = 1;
            activeGridState.rowOfSectionAfterActionCompletes = rowOfSection;

            if (columnOfSection < 0)
                columnOfSection = 0;
            else if (columnOfSection > 1)
                columnOfSection = 1;
            activeGridState.columnOfSectionAfterActionCompletes = columnOfSection;

            IEnumerator<YieldInstruction> syncToWorldEnumerator =
                SyncToNewWorld(allowGridToForceWorldShifts, oldWorldID, waitForOldObjectsToBeRemoved, false);
            while (syncToWorldEnumerator.MoveNext())
                yield return syncToWorldEnumerator.Current;
        }






        IEnumerator<YieldInstruction> SyncToNewWorld(bool allowGridToForceWorldShifts, int oldWorldID, bool waitForOldObjectsToBeRemoved, bool setPlayerYPositionBasedOnTerrain, float playerYOffset = 1f)
        {
            StopAllBoundaryMonitoring();
            ActiveGridCells postMoveAndSyncActiveCellGroup =
                activeGridTypeSpecificLogic.CreateActiveGridCells(activeGridState.primaryCellOfGridAfterActionCompletes, activeGridState.worldToSyncTo.WorldGrid.WorldType, activeGridState.layerOfSectionAfterActionCompletes, activeGridState.rowOfSectionAfterActionCompletes, activeGridState.columnOfSectionAfterActionCompletes);

            bool needToRemoveOldObjects = activeGridState.cellObjectsLoaded;
            if (activeGridState.cellObjectsEnabled)
            {
                postMoveAndSyncActiveCellGroup.GetAllCells(cellsToAddUsersTo);
                activeGridState.cellObjectsLoaded = true;

                IEnumerator<YieldInstruction> addCellsAndWaitEnumerator = activeGridState.worldToSyncTo.AddCellUsers_ZeroBasedAndWaitForCellObjectsToBeLoaded(cellsToAddUsersTo);
                while (addCellsAndWaitEnumerator.MoveNext())
                    yield return addCellsAndWaitEnumerator.Current;

                cellsToAddUsersTo.Clear();
            }
            else
                activeGridState.cellObjectsLoaded = false;

            if (setPlayerYPositionBasedOnTerrain)
            {
                Vector3 locationToMovePlayerTo = new Vector3
                (player.position.x,
                GetYPositionToMovePlayerTo(player.position, true, playerYOffset),
                player.position.z
                );

                if (playerMover != null)
                {
                    IEnumerator<YieldInstruction> movePlayerViaPlayerMoverEnumerator = MovePlayerViaPlayerMover(locationToMovePlayerTo, false);
                    while (movePlayerViaPlayerMoverEnumerator.MoveNext())
                        yield return movePlayerViaPlayerMoverEnumerator.Current;
                }
                else
                {
                    player.position = locationToMovePlayerTo;
                    OnPlayerMoved();
                }
            }
            
            OnSyncedToNewWorld(activeGridState.worldToSyncTo);

            if (needToRemoveOldObjects)
            {
                IEnumerator<YieldInstruction> removeOldObjectsEnumerator = RemoveOldObject(waitForOldObjectsToBeRemoved);
                while (removeOldObjectsEnumerator.MoveNext())
                    yield return removeOldObjectsEnumerator.Current;
            }

            PostSyncRoutine(postMoveAndSyncActiveCellGroup, allowGridToForceWorldShifts, oldWorldID);
        }





        IEnumerator<YieldInstruction> WaitForMoveCommand()
        {
            PlayerReadyToBeMoved = true;
            do
            {
                yield return null;
            } while (activeGridState.delayMove);
        }






        float GetYPositionToMovePlayerTo(Vector3 location, bool setPlayerYPositionBasedOnTerrain, float playerYOffset)
        {
            if (setPlayerYPositionBasedOnTerrain)
            {
                WorldCell worldCell;
                activeGridState.worldToSyncTo.TryGetWorldCellPositionIsIn(activeGridState.amountToMoveGridOrPositionToMoveGridTo, out worldCell);
                if (worldCell == null)
                    return location.y;
                else
                {
                    WorldCellWithTerrain worldCellWithTerrain = (WorldCellWithTerrain)worldCell;
                    Terrain terrainToSample = worldCellWithTerrain.Terrain;
                    float yPositionToMovePlayerTo = terrainToSample.SampleHeight(location) + terrainToSample.GetPosition().y + playerYOffset;

                    return yPositionToMovePlayerTo;
                }

            }
            else
                return location.y;
        }






        IEnumerator<YieldInstruction> MovePlayerViaPlayerMover(Vector3 locationToMovePlayerTo, bool fireSyncEventOnMove)
        {
            IEnumerator<YieldInstruction> movePlayerEnumerator;
            movePlayerEnumerator = playerMover.MovePlayerToPosition(player, locationToMovePlayerTo);

            while (movePlayerEnumerator.MoveNext())
            {
                if (playerMover.PlayerMoved)
                {
                    activeGridState.playerMovedDuringMultiFrameAction = true;
                    OnPlayerMoved();
                    if (fireSyncEventOnMove)
                        OnSyncedToNewWorld(activeGridState.worldToSyncTo);

                    yield return movePlayerEnumerator.Current;
                    goto DoNotCheckIfPlayerMoved;
                }
                yield return movePlayerEnumerator.Current;
            }

            OnPlayerMoved();
            if (fireSyncEventOnMove)
                OnSyncedToNewWorld(activeGridState.worldToSyncTo);

            yield break;

            DoNotCheckIfPlayerMoved:

            while (movePlayerEnumerator.MoveNext())
                yield return movePlayerEnumerator.Current;
        }
        




        IEnumerator<YieldInstruction> RemoveOldObject(bool waitForOldObjectsToBeRemoved)
        {
            if (waitForOldObjectsToBeRemoved)
            {
                activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);

                IEnumerator<YieldInstruction> removalEnumerator = world.RemoveCellUsers_ZeroBasedAndWaitForCellObjectsToBeUnloaded(cellsToRemoveUsersFrom);

                while (removalEnumerator.MoveNext())
                    yield return removalEnumerator.Current;

                cellsToRemoveUsersFrom.Clear();
            }
            else
            {
                RemoveClaimOnCurrentCells();
                yield break;
            }
        }
        





        void PostSyncRoutine(ActiveGridCells postMoveAndSyncActiveCellGroup, bool allowGridToForceWorldShifts, int oldWorldID)
        {
            if (world != null)
                world.DeRegister(oldWorldID);

            activeGridCells = postMoveAndSyncActiveCellGroup;
            world = activeGridState.worldToSyncTo;
            activeGridState.idOfSyncedToWorld = world.worldID;
            activeGridState.worldToSyncTo = null;
            ResetPrimaryCellIndexes();

            activeGridState.layerOfSection = activeGridState.layerOfSectionAfterActionCompletes;
            activeGridState.rowOfSection = activeGridState.rowOfSectionAfterActionCompletes;
            activeGridState.columnOfSection = activeGridState.columnOfSectionAfterActionCompletes;

            activeGridState.monitorWorldShiftBoundaries = allowGridToForceWorldShifts;
            activeGridState.setPlayerYPositionUsingTerrainHeight = false;
            activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = 0f;
            activeGridState.playerMovedDuringMultiFrameAction = false;

            if (player != null)
            {
                SetupActiveCellBoundary();
                if (activeGridState.monitorInnerAreaBoundaries || allowGridToForceWorldShifts)
                    SetupInnerAreaAndShiftBoundaryMonitors();

                StartMonitoringIfNecessary();
            }

            activeGridState.multiFrameActionExecuting = false;
        }





        void SetPostActionSection(Cell cellPlayerWillBeInAfterActionCompletes, Vector3 positionOfPlayerAfterActionCompletes, World worldAfterActionCompletes)
        {
            FindSectionPositionIsIn(cellPlayerWillBeInAfterActionCompletes, positionOfPlayerAfterActionCompletes, out activeGridState.layerOfSectionAfterActionCompletes, out activeGridState.rowOfSectionAfterActionCompletes, out activeGridState.columnOfSectionAfterActionCompletes, worldAfterActionCompletes);
        }





        /// <summary>
        /// Tries to de-sync the Active Grid from the World it is currently synced to.
        /// </summary>
        /// <param name="completeDesyncOnLoad" type="bool">If true, when the Active Grid's state is saved during the middle 
        /// of the de-sync process, it will be saved as if the de-sync process were completed (i.e., when the 
        /// save data is loaded, the Active Grid will not be synced to a world).</param>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the grid has been initialized or 
        /// while the Active Grid is busy executing a multi frame action. 
        /// Check IsBusy before calling ActiveGrid methods that begin with "Try".
        /// </exception>
        /// <displayName id="TryDesyncFromCurrentWorld">TryDesyncFromCurrentWorld(bool)</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; TryDesyncFromCurrentWorld(bool completeDesyncOnLoad)</syntax>
        public IEnumerator<YieldInstruction> TryDesyncFromCurrentWorld(bool completeDesyncOnLoad)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryDesyncFromCurrentWorld call on Active Grid with ID {0} failed. The Active Grid was has not been initialized. If the Active Grid was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this Active Grid) before calling this method.", ID));

            if (IsBusy)
                throw new InvalidOperationException(string.Format("TryDesyncFromCurrentWorld call on Active Grid with ID {0} failed. Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", ID));

            if (world == null)
                yield break;

            activeGridState.multiFrameActionExecuting = true;
            activeGridState.multiFrameActionType = MultiFrameActionType.Desync;
            activeGridState.worldToSyncTo = null;
            activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes = completeDesyncOnLoad;

            if (boundaryMonitor != null)
            {
                boundaryMonitor.SetDynamicBoundaryMonitoringInfo(innerAreaAndWorldShiftBoundaryMonitorID, null, null);
                boundaryMonitor.DisableDynamicBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);

                if (world.IsWorldOriginCentered)
                {
                    boundaryMonitor.SetStaticBoundaryMonitoringInfo(innerAreaAndWorldShiftBoundaryMonitorID, null, null);
                    boundaryMonitor.DisableStaticBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
                }

                boundaryMonitor.StopMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
            }

            activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);

            IEnumerator<YieldInstruction> removalEnumerator = world.RemoveCellUsers_ZeroBasedAndWaitForCellObjectsToBeUnloaded(cellsToRemoveUsersFrom);

            while (removalEnumerator.MoveNext())
                yield return removalEnumerator.Current;

            cellsToRemoveUsersFrom.Clear();
            world.DeRegister(worldRegistrationID);
            world = null;
            activeGridState.cellObjectsLoaded = false;
            activeGridState.multiFrameActionExecuting = false;
            OnSyncedToNewWorld(activeGridState.worldToSyncTo);           
        }






        void SetStandardPreActionData(Cell firstCellInInnerAreaOfGridAtNewLocation, MultiFrameActionType actionType, bool completeActionNextSessionIfGameExitsBeforeActionCompletes, World postActionWorld)
        {
            Cell primaryCellInActiveGridAtNewLocation = activeGridTypeSpecificLogic.FindPrimaryCellInGridUsingFirstCellInInnerAreaOfGrid(postActionWorld, firstCellInInnerAreaOfGridAtNewLocation);

            activeGridState.primaryCellOfGridAfterActionCompletes = primaryCellInActiveGridAtNewLocation;
            activeGridState.multiFrameActionType = actionType;
            activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes = completeActionNextSessionIfGameExitsBeforeActionCompletes;
            activeGridState.worldToSyncTo = postActionWorld;

            activeGridState.multiFrameActionExecuting = true;
        }

        void MakeSureGridIsInitialized(string methodName)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("{0} call on Active Grid with ID {1} failed. The Active Grid was has not been initialized. If the Active Grid was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this Active Grid) before calling this method.", methodName, ID));
        }

        void MakeSureGridIsNotBusy(string methodName)
        {
            if (IsBusy)
                throw new InvalidOperationException(string.Format("{0} call on Active Grid with ID {1} failed. Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", methodName, ID));
        }

        void MakeSureWorldIsNotNull(string methodName)
        {
            if (world == null)
                throw new InvalidOperationException(methodName + " on Active Grid with ID " + ID + " failed. The Active Grid is not currently synced to a World.");
        }

        void MakeSurePlayerIsPresent(string methodName, string whyPlayerMustBePresent)
        {
            if (player == null)
                throw new InvalidOperationException(string.Format("{0} call on Active Grid with ID {1} failed. No Player is associated with the Active Grid, so {2}.", methodName, ID, whyPlayerMustBePresent));
        }

        void MakeSurePlayerYPositionCanBeSetBasedOnTerrain(string methodName)
        {
            if (world.WorldGrid.CellObjectType != CellObjectType.Unity_Terrain || !activeGridState.cellObjectsEnabled)
                throw new InvalidOperationException(string.Format("{0} call on Active Grid with ID {0} failed. You've indicated that the y position of the player should be set based on the terrain at the new location, yet the world does not use Unity Terrain and/or the Active Grid has cell objects disabled.", methodName, ID));
        }

        void ResetPostActionData()
        {
            activeGridState.multiFrameActionExecuting = false;
            activeGridState.worldToSyncTo = null;
            activeGridState.setPlayerYPositionUsingTerrainHeight = false;
            activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = 0f;
            activeGridState.playerMovedDuringMultiFrameAction = false;
        }

        #endregion

        #region Publich Methods for Loading/Unloading cell objects

        /// <summary>
        /// Try to have the currently synced to World load the cell objects associated with the cells of this Active Grid 
        /// as soon as possible.
        /// <para>If the Component Manager's Awake method has not passed yet, this method will result in the objects 
        /// being loaded in Awake/Start, otherwise the load will occur over a series of frames (as if TryLoadCellObjects 
        /// was called).</para>
        /// <para>For this reason, it's recommended to only use this method from another scripts Awake method before 
        /// the game starts.</para> In any other situation, you should use 
        /// <see cref="TryLoadCellObjects" href="#TryLoadCellObjects">TryLoadCellObjects</see> or 
        /// <see cref="TryLoadCellObjectsAndWaitForLoadToComplete" href="#TryLoadCellObjectsAndWaitForLoadToComplete">TryLoadCellObjectsAndWaitForLoadToComplete</see> instead.
        /// </summary>
        /// <syntax>
        /// public void TryLoadCellObjectsASAP()
        /// </syntax>
        /// <displayName id = "TryLoadCellObjectsASAP">
        /// TryLoadCellObjectsASAP()
        /// </displayName>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the grid has been initialized or 
        /// while the Active Grid is busy executing a multi frame action. 
        /// Check IsBusy before calling ActiveGrid methods that begin with "Try".
        /// </exception>
        /// <exception name="MissingComponentException">
        /// Thrown when this method is called while the Active Grid is not synced to a 
        /// <see cref="World" href="World.html">World</see>.
        /// </exception>
        public void TryLoadCellObjectsASAP()
        {
            if (activeGridState.cellObjectsLoaded)
                return;

            if (world == null)
                throw new MissingComponentException(string.Format("TryLoadCellObjects call on Active Grid with ID {0} failed. The Active Grid is not synced to a world, so enabling cell users makes no sense.", ID));

            if (IsBusy)
                throw new InvalidOperationException(string.Format("TryLoadCellObjects call on Active Grid with ID {0} failed. The Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", ID));

            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryLoadCellObjects call on Active Grid with ID {0} failed. The Active Grid was has not been initialized. If the Active Grid was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this Active Grid) before calling this method.", ID));

            activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToAddUsersTo);

            world.AddCellUsersImmediately_ZeroBased(cellsToAddUsersTo);

            cellsToAddUsersTo.Clear();
            activeGridState.cellObjectsEnabled = true;
            activeGridState.cellObjectsLoaded = true;
        }

        /// <summary>
        /// Try to have the currently synced to World load the cell objects associated 
        /// with the cells of this Active Grid.
        /// <para>
        /// The objects are loaded during the World's normal update cycle. 
        /// If you need the objects loaded immediately at the start of the game in Awake, use 
        /// <see cref="TryLoadCellObjectsASAP" href="#TryLoadCellObjectsASAP">TryLoadCellObjectsASAP</see> instead. 
        /// If you need to keep track of when the objects are fully loaded, you should use 
        /// <see cref="TryLoadCellObjectsAndWaitForLoadToComplete" href="#TryLoadCellObjectsAndWaitForLoadToComplete">
        /// TryLoadCellObjectsAndWaitForLoadToComplete</see> instead.
        /// </para>
        /// <para>
        /// Normally when save data is saved for an Active Grid, if a multi frame action was executing and that action requires 
        /// that the player's y location be set to the terrain's height, the save data will reflect that fact and the 
        /// Dynamic Loading Kit will attempt to set the players y location to the starting terrain's height.
        /// </para>
        /// <para>
        /// With this method, 
        /// however (and only this method), the players y position will not be set to the terrain's location, as there is no 
        /// way to predict when the terrain will be loaded (and the terrain must be loaded in order to get it's location and 
        /// set the player's y position in relation to it). If this is a problem (there's a 99% chance it won't be), you should 
        /// make sure that the Component Manager is handling the cell object loading rather than calling this method yourself.
        /// </para>
        /// </summary>
        /// <syntax>
        /// public void TryLoadCellObjects()
        /// </syntax>
        /// <displayName id = "TryLoadCellObjects">
        /// TryLoadCellObjects()
        /// </displayName>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the grid has been initialized or 
        /// while the Active Grid is busy executing a multi frame action. 
        /// Check IsBusy before calling ActiveGrid methods that begin with "Try".
        /// </exception>
        /// <exception name="MissingComponentException">
        /// Thrown when this method is called while the Active Grid is not synced to a 
        /// <see cref="World" href="World.html">World</see>.
        /// </exception>
        public void TryLoadCellObjects()
        {
            if (activeGridState.cellObjectsLoaded)
                return;

            if (world == null)
                throw new MissingComponentException(string.Format("TryLoadCellObjects call on Active Grid with ID {0} failed. The Active Grid is not synced to a world, so enabling cell users makes no sense.", ID));

            if (IsBusy)
                throw new InvalidOperationException(string.Format("TryLoadCellObjects call on Active Grid with ID {0} failed. The Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", ID));

            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryLoadCellObjects call on Active Grid with ID {0} failed. The Active Grid was has not been initialized. If the Active Grid was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this Active Grid) before calling this method.", ID));

            activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToAddUsersTo);
            world.AddCellUsers_ZeroBased(cellsToAddUsersTo);

            cellsToAddUsersTo.Clear();
            activeGridState.cellObjectsEnabled = true;
            activeGridState.cellObjectsLoaded = true;
        }

        /// <summary>
        /// Tries to send the Active Grid's cells to the synced to World so that the World will load 
        /// the Cell Objects associated with the cells. The coroutine exits only after all the 
        /// objects have been loaded.
        /// </summary>
        /// <syntax>
        /// public IEnumerator&lt;YieldInstruction&gt; TryLoadCellObjectsAndWaitForLoadToComplete()
        /// </syntax>
        /// <displayName id = "TryLoadCellObjectsAndWaitForLoadToComplete">
        /// TryLoadCellObjectsAndWaitForLoadToComplete()
        /// </displayName>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the grid has been initialized or 
        /// while the Active Grid is busy executing a multi frame action. 
        /// Check IsBusy before calling ActiveGrid methods that begin with "Try".
        /// </exception>
        /// <exception name="MissingComponentException">
        /// Thrown when this method is called while the Active Grid is not synced to a 
        /// <see cref="World" href="World.html">World</see>.
        /// </exception>
        public IEnumerator<YieldInstruction> TryLoadCellObjectsAndWaitForLoadToComplete()
        {
            if (activeGridState.cellObjectsLoaded)
                yield break;

            if (world == null)
                throw new MissingComponentException(string.Format("TryLoadCellObjectsAndWaitForLoadToComplete call on Active Grid with ID {0} failed. The Active Grid is not synced to a world, so enabling cell users makes no sense.", ID));

            if (IsBusy)
                throw new InvalidOperationException(string.Format("TryLoadCellObjectsAndWaitForLoadToComplete call on Active Grid with ID {0} failed. Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", ID));

            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryLoadCellObjectsAndWaitForLoadToComplete call on Active Grid with ID {0} failed. The Active Grid was has not been initialized. If the Active Grid was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this Active Grid) before calling this method.", ID));

            activeGridState.cellObjectsEnabled = true;
            activeGridState.cellObjectsLoaded = true;

            activeGridState.multiFrameActionExecuting = true;
            activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes = false;
            StopMonitoringOfInnerAreaAndWorldShiftBoundaries();

            yield return null;

            activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToAddUsersTo);
            IEnumerator<YieldInstruction> waitEnumerator = world.AddCellUsers_ZeroBasedAndWaitForCellObjectsToBeLoaded(cellsToAddUsersTo);
            while (waitEnumerator.MoveNext())
                yield return waitEnumerator.Current;

            if (activeGridState.setPlayerYPositionUsingTerrainHeight)
            {
                Vector3 locationToMovePlayerTo;
                WorldCell worldCell;
                world.TryGetWorldCellPositionIsIn(player.position, out worldCell);
                if (worldCell == null)
                    locationToMovePlayerTo = player.position;
                else
                {
                    WorldCellWithTerrain worldCellWithTerrain = (WorldCellWithTerrain)worldCell;
                    Terrain terrainToSample = worldCellWithTerrain.Terrain;
                    float yPositionToMovePlayerTo = terrainToSample.SampleHeight(player.position) + terrainToSample.GetPosition().y + activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight;

                    locationToMovePlayerTo = new Vector3(player.position.x, yPositionToMovePlayerTo, player.position.z);
                }

                if (playerMover != null)
                {
                    IEnumerator<YieldInstruction> movePlayerEnumerator;
                    movePlayerEnumerator = playerMover.MovePlayerToPosition(player, locationToMovePlayerTo);

                    while (movePlayerEnumerator.MoveNext())
                    {
                        if (playerMover.PlayerMoved)
                        {
                            activeGridState.playerMovedDuringMultiFrameAction = true;

                            yield return movePlayerEnumerator.Current;
                            goto DoNotCheckIfPlayerMoved;
                        }
                        yield return movePlayerEnumerator.Current;
                    }

                    OnPlayerMoved();

                    goto End;

                    DoNotCheckIfPlayerMoved:

                    while (movePlayerEnumerator.MoveNext())
                        yield return movePlayerEnumerator.Current;
                }
                else
                {
                    player.position = locationToMovePlayerTo;
                    OnPlayerMoved();
                }
            }
            End:


            cellsToAddUsersTo.Clear();
            activeGridState.multiFrameActionExecuting = false;
            activeGridState.playerMovedDuringMultiFrameAction = false;
            StartMonitoringIfNecessary();
        }

        /// <summary>
        /// Try to unload the cell objects associated with the cells of this Active Grid.
        /// <para>Will throw an exception if the grid is busy.</para>
        /// </summary>
        /// <syntax>
        /// public void TryUnloadCellObjects()
        /// </syntax>
        /// <displayName id = "TryUnloadCellObjects">
        /// TryUnloadCellObjects()
        /// </displayName>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called while the Active Grid is busy executing a multi frame action. Check IsBusy before 
        /// calling methods that begin with "Try".
        /// </exception>
        /// <exception name="MissingComponentException">
        /// Thrown when this method is called while the Active Grid is not synced to a 
        /// <see cref="World" href="World.html">World</see>.
        /// </exception>
        public void TryUnloadCellObjects()
        {
            if (!activeGridState.cellObjectsLoaded)
                return;

            if (world == null)
                throw new MissingComponentException(string.Format("TryDisableCellUsers call on Active Grid with ID {0} failed. The Active Grid is not synced to a world, so enabling cell users makes no sense.", ID));

            if (IsBusy)
                throw new InvalidOperationException(string.Format("TryDisableCellUsers call on Active Grid with ID {0} failed. Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", ID));

            activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);
            world.RemoveCellUsers_ZeroBased(cellsToRemoveUsersFrom);
            cellsToRemoveUsersFrom.Clear();
            activeGridState.cellObjectsEnabled = false;
            activeGridState.cellObjectsLoaded = false;
        }

        /// <summary>
        /// Try to disable the cell users for this Active Grid and wait for the objects associated with those cell users to 
        /// be disabled and possibly unloaded from the scene.
        /// <para>
        /// Will throw an exception if the grid is busy.
        /// </para>
        /// </summary>
        /// <syntax>
        /// public IEnumerator&lt;YieldInstruction&gt; TryUnloadCellObjectsAndWaitForUnloadToComplete()
        /// </syntax>
        /// <displayName id = "TryUnloadCellObjectsAndWaitForUnloadToComplete">
        /// TryUnloadCellObjectsAndWaitForUnloadToComplete()
        /// </displayName>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called while the Active Grid is busy executing a multi frame action. Check IsBusy before 
        /// calling methods that begin with "Try".
        /// </exception>
        /// <exception name="MissingComponentException">
        /// Thrown when this method is called while the Active Grid is not synced to a 
        /// <see cref="World" href="World.html">World</see>.
        /// </exception>
        public IEnumerator<YieldInstruction> TryUnloadCellObjectsAndWaitForUnloadToComplete()
        {
            if (!activeGridState.cellObjectsLoaded)
                yield break;

            if (world == null)
                throw new MissingComponentException(string.Format("TryDisableCellUsersAndWaitForObjectsToBeUnloaded call on Active Grid with ID {0} failed. The Active Grid is not synced to a world, so enabling cell users makes no sense.", ID));

            if (IsBusy)
                throw new InvalidOperationException(string.Format("TryDisableCellUsersAndWaitForObjectsToBeUnloaded call on Active Grid with ID {0} failed. Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", ID));

            activeGridState.cellObjectsEnabled = false;
            activeGridState.cellObjectsLoaded = false;
            activeGridState.multiFrameActionExecuting = true;
            activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes = false;
            StopMonitoringOfInnerAreaAndWorldShiftBoundaries();

            activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);
            IEnumerator<YieldInstruction> waitEnumerator = world.RemoveCellUsers_ZeroBasedAndWaitForCellObjectsToBeUnloaded(cellsToRemoveUsersFrom);
            while (waitEnumerator.MoveNext())
                yield return waitEnumerator.Current;

            cellsToRemoveUsersFrom.Clear();
            activeGridState.multiFrameActionExecuting = false;
            StartMonitoringIfNecessary();
        }

        internal bool DoesPlayerYPositionNeedUpdatingToTerrainLocation()
        {
            return activeGridState.setPlayerYPositionUsingTerrainHeight && player != null && activeGridState.cellObjectsEnabled && activeGridState.cellObjectsLoaded && world != null && world.WorldGrid.CellObjectType == CellObjectType.Unity_Terrain;
        }

        internal void UpdatePlayerYPositionToTerrainLocation()
        {
            Vector3 locationToMovePlayerTo;
            WorldCell worldCell;
            world.TryGetWorldCellPositionIsIn(player.position, out worldCell);
            if (worldCell == null)
                locationToMovePlayerTo = player.position;
            else
            {
                WorldCellWithTerrain worldCellWithTerrain = (WorldCellWithTerrain)worldCell;
                Terrain terrainToSample = worldCellWithTerrain.Terrain;
                float yPositionToMovePlayerTo = terrainToSample.SampleHeight(player.position) + terrainToSample.GetPosition().y + activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight;

                locationToMovePlayerTo = new Vector3(player.position.x, yPositionToMovePlayerTo, player.position.z);
            }

            player.position = locationToMovePlayerTo;

            activeGridState.setPlayerYPositionUsingTerrainHeight = false;
            activeGridState.playerYOffsetWhenSettingBasedOnTerrainHeight = 0f;
        }

        #endregion

        #region Public Methods for enabling/disabling boundary monitoring

        /// <summary>
        /// Enable Inner Area Boundary Monitoring when the grid is synced to a world. This will effectively enable dynamic loading.
        /// </summary>
        /// <syntax>public void EnableInnerAreaBoundaryMonitoringWhenSynced()</syntax>
        /// <displayName id = "EnableInnerAreaBoundaryMonitoringWhenSynced">EnableInnerAreaBoundaryMonitoringWhenSynced()</displayName>
        /// <exception name = "RequiredComponentNotFoundException" link = "RequiredComponentNotFoundException.html">
        /// Thrown when a Player Transform has not been supplied to the Active Grid.
        /// </exception>
        public void EnableInnerAreaBoundaryMonitoringWhenSynced()
        {
            if (activeGridState.monitorInnerAreaBoundaries)
                return;

            if (player == null)
                throw new RequiredComponentNotFoundException("Could not enable the Inner Area Boundary Monitor on the Active Grid with ID " + activeGridID +
                " because no Player is present on that Active Grid.");

            activeGridState.monitorInnerAreaBoundaries = true;

            if (IsInitialized && world != null)
            {
                SetupInnerAreaBoundary();
                StartMonitoringOfInnerAreaAndWorldShiftBoundaries();
            }
        }

        /// <summary>
        /// Disable Inner Area Boundary Monitoring when the grid is synced to a world. This will effectively disable dynamic loading.
        /// </summary>
        /// <syntax>public void DisableInnerAreaBoundaryMonitoringWhenSynced()</syntax>
        /// <displayName id = "DisableInnerAreaBoundaryMonitoringWhenSynced">DisableInnerAreaBoundaryMonitoringWhenSynced()</displayName>
        public void DisableInnerAreaBoundaryMonitoringWhenSynced()
        {
            if (!activeGridState.monitorInnerAreaBoundaries)
                return;

            activeGridState.monitorInnerAreaBoundaries = false;

            if (IsInitialized && world != null && boundaryMonitor != null)
            {
                boundaryMonitor.DisableDynamicBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
                if (!world.IsWorldOriginCentered || !activeGridState.monitorWorldShiftBoundaries)
                    StopMonitoringOfInnerAreaAndWorldShiftBoundaries();
            }
        }

        /// <summary>
        /// Allows the grid to cause shifts in the World it is synced to (if it is synced to one). 
        /// This only has an effect when the grid is synced to an origin centered World
        /// and a player is associated with the Active Grid.
        /// </summary>
        /// <syntax>public void AllowGridToCauseWorldShiftsWhenSynced()</syntax>
        /// <displayName id = "AllowGridToCauseWorldShiftsWhenSynced">AllowGridToCauseWorldShiftsWhenSynced()</displayName>
        /// <exception name = "RequiredComponentNotFoundException" link = "RequiredComponentNotFoundException.html">
        /// Thrown when a Player Transform has not been supplied to the Active Grid.
        /// </exception>
        public void AllowGridToCauseWorldShiftsWhenSynced()
        {
            if (activeGridState.monitorWorldShiftBoundaries)
                return;

            if (player == null)
                throw new RequiredComponentNotFoundException("Could not allow the Active Grid with ID " + activeGridID +
                " to cause world shifts when synced because no Player is present on that Active Grid.");

            activeGridState.monitorWorldShiftBoundaries = true;

            if (IsInitialized && world != null && world.IsWorldOriginCentered)
            {
                SetupWorldShiftBoundary();
                StartMonitoringOfInnerAreaAndWorldShiftBoundaries();
            }
        }

        /// <summary>
        /// Stops this Active Grid from being able to cause shifts in the World it is synced to.
        /// </summary>
        /// <syntax>public void StopGridFromCausingWorldShiftsWhenSynced()</syntax>
        /// <displayName id = "StopGridFromCausingWorldShiftsWhenSynced">StopGridFromCausingWorldShiftsWhenSynced()</displayName>
        public void StopGridFromCausingWorldShiftsWhenSynced()
        {
            if (!activeGridState.monitorWorldShiftBoundaries)
                return;

            activeGridState.monitorWorldShiftBoundaries = false;

            if (IsInitialized && world != null)
            {
                boundaryMonitor.DisableStaticBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
                if (!activeGridState.monitorInnerAreaBoundaries)
                    StopMonitoringOfInnerAreaAndWorldShiftBoundaries();
            }
        }

        #endregion

        #region Method for Updating Grid Dimensions
        /// <summary>
        /// Try to change the Active Grid's dimensions. Will throw an exception if the grid is busy or if the 
        /// Active Grid Type is set to Sectioned_Grid.
        /// </summary>
        /// <param name = "newGridDimensions" type = "ActiveGridDimensions" link = "ActiveGridDimensions.html">
        /// The new Active Grid dimensions to use.
        /// </param>
        /// <syntax>
        /// public void TryChangeGridDimensions(ActiveGridDimensions newGridDimensions)
        /// </syntax>
        /// <displayName id = "TryChangeGridDimensions">
        /// TryChangeGridDimensions(ActiveGridDimensions)
        /// </displayName>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called when the Active Grid Type is set to Sectioned_Grid or while the Active Grid is 
        /// busy executing a multi frame action. Check IsBusy before calling methods that begin with "Try".
        /// </exception>
        public void TryChangeGridDimensions(ActiveGridDimensions newGridDimensions)
        {
            if (activeGridType == ActiveGridType.Sectioned_Grid)
                throw new InvalidOperationException(string.Format("TryChangeGridDimensions call on Active Grid with ID {0} failed. Active Grid Type is set to 'Sectioned_Grid'. Changing grid dimensions is only allowed when the type is set to 'Outer_Ring_Grid'.", ID));

            if (IsBusy)
                throw new InvalidOperationException(string.Format("TryChangeGridDimensions call on Active Grid with ID {0} failed. Active Grid was busy executing a multi frame action. If a method of the Active Grid begins with 'Try', then you must check to make sure the grid is not busy (via the IsBusy property) before calling the method.", ID));

            activeGridState.innerRows = newGridDimensions.innerAreaRows;
            activeGridState.innerColumns = newGridDimensions.innerAreaColumns;
            activeGridState.outerRingWidth = newGridDimensions.outerRingWidth;
            activeGridState.innerLayers = newGridDimensions.innerAreaLayers;

            if (IsInitialized && world != null)
                UpdateActiveCellGroupToReflectCurrentDimensions();
        }

        void UpdateActiveCellGroupToReflectCurrentDimensions()
        {
            Cell firstCellInNewInnerArea;
            if (activeGridState.monitorInnerAreaBoundaries)
                firstCellInNewInnerArea = world.FindEndlessGridCellPositionIsIn_ZeroBased(player.position);
            else
                firstCellInNewInnerArea = activeGridCells.FirstCellInInnerArea;

            //The +1 is because the first cell stored in the active grid state is 1 based, whereas the first cell 
            //in the inner area of the active cell group is 0 based.
            activeGridState.primaryCellLayer = firstCellInNewInnerArea.layer - activeGridState.outerRingWidth + 1;
            activeGridState.primaryCellRow = firstCellInNewInnerArea.row - activeGridState.outerRingWidth + 1;
            activeGridState.primaryCellColumn = firstCellInNewInnerArea.column - activeGridState.outerRingWidth + 1;

            if (activeGridState.cellObjectsLoaded)
            {
                activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);
                SetupActiveGridCells();
                activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToAddUsersTo);

                world.AddCellUsers_ZeroBased(cellsToAddUsersTo);
                world.RemoveCellUsers_ZeroBased(cellsToRemoveUsersFrom);

                cellsToAddUsersTo.Clear();
                cellsToRemoveUsersFrom.Clear();
            }
            else
                SetupActiveGridCells();

            ResetPrimaryCellIndexes();

            if (activeGridState.monitorInnerAreaBoundaries)
            {
                activeGridState.firstCellInInnerArea = firstCellInNewInnerArea;
                activeGridState.lastCellInInnerArea = activeGridCells.LastCellInInnerArea;
                activeGridTypeSpecificLogic.CalculateInnerAreaBoundaries();
            }
        }
        #endregion

        #region Miscellaneous Methods
        
        /// <summary>
        /// Tells a pending move operation that it is okay to proceed. This is used in conjunction with passing in true 
        /// for the waitForCommandBeforeMovingPlayer parameter of the 
        /// <see cref="TryMovePlayerToLocation" href = "#TryMovePlayerToLocation">TryMovePlayerToLocation</see> and  
        /// <see cref="TryMovePlayerToLocationOnNewWorld" href = "#TryMovePlayerToLocationOnNewWorld">
        /// TryMovePlayerToLocationOnNewWorld
        /// </see> Methods.
        /// <para>
        /// This allows you to gain greater control over when the move operation is executed, which is useful in many situations.
        /// </para>
        /// </summary>
        /// <syntax>public void InitiatePendingMove()</syntax>
        /// <displayName id = "InitiatePendingMove">InitiatePendingMove()</displayName>
        public void InitiatePendingMove()
        {
            activeGridState.delayMove = false;
        }

        Cell FindCellPlayerIsIn(World worldToUseToFindCell)
        {
            return worldToUseToFindCell.FindEndlessGridCellPositionIsIn_ZeroBased(player.position);
        }

        void OnSyncedToNewWorld(World newWorld)
        {
            if (WorldSyncedToChanged != null)
            {
                worldSyncedToChangedEventArgs.OldWorld = world;
                worldSyncedToChangedEventArgs.NewWorld = newWorld;
                WorldSyncedToChanged(this, worldSyncedToChangedEventArgs);
            }

            if (newWorld != null)
                activeCell = FindCellPlayerIsIn(newWorld);

            UpdateCellPlayerIsInChangedEventArgs(newWorld);
            OnCellPlayerIsInChanged();
        }

        //assumes activeCell is correct
        void UpdateCellPlayerIsInChangedEventArgs(World worldPlayerSyncedTo)
        {
            //Necessary?
            if (player == null)
                return;

            if (worldPlayerSyncedTo == null)
            {
                cellPlayerIsInChangedEventArgs.worldCellPlayerIsIn = null;
                cellPlayerIsInChangedEventArgs.reasonForNullWorldCell = "Could not locate a World Cell because the Active Grid with ID " + ID + " is not synced to a World";
                return;
            }

            bool isWorld3D = worldPlayerSyncedTo.IsWorld3D;
            cellPlayerIsInChangedEventArgs.EndlessGridCellPlayerIsIn = activeCell.ConvertTo1Based(isWorld3D);

            cellPlayerIsInChangedEventArgs.WorldGridCellPlayerIsIn = worldPlayerSyncedTo.ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(activeCell).ConvertTo1Based(isWorld3D);

            worldPlayerSyncedTo.TryGetWorldCellAssociatedWithEndlessGridCell(cellPlayerIsInChangedEventArgs.EndlessGridCellPlayerIsIn, out cellPlayerIsInChangedEventArgs.worldCellPlayerIsIn, out cellPlayerIsInChangedEventArgs.reasonForNullWorldCell);
        }



        void OnCellPlayerIsInChanged()
        {
            if (player == null)
                return;

            if (CellPlayerIsInChanged != null)
                CellPlayerIsInChanged(this, cellPlayerIsInChangedEventArgs);
        }

        void OnPlayerMoved()
        {
            if (PlayerMovedByGrid != null)
                PlayerMovedByGrid(this, playerMovedByGridEventArgs);
        }

        

        

        //Check if the active cell has changed (i.e., the cell the player is in)
        //this should only be called when the player is moved to a new location and 
        //it's uncertain whether the new location is in a new cell.
        //When the player is synced to a new world, the cell changed event will be triggered by those 
        //methods, so there's no need to call this method.

        //In some situations, the endless grid cell might be the same, but it may be in a different 
        //location, in which case the active cell boundary needs to be updated.
        void CheckIfActiveCellChangedAndReactAccordingly(Cell newActiveCell_ZeroBased)
        {
            if(newActiveCell_ZeroBased == activeCell)
                SetupActiveCellBoundary();
            else
            {
                activeCell = newActiveCell_ZeroBased;
                OnActiveCellChanged();
            }
        }

        void OnActiveCellChanged()
        {
            SetupActiveCellBoundary();
            UpdateCellPlayerIsInChangedEventArgs(world);
            OnCellPlayerIsInChanged();
        }

        //Method that is called when the active cell the player is in changes (as detected by Boundary Monitor)
        void OnActiveCellBoundaryCrossed(BoundaryCrossed eastOrWestBoundaryCrossed, BoundaryCrossed northOrSouthBoundaryCrossed, BoundaryCrossed topOrBottomBoundaryCrossed)
        {
            //these increments will help us calculate the new active cell
            int rowIncrement = 0, columnIncrement = 0, layerIncrement = 0;
            if (eastOrWestBoundaryCrossed == BoundaryCrossed.East)
                columnIncrement = 1;
            else if (eastOrWestBoundaryCrossed == BoundaryCrossed.West)
                columnIncrement = -1;

            if (northOrSouthBoundaryCrossed == BoundaryCrossed.North)
                rowIncrement = 1;
            else if (northOrSouthBoundaryCrossed == BoundaryCrossed.South)
                rowIncrement = -1;

            if (topOrBottomBoundaryCrossed == BoundaryCrossed.Top)
                layerIncrement = 1;
            else if (topOrBottomBoundaryCrossed == BoundaryCrossed.Bottom)
                layerIncrement = -1;

            activeCell += new Cell(rowIncrement, columnIncrement, layerIncrement);
            OnActiveCellChanged();
        }

        #endregion
    }
}