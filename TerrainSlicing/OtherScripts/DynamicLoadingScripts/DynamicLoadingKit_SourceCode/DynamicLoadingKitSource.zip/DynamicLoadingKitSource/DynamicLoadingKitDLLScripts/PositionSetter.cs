﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;

    internal abstract class PositionSetter
    {
        public abstract Vector3 SetPosition(float rowPosition, float columnPosition, float layerPosition);
    }

    internal class PositionSetter2DXY : PositionSetter
    {
        public sealed override Vector3 SetPosition(float rowPosition, float columnPosition, float layerPosition)
        {
            return new Vector3(columnPosition, rowPosition, layerPosition);
        }
    }

    internal class PositionSetter2DXZ : PositionSetter
    {
        public sealed override Vector3 SetPosition(float rowPosition, float columnPosition, float layerPosition)
        {
            return new Vector3(columnPosition, layerPosition, rowPosition);
        }
    }

    internal class PositionSetter3D : PositionSetter
    {
        public sealed override Vector3 SetPosition(float rowPosition, float columnPosition, float layerPosition)
        {
            return new Vector3(columnPosition, layerPosition, rowPosition);
        }
    }
}