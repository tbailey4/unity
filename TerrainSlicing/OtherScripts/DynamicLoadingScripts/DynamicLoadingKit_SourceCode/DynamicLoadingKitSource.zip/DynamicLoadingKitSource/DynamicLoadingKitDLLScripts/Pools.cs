﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System.Collections.Generic;

    internal class Pool<T>
    {
        Queue<T> pool;

        internal Pool()
        {
            pool = new Queue<T>();
        }

        internal bool PoolIsEmpty { get { return pool.Count == 0; } }

        internal T GetObject()
        {
            return pool.Dequeue();
        }

        internal void AddObject(T obj)
        {
            pool.Enqueue(obj);
        }
    }

    internal class DictionaryPool<TKey, TValue>
    {
        EqualityComparer<TKey> equalityComparer;
        Queue<Dictionary<TKey, TValue>> pool;

        internal DictionaryPool(EqualityComparer<TKey> equalityComparer)
        {
            this.equalityComparer = equalityComparer;
            pool = new Queue<Dictionary<TKey, TValue>>();
            pool.Enqueue(new Dictionary<TKey,TValue>(equalityComparer));
            pool.Enqueue(new Dictionary<TKey,TValue>(equalityComparer));
        }

        internal Dictionary<TKey, TValue> GetDictionary()
        {
            if (pool.Count > 0)
                return pool.Dequeue();
            else
                return new Dictionary<TKey, TValue>(equalityComparer);
        }

        internal void ReturnDictionary(Dictionary<TKey, TValue> dictionary)
        {
            pool.Enqueue(dictionary);
        }
    }

    internal interface IGridPool<T>
    {
        FixedSizePool<T> this[Cell cell]
        {
            get;
        }
    }

    internal class GridPool2D<T> : IGridPool<T>
    {
        FixedSizePool<T>[] pools;
        int columns;

        internal GridPool2D(int rows, int columns, int poolSize)
        {
            this.columns = columns;
            pools = new FixedSizePool<T>[rows * columns];
            for (int i = 0; i < pools.Length; i++)
                pools[i] = new FixedSizePool<T>(poolSize);
        }

        public FixedSizePool<T> this[Cell cell]
        {
            get { return pools[(cell.row - 1) * columns + (cell.column - 1)]; }
        }
    }

    internal class GridPool3D<T> : IGridPool<T>
    {
        FixedSizePool<T>[] pools;
        int rows, columns;

        internal GridPool3D(int layers, int rows, int columns, int poolSize)
        {
            this.columns = columns;
            this.rows = rows;
            pools = new FixedSizePool<T>[rows * columns * layers];
            for (int i = 0; i < pools.Length; i++)
                pools[i] = new FixedSizePool<T>(poolSize);
        }

        public FixedSizePool<T> this[Cell cell]
        {
            get { return pools[((cell.row - 1) * columns + (cell.column - 1)) + (columns * rows * (cell.layer - 1))]; }
        }
    }

    internal class FixedSizePool<T>
    {
        T[] pool;
        int count = 0;

        internal FixedSizePool(int fixedSize)
        {
            pool = new T[fixedSize];
        }

        internal bool TryAddObjectToPool(T obj)
        {
            if (count == pool.Length)
                return false;
            else
            {
                pool[count++] = obj;
                return true;
            }
        }

        internal bool TryGetObjectFromPool(out T obj)
        {
            if (count == 0)
            {
                obj = default(T);
                return false;
            }
            else
            {
                count--;
                obj = pool[count];
                return true;
            }
        }
    }
}
