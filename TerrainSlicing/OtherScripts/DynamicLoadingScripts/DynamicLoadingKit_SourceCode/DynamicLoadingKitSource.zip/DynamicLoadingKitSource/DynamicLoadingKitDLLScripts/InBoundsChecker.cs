﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System;

    internal abstract class InBoundsChecker
    {
        protected int rows, columns;
        protected Func<int, bool> IsRowInBounds, IsColumnInBounds;

        public InBoundsChecker(int rows, bool areRowsEndless, int columns, bool areColumnsEndless)
        { 
            this.rows = rows;
            this.columns = columns;

            if (areRowsEndless)
                IsRowInBounds = row => true;
            else
                IsRowInBounds = row => row >= 0 && row < this.rows;

            if (areColumnsEndless)
                IsColumnInBounds = column => true;
            else
                IsColumnInBounds = column => column >= 0 && column < this.columns;
        }

        public abstract bool IsCellInBounds(Cell cellOnEndlessGrid);
    }

    internal class TwoDimensionalInBoundsChecker : InBoundsChecker
    {
        public TwoDimensionalInBoundsChecker(int rows, bool areRowsEndless, int columns, bool areColumnsEndless)
            : base(rows, areRowsEndless, columns, areColumnsEndless){}

        public sealed override bool IsCellInBounds(Cell cellOnEndlessGrid)
        {
            return IsRowInBounds(cellOnEndlessGrid.row) && IsColumnInBounds(cellOnEndlessGrid.column);
        }
    }

    internal class ThreeDimensionalInBoundsChecker : InBoundsChecker
    {
        int layers;
        Func<int, bool> IsLayerInBounds;
        public ThreeDimensionalInBoundsChecker(int layers, bool areLayersEndless, int rows, bool areRowsEndless, int columns, bool areColumnsEndless)
            : base(rows, areRowsEndless, columns, areColumnsEndless)
        { 
            this.layers = layers;
            if (areLayersEndless)
                IsLayerInBounds = layer => true;
            else
                IsLayerInBounds = layer => layer >= 0 && layer < this.layers;
        }

        public sealed override bool IsCellInBounds(Cell cellOnEndlessGrid)
        {
            return IsLayerInBounds(cellOnEndlessGrid.layer) && IsRowInBounds(cellOnEndlessGrid.row) && IsColumnInBounds(cellOnEndlessGrid.column);
        }
    }
}