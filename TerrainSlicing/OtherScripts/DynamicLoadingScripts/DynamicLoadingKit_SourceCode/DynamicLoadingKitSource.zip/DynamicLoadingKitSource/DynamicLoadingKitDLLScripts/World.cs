﻿ //Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System;
    using System.Text;
    using System.Collections.Generic;

    /// <summary>
    /// Represents a World that can either be endless or non endless. When endless, the world repeats itself over and over again
    /// endlessly. The World can also be set to stay centered around its origin, which is useful when dealing with large worlds 
    /// where floating point imprecision can be an issue.
    /// <para>
    /// Worlds represent the cells of your World Grid in game. Unlike the World Grid, which is just a collection 
    /// of data, the World has an origin in scene space and you can manipulate the make-up of the world at any time.
    /// </para>
    /// <para>
    /// This is done by adding and removing cell users from the cells of the BaseWorld. When a cell on the world has no users, it remains in or transitions to 
    /// an inactivate state, where its objects are not loaded into the scene. Once a cell has users, it becomes active and the objects associated 
    /// with that cell are loaded into the scene.
    /// </para>
    /// <para>
    /// By design, the Active Grid is the only component which adds and removes cell users to and from the world, though you are free to design your own systems that also do so.
    /// </para>
    /// <para>
    /// Add and remove request are processed over several frames, and it's possible for these requests to cancel each other out. Once processed, 
    /// the world is updated (objects are added and/or removed from the scene) and then the World waits for additional requests, or processes requests 
    /// received while the world was updating. This cycle repeats for the life of the World.
    /// </para>
    /// <para>
    /// Also note that once a World Grid is added to the World in the inspector, some new options become visible. These options allow you 
    /// to load the objects that make up your world into the scene view for use in the editor. For more information, please take a look at the 
    /// <see href="http://deepspacelabs.net/files/Dynamic%20Loading%20Kit_Full_Guide.pdf">Dynamic Loading Kit Full Guide</see>.
    /// </para>
    /// <para>
    /// A World should only be disabled (or its game object disabled) if it is being used as a prototype to create worlds 
    /// at runtime. Do not disable a World with the intention of enabling/using it at a later time, as this will not work properly. Instead, 
    /// you should create the World via the Component Manager, and destroy it when it is no longer needed.
    /// </para>
    /// </summary>
    /// <title>World Class</title>
    /// <category>Primary Components</category>
    /// <navigationName>World</navigationName>
    /// <fileName>World.html</fileName>
    /// <syntax>public sealed class World : MonoBehaviour, <see cref="IIdentifiable" href="IIdentifiable.html">IIdentifiable</see>, <see cref="ICellObjectGroup" href="ICellObjectGroup.html">ICellObjectGroup</see></syntax>
    /// 
    /// <inspector name ="Are Columns Endless" type="bool">
    /// If checked, the columns of this world will be endless, i.e., when the player reaches
    /// the edge of the world on whatever axis the columns are on, the world will repeat.
    /// </inspector>
    /// 
    /// <inspector name ="Are Layers Endless" type="bool">
    /// If checked, the layers of this world will be endless, i.e., when the player reaches
    /// the edge of the world on whatever axis the layers are on, the world will repeat.
    /// <para>
    /// This option is only used when the World Grid associated with the World has a "World Type" of "Three Dimensional".
    /// </para>
    /// </inspector>
    /// 
    /// <inspector name ="Are Rows Endless" type="bool">
    /// If checked, the rows of this world will be endless, i.e., when the player reaches
    /// the edge of the world on whatever axis the rows are on, the world will repeat.
    /// </inspector>
    /// 
    /// <inspector name ="Load Cushion" type="float">
    /// Hover over this option in the inspector for a detailed explanation, or view
    /// the <see href="http://deepspacelabs.net/files/Dynamic%20Loading%20Kit_Full_Guide.pdf">Dynamic Loading Kit Full Guide</see>. Basically, smaller values will result in faster dynamic loading, but will increase
    /// the frequency of redundant operations (a cell being loaded and then unloaded soon after), which may hinder performance.</inspector>
    /// 
    /// <inspector name="Primary Cell Object Sub Controller" type="PrimaryCellObjectSubController" link="PrimaryCellObjectSubController.html">
    /// The Primary Cell Object Sub Controller that will be used by the World. The sub controller is responsible for retrieving objects
    /// when needed and disposing of objects when not needed. This component must be provided!</inspector>
    /// 
    /// <inspector name="Use this Game Object's Position as World Origin" type="bool">
    /// If checked, the world position of whatever game object this World component is attached to will be used for the World's origin.
    /// <para>Note that changing the game objects position during the game will have no effect on the world's position.</para></inspector>
    /// 
    /// <inspector name="World Grid" type="WorldGridBase" link="WorldGridBase.html">
    /// The World Grid that should be used as a blue print to build the world. This determines the size of the World's cells and what objects
    /// are loaded.</inspector>
    /// 
    /// <inspector name="World ID" type="int">The ID that uniquely identifies this World. If multiple Worlds/ShiftableWorlds exist in the same scene,
    /// it is imperative that their ID's be unique. When creating World's at runtime via the 
    /// <see cref="ComponentManager" href="ComponentManager.html">Component Manager</see>, a unique ID is automatically
    /// assigned to the created World.</inspector>
    /// 
    /// <inspector name="World Origin" type="Vector3">The origin of this World. This option is hidden if 
    /// "Use this Game Object's Position as World Origin" is checked.</inspector>
    [AddComponentMenu("Dynamic Loading Kit/Main Components/World")]
    public sealed class World : MonoBehaviour, IIdentifiable, ICellObjectGroup
    {
        #region Inspector Variables
        [SerializeField]
        internal bool areColumnsEndless = false,
                      areLayersEndless = false,
                      areRowsEndless = false,
                      keepWorldCenteredAroundOrigin = false,
                      useThisGameObjectsPositionAsWorldOrigin = true,
                      destroyObjectsOnPlay = true,
                      performShiftActivationInSingleFrame = true;

        [SerializeField]
        internal float loadCushion = .3f,
                       //Actually just east boundary, but keeping name the same for compatibility
                       distanceOfEastAndWestShiftBoundaryFromOrigin,
                       distanceOfWestBoundaryFromOrigin,

                       //Just North Boundary
                       distanceOfNorthAndSouthShiftBoundaryFromOrigin,
                       distanceOfSouthBoundaryFromOrigin,

                       //Just Top Boundary
                       distanceOfTopAndBottomShiftBoundaryFromOrigin,
                       distanceOfBottomBoundaryFromOrigin;

        [SerializeField]
        internal WorldGridBase worldGrid;

        //Required Components
        [SerializeField]
        internal PrimaryCellObjectSubController primaryCellObjectSubController;

        [SerializeField]
        internal Vector3 worldOrigin;

        [SerializeField]
        internal int worldID, oneBasedOriginCellRow = 1, oneBasedOriginCellLayer = 1, oneBasedOriginCellColumn = 1;

        //Cell object preview stuff
        [SerializeField]
        internal List<GameObject> previewCellObjects = new List<GameObject>();

        [SerializeField]
        internal int rangeTemplate = 0;

        [SerializeField]
        internal ObjectGroup[] objectGroups;

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets a value indicating whether at least one world cell has been fully loaded for this world. Methods that try and retrieve world cells should not be used until this property returns true.
        /// </summary>
        /// <type>bool</type>
        public bool HaveWorldCellsBeenFullyLoaded { get { return cellController != null && cellController.AreWorldCellsLoaded; } }

        /// <summary>
        /// Gets a value indicating whether the World's columns are endless.
        /// </summary>
        /// <type>bool</type>
        public bool AreColumnsEndless { get { return areColumnsEndless; } }

        /// <summary>
        /// Gets a value indicating whether the World's layers are endless.
        /// </summary>
        /// <type>bool</type>
        public bool AreLayersEndless { get { return areLayersEndless; } }

        /// <summary>
        /// Gets a value indicating whether the World's rows are endless.
        /// </summary>
        /// <type>bool</type>
        public bool AreRowsEndless { get { return areRowsEndless; } }

        /// <summary>
        /// Gets a value that can be added to a dynamic position to convert it to a static position.
        /// This is most useful for multiplayer games.
        /// </summary>
        /// <type>Vector3</type>
        public Vector3 DynamicToStaticPositionAddition { get { return currentOffset; } }

        /// <summary>
        /// Gets the group name of the object group associated with the World. This will most likely be the same as 
        /// the Group Name of the World Grid linked to this World, unless you have changed the group name via the 
        /// <see cref="ChangeGroupName" href="#ChangeGroupName">ChangeGroupName</see> method.
        /// </summary>
        /// <type>string</type>
        public string GroupName { get; private set; }

        /// <summary>
        /// Gets a value indicating whether the world is idle (Update cycle not running).
        /// </summary>
        /// <type>bool</type>
        public bool IsIdle { get; private set; }

        /// <summary>
        /// Gets a value indicating whether the World has been initialized yet.
        /// </summary>
        /// <type>bool</type>
        public bool IsInitialized { get { return WorldState != WorldState.Uninitialized; } }

        /// <summary>
        /// Gets a value indicating whether the World is persistent between game sessions.
        /// </summary>
        /// <type>bool</type>
        public bool IsWorldPersistent { get { return persistent; } }

        /// <summary>
        /// Gets a value indicated whether a World Shift is currently in progress.
        /// </summary>
        /// <type>bool</type>
        public bool IsOriginCellUpdateInProgress { get; private set; }

        /// <summary>
        /// Gets the unique ID of the World.
        /// </summary>
        /// <type>int</type>
        public int ID { get { return worldID; } }

        /// <summary>
        /// Gets a value indicating whether the World is three dimensional.
        /// </summary>
        /// <type>bool</type>
        public bool IsWorld3D { get { return worldGrid.worldType == WorldType.Three_Dimensional; } }

        /// <summary>
        /// Gets a value indicating whether the World is set to stay centered about the origin.
        /// </summary>
        /// <type>bool</type>
        public bool IsWorldOriginCentered { get { return keepWorldCenteredAroundOrigin; } }

        /// <summary>
        /// Gets the Naming Convention used by this World.
        /// </summary>
        /// <type link = "INamingConvention.html">INamingConvention</type>
        public INamingConvention NamingConvention { get; private set; }

        /// <summary>
        /// The current origin cell of the world. If using a world that doesn't stay centered around the origin,
        /// this should always be row = 1, column = 1, and layer = 1. The layer will also always be 1 if using a 2D world.
        /// </summary>
        /// <type link="Cell.html">Cell</type>
        public Cell OriginCell { get { return new Cell(oneBasedOriginCellRow, oneBasedOriginCellColumn, oneBasedOriginCellLayer); } }

        /// <summary>
        /// Gets the position of the origin cell, which is always equal to the world origin.
        /// </summary>
        /// <type>Vector3</type>
        public Vector3 OriginCellPosition
        {
            get { return worldOrigin; }
        }

        /// <summary>
        /// The position of the origin cell column. Will always be the x value of the world origin.
        /// </summary>
        /// <type>float</type>
        public float OriginColumnPosition { get { return worldOrigin.x; } }

        /// <summary>
        /// The position of the origin cell layer. For 3D worlds, will be the y value of the world origin. For 2D worlds, will be 0.
        /// <para>Not valid until after ManagedAwake has been called.</para>
        /// </summary>
        /// <type>float</type>
        public float OriginLayerPosition { get; private set; }

        /// <summary>
        /// The position of the origin cell row.
        /// <para>Not valid until after ManagedAwake has been called.</para>
        /// </summary>
        /// <type>float</type>
        public float OriginRowPosition { get; private set; }

        /// <summary>
        /// Gets the Persistent Data Save Key for this World. This is only valid if 
        /// "Use Custom Save/Load Solution" is not checked on your Component Manager.
        /// </summary>
        /// <type>string</type>
        public string PersistentDataSaveKey { get; internal set; }

        /// <summary>
        /// Returns the Prototype this runtime created World was constructed from. If the world is an inspector 
        /// created World rather than a Runtime created one, this will return 0.
        /// </summary>
        /// <type>bool</type>
        public int PrototypeConstructedFrom { get; internal set; }

        /// <summary>
        /// Gets a value that can be added to a static position to convert it to a dynamic position based on the 
        /// current origin cell and position of this world. This is most useful for multiplayer games.
        /// </summary>
        /// <type>Vector3</type>
        public Vector3 StaticToDynamicPositionAddition { get { return -currentOffset; } }

        /// <summary>
        /// Gets the World Grid associated with the World.
        /// </summary>
        /// <type link = "WorldGridBase.html">WorldGridBase</type>
        public WorldGridBase WorldGrid { get { return worldGrid; } }

        /// <summary>
        /// Gets the origin of the World. Will not be valid until after 
        /// the world has been initialized.
        /// <para>If you are trying to access the position of the origin layer, origin row, or origin column, 
        /// use the corresponding properties, as they will automatically take into account the World Type.</para>
        /// </summary>
        /// <type>Vector3</type>
        public Vector3 WorldOrigin { get { return worldOrigin; } }
        
        /// <summary>
        /// Gets the current WorldState of the World.
        /// </summary>
        /// <type link="WorldState.html">WorldState</type>
        public WorldState WorldState { get; private set; }

        /// <summary>
        /// Gets the World associated with the Cell Object Group implementating object.
        /// <para>Explicit Interface Implementation for 
        /// <see cref="ICellObjectGroup" href="ICellObjectGroup.html">ICellObjectGroup</see>
        /// </para>
        /// </summary>
        /// <type link="World.html">World</type>
        /// <displayName>ICellObjectGroup.World</displayName>
        World ICellObjectGroup.World {get{return this;}}

        #endregion

        #region Private Variables

        enum CellOriginUpdateType { None, WorldShift, ExplicitUpdate }
        CellOriginUpdateType cellOriginUpdateType;

        bool checkedUsersForPreparednessAtLeastOnce, update = false, 
            ignoreGroupNameInPersistentData, ignoreWorldOriginInPersistentData, ignoreOriginCellInPersistentData, persistentDataSet;

        Cell newEndlessGridZeroBasedOriginCell;
        ComponentManager componentManager;
        Dictionary<Cell, int> addRequestBuffer, removeRequestBuffer;
        Func<Cell, bool> IsCellEmpty;
        InBoundsChecker inBoundsChecker;
        List<ActiveGrid> usersPreparedForOriginCellChange, usersUnpreparedForOriginCellChange;
        PositionGetter positionGetter;
        PositionSetter positionSetter;
        Queue<Cell> cellsToRemoveUsersFrom, cellsToAddUsersTo;
        RegistrationHandler<IWorldUser> users;
        WorldShifter worldShifter;
        YieldInstruction waitForSeconds;

        //how much the world is offset from its default position.
        Vector3 currentOffset;
        Transform transformToUseToCalculateShift;

        internal int DesiredZeroBasedOriginCellRow { get; private set; }
        internal int DesiredZeroBasedOriginCellColumn { get; private set; }
        internal int DesiredZeroBasedOriginCellLayer { get; private set; }

        internal int ZeroBasedOriginCellRow { get { return oneBasedOriginCellRow - 1; } }
        internal int ZeroBasedOriginCellColumn { get { return oneBasedOriginCellColumn - 1; } }
        internal int ZeroBasedOriginCellLayer { get { return oneBasedOriginCellLayer - 1; } }

        Cell endlessGridCellShift;

        #endregion

        #region Internal Variables/Properties
        internal bool allowShifting = true, runtimeCreated = false, persistent = true;
        internal CellController cellController;
        internal Boundary WorldShiftBoundary { get; private set; }
        internal Action<Transform> MethodToCallWhenWorldShiftBoundaryCrossed { get; private set; }
        #endregion

        #region Initialization

        internal void Initialize(ComponentManager componentManager = null)
        {
            if (componentManager != null)
                this.componentManager = componentManager;

            //Ensures this method will only run once
            if (IsInitialized)
                return;

            if (worldGrid == null)
                throw new RequiredComponentNotFoundException("A World Grid is missing from the World with ID " + worldID + ".");

            if (primaryCellObjectSubController == null)
                throw new RequiredComponentNotFoundException("A Primary Cell Object Sub Controller is missing from the World with ID " + worldID + ".");

            if(primaryCellObjectSubController.cellObjectLoader == null)
                throw new RequiredComponentNotFoundException("A Cell Object Loader is missing from the Primary Cell Object Sub Controller attached to the World with ID " + worldID + ".");

            WorldState = WorldState.Idle;

            worldGrid.Initialize();
            IsCellEmpty = worldGrid.GetIsWorldGridCellEmptyFunction_ZeroBased();

            if (GroupName == null)
                GroupName = worldGrid.gridName;

            if (previewCellObjects != null && destroyObjectsOnPlay && previewCellObjects.Count > 0)
                RemovePreviewObjects();


            SetNamingConvention();
            cellController = CreateCellObjectMasterController();

            if (useThisGameObjectsPositionAsWorldOrigin)
                worldOrigin = gameObject.transform.position;

            EnsureOriginCellIsWithinBounds();
            SetCellOriginPositions();

            MethodToCallWhenWorldShiftBoundaryCrossed = WorldShiftBoundaryCrossed;
            SetupWorldShiftBoundary();

            CreateWorldGridDependentHelperObjects();

            waitForSeconds = loadCushion > 0f ? new WaitForSeconds(loadCushion) : null;

            CreateQueuesAndBuffers();
        }

        internal void RemovePreviewObjects()
        {
            for (int i = previewCellObjects.Count - 1; i >= 0; i--)
            {
                GameObject obj = previewCellObjects[i];
                previewCellObjects.RemoveAt(i);

                if (obj != null)
                    UnityEngine.Object.Destroy(obj);
            }

            previewCellObjects = null;
        }

        void EnsureOriginCellIsWithinBounds()
        {
            oneBasedOriginCellRow = worldGrid.ConvertEndlessGridRowToWorldGridRow(oneBasedOriginCellRow);
            oneBasedOriginCellColumn = worldGrid.ConvertEndlessGridColumnToWorldGridColumn(oneBasedOriginCellColumn);

            if (IsWorld3D)
                oneBasedOriginCellLayer = worldGrid.ConvertEndlessGridLayerToWorldGridLayer(oneBasedOriginCellLayer);
            else
                oneBasedOriginCellLayer = 1;
        }

        void SetCellOriginPositions()
        {
            if (worldGrid.WorldType == WorldType.Two_Dimensional_On_XY_Axes)
            {
                OriginRowPosition = worldOrigin.y;
                OriginLayerPosition = worldOrigin.z;
            }
            else
            {
                OriginRowPosition = worldOrigin.z;
                OriginLayerPosition = worldOrigin.y;
            }
        }

        void SetupWorldShiftBoundary()
        {
            if (keepWorldCenteredAroundOrigin)
            {
                WorldShiftBoundary = new Boundary(worldGrid.WorldType, worldOrigin, distanceOfEastAndWestShiftBoundaryFromOrigin,
                    distanceOfNorthAndSouthShiftBoundaryFromOrigin, distanceOfTopAndBottomShiftBoundaryFromOrigin);
            }
            else
                WorldShiftBoundary = null;
        }

        void CreateWorldGridDependentHelperObjects()
        {
            if (worldGrid.WorldType == WorldType.Two_Dimensional_On_XZ_Axes)
            {
                worldShifter = new WorldShifter2DXZ(this);
                positionGetter = new PositionGetter2DXZ();
                positionSetter = new PositionSetter2DXZ();
            }
            else if (worldGrid.WorldType == WorldType.Two_Dimensional_On_XY_Axes)
            {
                worldShifter = new WorldShifter2DXY(this);
                positionGetter = new PositionGetter2DXY();
                positionSetter = new PositionSetter2DXY();
            }
            else
            {
                worldShifter = new WorldShifter3D(this);
                positionGetter = new PositionGetter3D();
                positionSetter = new PositionSetter3D();
            }
            CreateInBoundsChecker();
        }

        void CreateInBoundsChecker()
        {
            if (worldGrid.worldType == WorldType.Three_Dimensional)
                inBoundsChecker = new ThreeDimensionalInBoundsChecker(worldGrid.layers, areLayersEndless, worldGrid.rows, areRowsEndless, worldGrid.columns, areColumnsEndless);
            else
                inBoundsChecker = new TwoDimensionalInBoundsChecker(worldGrid.rows, areRowsEndless, worldGrid.columns, areColumnsEndless);
        }

        void CreateQueuesAndBuffers()
        {
            cellsToRemoveUsersFrom = new Queue<Cell>(16);
            cellsToAddUsersTo = new Queue<Cell>(16);
            usersPreparedForOriginCellChange = new List<ActiveGrid>(4);
            usersUnpreparedForOriginCellChange = new List<ActiveGrid>(4);
            users = new RegistrationHandler<IWorldUser>();

            EqualityComparer<Cell> equalityComparer = worldGrid.worldType == WorldType.Three_Dimensional ? 
                (EqualityComparer<Cell>)new ThreeDimensionalCellComparer() : (EqualityComparer<Cell>)new TwoDimensionalCellComparer();

            addRequestBuffer = new Dictionary<Cell, int>(16, equalityComparer);
            removeRequestBuffer = new Dictionary<Cell, int>(16, equalityComparer);
        }

        void SetNamingConvention()
        {
            NamingConvention = worldGrid.namingConvention.GetCorrectNamingConvention(worldGrid.WorldType == WorldType.Three_Dimensional);
        }

        CellController CreateCellObjectMasterController()
        {
            if (worldGrid.cellObjectType == CellObjectType.Unity_Terrain)
                return new TerrainOrientedCellController(this);
            else
                return new CellController(this);
        }
        
        #endregion

        #region State Saving/Loading

        internal void SetStateFromSaveData(string saveData)
        {
            string[] data = saveData.Split('/');

            if(!ignoreOriginCellInPersistentData)
            {
                oneBasedOriginCellRow = int.Parse(data[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + 1;
                oneBasedOriginCellColumn = int.Parse(data[1], System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + 1;
                oneBasedOriginCellLayer = worldGrid.WorldType == WorldType.Three_Dimensional ? int.Parse(data[2], System.Globalization.CultureInfo.InvariantCulture.NumberFormat) + 1 : 1;
            }
            
            if(!ignoreGroupNameInPersistentData)
                GroupName = data[3];

            if (!ignoreWorldOriginInPersistentData && data.Length == 7)
            {
                useThisGameObjectsPositionAsWorldOrigin = false;
                worldOrigin = new Vector3(float.Parse(data[4], System.Globalization.CultureInfo.InvariantCulture.NumberFormat), float.Parse(data[5], System.Globalization.CultureInfo.InvariantCulture.NumberFormat), float.Parse(data[6], System.Globalization.CultureInfo.InvariantCulture.NumberFormat));
            }

            persistentDataSet = true;
        }

        /// <summary>
        /// Gets persistent save data for the World in the form of a string. This can be used when creating a new 
        /// World via the Component Manager's CreatePersistentWorld or CreateNonPersistentWorld methods.
        /// </summary>
        /// <param name="stringBuilder" type="StringBuilder">A string builder object that will be used to create the string save data.</param>
        /// <returns type="string">The string save data.</returns>
        /// <displayName id="GetPersistentStringSaveData1">GetPersistentStringSaveData(StringBuilder)</displayName>
        /// <syntax>public string GetPersistentStringSaveData(StringBuilder stringBuilder)</syntax>
        public string GetPersistentStringSaveData(StringBuilder stringBuilder)
        {
            if (stringBuilder == null)
                stringBuilder = new StringBuilder();
            else if (stringBuilder.Length > 0)
                stringBuilder.Length = 0;

            AppendPersistentDataToStringBuilder(stringBuilder);

            return stringBuilder.ToString();
        }

        internal void AppendPersistentDataToStringBuilder(StringBuilder stringBuilder)
        {
            stringBuilder.Append(oneBasedOriginCellRow - 1);
            stringBuilder.Append('/');
            stringBuilder.Append(oneBasedOriginCellColumn - 1);
            stringBuilder.Append('/');
            stringBuilder.Append(oneBasedOriginCellLayer - 1);
            stringBuilder.Append('/');
            stringBuilder.Append(GroupName);
            stringBuilder.Append('/');
            stringBuilder.Append(worldOrigin.x);
            stringBuilder.Append('/');
            stringBuilder.Append(worldOrigin.y);
            stringBuilder.Append('/');
            stringBuilder.Append(worldOrigin.z);
        }

        /// <summary>
        /// Gets persistent save data for the World in the form of a string. This can be used when creating a new 
        /// World via the Component Manager's CreatePersistentWorld or CreateNonPersistentWorld methods.
        /// </summary>
        /// <returns type="string">The string save data.</returns>
        /// <displayName id="GetPersistentStringSaveData2">GetPersistentStringSaveData()</displayName>
        /// <syntax>public string GetPersistentStringSaveData()</syntax>
        public string GetPersistentStringSaveData()
        {
            return (oneBasedOriginCellRow - 1) + "/" + (oneBasedOriginCellColumn - 1) + "/" + (oneBasedOriginCellLayer - 1) + "/" + GroupName + "/" +
                worldOrigin.x + "/" + worldOrigin.y + "/" + worldOrigin.z;
        }

        #endregion

        #region Running/Updating the World

        /// <summary>
        /// Updates the Load Cushion used by the World.
        /// <para>
        /// The load cushion is the amount of time the World will wait after it receives cell add/remove request or a 
        /// world shift order before proceeding with a World Update or Shift. Increasing 
        /// the load cushion time gives your player time cross additional boundaries before the world is updated.
        /// This can reduce some loading/unloading that occurs as the result of a very fast moving player 
        /// or small terrain/object sizes.
        /// </para>
        /// </summary>
        /// <param name="newLoadCushion" type="float">The new load cushion, in seconds.</param>
        /// <displayName id="UpdateLoadCushion">UpdateLoadCushion(float)</displayName>
        /// <syntax>public void UpdateLoadCushion(float newLoadCushion)</syntax>
        public void UpdateLoadCushion(float newLoadCushion)
        {
            waitForSeconds = newLoadCushion > 0f ? new WaitForSeconds(newLoadCushion) : null;
        }

        internal void AwakeFromIdle()
        {
            //If world is not idle or not active, do not wake
            if (WorldState != DynamicLoadingKit.WorldState.Idle || !gameObject.activeInHierarchy)
                return;

            StartCoroutine(UpdateLoop());
        }

        IEnumerator<YieldInstruction> UpdateLoop()
        {
            WorldState = WorldState.WaitingForRequest;
            update = true;

            while(true)
            {
                if (update)
                {
                    if (cellsToAddUsersTo.Count != 0 || cellsToRemoveUsersFrom.Count != 0 || cellOriginUpdateType != CellOriginUpdateType.None)
                    {
                        WorldState = WorldState.ProcessingRequest;

#if DEBUG_ON
                        Debug.Log(string.Format("Frame " + Time.frameCount + ": Need for World Update Detected:\nNumber of cells to add users to = {0}\nNumber of cells to remove users from = {1}\nCell Origin Update Type = {2}", cellsToAddUsersTo.Count, cellsToRemoveUsersFrom.Count, cellOriginUpdateType));
#endif

                    ProcessAddRequest:

                        while (cellsToAddUsersTo.Count > 0)
                            ProcessAddRequest(cellsToAddUsersTo.Dequeue());

                        yield return null;

                    ProcessRemoveRequest:

                        while (cellsToRemoveUsersFrom.Count > 0)
                            ProcessRemoveRequest(cellsToRemoveUsersFrom.Dequeue());

                        if (waitForSeconds != null)
                        {
                            //This way we can change the time to wait even while the world is yielding the wait time.
                            YieldInstruction wait = waitForSeconds;
                            yield return wait;
                        }
                        else
                            yield return null;

                        //Check if any more request exists
                        if (cellsToAddUsersTo.Count > 0)
                            goto ProcessAddRequest;
                        else if (cellsToRemoveUsersFrom.Count > 0)
                            goto ProcessRemoveRequest;

#if DEBUG_ON

                        if (cellsToAddUsersTo.Count > 0)
                        {
                            string o = "Frame " + Time.frameCount + ": After processing request, the World has determined that the following cells (Indexing is 1 based) need users added.\n";
                            foreach (Cell cell in cellsToAddUsersTo)
                            {
                                o += string.Format("Row {0} | Column {1}\n", cell.row + 1, cell.column + 1);
                            }
                            Debug.Log(o);
                        }

                        if (cellsToRemoveUsersFrom.Count > 0)
                        {
                            string o = "Frame " + Time.frameCount + ": After processing request, the World has determined that the following cells (Indexing is 1 based) need users removed.\n";
                            foreach (Cell cell in cellsToRemoveUsersFrom)
                            {
                                o += string.Format("Row {0} | Column {1}\n", cell.row + 1, cell.column + 1);
                            }
                            Debug.Log(o);
                        }
#endif

                        bool updateCellOrigin = false;

                        CellOriginUpdateType updateType = cellOriginUpdateType;
                        if (updateType != CellOriginUpdateType.None)
                        {
                            CheckForPreparedness(updateType);

                            //only shift the world if all users are prepared for it.
                            updateCellOrigin = usersUnpreparedForOriginCellChange.Count == 0;
                        }

                        IEnumerator<YieldInstruction> updateWorldEnumerator = null;
                        Vector3 shiftAmount = Vector3.zero;

                        if (updateCellOrigin)
                        {
                            //Calculate new origin cell and other stuff
                            if (updateType == CellOriginUpdateType.WorldShift)
                            {
                                WorldState = WorldState.UpdatingWorldWithShift;
                                BoundaryCrossed eastOrWest, northOrSouth, topOrBottom;

                                WorldShiftBoundary.WereBoundariesCrossed(transformToUseToCalculateShift.position, out eastOrWest, out northOrSouth, out topOrBottom);

                                worldShifter.ShiftOriginCell(transformToUseToCalculateShift.position, eastOrWest,
                                            northOrSouth, topOrBottom, out shiftAmount);

                                transformToUseToCalculateShift = null;
                            }
                            else
                            {
                                WorldState = WorldState.UpdatingWorldWithExplicitOriginCellUpdate;
                                UpdateOriginCell_Internal(newEndlessGridZeroBasedOriginCell);
                            }
                            
                            cellOriginUpdateType = CellOriginUpdateType.None;
                            checkedUsersForPreparednessAtLeastOnce = false;
                            IsOriginCellUpdateInProgress = true;

                            if (updateType == CellOriginUpdateType.WorldShift)
                            {
                                foreach (ActiveGrid activeGrid in usersPreparedForOriginCellChange)
                                    activeGrid.WorldShiftCommencing(shiftAmount);

                                updateWorldEnumerator = cellController.CreateNewShiftedWorld_ZeroBased(shiftAmount, addRequestBuffer, removeRequestBuffer, endlessGridCellShift);
                            }
                            else
                                updateWorldEnumerator = cellController.AddAndRemoveCellUsersAndResetPositionOfWorld_ZeroBased(addRequestBuffer, removeRequestBuffer);
                        }
                        else//otherwise execute a normal update world, we'll try to shift the world next time around.
                        {
                            if (addRequestBuffer.Count > 0 && removeRequestBuffer.Count > 0)
                                updateWorldEnumerator = cellController.AddAndRemoveCellUsers_ZeroBased(addRequestBuffer, removeRequestBuffer);
                            else if (addRequestBuffer.Count > 0)
                                updateWorldEnumerator = cellController.AddCellUsers_ZeroBased(addRequestBuffer);
                            else if (removeRequestBuffer.Count > 0)
                                updateWorldEnumerator = cellController.RemoveCellUsers_ZeroBased(removeRequestBuffer);

                            WorldState = WorldState.UpdatingWorldWithoutShift;
                        }

                        if (updateWorldEnumerator != null)
                        {
                            while (updateWorldEnumerator.MoveNext())
                                yield return updateWorldEnumerator.Current;

                            addRequestBuffer.Clear();
                            removeRequestBuffer.Clear();
                        }

                        if (updateCellOrigin)
                        {
                            //Note we're commiting the origin cell changes here.
                            //From this point foward if the World's data is saved it will be saved with the new origin cell.
                            //Also, any other script that access the StaticToDynamicPositionAddition and DynamicToStaticPositionAddition 
                            //properties will get a value reflective of the origin cell change.
                            CommitOriginCellChange();
                            if (updateType == CellOriginUpdateType.WorldShift)
                            {
                                WorldState = WorldState.CompletingWorldShift;
                                foreach (IWorldUser user in users.RegistrantEntries())
                                    user.OnWorldShifted(shiftAmount, OriginCell, endlessGridCellShift);
       
                                if(performShiftActivationInSingleFrame)
                                {
                                    foreach (ActiveGrid activeGrid in usersPreparedForOriginCellChange)
                                    {
                                        IEnumerator<YieldInstruction>  e = activeGrid.WorldShiftComplete(endlessGridCellShift);
                                        while (e.MoveNext())
                                            continue;
                                    }
                                    usersPreparedForOriginCellChange.Clear();
                                }
                                else
                                {
                                    foreach (ActiveGrid activeGrid in usersPreparedForOriginCellChange)
                                    {
                                        IEnumerator<YieldInstruction> e = activeGrid.WorldShiftComplete(endlessGridCellShift);
                                        while (e.MoveNext())
                                            yield return e.Current;
                                    }
                                    usersPreparedForOriginCellChange.Clear();

                                    IEnumerator<YieldInstruction> removePreShiftWorldEnumerator = cellController.RemovePreShiftWorld();
                                    while (removePreShiftWorldEnumerator.MoveNext())
                                        yield return removePreShiftWorldEnumerator.Current;
                                }                                
                            }
                            else
                            {
                                foreach (IWorldUser user in users.RegistrantEntries())
                                    user.OnOriginCellChanged(OriginCell);

                                usersPreparedForOriginCellChange.Clear();
                            }

                            IsOriginCellUpdateInProgress = false;                            
                        }

                        WorldState = WorldState.WaitingForRequest;
                    }
                    else if(!users.RegistrantsExists)
                    {
                        WorldState = WorldState.Idle;
                        yield break;
                    }
                }
                yield return null;
            }            
        }

        void ProcessAddRequest(Cell cellToAddUsersTo)
        {
            //the cell is zero based
            if (!inBoundsChecker.IsCellInBounds(cellToAddUsersTo))
                return;

            if (IsCellEmpty(ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(cellToAddUsersTo)))
                return;

            if (removeRequestBuffer.ContainsKey(cellToAddUsersTo))
            {
                int numOfRequest = removeRequestBuffer[cellToAddUsersTo];
                if (numOfRequest == 1)
                    removeRequestBuffer.Remove(cellToAddUsersTo);
                else
                    removeRequestBuffer[cellToAddUsersTo] = numOfRequest - 1;
            }
            else if (addRequestBuffer.ContainsKey(cellToAddUsersTo))
                addRequestBuffer[cellToAddUsersTo] += 1;
            else
                addRequestBuffer.Add(cellToAddUsersTo, 1);
        }

        void ProcessRemoveRequest(Cell cellToRemoveUserFrom)
        {
            if (!inBoundsChecker.IsCellInBounds(cellToRemoveUserFrom))
                return;

            if (IsCellEmpty(ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(cellToRemoveUserFrom)))
                return;

            if (addRequestBuffer.ContainsKey(cellToRemoveUserFrom))
            {
                int numOfRequest = addRequestBuffer[cellToRemoveUserFrom];
                if (numOfRequest == 1)
                    addRequestBuffer.Remove(cellToRemoveUserFrom);
                else
                    addRequestBuffer[cellToRemoveUserFrom] = numOfRequest - 1;
            }
            else if (removeRequestBuffer.ContainsKey(cellToRemoveUserFrom))
                removeRequestBuffer[cellToRemoveUserFrom] += 1;
            else
                removeRequestBuffer.Add(cellToRemoveUserFrom, 1);
        }

        void CheckForPreparedness(CellOriginUpdateType updateType)
        {
            if (!checkedUsersForPreparednessAtLeastOnce)
            {
                if (updateType == CellOriginUpdateType.WorldShift)
                    users.GetAllRegistrantsOfType<ActiveGrid>(usersUnpreparedForOriginCellChange);
                else
                    users.GetAllRegistrantsOfType<ActiveGrid>(usersPreparedForOriginCellChange);//no prep needed for cell origin update so just go ahead

                checkedUsersForPreparednessAtLeastOnce = true;
            }

            if (updateType == CellOriginUpdateType.WorldShift)
            {
                for (int i = usersUnpreparedForOriginCellChange.Count - 1; i >= 0; i--)
                {
                    ActiveGrid activeGrid = usersUnpreparedForOriginCellChange[i];

                    if (activeGrid.IsReadyForWorldShiftPreparation)
                    {
                        activeGrid.BlockOtherActionsUntilWorldShiftCompletes();
                        usersPreparedForOriginCellChange.Add(activeGrid);
                        usersUnpreparedForOriginCellChange.RemoveAt(i);
                    }
                }
            }
        }

        void WorldShiftBoundaryCrossed(Transform transformToUseToCalculateShift)
        {
            //If the world is already set to shift, ignore this call
            if (cellOriginUpdateType != CellOriginUpdateType.None)
                return;

            cellOriginUpdateType = CellOriginUpdateType.WorldShift;
            this.transformToUseToCalculateShift = transformToUseToCalculateShift;
            AwakeFromIdle();
        }

        //expects a zero based origin cell
        internal void UpdateOriginCell(Cell explicitEndlessGridZeroBasedOriginCell)
        {
            //shouldn't happen but we'll guard against it just in case
            if (cellOriginUpdateType != CellOriginUpdateType.None)
                return;

            cellOriginUpdateType = CellOriginUpdateType.ExplicitUpdate;
            newEndlessGridZeroBasedOriginCell = explicitEndlessGridZeroBasedOriginCell;
            AwakeFromIdle();
        }

        void UpdateOriginCell_Internal(Cell explicitEndlessGridZeroBasedOriginCell)
        {
            Cell worldGridZeroBasedOriginCell = ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(explicitEndlessGridZeroBasedOriginCell);
            endlessGridCellShift = worldGridZeroBasedOriginCell - explicitEndlessGridZeroBasedOriginCell;

            DesiredZeroBasedOriginCellRow = worldGridZeroBasedOriginCell.row;

            DesiredZeroBasedOriginCellColumn = worldGridZeroBasedOriginCell.column;

            if(IsWorld3D)
                DesiredZeroBasedOriginCellLayer = worldGridZeroBasedOriginCell.layer;
        }

        void CommitOriginCellChange()
        {
            oneBasedOriginCellLayer = DesiredZeroBasedOriginCellLayer + 1;
            oneBasedOriginCellColumn = DesiredZeroBasedOriginCellColumn + 1;
            oneBasedOriginCellRow = DesiredZeroBasedOriginCellRow + 1;

            //set the curret offset
            currentOffset = WorldGrid.GetDistanceFromOriginOfWorldGridCell_ZeroBased(new Cell(DesiredZeroBasedOriginCellRow, DesiredZeroBasedOriginCellColumn, DesiredZeroBasedOriginCellLayer));
        }

        #endregion

        #region Registration/DeRegistration

        /// <summary>
        /// Register an IOriginCenteredWorldUser user with the World. This is only necessary when the world is set to stay 
        /// centered around the origin, so that as the world shifts (to stay centered), users can be prepared pre-shift and notified 
        /// post shift (in order to adjust player/boundaries/etc.). Custom users can be setup, though some guidelines must be followed. 
        /// See the <see cref="IWorldUser" href="IWorldUser.html">IWorldUser</see> page for more information.
        /// </summary>
        /// <param name="user" type="IWorldUser" link="IWorldUser.html">The user to register.</param>
        /// <param name="registrationID" type="out int">The ID assigned to the user upon registration. You must pass in this ID when de-registering.</param>
        /// <displayName id="Register">Register(IOriginCenteredWorldUser, out int)</displayName>
        /// <syntax>public void Register(IOriginCenteredWorldUser user, out int registrationID)</syntax>
        public void Register(IWorldUser user, out int registrationID)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("Register call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            users.AddRegistrant(user, out registrationID);
            
            if (checkedUsersForPreparednessAtLeastOnce && user is ActiveGrid)
                usersUnpreparedForOriginCellChange.Add((ActiveGrid)user);
        }

        /// <summary>
        /// Deregister a user from the World. Note that if the user is currently "prepared" for a world shift, they will NOT receive 
        /// notification from the World once the shift is completed.
        /// </summary>
        /// <param name="registrationID">The ID of the user that should be de registered.</param>
        /// <displayName id="DeRegister">DeRegister(int)</displayName>
        /// <syntax>public void DeRegister(int registrationID)</syntax>
        public void DeRegister(int registrationID)
        {
            IWorldUser user = users[registrationID];
            users.RemoveRegistrant(registrationID);

            //If no users exist in unprepared user list or if the user is not found in that list
            //(if it is found, remove it)
            if (user is ActiveGrid)
            {
                ActiveGrid activeGridUser = (ActiveGrid)user;
                if (usersUnpreparedForOriginCellChange.Count == 0 || !usersUnpreparedForOriginCellChange.Remove(activeGridUser))
                {
                    //Check the prepared list for the user and remove it if found
                    if (usersPreparedForOriginCellChange.Count > 0 && WorldState < WorldState.CompletingWorldShift)
                        usersPreparedForOriginCellChange.Remove(activeGridUser);
                }
            }
        }

        internal bool ArePersistentActiveGridsRegistered()
        {
            foreach(IWorldUser user in users.RegistrantEntries())
            {
                if (user is ActiveGrid && ((ActiveGrid)user).IsActiveGridPersistent)
                    return true;
            }

            return false;
        }

        internal int GetNumberOfUsersRegistered()
        {
            return users.RegistrantsRegistered;
        }

        #endregion

        #region Adding/Removing Cell Users

        /// <summary>
        /// Adds cell users to the specified list of cells and then waits for the cell objects associated with those cells to be loaded into the scene.
        /// <para>Note that objects are not guaranteed to be loaded for a given cell. For instance, if another soruce sends in a remove cell user request for a cell 
        /// you've sent an add user request in for, the two requests will cancel out and the cell will not be activated (and thus the object will not be loaded).</para>
        /// </summary>
        /// <param name="cellsToAddUsersTo" type="IList&lt;Cell&gt;" link="Cell.html">The list of cells to add users to.</param>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="AddCellUsersAndWaitForCellObjectsToBeLoaded">AddCellUsersAndWaitForCellObjectsToBeLoaded(IList&lt;Cell&gt;)</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; AddCellUsersAndWaitForCellObjectsToBeLoaded(IList&lt;Cell&gt; cellsToAddUsersTo)</syntax>
        public IEnumerator<YieldInstruction> AddCellUsersAndWaitForCellObjectsToBeLoaded(IList<Cell> cellsToAddUsersTo)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("AddCellUsers_ZeroBasedAndWaitForCellObjectsToBeLoaded call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            AddCellUsers(cellsToAddUsersTo);

            if(WorldState == WorldState.Idle)
            {
                StartCoroutine(UpdateLoop());
                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
            else if (WorldState < WorldState.UpdatingWorldWithoutShift)
            {
                if (WorldState == WorldState.WaitingForRequest)
                    yield return null;

                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
            else //Some type of update is in progress
            {
                //If the world is currently updating or completing a world shift, yield until it's done.
                while (WorldState >= WorldState.UpdatingWorldWithoutShift && WorldState <= WorldState.CompletingWorldShift)
                    yield return null;

            WaitOneFrameAndCheckIfUpdating:

                // let a frame pass. After, update will either be true or false.
                //false indicates some other operation has halted the update process, so we yield until it's true.
                //true means our request was processed and we're on our way to getting the users/objects added/loaded.
                if (WorldState == WorldState.WaitingForRequest)
                    yield return null;

                //if update is false, yield until it is true
                if (!update)
                {
                    do { yield return null; } while (!update);
                    goto WaitOneFrameAndCheckIfUpdating;
                }

                //Process all request and update the world. 
                //After this, the cell objects for the cells we just added users to will definitely be loaded.
                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
        }

        internal IEnumerator<YieldInstruction> AddCellUsers_ZeroBasedAndWaitForCellObjectsToBeLoaded(IList<Cell> cellsToAddUsersTo)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("AddCellUsers_ZeroBasedAndWaitForCellObjectsToBeLoaded call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            AddCellUsers_ZeroBased(cellsToAddUsersTo);

            if (WorldState == WorldState.Idle)
            {
                StartCoroutine(UpdateLoop());
                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
            else if (WorldState < WorldState.UpdatingWorldWithoutShift)
            {
                if (WorldState == WorldState.WaitingForRequest)
                    yield return null;

                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
            else //Some type of update is in progress
            {
                //If the world is currently updating or completing a world shift, yield until it's done.
                while (WorldState >= WorldState.UpdatingWorldWithoutShift && WorldState <= WorldState.CompletingWorldShift)
                    yield return null;

            WaitOneFrameAndCheckIfUpdating:

                // let a frame pass. After, update will either be true or false.
                //false indicates some other operation has halted the update process, so we yield until it's true.
                //true means our request was processed and we're on our way to getting the users/objects added/loaded.
                if (WorldState == WorldState.WaitingForRequest)
                    yield return null;

                //if update is false, yield until it is true
                if (!update)
                {
                    do { yield return null; } while (!update);
                    goto WaitOneFrameAndCheckIfUpdating;
                }

                //Process all request and update the world. 
                //After this, the cell objects for the cells we just added users to will definitely be loaded.
                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
        }

        /// <summary>
        /// Remove cell users from the specified list of cells and then waits for the cell objects associated with those cells to be unloaded from the scene.
        /// <para>Note that objects are not guaranteed to be unloaded for a given cell. For instance, if another soruce sends in a add cell user request for a cell 
        /// you've sent a remove user request in for, the two requests will cancel out and the cell will remain active (and thus the objects will not be unloaded).</para>
        /// </summary>
        /// <param name="cellsToRemoveUsersFrom" type="IList&lt;Cell&gt;" link="Cell.html">The list of cells to remove users from.</param>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="RemoveCellUsersAndWaitForCellObjectsToBeUnloaded">RemoveCellUsersAndWaitForCellObjectsToBeUnloaded(IList&lt;Cell&gt;)</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; RemoveCellUsersAndWaitForCellObjectsToBeUnloaded(IList&lt;Cell&gt; cellsToRemoveUsersFrom)</syntax>
        public IEnumerator<YieldInstruction> RemoveCellUsersAndWaitForCellObjectsToBeUnloaded(IList<Cell> cellsToRemoveUsersFrom)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("RemoveCellUsers_ZeroBasedAndWaitForCellObjectsToBeUnloaded call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            AwakeFromIdle();
            RemoveCellUsers(cellsToRemoveUsersFrom);

            if (WorldState == WorldState.Idle)
            {
                StartCoroutine(UpdateLoop());
                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
            else if (WorldState < WorldState.UpdatingWorldWithoutShift)
            {
                if (WorldState == WorldState.WaitingForRequest)
                    yield return null;

                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
            else //Some type of update is in progress
            {
                //If the world is currently updating or completing a world shift, yield until it's done.
                while (WorldState >= WorldState.UpdatingWorldWithoutShift && WorldState <= WorldState.CompletingWorldShift)
                    yield return null;

            WaitOneFrameAndCheckIfUpdating:

                // let a frame pass. After, update will either be true or false.
                //false indicates some other operation has halted the update process, so we yield until it's true.
                //true means our request was processed and we're on our way to getting the users/objects added/loaded.
                if (WorldState == WorldState.WaitingForRequest)
                    yield return null;

                //if update is false, yield until it is true
                if (!update)
                {
                    do { yield return null; } while (!update);
                    goto WaitOneFrameAndCheckIfUpdating;
                }

                //Process all request and update the world. 
                //After this, the cell objects for the cells we just added users to will definitely be loaded.
                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
        }

        internal IEnumerator<YieldInstruction> RemoveCellUsers_ZeroBasedAndWaitForCellObjectsToBeUnloaded(IList<Cell> cellsToRemoveUsersFrom)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("RemoveCellUsers_ZeroBasedAndWaitForCellObjectsToBeUnloaded call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            AwakeFromIdle();
            RemoveCellUsers_ZeroBased(cellsToRemoveUsersFrom);

            if (WorldState == WorldState.Idle)
            {
                StartCoroutine(UpdateLoop());
                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
            else if (WorldState < WorldState.UpdatingWorldWithoutShift)
            {
                if (WorldState == WorldState.WaitingForRequest)
                    yield return null;

                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
            else //Some type of update is in progress
            {
                //If the world is currently updating or completing a world shift, yield until it's done.
                while (WorldState >= WorldState.UpdatingWorldWithoutShift && WorldState <= WorldState.CompletingWorldShift)
                    yield return null;

            WaitOneFrameAndCheckIfUpdating:

                // let a frame pass. After, update will either be true or false.
                //false indicates some other operation has halted the update process, so we yield until it's true.
                //true means our request was processed and we're on our way to getting the users/objects added/loaded.
                if (WorldState == WorldState.WaitingForRequest)
                    yield return null;

                //if update is false, yield until it is true
                if (!update)
                {
                    do { yield return null; } while (!update);
                    goto WaitOneFrameAndCheckIfUpdating;
                }

                //Process all request and update the world. 
                //After this, the cell objects for the cells we just added users to will definitely be loaded.
                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }
        }

        /// <summary>
        /// Removes all cell users from every cell on the world. This will effectively unload all the objects that make up your world.
        /// <para>Using the method manually is not recommended, as any Active Grids synced to this world that have objects loaded will not be notified that 
        /// the objects have been removed. This will result in those grids thinking the objects are loaded when they are in fact not. It is better to remove the objects via each 
        /// individual Active Grid.</para>
        /// </summary>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="RemoveAllCellUsersAndCellObjects">RemoveAllCellUsersAndCellObjects()</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; RemoveAllCellUsersAndCellObjects()</syntax>
        public IEnumerator<YieldInstruction> RemoveAllCellUsersAndCellObjects()
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("RemoveAllCellUsersAndCellObjects call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            if(WorldState == WorldState.Idle)
                update = false;
            else
            {
                //Waits for another operation that stopped the update loop to finish
                while (!update)
                    yield return null;

                update = false;

                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }

            addRequestBuffer.Clear();
            removeRequestBuffer.Clear();
            cellsToRemoveUsersFrom.Clear();
            cellsToAddUsersTo.Clear();

            //Update loop is effectively stopped at this point. We can now remove all the cell users and objects.
            //Note that Add Cell User request will be processed once this operation has completed
            //Remove Cell User request are ignored during this process, however.
            IEnumerator<YieldInstruction> removeAllEnumerator = cellController.RemoveAllCellUsersAndCellObjects();
            while (removeAllEnumerator.MoveNext())
                yield return removeAllEnumerator.Current;

            update = true;
        }


        
        /// <summary>
        /// Sends in a request to add users to the list of specified cells.
        /// </summary>
        /// <param name="cellsToAddUsersTo" type="IList&lt;Cell&gt;" link="Cell.html">The list of cells to add users to.</param>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="AddCellUsers">AddCellUsers(IList&lt;Cell&gt;)</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; AddCellUsers(IList&lt;Cell&gt; cellsToAddUsersTo)</syntax>
        public void AddCellUsers(IList<Cell> cellsToAddUsersTo)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("AddCellUsers call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

#if DEBUG_ON
            string users = "";
            foreach (Cell cell in cellsToAddUsersTo)
                users += string.Format("Row {0} | Column {1}\n", cell.row + 1, cell.column + 1);
            Debug.Log("Frame " + Time.frameCount + ": A non internal object has requested to add " + cellsToAddUsersTo.Count + " users:\n" + users);
#endif
            AwakeFromIdle();
            for (int i = 0; i < cellsToAddUsersTo.Count; i++)
                this.cellsToAddUsersTo.Enqueue(cellsToAddUsersTo[i].ConvertTo0Based(IsWorld3D));
        }

        internal void AddCellUsers_ZeroBased(IList<Cell> cellsToAddUsersTo)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("AddCellUsers call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            //Debug.Log("Adding these cells");
            //Debug.Log("------------------------------");
            //foreach (Cell cell in cellsToAddUsersTo)
            //    Debug.Log(cell.ToString());
            //Debug.Log("------------------------------");

#if DEBUG_ON
            string users = "";
            foreach (Cell cell in cellsToAddUsersTo)
                users += string.Format("Row {0} | Column {1}\n", cell.row + 1, cell.column + 1);
            Debug.Log("Frame " + Time.frameCount + ": An internal object has requested to add " + cellsToAddUsersTo.Count + " users:\n" + users);
#endif
            AwakeFromIdle();
            for (int i = 0; i < cellsToAddUsersTo.Count; i++)
                this.cellsToAddUsersTo.Enqueue(cellsToAddUsersTo[i]);
        }

        /// <summary>
        /// Sends in a request to remove users from the list of specified cells.
        /// </summary>
        /// <param name="cellsToRemoveUsersFrom" type="IList&lt;Cell&gt;" link="Cell.html">The list of cells to remove users from.</param>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="RemoveCellUsers">RemoveCellUsers(IList&lt;Cell&gt;)</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; RemoveCellUsers(IList&lt;Cell&gt; cellsToRemoveUsersFrom)</syntax>
        public void RemoveCellUsers(IList<Cell> cellsToRemoveUsersFrom)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("RemoveCellUsers_ZeroBased call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

#if DEBUG_ON
            string users = "";
            foreach (Cell cell in cellsToRemoveUsersFrom)
                users += string.Format("Row {0} | Column {1}\n", cell.row + 1, cell.column + 1);
            Debug.Log("Frame " + Time.frameCount + ": A non internal object has requested to remove " + cellsToRemoveUsersFrom.Count + " users:\n" + users);
#endif

            AwakeFromIdle();
            for (int i = 0; i < cellsToRemoveUsersFrom.Count; i++)
                this.cellsToRemoveUsersFrom.Enqueue(cellsToRemoveUsersFrom[i].ConvertTo0Based(IsWorld3D));
        }

        internal void RemoveCellUsers_ZeroBased(IList<Cell> cellsToRemoveUsersFrom)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("RemoveCellUsers_ZeroBased call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            //Debug.Log("Removing these cells");
            //Debug.Log("------------------------------");
            //foreach (Cell cell in cellsToRemoveUsersFrom)
            //    Debug.Log(cell.ToString());
            //Debug.Log("------------------------------");

#if DEBUG_ON
            string users = "";
            foreach (Cell cell in cellsToRemoveUsersFrom)
                users += string.Format("Row {0} | Column {1}\n", cell.row + 1, cell.column + 1);
            Debug.Log("Frame " + Time.frameCount + ": An internal object has requested to remove " + cellsToRemoveUsersFrom.Count + " users:\n" + users);
#endif

            AwakeFromIdle();
            for (int i = 0; i < cellsToRemoveUsersFrom.Count; i++)
                this.cellsToRemoveUsersFrom.Enqueue(cellsToRemoveUsersFrom[i]);
        }

        /// <summary>
        /// Adds users to the list of specified cells so the cells are activated and the objects associated with those 
        /// cells are loaded into the scene.
        /// <para>This is meant to be used to ensure objects are loaded before the first Update at the beginning of a scene, and 
        /// should only be called from the initial Awake phase at the start of a scene.</para>
        /// </summary>
        /// <param name="cellsToAddUsersTo" type="IList&lt;Cell&gt;" link="Cell.html">The list of cells to add users to.</param>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="AddCellUsersImmediately">AddCellUsersImmediately(IList&lt;Cell&gt;)</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; AddCellUsersImmediately(IList&lt;Cell&gt; cellsToAddUsersTo)</syntax>
        public void AddCellUsersImmediately(IList<Cell> cellsToAddUsersTo)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("AddCellUsersImmediately call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            if (WorldState > WorldState.Idle || componentManager.phase != ComponentManager.Phase.Asleep)
                AddCellUsers(cellsToAddUsersTo);
            else
            {
#if DEBUG_ON
                string users = "";
                foreach (Cell cell in cellsToAddUsersTo)
                    users += string.Format("Row {0} | Column {1}\n", cell.row + 1, cell.column + 1);
                Debug.Log("Frame " + Time.frameCount + ": A non internal object has requested to add " + cellsToAddUsersTo.Count + " users immediately:\n" + users);
#endif
                //Remove cells that are out of bounds or don't have cell objects
                Debug.Log("Adding Starting Cell Users");
                for (int i = cellsToAddUsersTo.Count - 1; i >= 0; i--)
                {
                    Cell zeroBasedCell = cellsToAddUsersTo[i].ConvertTo0Based(IsWorld3D);
                    if (!inBoundsChecker.IsCellInBounds(zeroBasedCell) || IsCellEmpty(ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(zeroBasedCell)))
                        cellsToAddUsersTo.RemoveAt(i);
                    else
                        cellsToAddUsersTo[i] = zeroBasedCell;
                }

                cellController.AddStartingCellUsers_ZeroBased(cellsToAddUsersTo);
                cellsToAddUsersTo.Clear();
            }
        }

        internal void AddCellUsersImmediately_ZeroBased(IList<Cell> cellsToAddUsersTo)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("AddCellUsersImmediately_ZeroBased call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            if (WorldState > WorldState.Idle || componentManager.phase != ComponentManager.Phase.Asleep)
            {
#if DEBUG_ON
                Debug.Log("Not adding cell users immediately");
                Debug.Log(WorldState);
                Debug.Log(componentManager.phase);
#endif
                AddCellUsers_ZeroBased(cellsToAddUsersTo);
                //Debug.Log("Not adding immediately");
                //Debug.Log(WorldState);
                //Debug.Log(componentManager.phase);
            }
            else
            {
#if DEBUG_ON
                Debug.Log("adding immediately");
                string users = "";
                foreach (Cell cell in cellsToAddUsersTo)
                    users += string.Format("Row {0} | Column {1}\n", cell.row + 1, cell.column + 1);
                Debug.Log("Frame " + Time.frameCount + ": An internal object has requested to add " + cellsToAddUsersTo.Count + " users immediately:\n" + users);
#endif
                //Debug.Log("Adding immediately");
                //Debug.Log(WorldState);
                //Debug.Log(componentManager.phase);
                //Remove cells that are out of bounds or don't have cell objects
                for (int i = cellsToAddUsersTo.Count - 1; i >= 0; i--)
                {
                    if (!inBoundsChecker.IsCellInBounds(cellsToAddUsersTo[i]) || IsCellEmpty(ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(cellsToAddUsersTo[i])))
                        cellsToAddUsersTo.RemoveAt(i);
                }

                cellController.AddStartingCellUsers_ZeroBased(cellsToAddUsersTo);
                cellsToAddUsersTo.Clear();
            }
        }

        #endregion
        
        #region Useful Public Methods

        /// <summary>
        /// Get the cell dimensions of cell on the World Grid. The indexes of this cell must fall within the range 
        /// of rows, columns, and/or layers of your World Grid.
        /// <para> For instance, in a 4 rows x 4 columns World Grid, a row or column index of
        /// 0 or 5 would not be valid (but 1, 2, 3, or 4 would be).
        /// </para>
        /// </summary>
        /// <param name="worldGridCell" type="Cell" link="Cell.html">The cell on the World Grid whose dimensions should be retrieved.</param>
        /// <returns type="CellDimensions" link="CellDimensions.html">The cell dimensions of the cell.</returns>
        /// <displayName id="GetDimensionsOfWorldGridCell">GetDimensionsOfWorldGridCell(Cell)</displayName>
        /// <syntax>public CellDimensions GetDimensionsOfWorldGridCell(Cell worldGridCell)</syntax>
        public CellDimensions GetDimensionsOfWorldGridCell(Cell worldGridCell)
        {
            return GetDimensionsOfWorldGridCell_ZeroBased(worldGridCell.ConvertTo0Based(IsWorld3D));
        }

        internal CellDimensions GetDimensionsOfWorldGridCell_ZeroBased(Cell worldGridCell)
        {
            float layerHeight = worldGrid.GetHeightOfWorldGridLayer_ZeroBased(worldGridCell.layer);
            float rowLength = worldGrid.GetLengthOfWorldGridRow_ZeroBased(worldGridCell.row);
            float columnWidth = worldGrid.GetWidthOfWorldGridColumn_ZeroBased(worldGridCell.column);
            return new CellDimensions(layerHeight, rowLength, columnWidth);
        }

        /// <summary>
        /// Get the cell dimensions of an endless grid cell (can be any value)
        /// </summary>
        /// <param name="endlessGridCell" type="Cell" link="Cell.html">The endless grid cell whose dimensions should be retrieved.</param>
        /// <returns type="CellDimensions" link="CellDimensions.html">The cell dimensions of the cell.</returns>
        /// <displayName id="GetDimensionsOfEndlessGridCell">GetDimensionsOfEndlessGridCell(Cell)</displayName>
        /// <syntax>public CellDimensions GetDimensionsOfEndlessGridCell(Cell endlessGridCell)</syntax>
        public CellDimensions GetDimensionsOfEndlessGridCell(Cell endlessGridCell)
        {
            return GetDimensionsOfEndlessGridCell_ZeroBased(endlessGridCell.ConvertTo0Based(IsWorld3D));
        }

        internal CellDimensions GetDimensionsOfEndlessGridCell_ZeroBased(Cell endlessGridCell)
        {
            WorldCell worldCellOfEndlessGridCell;
            if (cellController.TryGetWorldCellOfEndlessGridCell(endlessGridCell, out worldCellOfEndlessGridCell))
                return worldCellOfEndlessGridCell.dimensions;
            else
            {
                Cell equivalentCellOnWorldGrid = ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(endlessGridCell);
                return GetDimensionsOfWorldGridCell_ZeroBased(equivalentCellOnWorldGrid);
            }
        }

        /// <summary>
        /// Retrieves the position of an endless grid cell. Unlike world grid cells, the indexes of this cell can be any value.
        /// </summary>
        /// <param name="endlessGridCell" type="Cell" link="Cell.html">The cell whose position should be retrieved.</param>
        /// <returns>The position of the cell.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="GetPositionOfEndlessGridCell">GetPositionOfEndlessGridCell(Cell)</displayName>
        /// <syntax>public Vector3 GetPositionOfEndlessGridCell(Cell endlessGridCell)</syntax>
        public Vector3 GetPositionOfEndlessGridCell(Cell endlessGridCell)
        {
            return GetPositionOfEndlessGridCell_ZeroBased(endlessGridCell.ConvertTo0Based(IsWorld3D));
        }

        internal Vector3 GetPositionOfEndlessGridCell_ZeroBased(Cell endlessGridCell)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("GetPositionOfEndlessGridCell_ZeroBased call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            float rowPosition = worldGrid.GetPositionOfEndlessGridRow_ZeroBased(endlessGridCell.row, oneBasedOriginCellRow-1, OriginRowPosition);
            float columnPosition = worldGrid.GetPositionOfEndlessGridColumn_ZeroBased(endlessGridCell.column, oneBasedOriginCellColumn-1, OriginColumnPosition);
            float layerPosition = worldGrid.GetPositionOfEndlessGridLayer_ZeroBased(endlessGridCell.layer, oneBasedOriginCellLayer-1, OriginLayerPosition);

            return positionSetter.SetPosition(rowPosition, columnPosition, layerPosition);
        }

        /// <summary>
        /// Gets the position of an endless grid cell as if a specific origin cell is the origin cell of this world.
        /// </summary>
        /// <param name="endlessGridCell" type="Cell" link="Cell.html">
        /// The one based endless grid cell whose position will be returned.
        /// </param>
        /// <param name="theoreticalOriginCell" type="Cell" link="Cell.html">
        /// The theoretical origin cell to base the endless grid cells 
        /// position on.
        /// </param>
        /// <returns>The position of the endless grid cell.</returns>
        /// <displayName id="GetPositionOfEndlessGridCellUsingTheoreticalOriginCell">
        /// GetPositionOfEndlessGridCellUsingTheoreticalOriginCell(Cell, Cell)
        /// </displayName>
        /// <syntax>
        /// public Vector3 GetPositionOfEndlessGridCellUsingTheoreticalOriginCell(Cell endlessGridCell, Cell theoreticalOriginCell)
        /// </syntax>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        public Vector3 GetPositionOfEndlessGridCellUsingTheoreticalOriginCell(Cell endlessGridCell, Cell theoreticalOriginCell)
        {
            return GetPositionOfEndlessGridCellUsingTheoreticalOriginCell_ZeroBased(endlessGridCell.ConvertTo0Based(IsWorld3D), theoreticalOriginCell.ConvertTo0Based(IsWorld3D));
        }

        internal Vector3 GetPositionOfEndlessGridCellUsingTheoreticalOriginCell_ZeroBased(Cell endlessGridCell, Cell theoreticalOriginCell)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("GetPositionOfEndlessGridCellUsingDesiredOriginCell_ZeroBased call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            float rowPosition = worldGrid.GetPositionOfEndlessGridRow_ZeroBased(endlessGridCell.row, theoreticalOriginCell.Row, OriginRowPosition);
            float columnPosition = worldGrid.GetPositionOfEndlessGridColumn_ZeroBased(endlessGridCell.column, theoreticalOriginCell.Column, OriginColumnPosition);
            float layerPosition = worldGrid.GetPositionOfEndlessGridLayer_ZeroBased(endlessGridCell.layer, theoreticalOriginCell.Layer, OriginLayerPosition);

            return positionSetter.SetPosition(rowPosition, columnPosition, layerPosition);
        }

        /// <summary>
        /// Finds the endless grid cell that the input position would be in if the origin cell of this world 
        /// were equal to the theoretical origin cell provided.
        /// <para>
        /// This is useful if you're about to change the origin cell via the Active Grid's TryMakeCellOriginCell 
        /// method and need to calculate some data based on the new origin cell.
        /// </para>
        /// </summary>
        /// <param name="position">The position to use to find the endless grid cell.</param>
        /// <param name="theoreticalOriginCell">
        /// The theoretical origin cell to use to find the endlesss grid cell.</param>
        /// <returns type="Cell" link="Cell.html">
        /// The endless grid cell the position would be in if the theoretical origin cell was the 
        /// origin cell of this world.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="FindEndlessGridCellPositionIsInUsingTheoreticalOriginCell">
        /// FindEndlessGridCellPositionIsInUsingTheoreticalOriginCell(Vector3, Cell)
        /// </displayName>
        /// <syntax>
        /// public Cell FindEndlessGridCellPositionIsInUsingTheoreticalOriginCell(Vector3 position, Cell theoreticalOriginCell)
        /// </syntax>
        public Cell FindEndlessGridCellPositionIsInUsingTheoreticalOriginCell(Vector3 position, Cell theoreticalOriginCell)
        {
            return FindEndlessGridCellPositionIsInUsingTheoreticalOriginCell_ZeroBased(position, theoreticalOriginCell.ConvertTo0Based(IsWorld3D));
        }

        internal Cell FindEndlessGridCellPositionIsInUsingTheoreticalOriginCell_ZeroBased(Vector3 position, Cell theoreticalOriginCell/*endless grid cell*/)
        {
            float rowPosition, layerPosition;
            positionGetter.GetRowAndLayerPosition(position, out rowPosition, out layerPosition);

            Cell worldGridOriginCell_theoretical = ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(theoreticalOriginCell);

            int row = worldGrid.FindEndlessGridRowPointIsIn_ZeroBased(rowPosition, worldGridOriginCell_theoretical.Row, OriginRowPosition);
            int column = worldGrid.FindEndlessGridColumnPointIsIn_ZeroBased(position.x, worldGridOriginCell_theoretical.Column, OriginColumnPosition);
            int layer = worldGrid.FindEndlessGridLayerPointIsIn_ZeroBased(layerPosition, worldGridOriginCell_theoretical.Layer, OriginLayerPosition);

            return new Cell(row, column, layer);
        }

        /// <summary>
        /// Finds the endless grid cell that the specified position falls within.
        /// <para>
        /// Note that the returned cell is 1 based.
        /// </para>
        /// </summary>
        /// <param name="position" type="Vector3">The position in world space.</param>
        /// <returns type="Cell" link="Cell.html">The endless grid cell the position falls within.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="FindEndlessGridCellPositionIsIn1">FindEndlessGridCellPositionIsIn(Vector3)</displayName>
        /// <syntax>public Cell FindEndlessGridCellPositionIsIn(Vector3 position)</syntax>
        public Cell FindEndlessGridCellPositionIsIn(Vector3 position)
        {
            return FindEndlessGridCellPositionIsIn_ZeroBased(position).ConvertTo1Based(IsWorld3D);
        }

        internal Cell FindEndlessGridCellPositionIsIn_ZeroBased(Vector3 position)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("FindEndlessGridCellPositionIsIn_ZeroBased call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            float rowPosition, layerPosition;
            positionGetter.GetRowAndLayerPosition(position, out rowPosition, out layerPosition);

            int row = worldGrid.FindEndlessGridRowPointIsIn_ZeroBased(rowPosition, ZeroBasedOriginCellRow, OriginRowPosition);
            int column = worldGrid.FindEndlessGridColumnPointIsIn_ZeroBased(position.x, ZeroBasedOriginCellColumn, OriginColumnPosition);
            int layer = worldGrid.FindEndlessGridLayerPointIsIn_ZeroBased(layerPosition, ZeroBasedOriginCellLayer, OriginLayerPosition);

            return new Cell(row, column, layer);
        }

        /// <summary>
        /// Finds the endless grid cell that the specified position falls within. Also outputs how much the found endless grid 
        /// cell is displaced from the origin cell.
        /// </summary>
        /// <param name="position" type="Vector3">The position in world space.</param>
        /// <param name="endlessGridCellDisplacementFromOrigin" type="out Vector3">The displacement of the found endless 
        /// grid cell in relation to the origin cell's position.</param>
        /// <returns type="Cell" link="Cell.html">The endless grid cell the position falls within.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="FindEndlessGridCellPositionIsIn2">
        /// FindEndlessGridCellPositionIsIn(Vector3, out Vector3)
        /// </displayName>
        /// <syntax>
        /// public Cell FindEndlessGridCellPositionIsIn(Vector3 position, out Vector3 endlessGridCellDisplacementFromOrigin)
        /// </syntax>
        public Cell FindEndlessGridCellPositionIsIn(Vector3 position, out Vector3 endlessGridCellDisplacementFromOrigin)
        {
            return FindEndlessGridCellPositionIsIn_ZeroBased(position, out endlessGridCellDisplacementFromOrigin).ConvertTo1Based(IsWorld3D);
        }

        internal Cell FindEndlessGridCellPositionIsIn_ZeroBased(Vector3 position, out Vector3 endlessGridCellDisplacementFromOrigin)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("FindEndlessGridCellPositionIsIn_ZeroBased call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            float rowPosition, layerPosition;
            positionGetter.GetRowAndLayerPosition(position, out rowPosition, out layerPosition);

            float displacementFromFoundRowToOriginRow, displacementFromFoundColumnToOriginColumn, displacementFromFoundLayerToOriginLayer;

            int row = worldGrid.FindEndlessGridRowPointIsIn_ZeroBased(rowPosition, ZeroBasedOriginCellRow, OriginRowPosition, out displacementFromFoundRowToOriginRow);
            int column = worldGrid.FindEndlessGridColumnPointIsIn_ZeroBased(position.x, ZeroBasedOriginCellColumn, OriginColumnPosition, out displacementFromFoundColumnToOriginColumn);
            int layer = worldGrid.FindEndlessGridLayerPointIsIn_ZeroBased(layerPosition, ZeroBasedOriginCellLayer, OriginLayerPosition, out displacementFromFoundLayerToOriginLayer);

            endlessGridCellDisplacementFromOrigin = new Vector3(displacementFromFoundRowToOriginRow, displacementFromFoundColumnToOriginColumn, displacementFromFoundLayerToOriginLayer);

            return new Cell(row, column, layer);        
        }

        /// <summary>
        /// Retrieves the position and dimensions of an endless grid cell.
        /// </summary>
        /// <param name="endlessGridCell" type="Cell" link="Cell.html">
        /// The endless grid cell whose position and dimensions should be retrieved.
        /// </param>
        /// <param name="positionOfCell" type="Vector3">
        /// The position of the cell (will be set when the method returns).
        /// </param>
        /// <param name="dimensionsOfCell" type="out CellDimensions" link="CellDimensions.html">
        /// The cell dimensions of the cell (will be set when the method returns).
        /// </param>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="GetPositionAndDimensionsOfEndlessGridCell">
        /// GetPositionAndDimensionsOfEndlessGridCell(Cell, out Vector3, out CellDimensions)
        /// </displayName>
        /// <syntax>
        /// public void GetPositionAndDimensionsOfEndlessGridCell(Cell endlessGridCell, out Vector3 positionOfCell, out CellDimensions dimensionsOfCell))
        /// </syntax>
        public void GetPositionAndDimensionsOfEndlessGridCell(Cell endlessGridCell, out Vector3 positionOfCell, out CellDimensions dimensionsOfCell)
        {
            GetPositionAndDimensionsOfEndlessGridCell_ZeroBased(endlessGridCell.ConvertTo0Based(IsWorld3D), out positionOfCell, out dimensionsOfCell);
        }

        internal void GetPositionAndDimensionsOfEndlessGridCell_ZeroBased(Cell endlessGridCell, out Vector3 positionOfCell, out CellDimensions dimensionsOfCell)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("GetPositionAndDimensionsOfEndlessGridCell_ZeroBased call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.", ID));

            WorldCell worldCellOfEndlessGridCell;
            if (cellController.TryGetWorldCellOfEndlessGridCell(endlessGridCell, out worldCellOfEndlessGridCell))
            {
                positionOfCell = worldCellOfEndlessGridCell.CellPosition;
                dimensionsOfCell = worldCellOfEndlessGridCell.dimensions;
            }
            else
            {
                Cell equivalentCellOnWorldGrid = ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(endlessGridCell);
                dimensionsOfCell = GetDimensionsOfWorldGridCell_ZeroBased(equivalentCellOnWorldGrid);
                positionOfCell = GetPositionOfEndlessGridCell_ZeroBased(endlessGridCell);
            }
        }

        /// <summary>
        /// Converts an endless grid cell to its equivalent world grid cell. Each endless grid cell is just a projection 
        /// of a world grid cell, and thus has the same dimensions and object associations.
        /// <para>
        /// Note that the passed in cell should be 1 based. That is, the first cell in the grid has a row of 1, column of 1, 
        /// and layer of 1. The returned World Grid cell will also be 1 based.
        /// </para>
        /// </summary>
        /// <param name="cellOnEndlessGrid" type="Cell" link="Cell.html">The endless grid cell to be converted.</param>
        /// <returns type="Cell" link="Cell.html">The equivalent world grid cell for the endless grid cell specified.</returns>
        /// <displayName id="ConvertCellOnEndlessGridToCellOnWorldGrid">ConvertCellOnEndlessGridToCellOnWorldGrid(Cell)</displayName>
        /// <syntax>public Cell ConvertCellOnEndlessGridToCellOnWorldGrid(Cell cellOnEndlessGrid)</syntax>
        public Cell ConvertCellOnEndlessGridToCellOnWorldGrid(Cell cellOnEndlessGrid)
        {
            return ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(cellOnEndlessGrid.ConvertTo0Based(IsWorld3D)).ConvertTo1Based(IsWorld3D);
        }

        internal Cell ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(Cell cellOnEndlessGrid)
        {
            int rowOnWorldGrid = worldGrid.ConvertEndlessGridRowToWorldGridRow_ZeroBased(cellOnEndlessGrid.row);
            int columnOnWorldGrid = worldGrid.ConvertEndlessGridColumnToWorldGridColumn_ZeroBased(cellOnEndlessGrid.column);
            int layerOnWorldGrid = worldGrid.ConvertEndlessGridLayerToWorldGridLayer_ZeroBased(cellOnEndlessGrid.layer); ;

            return new Cell(rowOnWorldGrid, columnOnWorldGrid, layerOnWorldGrid);
        }

        /// <summary>
        /// Tries to get the <see cref="WorldCell" href="WorldCell.html">World Cell</see> that the 
        /// position is in. If no World Cell can be identified, false will be returned and worldCell will be null. 
        /// In this case, reasonForFailure can tell you important information on why the World Cell could not be 
        /// found, such as the position was outside the bounds of the World Grid or fell within the 
        /// bounds of an empty world grid cell.
        /// </summary>
        /// <param name="position" type="Vector3">
        /// The position to use to find the world cell.
        /// </param>
        /// <param name="worldCell" type="WorldCell" link="WorldCell.html">
        /// When this method returns, contains the world cell associated with the endless grid cell, or null 
        /// if a World Cell cannot be identified
        /// </param>
        /// <param name="reasonForFailure" type="WorldCell" link="WorldCell.html">
        /// If a World Cell was located, this will be null, otherwise it will contain a helpful message 
        /// you can use to debug the reason for the failure.
        /// </param>
        /// <syntax>
        /// public bool TryGetWorldCellPositionIsIn(Vector3 position, out WorldCell worldCell, out string reasonForFailure)
        /// </syntax>
        /// <displayName id="TryGetWorldCellPositionIsIn1">
        /// TryGetWorldCellPositionIsIn(Vector3, out WorldCell, out string)
        /// </displayName>
        /// <returns type="bool">A bool indicating whether the world cell was able to be retrieved.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        public bool TryGetWorldCellPositionIsIn(Vector3 position, out WorldCell worldCell, out string reasonForFailure)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryGetWorldCellPositionIsIn call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.\n\n", ID));

            Cell zeroBasedEndlessGridCellPositionIsIn = FindEndlessGridCellPositionIsIn_ZeroBased(position);
            bool tryGetSucceeded = cellController.TryGetWorldCellOfEndlessGridCell(zeroBasedEndlessGridCellPositionIsIn, out worldCell);

            if (tryGetSucceeded)
                reasonForFailure = null;
            else
                reasonForFailure = FindReasonForFailedWorldCellGetAttempt(zeroBasedEndlessGridCellPositionIsIn);

            return tryGetSucceeded;
        }

        /// <summary>
        /// Tries to get the <see cref="WorldCell" href="WorldCell.html">World Cell</see> that the 
        /// position is in. This method may fail to identify a World Cell for several reasons. If you are 
        /// having trouble identifing the reason, you can use the alternative method with the out 
        /// string parameter.
        /// </summary>
        /// <param name="position" type="Vector3">
        /// The position to use to find the world cell.
        /// </param>
        /// <param name="worldCell" type="WorldCell" link="WorldCell.html">
        /// When this method returns, contains the world cell associated with the endless grid cell, or null 
        /// if a World Cell cannot be identified
        /// </param>
        /// <syntax>
        /// public bool TryGetWorldCellPositionIsIn(Vector3 position, out WorldCell worldCell)
        /// </syntax>
        /// <displayName id="TryGetWorldCellPositionIsIn2">
        /// TryGetWorldCellPositionIsIn(Vector3, out WorldCell)
        /// </displayName>
        /// <returns type="bool">A bool indicating whether the world cell was able to be retrieved.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        public bool TryGetWorldCellPositionIsIn(Vector3 position, out WorldCell worldCell)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryGetWorldCellPositionIsIn call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.\n\n", ID));

            return cellController.TryGetWorldCellOfEndlessGridCell(FindEndlessGridCellPositionIsIn_ZeroBased(position), out worldCell);
        }

        /// <summary>
        /// Tries to get the <see cref="WorldCell" href="WorldCell.html">World Cell</see> associated with 
        /// the endless grid cell. If no World Cell can be identified, false will be returned and 
        /// worldCell will be null. 
        /// In this case, reasonForFailure can tell you important information on why the World Cell could not be 
        /// found, such as the endless grid cell was outside the bounds of the World Grid 
        /// or was associated with an empty world grid cell.
        /// </summary>
        /// <param name="endlessGridCell" type="Cell" link="Cell.html">
        /// The endless grid cell to use to find the world cell.
        /// </param>
        /// <param name="worldCell" type="WorldCell" link="WorldCell.html">
        /// When this method returns, contains the world cell associated with the endless grid cell, or null 
        /// if a World Cell cannot be identified
        /// </param>
        /// <param name="reasonForFailure" type="WorldCell" link="WorldCell.html">
        /// If a World Cell was located, this will be null, otherwise it will contain a helpful message 
        /// you can use to debug the reason for the failure.
        /// </param>
        /// <syntax>
        /// public bool TryGetWorldCellAssociatedWithEndlessGridCell(Cell endlessGridCell, out WorldCell worldCell, out string reasonForFailure)
        /// </syntax>
        /// <displayName id="TryGetWorldCellAssociatedWithEndlessGridCell1">
        /// TryGetWorldCellAssociatedWithEndlessGridCell(Cell, out WorldCell, out string)
        /// </displayName>
        /// <returns type="bool">A bool indicating whether the world cell was able to be retrieved.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        public bool TryGetWorldCellAssociatedWithEndlessGridCell(Cell endlessGridCell, out WorldCell worldCell, out string reasonForFailure)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryGetWorldCellAssociatedWithEndlessGridCell call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.\n\n", ID));

            Cell zeroBasedEndlessGridCellPositionIsIn = endlessGridCell.ConvertTo0Based(IsWorld3D);
            bool tryGetSucceeded = cellController.TryGetWorldCellOfEndlessGridCell(zeroBasedEndlessGridCellPositionIsIn, out worldCell);

            if (tryGetSucceeded)
                reasonForFailure = null;
            else
                reasonForFailure = FindReasonForFailedWorldCellGetAttempt(zeroBasedEndlessGridCellPositionIsIn);

            return tryGetSucceeded;
        }

        /// <summary>
        /// Tries to get the <see cref="WorldCell" href="WorldCell.html">World Cell</see> that the 
        /// position is in. This method may fail to identify a World Cell for several reasons. If you are 
        /// having trouble identifing the reason, you can use the alternative method with the out 
        /// string parameter.
        /// </summary>
        /// <param name="endlessGridCell" type="Cell" link="Cell.html">
        /// The endless grid cell to use to find the world cell.
        /// </param>
        /// <param name="worldCell" type="WorldCell" link="WorldCell.html">
        /// When this method returns, contains the world cell associated with the endless grid cell, or null 
        /// if a World Cell cannot be identified.
        /// </param>
        /// <syntax>
        /// public bool TryGetWorldCellAssociatedWithEndlessGridCell(Cell endlessGridCell, out WorldCell worldCell)
        /// </syntax>
        /// <displayName id="TryGetWorldCellAssociatedWithEndlessGridCell2">
        /// TryGetWorldCellAssociatedWithEndlessGridCell(Cell, out WorldCell)
        /// </displayName>
        /// <returns type="bool">A bool indicating whether the world cell was able to be retrieved.</returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        public bool TryGetWorldCellAssociatedWithEndlessGridCell(Cell endlessGridCell, out WorldCell worldCell)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("TryGetWorldCellAssociatedWithEndlessGridCell call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.\n\n", ID));

            return cellController.TryGetWorldCellOfEndlessGridCell(endlessGridCell.ConvertTo0Based(IsWorld3D), out worldCell);
        }

        internal bool TryGetWorldCellAssociatedWithEndlessGridCell_ZeroBased(Cell endlessGridCell, out WorldCell worldCell)
        {
            return cellController.TryGetWorldCellOfEndlessGridCell(endlessGridCell, out worldCell);
        }

        string FindReasonForFailedWorldCellGetAttempt(Cell endlessGridCell_zeroBased)
        {
            if (!cellController.AreWorldCellsLoaded)
                return "Could not locate a World Cell because the World with ID " + ID + " has not had a chance to load World Cells. If the 'Initialize on Awake' option is checked on your ComponentManager, you should only call the TryGetWorldCell... method from within the Start method of a script set to Execute after the Component Manager, as it is within the Component Manager's start method that the World Cells are first loaded. You can adjust this via Edit -> Project Settings -> Script Execution Order.\n\nIf you are calling the Component Manager's Initialize method manually, try waiting a frame or two before trying to get the World Cell, as two frames are needed to fully load the World Cells.\n\nFinally, if you are calling the InitializeGradually method of the Component Manager, wait until this coroutine finishes before trying to get the World Cell.";

            //the cell is zero based
            if (!inBoundsChecker.IsCellInBounds(endlessGridCell_zeroBased))
                return "Could not locate a World Cell because the position or endless grid cell provided does not fall within the bounds of the World with ID " + ID + ". You might consider switching to an endless world.";

            if (IsCellEmpty(ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(endlessGridCell_zeroBased)))
                return "Could not locate a World Cell because the position or endless grid cell provided is associated with an empty world grid cell (as defined on your World Grid asset) on the World with ID " + ID + ".";

            return "Could not locate a World Cell because the cell is not active on the World with ID " + ID + ". A cell is only active when one or more World users (such as an Active Grid) are 'using' that cell.";
        }

        /// <summary>
        /// Get the row and layer position of a cell given it's absolute world space position. 
        /// This is useful because 
        /// the row and layer positions may be using the y or z components of the Vector3, 
        /// depending on the World Type.
        /// <para>
        /// When WorldType is Two_Dimensional_On_XZ_Axes or Three_Dimensional Row Position uses z component and 
        /// Layer Position uses y component.
        /// </para>
        /// <para>
        /// When WorldType is Two_Dimensional_On_XY_Axes Row Position uses y component and Layer Position uses 
        /// z component.
        /// </para>
        /// </summary>
        /// <param name="cellPosition">The world space position of the cell.</param>
        /// <param name="rowPosition" type="float">
        /// The Row Position of the cell after this method returns.
        /// </param>
        /// <param name="layerPosition" type="float">
        /// The Layer Position of the cell after this method returns.
        /// </param>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called before the World has been initialized.
        /// </exception>
        /// <syntax>
        /// public void GetRowPositionOfCell(Vector3 cellPosition, out float rowPosition, out float layerPosition)
        /// </syntax>
        /// <displayName id="GetRowPositionOfCell">
        /// GetRowPositionOfCell(Vector3, out float, out float)
        /// </displayName>
        public void GetRowAndLayerPositionOfCell(Vector3 cellPosition, out float rowPosition, out float layerPosition)
        {
            if (!IsInitialized)
                throw new InvalidOperationException(string.Format("GetRowPositionOfCell call on the World with ID {0} failed. The World was has not been initialized. If the World was added in the inspector or re created by the Component Manager, make sure the Component Manager is initialized (which will in turn initialize this World) before calling this method.\n\n", ID));
            
            positionGetter.GetRowAndLayerPosition(cellPosition, out rowPosition, out layerPosition);
        }

        #endregion

        #region Pre Initialization Set Methods

        /// <summary>
        /// Changes the World Origin that this World will initially use. This must be called before the World has been initialized.
        /// </summary>
        /// <param name="newWorldOrigin" type="Vector3">
        /// The new world origin.
        /// </param>
        /// <param name="overwriteWorldOriginFromPersistentData" type="bool">
        /// Should the new world origin overwrite the world origin found in persistent data for this World (if any exist)?
        /// </param>
        /// <displayName id="PreInitialize_SetWorldOrigin">
        /// PreInitialize_SetWorldOrigin(Vector3, bool)
        /// </displayName>
        /// <syntax>
        /// public void PreInitialize_SetWorldOrigin(Vector3 newWorldOrigin, bool overwriteWorldOriginFromPersistentData)
        /// </syntax>
        public void PreInitialize_SetWorldOrigin(Vector3 newWorldOrigin, bool overwriteWorldOriginFromPersistentData)
        {
            if (IsInitialized)
                throw new InvalidOperationException("PreInitialize_SetWorldOrigin call on World with ID" + ID + " failed. The World has already been initialized, and this method must be called before it has been initialized.");

            ignoreWorldOriginInPersistentData = overwriteWorldOriginFromPersistentData;

            if (!persistentDataSet || overwriteWorldOriginFromPersistentData)
            {
                useThisGameObjectsPositionAsWorldOrigin = false;
                worldOrigin = newWorldOrigin;
            }
        }

        /// <summary>
        /// Changes the Group Name that this World will initially use. This must be called before the World has been initialized.
        /// </summary>
        /// <param name="newGroupName" type="string">
        /// The new group name.
        /// </param>
        /// <param name="overwriteNameFromPersistentData" type="bool">
        /// Should the new group name overwrite the group name found in persistent data for this World (if any exist)?
        /// </param>
        /// <displayName id="PreInitialize_SetGroupName">
        /// PreInitialize_SetGroupName(string, bool)
        /// </displayName>
        /// <syntax>
        /// public void PreInitialize_SetGroupName(string newGroupName, bool overwriteNameFromPersistentData)
        /// </syntax>
        public void PreInitialize_SetGroupName(string newGroupName, bool overwriteNameFromPersistentData)
        {
            if (IsInitialized)
                throw new InvalidOperationException("PreInitialize_SetGroupName call on World with ID" + ID + " failed. The World has already been initialized, and this method must be called before it has been initialized.");

            ignoreGroupNameInPersistentData = overwriteNameFromPersistentData;

            if (!persistentDataSet || overwriteNameFromPersistentData)
                GroupName = newGroupName;
        }

        /// <summary>
        /// Changes the Origin Cell that this World will initially use. This must be called before the World has been initialized.
        /// </summary>
        /// <param name="newOriginCell" type="Cell" link="Cell.html">
        /// The new origin cell.
        /// <para>
        /// Note, this origin cell is 1 based, i.e., the bottom left most cell of the world has an index of row = 1, column = 1, and 
        /// layer = 1 (for 3D worlds). The origin cell in the save data, on the other hand, is 0 based.
        /// </para>
        /// <para>
        /// Also note the layer is only used if the World Grid is Three Dimensional.
        /// </para>
        /// </param>
        /// <param name="overwriteOriginCellFromPersistentData" type="bool">
        /// Should the new origin cell overwrite the origin cell found in persistent data for this World (if any exist)?
        /// </param>
        /// <displayName id="PreInitialize_SetOriginCell">
        /// PreInitialize_SetOriginCell(Cell, bool)
        /// </displayName>
        /// <syntax>
        /// public void PreInitialize_SetOriginCell(Cell newOriginCell, bool overwriteOriginCellFromPersistentData)
        /// </syntax>
        public void PreInitialize_SetOriginCell(Cell newOriginCell, bool overwriteOriginCellFromPersistentData)
        {
            if (IsInitialized)
                throw new InvalidOperationException("PreInitialize_SetOriginCell call on World with ID" + ID + " failed. The World has already been initialized, and this method must be called before it has been initialized.");

            ignoreOriginCellInPersistentData = overwriteOriginCellFromPersistentData;

            if (!persistentDataSet || overwriteOriginCellFromPersistentData)
            {
                Cell originCellOnWorldGrid = ConvertCellOnEndlessGridToCellOnWorldGrid(newOriginCell);
                oneBasedOriginCellRow = originCellOnWorldGrid.row;
                oneBasedOriginCellColumn = originCellOnWorldGrid.column;

                if (worldGrid.WorldType == WorldType.Three_Dimensional)
                    oneBasedOriginCellLayer = originCellOnWorldGrid.layer;
                else
                    oneBasedOriginCellLayer = 1;
            }
        }


        /// <summary>
        /// Changes the Group Name of this World (change persist between sessions if the World is persistent) and 
        /// optionally refreshes the World so it will be made up entirely of the objects associated with the new group name. 
        /// </summary>
        /// <param name="newGroupName" type="string">
        /// The new group name.
        /// </param>
        /// <param name="refreshWorld" type="bool">
        /// If true, the objects related to the previous group name are completely unloaded, and the objects related to 
        /// the new group name are loaded.
        /// <para>
        /// This is useful for loading alternate versions of your terrain/objects (such as a lower resolution version) 
        /// mid-game. The alternate terrain/objects dimensions/type must match the normal versions dimensions/type. 
        /// For example, if the normal version of an object is a 500m x 500m terrain, the alternate version must also be a 500m x 500m terrain.
        /// </para>
        /// <para>
        /// This method will load the new objects first, then remove the old objects. This will not look good, so refreshWorld should 
        /// probably only be set to true if using a loading screen or some other method that hides the game view from the player.
        /// </para>
        /// </param>
        /// <exception name="InvalidOperationException">
        /// Thrown when the method is called before the World has been initialized.
        /// </exception>
        /// <displayName id="ChangeNameAndRefreshWorld">
        /// ChangeGroupName(string, bool)
        /// </displayName>
        /// <syntax>
        /// public IEnumerator&lt;YieldInstruction&gt; ChangeGroupName(string newGroupName, bool refreshWorld)
        /// </syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        public IEnumerator<YieldInstruction> ChangeGroupName(string newGroupName, bool refreshWorld)
        {
            if(!IsInitialized)
                throw new InvalidOperationException("ChangeGroupName call on World with ID" + ID + " failed. The World has not been initialized. Use PreInitialize_SetGroupName instead.");
            
            if (!refreshWorld)
            {
                IEnumerator<YieldInstruction> changeNameEnumerator = WaitForUpdateThenChangeName(newGroupName);
                while (changeNameEnumerator.MoveNext())
                    yield return changeNameEnumerator.Current;
            }
            else
            {
                if (WorldState == WorldState.Idle)
                    update = false;
                else
                {
                    //Waits for another operation that stopped the update loop to finish
                    while (!update)
                        yield return null;

                    while (WorldState != WorldState.WaitingForRequest)
                        yield return null;

                    update = false;
                }
                
                GroupName = newGroupName;

                IEnumerator<YieldInstruction> refreshEnumerator = cellController.RefreshWorldWithNewGroupNameObjects();
                while (refreshEnumerator.MoveNext())
                    yield return refreshEnumerator.Current;

                update = true;
            }
        }

        IEnumerator<YieldInstruction> WaitForUpdateThenChangeName(string newGroupName)
        {
            do
            {
                yield return null;
            }
            while (WorldState >= WorldState.UpdatingWorldWithoutShift && WorldState <= WorldState.UpdatingWorldWithExplicitOriginCellUpdate);

            ChangeNameAndUpdatePrimaryCellObjectSubController(newGroupName);
        }

        void ChangeNameAndUpdatePrimaryCellObjectSubController(string newGroupName)
        {
            GroupName = newGroupName;
            cellController.DeRegisterWithSubController();
            cellController.RegisterWithSubController();
        }

        #endregion

        #region Destruction Logic

        /// <summary>
        /// Deactivates all cells of the world and unloads the objects associated with those cells, then destroys the World component.
        /// <para>When destroyed, the World will de-register with the associated Primary Cell Object Sub Controller (so you don't need to worry about 
        /// doing this yourself).</para>
        /// </summary>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        /// <displayName id="Destroy">Destroy()</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; Destroy()</syntax>
        internal IEnumerator<YieldInstruction> Destroy()
        {
            persistent = false;

            if (WorldState == WorldState.Idle)
                update = false;
            else
            {
                //Waits for another operation that stopped the update loop to finish
                while (!update)
                    yield return null;

                update = false;

                while (WorldState > WorldState.WaitingForRequest)
                    yield return null;
            }

            foreach (IWorldUser user in users.RegistrantEntries())
                user.OnWorldDestroyed();

            addRequestBuffer.Clear();
            removeRequestBuffer.Clear();
            cellsToRemoveUsersFrom.Clear();
            cellsToAddUsersTo.Clear();

            if (cellController != null)
            {
                if (cellController.UsersExists)
                {
                    //Update loop is effectively stopped at this point. We can now remove all the cell users and objects.
                    //Note that Add Cell User request will be processed once this operation has completed
                    //Remove Cell User request are ignored during this process, however.
                    IEnumerator<YieldInstruction> removeAllEnumerator = cellController.RemoveAllCellUsersAndCellObjects();
                    while (removeAllEnumerator.MoveNext())
                        yield return removeAllEnumerator.Current;
                }

                if (cellController != null)
                {
                    cellController.DeRegisterObjectGroups();
                    cellController.DeRegisterWithSubController();
                    cellController = null;
                }
            }

            Destroy(this);
        }

        #endregion

        #region WorldShifter Classes
        abstract class WorldShifter
        {
            protected World world;
            public WorldShifter(World world)
            {
                this.world = world;
            }

            public abstract void ShiftOriginCell(Vector3 positionToUseToCalculateShift, BoundaryCrossed eastOrWest, BoundaryCrossed northOrSouth, BoundaryCrossed topOrBottom, out Vector3 shiftAmount);

            protected void CalculateColumnShift(float columnPositionToUseToCalculateShift, BoundaryCrossed eastOrWest, out float columnShiftAmount, out int newOriginColumn)
            {
                float newOriginColumnDisplacementFromOldOriginColumn;

                if(eastOrWest == BoundaryCrossed.East)
                {
                    newOriginColumn = world.worldGrid.FindEndlessGridColumnPointIsIn_ZeroBased(columnPositionToUseToCalculateShift, world.DesiredZeroBasedOriginCellColumn, world.OriginColumnPosition, out newOriginColumnDisplacementFromOldOriginColumn);
                    columnShiftAmount = -newOriginColumnDisplacementFromOldOriginColumn;
                }
                else if(eastOrWest == BoundaryCrossed.West)
                {
                    newOriginColumn = world.worldGrid.FindEndlessGridColumnPointIsIn_ZeroBased(columnPositionToUseToCalculateShift, world.DesiredZeroBasedOriginCellColumn, world.OriginColumnPosition, out newOriginColumnDisplacementFromOldOriginColumn);
                    columnShiftAmount = -newOriginColumnDisplacementFromOldOriginColumn;
                }
                else
                {
                    newOriginColumn = world.DesiredZeroBasedOriginCellColumn;
                    columnShiftAmount = 0f;
                }
            }

            protected void CalculateRowShift(float rowPositionToUseToCalculateShift, BoundaryCrossed northOrSouth, out float rowShiftAmount, out int newOriginRow)
            {
                float newOriginRowDisplacementFromOldOriginRow;

                if(northOrSouth == BoundaryCrossed.North)
                {
                    newOriginRow = world.worldGrid.FindEndlessGridRowPointIsIn_ZeroBased(rowPositionToUseToCalculateShift, world.ZeroBasedOriginCellRow, world.OriginRowPosition, out newOriginRowDisplacementFromOldOriginRow);
                    rowShiftAmount = -newOriginRowDisplacementFromOldOriginRow;
                }
                else if(northOrSouth == BoundaryCrossed.South)
                {
                    newOriginRow = world.worldGrid.FindEndlessGridRowPointIsIn_ZeroBased(rowPositionToUseToCalculateShift, world.ZeroBasedOriginCellRow, world.OriginRowPosition, out newOriginRowDisplacementFromOldOriginRow);
                    rowShiftAmount = -newOriginRowDisplacementFromOldOriginRow;
                }
                else
                {
                    newOriginRow = world.ZeroBasedOriginCellRow;
                    rowShiftAmount = 0f;
                }
            }

            protected void CalculateLayerShift(float layerPositionToUseToCalculateShift, BoundaryCrossed topOrBottom, out float layerShiftAmount, out int newOriginLayer)
            {
                float newOriginLayerDisplacementFromOldOriginLayer;

                if(topOrBottom == BoundaryCrossed.Top)
                {
                    newOriginLayer = world.worldGrid.FindEndlessGridLayerPointIsIn_ZeroBased(layerPositionToUseToCalculateShift, world.DesiredZeroBasedOriginCellLayer, world.OriginLayerPosition, out newOriginLayerDisplacementFromOldOriginLayer);
                    layerShiftAmount = -newOriginLayerDisplacementFromOldOriginLayer;
                }
                else if(topOrBottom == BoundaryCrossed.Bottom)
                {
                    newOriginLayer = world.worldGrid.FindEndlessGridLayerPointIsIn_ZeroBased(layerPositionToUseToCalculateShift, world.DesiredZeroBasedOriginCellLayer, world.OriginLayerPosition, out newOriginLayerDisplacementFromOldOriginLayer);
                    layerShiftAmount = -newOriginLayerDisplacementFromOldOriginLayer;
                }
                else
                {
                    newOriginLayer = world.DesiredZeroBasedOriginCellLayer;
                    layerShiftAmount = 0f;
                }
            }
        }

        class WorldShifter2DXY : WorldShifter
        {
            public WorldShifter2DXY(World world) : base(world) { }

            public sealed override void ShiftOriginCell(Vector3 positionToUseToCalculateShift, BoundaryCrossed eastOrWest, BoundaryCrossed northOrSouth, BoundaryCrossed topOrBottom, out Vector3 shiftAmount)
            {
                float rowShiftAmount, columnShiftAmount;
                int newRowOrigin, newColumnOrigin;

                CalculateRowShift(positionToUseToCalculateShift.y, northOrSouth, out rowShiftAmount, out newRowOrigin);
                CalculateColumnShift(positionToUseToCalculateShift.x, eastOrWest, out columnShiftAmount, out newColumnOrigin);

                if (newRowOrigin == world.ZeroBasedOriginCellRow && newColumnOrigin == world.ZeroBasedOriginCellColumn)
                {
                    if (!world.componentManager.suppressWarnings)
                        Debug.Log("A shift was executed, but the new origin cell was the same as the old origin cell. This is most likely due to your shift boundaries not being far enough away from your world origin.");
                }

                //newRowOrigin and newColumnOrigin are endless grid cells. We need to convert them to world grid cells,
                //and record the difference between the endless grid cell value and world grid cell value

                world.DesiredZeroBasedOriginCellRow = world.WorldGrid.ConvertEndlessGridRowToWorldGridRow_ZeroBased(newRowOrigin);
                int rowShift = world.DesiredZeroBasedOriginCellRow - newRowOrigin;

                world.DesiredZeroBasedOriginCellColumn = world.WorldGrid.ConvertEndlessGridColumnToWorldGridColumn_ZeroBased(newColumnOrigin);
                int columnShift = world.DesiredZeroBasedOriginCellColumn - newColumnOrigin;

                world.endlessGridCellShift = new Cell(rowShift, columnShift);
                shiftAmount = new Vector3(columnShiftAmount, rowShiftAmount, 0f);
            }
        }

        class WorldShifter2DXZ : WorldShifter
        {
            public WorldShifter2DXZ(World world) : base(world) { }

            public sealed override void ShiftOriginCell(Vector3 positionToUseToCalculateShift, BoundaryCrossed eastOrWest, BoundaryCrossed northOrSouth, BoundaryCrossed topOrBottom, out Vector3 shiftAmount)
            {
                float rowShiftAmount, columnShiftAmount;
                int newRowOrigin, newColumnOrigin;

                CalculateRowShift(positionToUseToCalculateShift.z, northOrSouth, out rowShiftAmount, out newRowOrigin);
                CalculateColumnShift(positionToUseToCalculateShift.x, eastOrWest, out columnShiftAmount, out newColumnOrigin);

                if (newRowOrigin == world.ZeroBasedOriginCellRow && newColumnOrigin == world.ZeroBasedOriginCellColumn)
                {
                    if (!world.componentManager.suppressWarnings)
                        Debug.Log("A shift was executed, but the new origin cell was the same as the old origin cell. This is most likely due to your shift boundaries not being far enough away from your world origin.");
                }

                //newRowOrigin and newColumnOrigin are endless grid cells. We need to convert them to world grid cells,
                //and record the difference between the endless grid cell value and world grid cell value

                world.DesiredZeroBasedOriginCellRow = world.WorldGrid.ConvertEndlessGridRowToWorldGridRow_ZeroBased(newRowOrigin);
                int rowShift = world.DesiredZeroBasedOriginCellRow - newRowOrigin;

                world.DesiredZeroBasedOriginCellColumn = world.WorldGrid.ConvertEndlessGridColumnToWorldGridColumn_ZeroBased(newColumnOrigin);
                int columnShift = world.DesiredZeroBasedOriginCellColumn - newColumnOrigin;

                world.endlessGridCellShift = new Cell(rowShift, columnShift);

                shiftAmount = new Vector3(columnShiftAmount, 0f, rowShiftAmount);
            }
        }

        class WorldShifter3D : WorldShifter
        {
            public WorldShifter3D(World world) : base(world) { }

            public sealed override void ShiftOriginCell(Vector3 positionToUseToCalculateShift, BoundaryCrossed eastOrWest, BoundaryCrossed northOrSouth, BoundaryCrossed topOrBottom, out Vector3 shiftAmount)
            {
                float rowShiftAmount, columnShiftAmount, layerShiftAmount;
                int newRowOrigin, newColumnOrigin, newLayerOrigin;

                CalculateRowShift(positionToUseToCalculateShift.z, northOrSouth, out rowShiftAmount, out newRowOrigin);
                CalculateColumnShift(positionToUseToCalculateShift.x, eastOrWest, out columnShiftAmount, out newColumnOrigin);
                CalculateLayerShift(positionToUseToCalculateShift.y, topOrBottom, out layerShiftAmount, out newLayerOrigin);

                if (newRowOrigin == world.ZeroBasedOriginCellRow && newColumnOrigin == world.ZeroBasedOriginCellColumn && newLayerOrigin == world.ZeroBasedOriginCellLayer)
                {
                    if (!world.componentManager.suppressWarnings)
                        Debug.Log("A shift was executed, but the new origin cell was the same as the old origin cell. This is most likely due to your shift boundaries not being far enough away from your world origin.");
                }

                //newRowOrigin and newColumnOrigin are endless grid cells. We need to convert them to world grid cells,
                //and record the difference between the endless grid cell value and world grid cell value

                world.DesiredZeroBasedOriginCellRow = world.WorldGrid.ConvertEndlessGridRowToWorldGridRow_ZeroBased(newRowOrigin);
                int rowShift = world.DesiredZeroBasedOriginCellRow - newRowOrigin;

                world.DesiredZeroBasedOriginCellColumn = world.WorldGrid.ConvertEndlessGridColumnToWorldGridColumn_ZeroBased(newColumnOrigin);
                int columnShift = world.DesiredZeroBasedOriginCellColumn - newColumnOrigin;

                world.DesiredZeroBasedOriginCellLayer = world.WorldGrid.ConvertEndlessGridLayerToWorldGridLayer_ZeroBased(newLayerOrigin);
                int layerShift = world.DesiredZeroBasedOriginCellLayer - newLayerOrigin;

                world.endlessGridCellShift = new Cell(rowShift, columnShift, layerShift);

                shiftAmount = new Vector3(columnShiftAmount, layerShiftAmount, rowShiftAmount);
            }
        }

        #endregion

        #region Pre Initialization Safe Helper Methods

        /// <summary>
        /// Gets a Vector3 that can be added to a static position to convert it to a dynamic position.
        /// The static position is the position in the World when the Origin Cell of the world is 1, 1, 1, while the 
        /// dynamic position is the position in the World when it's Origin Cell is some other value, in this case the 
        /// theoretical origin cell value passed in.
        /// This is useful if you're trying to predict what the position of an object will be after the World has been 
        /// set to a specific origin cell.
        /// <para>
        /// Note that this method can safely be called even if the World has not been initialized, and as such can 
        /// be used with prototype Worlds (which will never be intialized).
        /// </para>
        /// <para>
        /// If you're trying to get a StaticToDynamicPositionAddition value for the World's 
        /// current OriginCell and the World has been initialized, simply use the StaticToDynamicPositionAddition property.
        /// </para>
        /// </summary>
        /// <param name="theoreticalOriginCell" type="Cell" link="Cell.html">The one based theoretical origin cell of the world that is used to compute the Addition value needed to convert from a static to dynamic position.</param>
        /// <syntax>
        /// public Vector3 InitIndependent_GetStaticToDynamicPositionAdditionForTheoreticalOriginCell(Cell theoreticalOriginCell)
        /// </syntax>
        /// <displayName id="InitIndependent_GetStaticToDynamicPositionAdditionForTheoreticalOriginCell">
        /// InitIndependent_GetStaticToDynamicPositionAdditionForTheoreticalOriginCell(Cell)
        /// </displayName>
        /// <returns type="Vector3">A Vector3 value that can be added to a static position to produce a dynamic position.</returns>
        public Vector3 InitIndependent_GetStaticToDynamicPositionAdditionForTheoreticalOriginCell(Cell theoreticalOriginCell)
        {
            Cell zeroBasedTheoreticalOriginCell = new Cell(theoreticalOriginCell.Row - 1, theoreticalOriginCell.Column - 1, WorldGrid.WorldType == WorldType.Three_Dimensional ? theoreticalOriginCell.Layer - 1 : 0);

            Cell zeroBasedWorldGridCell = ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(zeroBasedTheoreticalOriginCell);
            return -WorldGrid.GetDistanceFromOriginOfWorldGridCell_ZeroBased(zeroBasedWorldGridCell);
        }

        /// <summary>
        /// Gets a Vector3 that can be added to a dynamic position to convert it to a static position.
        /// The static position is the position in the World when the Origin Cell of the world is 1, 1, 1, while the 
        /// dynamic position is the position in the World when it's Origin Cell is some other value, in this case the 
        /// theoretical origin cell value passed in.
        /// <para>
        /// Note that this method can safely be called even if the World has not been initialized, and as such can 
        /// be used with prototype Worlds (which will never be intialized).
        /// </para>
        /// <para>
        /// If you're trying to get a DynamicToStaticPositionAddition value for the World's 
        /// current OriginCell and the World has been initialized, simply use the DynamicToStaticPositionAddition property.
        /// </para>
        /// </summary>
        /// <param name="theoreticalOriginCell" type="Cell" link="Cell.html">The one based theoretical origin cell of the world that is used to compute the Addition value needed to convert from a dynamic to static position.</param>
        /// <syntax>
        /// public Vector3 InitIndependent_GetDynamicToStaticPositionAdditionForTheoreticalOriginCell(Cell theoreticalOriginCell)
        /// </syntax>
        /// <displayName id="InitIndependent_GetDynamicToStaticPositionAdditionForTheoreticalOriginCell">
        /// InitIndependent_GetDynamicToStaticPositionAdditionForTheoreticalOriginCell(Cell)
        /// </displayName>
        /// <returns type="Vector3">A Vector3 value that can be added to a dynamic position to produce a static position.</returns>
        public Vector3 InitIndependent_GetDynamicToStaticPositionAdditionForTheoreticalOriginCell(Cell theoreticalOriginCell)
        {
            Cell zeroBasedTheoreticalOriginCell = new Cell(theoreticalOriginCell.Row - 1, theoreticalOriginCell.Column - 1, WorldGrid.WorldType == WorldType.Three_Dimensional ? theoreticalOriginCell.Layer - 1 : 0);

            Cell zeroBasedWorldGridCell = ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(zeroBasedTheoreticalOriginCell);
            return WorldGrid.GetDistanceFromOriginOfWorldGridCell_ZeroBased(zeroBasedWorldGridCell);
        }

        /// <summary>
        /// Finds the World Grid cell (One Based) that the specified position falls within. 
        /// If the position does not fall within the bounds of 
        /// the world (from the origin to the edge of last row/columm/layer in the World Grid), an exception will be the thrown.
        /// <para>
        /// This method is safe to call at any time, even before the World has been initialized. This means it can even be called 
        /// on a World prototype.
        /// </para>
        /// </summary>
        /// <param name="position" type="Vector3">The position in world space.</param>
        /// <returns type="Cell" link="Cell.html">The World Grid Cell the position falls within.</returns>
        /// <exception name="ArgumentOutOfRangeException">
        /// Thrown when the position argument is not within the bounds of the World.
        /// </exception>
        /// <displayName id="InitIndependent_FindWorldGridCellPositionIsIn">
        /// InitIndependent_FindWorldGridCellPositionIsIn(Vector3)
        /// </displayName>
        /// <syntax>
        /// public Cell InitIndependent_FindWorldGridCellPositionIsIn(Vector3 position)
        /// </syntax>
        public Cell InitIndependent_FindWorldGridCellPositionIsIn(Vector3 position)
        {
            return WorldGrid.GetWorldGridCellPositionIsIn_OneBased(position, worldOrigin);
        }

        #endregion
    }
}