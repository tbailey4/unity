//Terrain Slicing & Dynamic Loading Kits copyright � 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System;

    /// <summary>
    /// The exception that is thrown when multiple components of the same type in the same scene have the same ID.
    /// </summary>
    /// <title>DuplicateIDException Class</title>
    /// <category>Exceptions</category>
    /// <navigationName>DuplicateIDException</navigationName>
    /// <fileName>DuplicateIDException.html</fileName>
    /// <syntax>public class DuplicateIDException : Exception</syntax>
    public class DuplicateIDException : Exception
    {
        public DuplicateIDException() : base() { }
        public DuplicateIDException(string message) : base(message) { }
        public DuplicateIDException(string message, Exception inner) : base(message, inner) { }
    }

    /// <summary>
    /// The exception that is thrown when an Active Grid has not been properly awoken (ManagedAwake not called successfully).
    /// </summary>
    /// <title>UninitializedActiveGridException Class</title>
    /// <navigationName>UninitializedActiveGridException</navigationName>
    /// <fileName>UninitializedActiveGridException.html</fileName>
    /// <syntax>public class UninitializedActiveGridException : Exception</syntax>
    public class UninitializedActiveGridException : Exception
    {
        public UninitializedActiveGridException() : base() { }
        public UninitializedActiveGridException(string message) : base(message) { }
        public UninitializedActiveGridException(string message, Exception inner) : base(message, inner) { }
    }

    /// <summary>
    /// The exception that is thrown when trying to create a World or Active Grid at runtime from a prototype that does not exist.
    /// </summary>
    /// <title>InvalidPrototypeException Class</title>
    /// <category>Exceptions</category>
    /// <navigationName>InvalidPrototypeException</navigationName>
    /// <fileName>InvalidPrototypeException.html</fileName>
    /// <syntax>public class InvalidPrototypeException : Exception</syntax>
    public class InvalidPrototypeException : Exception
    {
        public InvalidPrototypeException() : base() { }
        public InvalidPrototypeException(string message) : base(message) { }
        public InvalidPrototypeException(string message, Exception inner) : base(message, inner) { }
    }

    /// <summary>
    /// The exception that is thrown when the save data for a Component Manager is not valid. The save data might have been loaded 
    /// manually via LoadSaveData (if using a custom save/load solution) or automatically via the Persistent Data Controller.
    /// </summary>
    /// <title>InvalidSaveDataException Class</title>
    /// <category>Exceptions</category>
    /// <navigationName>InvalidSaveDataException</navigationName>
    /// <fileName>InvalidSaveDataException.html</fileName>
    /// <syntax>public class InvalidSaveDataException : Exception</syntax>
    public class InvalidSaveDataException : Exception
    {
        public InvalidSaveDataException() : base() { }
        public InvalidSaveDataException(string message) : base(message) { }
        public InvalidSaveDataException(string message, Exception inner) : base(message, inner) { }
    }

    /// <summary>
    /// The exception that is thrown when a supplied ID does not match a valid component.
    /// </summary>
    /// <title>InvalidIDException Class</title>
    /// <category>Exceptions</category>
    /// <navigationName>InvalidIDException</navigationName>
    /// <fileName>InvalidIDException.html</fileName>
    /// <syntax>public class InvalidIDException : Exception</syntax>
    public class InvalidIDException : Exception
    {
        public InvalidIDException() : base() { }
        public InvalidIDException(string message) : base(message) { }
        public InvalidIDException(string message, Exception inner) : base(message, inner) { }
    }

    /// <summary>
    /// The exception that is thrown when an attempt is made to sync a persistent 
    /// <see cref="ActiveGrid" href="ActiveGrid.html">Active Grid</see> 
    /// to a non persistent <see cref="World" href="World.html">World</see>.
    /// </summary>
    /// <title>InvalidPersistenceException Class</title>
    /// <category>Exceptions</category>
    /// <navigationName>InvalidPersistenceException</navigationName>
    /// <fileName>InvalidPersistenceException.html</fileName>
    /// <syntax>public class InvalidPersistenceException : Exception</syntax>
    public class InvalidPersistenceException : Exception
    {
        public InvalidPersistenceException() : base() { }
        public InvalidPersistenceException(string message) : base(message) { }
        public InvalidPersistenceException(string message, Exception inner) : base(message, inner) { }
    }

    /// <summary>
    /// The exception that is thrown when a required component or Scriptable Object asset are not found on a component that needs to use them.
    /// </summary>
    /// <title>RequiredComponentNotFoundException Class</title>
    /// <category>Exceptions</category>
    /// <navigationName>RequiredComponentNotFoundException</navigationName>
    /// <fileName>RequiredComponentNotFoundException.html</fileName>
    /// <syntax>public class RequiredComponentNotFoundException : Exception</syntax>
    public class RequiredComponentNotFoundException : Exception
    {
        public RequiredComponentNotFoundException() : base() { }
        public RequiredComponentNotFoundException(string message) : base(message) { }
        public RequiredComponentNotFoundException(string message, Exception inner) : base(message, inner) { }
    }

    /// <summary>
    /// The exception that is thrown when a <see cref="BaseSceneLoader" href="BaseSceneLoader.html">Scene Loader</see> Component cannot find a newly loaded object.
    /// <para>This is most likely due to incorrect naming or tag setup. Please refer to the 
    /// <see href="http://deepspacelabs.net/files/Dynamic_Loading_Kit_Quick_Guide.pdf">Dynamic Loading Kit Quick Guide</see> for more information.</para>
    /// </summary>
    /// <title>UnboundCellObjectNotFoundException Class</title>
    /// <category>Exceptions</category>
    /// <navigationName>UnboundCellObjectNotFoundException</navigationName>
    /// <fileName>UnboundCellObjectNotFoundException.html</fileName>
    /// <syntax>public class UnboundCellObjectNotFoundException : Exception</syntax>
    public class UnboundCellObjectNotFoundException : Exception
    {
        public UnboundCellObjectNotFoundException() : base() { }
        public UnboundCellObjectNotFoundException(string message) : base(message) { }
        public UnboundCellObjectNotFoundException(string message, Exception inner) : base(message, inner) { }
    }

    /// <summary>
    /// The exception that is thrown when the data of a World Grid Scriptable Object asset has not been "set" before entering Play Mode.
    /// </summary>
    /// <title>WorldGridNotSetException Class</title>
    /// <category>Exceptions</category>
    /// <navigationName>WorldGridNotSetException</navigationName>
    /// <fileName>WorldGridNotSetException.html</fileName>
    /// <syntax>public class WorldGridNotSetException : Exception</syntax>
    public class WorldGridNotSetException : Exception
    {
        public WorldGridNotSetException() : base() { }
        public WorldGridNotSetException(string message) : base(message) { }
        public WorldGridNotSetException(string message, Exception inner) : base(message, inner) { }
    }
}