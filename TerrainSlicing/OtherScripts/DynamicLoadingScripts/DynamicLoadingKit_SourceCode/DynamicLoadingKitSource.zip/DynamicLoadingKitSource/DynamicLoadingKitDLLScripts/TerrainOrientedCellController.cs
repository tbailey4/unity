﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System.Collections.Generic;
    using UnityEngine;

    internal class TerrainOrientedCellController : CellController
    {
        HashSet<WorldCellWithTerrain> worldCellsThatMayNeedTerrainNeighborsReset;

        public TerrainOrientedCellController(World world)
            : base(world)
        {
            worldCellsThatMayNeedTerrainNeighborsReset = new HashSet<WorldCellWithTerrain>(new EndlessGridTwoDimensionalWorldCellComparer());

            PostActivationCellProcessing = SetTerrainNeighbors;
            PostDeactivationCellProcessing = ClearTerrainNeighbors;
        }

        //protected sealed override void SetAdditionalWorldCellData(WorldCell worldCell, Cell zeroBasedCellOnEndlessGrid)
        //{
        //    ((WorldCellWithTerrain)worldCell).zeroBasedCellOnEndlessGrid = zeroBasedCellOnEndlessGrid;
        //}

        protected sealed override WorldCell CreateNewWorldCell()
        {
            return new WorldCellWithTerrain(NumObjectGroups);
        }

        protected sealed override void CopyAdditionalWorldCellData(WorldCell copyFrom, WorldCell copyTo)
        {
            WorldCellWithTerrain tCopyTo = (WorldCellWithTerrain)copyTo;
            WorldCellWithTerrain tCopyFrom = (WorldCellWithTerrain)copyFrom;

            tCopyTo.terrain = tCopyFrom.terrain;
            for (int i = 0; i < 4; i++ )
                tCopyTo.neighbors[i] = tCopyFrom.neighbors[i];

            //Need to update neighbors to tell them their new neighbor is the copy to cell, otherwise they will
            //continue to reference to copy from cell
            if (tCopyTo.neighbors[0] != null)
                tCopyTo.neighbors[0].RightNeighbor = tCopyTo;

            if (tCopyTo.neighbors[1] != null)
                tCopyTo.neighbors[1].BottomNeighbor = tCopyTo;

            if (tCopyTo.neighbors[2] != null)
                tCopyTo.neighbors[2].LeftNeighbor = tCopyTo;

            if (tCopyTo.neighbors[3] != null)
                tCopyTo.neighbors[3].TopNeighbor = tCopyTo;

            tCopyTo.zeroBasedCellOnEndlessGrid = tCopyFrom.zeroBasedCellOnEndlessGrid;
        }

        protected sealed override void NullAdditionalReferenceTypes(WorldCell cellToNull)
        {
            WorldCellWithTerrain tCellToNull = (WorldCellWithTerrain)cellToNull;
            //Can't just null the neighbors reference, because some other methods are counting on it being not null.
            //Instead, we can create a new array.
            for (int i = 0; i < 4; i++)
                tCellToNull.neighbors[i] = null;
            tCellToNull.terrain = null;
        }

        IEnumerator<YieldInstruction> ClearTerrainNeighbors(List<WorldCell> deactivatedCells)
        {
            foreach (WorldCellWithTerrain cell in deactivatedCells)
            {
                ClearCellNeighbors(cell);
                cell.ClearNeighborsAndNullTerrain();
                yield return null;
            }

            foreach (WorldCellWithTerrain worldCell in worldCellsThatMayNeedTerrainNeighborsReset)
            {
                worldCell.ResetNeighbors();
                yield return null;
            }

            worldCellsThatMayNeedTerrainNeighborsReset.Clear();
        }

        void ClearCellNeighbors(WorldCellWithTerrain cell)
        {
            WorldCellWithTerrain leftNeighbor = cell.LeftNeighbor;
            if (leftNeighbor != null)
            {
                leftNeighbor.RightNeighbor = null;
                worldCellsThatMayNeedTerrainNeighborsReset.Add(leftNeighbor);
            }

            WorldCellWithTerrain rightNeighbor = cell.RightNeighbor;
            if (rightNeighbor != null)
            {
                rightNeighbor.LeftNeighbor = null;
                worldCellsThatMayNeedTerrainNeighborsReset.Add(rightNeighbor);
            }

            WorldCellWithTerrain topNeighbor = cell.TopNeighbor;
            if (topNeighbor != null)
            {
                topNeighbor.BottomNeighbor = null;
                worldCellsThatMayNeedTerrainNeighborsReset.Add(topNeighbor);
            }

            WorldCellWithTerrain bottomNeighbor = cell.BottomNeighbor;
            if (bottomNeighbor != null)
            {
                bottomNeighbor.TopNeighbor = null;
                worldCellsThatMayNeedTerrainNeighborsReset.Add(bottomNeighbor);
            }
        }

        IEnumerator<YieldInstruction> SetTerrainNeighbors(List<WorldCell> activatedCells)
        {
            for (int i = 0; i < activatedCells.Count; i++)
            {
                WorldCellWithTerrain worldCellWithTerrain = (WorldCellWithTerrain)activatedCells[i];
                worldCellWithTerrain.terrain = worldCellWithTerrain.primaryCellObject.GetComponentInChildren<Terrain>();
                SetCellNeighbors(worldCellWithTerrain);
                worldCellsThatMayNeedTerrainNeighborsReset.Add(worldCellWithTerrain);
                yield return null;
            }

            foreach (WorldCellWithTerrain worldCell in worldCellsThatMayNeedTerrainNeighborsReset)
            {
                worldCell.ResetNeighbors();
                yield return null;
            }

            worldCellsThatMayNeedTerrainNeighborsReset.Clear();
        }

        void SetCellNeighbors(WorldCellWithTerrain cell)
        {
            Cell key = cell.zeroBasedCellOnEndlessGrid;

            //Tune key to left neighbor
            key.column -= 1;
            WorldCell neighbor;
            if (worldCells.TryGetValue(key, out neighbor))
            {
                WorldCellWithTerrain leftNeighbor = (WorldCellWithTerrain)neighbor;
                cell.LeftNeighbor = leftNeighbor;
                leftNeighbor.RightNeighbor = cell;
                worldCellsThatMayNeedTerrainNeighborsReset.Add(leftNeighbor);
            }

            //Tune key to right neighbor
            key.column += 2;
            //WorldCell rightNeighbor;
            if (worldCells.TryGetValue(key, out neighbor))
            {
                WorldCellWithTerrain rightNeighbor = (WorldCellWithTerrain)neighbor;
                cell.RightNeighbor = rightNeighbor;
                rightNeighbor.LeftNeighbor = cell;
                worldCellsThatMayNeedTerrainNeighborsReset.Add(rightNeighbor);
            }

            //Tune key to top neighbor
            key.column -= 1;
            key.row += 1;
            if (worldCells.TryGetValue(key, out neighbor))
            {
                WorldCellWithTerrain topNeighbor = (WorldCellWithTerrain)neighbor;
                cell.TopNeighbor = topNeighbor;
                topNeighbor.BottomNeighbor = cell;
                worldCellsThatMayNeedTerrainNeighborsReset.Add(topNeighbor);
            }

            //Tunes key to bottom neighbor's cell
            key.row -= 2;
            if (worldCells.TryGetValue(key, out neighbor))
            {
                WorldCellWithTerrain bottomNeighbor = (WorldCellWithTerrain)neighbor;
                cell.BottomNeighbor = bottomNeighbor;
                bottomNeighbor.TopNeighbor = cell;
                worldCellsThatMayNeedTerrainNeighborsReset.Add(bottomNeighbor);
            }
        }
    }
}