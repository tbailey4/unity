﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;

    /// <summary>
    /// Component which was previously used to reset the Active Grid. It is no longer used, but it remains in the kit to
    /// avoid compatibility issues.
    /// </summary>
    /// <title>ActiveGridResetter Class</title>
    /// <category>Secondary Components</category>
    /// <navigationName>ActiveGridResetter</navigationName>
    /// <fileName>ActiveGridResetter.html</fileName>
    /// <syntax>public class ActiveGridResetter : MonoBehaviour</syntax>
    public class ActiveGridResetter : MonoBehaviour
    {
        //Obsolete class
    }
}