//Terrain Slicing & Dynamic Loading Kits copyright © 2015 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
    using System;
	using System.Collections;
	using System.Collections.Generic;

    internal class CellController
    {
        #region Delegates
        public delegate IEnumerator<YieldInstruction> CellProcessing(List<WorldCell> cells);
        #endregion

        #region Protected Fields
        protected CellProcessing PostActivationCellProcessing, PreDeactivationCellProcessing, PostDeactivationCellProcessing;
        protected World world;
        protected Dictionary<Cell, WorldCell> worldCells;
        #endregion

        #region Private Fields
        EqualityComparer<Cell> cellComparer;

        List<WorldCell> cellList1, cellList2, cellList3, cellList4, allDictionaryCells;
        List<ObjectGroupCell> objectGroupCellsReusableList1;
        Pool<WorldCell> worldCellPool;


        int primaryCellObjectSubControllerID;
        ObjectGroupInternal[] objectGroups;
        Pool<ObjectGroupCell> objectGroupCellPool;

        #endregion

        #region Properties

        bool UsingObjectGroups { get { return objectGroups != null; } }
        protected int NumObjectGroups { get { return objectGroups == null ? 0 : objectGroups.Length; } }
        public bool DoStartingCellsNeedToBeActivated { get; private set; }
        public bool UsersExists { get { return worldCells.Count > 0; } }
        public bool AreWorldCellsLoaded { get; private set; }

        #endregion

        #region Constructors

        public CellController(World world)
        {
            this.world = world;

            CreateInternalObjectGroups();
            RegisterWithSubController();

            cellList1 = new List<WorldCell>();
            cellList2 = new List<WorldCell>();
            cellList3 = new List<WorldCell>();
            cellList4 = new List<WorldCell>();

            if (world.worldGrid.worldType == WorldType.Three_Dimensional)
                cellComparer = new ThreeDimensionalCellComparer();
            else
                cellComparer = new TwoDimensionalCellComparer();

            worldCells = new Dictionary<Cell, WorldCell>(cellComparer);
            worldCellPool = new Pool<WorldCell>();

            if (UsingObjectGroups)
            {
                objectGroupCellPool = new Pool<ObjectGroupCell>();
                objectGroupCellsReusableList1 = new List<ObjectGroupCell>();
            }
        }

        #endregion

        #region Initialization/Registration
        void CreateInternalObjectGroups()
        {
            if (world.objectGroups == null || world.objectGroups.Length == 0)
            {
                world.objectGroups = null;
                return;
            }

            List<ObjectGroupInternal> initializedObjectGroups = new List<ObjectGroupInternal>(world.objectGroups.Length);
            
            for (int i = 0; i < world.objectGroups.Length; i++)
            {
                ObjectGroupInternal objectGroup = new ObjectGroupInternal();
                if (objectGroup.TryInitialize(world.objectGroups[i], world))
                {
                    objectGroup.PrimaryCellObjectSubController.Register(objectGroup, out objectGroup.primaryCellObjectSubControllerID);
                    initializedObjectGroups.Add(objectGroup);
                }
            }

            if (initializedObjectGroups.Count > 0)
            {
                objectGroups = new ObjectGroupInternal[initializedObjectGroups.Count];
                for (int i = 0; i < objectGroups.Length; i++)
                    objectGroups[i] = initializedObjectGroups[i];
            }
            else
                world.objectGroups = null;
        }

        public void DeRegisterObjectGroups()
        {
            if (objectGroups != null)
            {
                for (int i = 0; i < objectGroups.Length; i++)
                {
                    objectGroups[i].PrimaryCellObjectSubController.DeRegister(objectGroups[i].primaryCellObjectSubControllerID);
                }
            }
        }

        public void RegisterWithSubController()
        {
            world.primaryCellObjectSubController.Register(world, out primaryCellObjectSubControllerID);
        }

        public void DeRegisterWithSubController()
        {
            if (world.primaryCellObjectSubController != null)
                world.primaryCellObjectSubController.DeRegister(primaryCellObjectSubControllerID);
        }
        #endregion

        #region Adding Inititial Users

        //Should be called by the World when Active Grids add their initial cells during Awake
        public void AddStartingCellUsers_ZeroBased(IList<Cell> cellsToAddUsersTo)
        {
            if (cellsToAddUsersTo.Count == 0)
                return;

            DoStartingCellsNeedToBeActivated = true;

            //cellList1 contains the entries for this method call
            //cellList2 contains the entries for all method calls
            Cell worldOriginCellToBaseCellPositionsOn = new Cell(world.ZeroBasedOriginCellRow, world.ZeroBasedOriginCellColumn, world.ZeroBasedOriginCellLayer);

            foreach (Cell cell in cellsToAddUsersTo)
            { 
                WorldCell worldCell;
                if (!worldCells.TryGetValue(cell, out worldCell))
                {
                    worldCell = CreateNewWorldCell();
                    SetWorldCellData(worldCell, cell, worldOriginCellToBaseCellPositionsOn);
                    worldCells.Add(cell, worldCell);
                    cellList1.Add(worldCell);
                    cellList2.Add(worldCell);
                }
                worldCell.AddUsers(1);
            }

            //Perform any required pre loading for the cells needing activation
            //Using two list allows us to ensure that even if the primary cell object sub controller modifies the cellList3 list,
            //the modifications won't impact anything because this class will use the cellList1 list.
            if (cellList1.Count != 0)
            {
                if (world.primaryCellObjectSubController.IsSingleFrameAttachmentPreloadingRequired)
                {
                    cellList3.AddRange(cellList1);
                    world.primaryCellObjectSubController.PerformSingleFrameAttachmentPreloading<WorldCell>(cellList3, primaryCellObjectSubControllerID);
                    cellList3.Clear();
                }

                if(UsingObjectGroups)
                {
                    for(int i = 0; i < objectGroups.Length; i++)
                    {
                        if (objectGroups[i].PrimaryCellObjectSubController.IsSingleFrameAttachmentPreloadingRequired)
                        {
                            foreach (WorldCell cell in cellList1)
                            {
                                if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                                    objectGroupCellsReusableList1.Add(cell.objectGroupCells[i]);
                            }

                            objectGroups[i].PrimaryCellObjectSubController.PerformSingleFrameAttachmentPreloading<ObjectGroupCell>(objectGroupCellsReusableList1, objectGroups[i].primaryCellObjectSubControllerID);

                            objectGroupCellsReusableList1.Clear();
                        }
                    }
                }

                cellList1.Clear();
            }
        }

        public void ActivateStartingCells()
        {
            //Get objects for main world cells
            cellList3.AddRange(cellList2);

            world.primaryCellObjectSubController.AttachCellObjectsToCellsInSingleFrame<WorldCell>(cellList3, primaryCellObjectSubControllerID);
            cellList3.Clear();
            
            //activate main world cells
            foreach (WorldCell cell in cellList2)
            {
                if (!cell.positioned)
                    cell.RepositionPrimaryCellObject();

                if(cell.primaryCellObject.activeSelf == false)
                    cell.primaryCellObject.SetActive(true);

                if (world.primaryCellObjectSubController.useCellActions)
                {
                    cell.cellActions = cell.primaryCellObject.GetComponents<CellAction>();
                    if (cell.cellActions != null)
                    {
                        foreach (CellAction cellAction in cell.cellActions)
                        {
                            IEnumerator<YieldInstruction> cellActionEnumerator = cellAction.DoStuffAfterCellIsActivated(cell);
                            while (cellActionEnumerator.MoveNext())
                                continue;
                        }
                    }
                }
            }

            if (PostActivationCellProcessing != null)
            {
                IEnumerator<YieldInstruction> e = PostActivationCellProcessing(cellList2);
                while (e.MoveNext())
                    continue;
            }

            if(UsingObjectGroups)
            {
                for(int i = 0; i < objectGroups.Length; i++)
                {
                    //Create list of object group cells needing primary cell object
                    foreach (WorldCell cell in cellList2)
                    {
                        if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                            objectGroupCellsReusableList1.Add(cell.objectGroupCells[i]);
                    }

                    //get the primary cell object for each cell
                    objectGroups[i].PrimaryCellObjectSubController.AttachCellObjectsToCellsInSingleFrame<ObjectGroupCell>(objectGroupCellsReusableList1, objectGroups[i].primaryCellObjectSubControllerID);
                    objectGroupCellsReusableList1.Clear();

                    foreach (WorldCell cell in cellList2)
                    {
                        if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                        {
                            ObjectGroupCell objGroupCell = cell.objectGroupCells[i];
                            if (!objGroupCell.positioned)
                                objGroupCell.RepositionPrimaryCellObject();

                            //3.5-4.x difference
                            if (objGroupCell.primaryCellObject.activeSelf == false)
                                objGroupCell.primaryCellObject.SetActive(true);

                            if (objectGroups[i].PrimaryCellObjectSubController.useCellActions)
                            {
                                objGroupCell.cellActions = objGroupCell.primaryCellObject.GetComponents<CellAction>();
                                if (objGroupCell.cellActions != null)
                                {
                                    foreach (CellAction cellAction in objGroupCell.cellActions)
                                    {
                                        IEnumerator<YieldInstruction> e = cellAction.DoStuffAfterCellIsActivated(objGroupCell);
                                        while (e.MoveNext())
                                            continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            cellList2.Clear();
            DoStartingCellsNeedToBeActivated = false;
            AreWorldCellsLoaded = true;
        }

        public IEnumerator<YieldInstruction> ActivateStartingCellsEnumerated()
        {
            cellList3.AddRange(cellList1);
            DoStartingCellsNeedToBeActivated = false;

            yield return null;

            IEnumerator<YieldInstruction> attachAndActivateEnumerator = AttachCellObjectsAndActivateCells(cellList3, cellList1, objectGroupCellsReusableList1);
            while (attachAndActivateEnumerator.MoveNext())
                yield return attachAndActivateEnumerator.Current;

            AreWorldCellsLoaded = true;
        }

        #endregion

        #region Methods for adding/removing cell users at runtime

        public IEnumerator<YieldInstruction> AddAndRemoveCellUsers_ZeroBased(Dictionary<Cell, int> cellsToAddUsersTo, Dictionary<Cell, int> cellsToRemoveUsersFrom)
        {
            Cell worldOriginCellToBaseCellPositionsOn = new Cell(world.ZeroBasedOriginCellRow, world.ZeroBasedOriginCellColumn, world.ZeroBasedOriginCellLayer);

            DetermineWhichCellsNeedToBeActivated(cellsToAddUsersTo, worldOriginCellToBaseCellPositionsOn);
            yield return null;

#if DEBUG_ON
            string o = "Frame " + Time.frameCount + ": After adding the users, the following cells need to be activated (i.e., cell objects need to be loaded).\n";

            foreach (WorldCell cell in cellList1)
                o += string.Format("Row {0} | Column {1} | Users = {2}\n", cell.CellOnWorldGrid.Row, cell.CellOnWorldGrid.Column, cell.users);
            Debug.Log(o);
#endif

            //Deducts the users from each cell in the world cells dictionary.
            //If user count for a world cell reaches 0, the world cell is removed from the 
            //dictionary and added to the cellList2 list.
            DetermineWhichCellsNeedToBeDeactivated(cellsToRemoveUsersFrom);
            yield return null;

#if DEBUG_ON
            o = "Frame " + Time.frameCount + ": After removing the users, the following cells need to be deactivated (i.e., cell objects need to be removed), as these cells now have 0 users.\n";

            foreach (WorldCell cell in cellList2)
                o += string.Format("Row {0} | Column {1}\n", cell.CellOnWorldGrid.Row, cell.CellOnWorldGrid.Column);
            Debug.Log(o);
#endif

            //Deactivate the cells that need to be deactivated. This consist of:
            //1) Running Cell Actions if needed, and
            //2) Deactivating the cell object via the Game object state switcher
            //Note that the cell objects are not sent to the primary cell object sub controller for post deactivation processing,
            //since some of the cell objects may be able to be reused by cells that are about to be activated.
            IEnumerator<YieldInstruction> deactivateCells = DeactivateCells(cellList2);
            while (deactivateCells.MoveNext())
                yield return deactivateCells.Current;
            

            //This list will keep track of the cells that need primary cell objects.
            //At first, ALL cells that are going to be activated need a cell object.
            cellList3.AddRange(cellList1);
            yield return null;

            IEnumerator<YieldInstruction> matchEnumerator = MatchDeactivatedCellObjectsWithCellsNeedingObject(cellList2, cellList3);
            while (matchEnumerator.MoveNext())
                yield return matchEnumerator.Current;

            
            if (cellList2.Count > 0)
            {
                IEnumerator<YieldInstruction> detachObjectsFromCellsEnumerator = DetatchCellObjects(cellList2, objectGroupCellsReusableList1);
                while (detachObjectsFromCellsEnumerator.MoveNext())
                    yield return detachObjectsFromCellsEnumerator.Current;
            }

            IEnumerator<YieldInstruction> attachAndActivateCellsEnumerator = AttachCellObjectsAndActivateCells(cellList3, cellList1, objectGroupCellsReusableList1);
            while (attachAndActivateCellsEnumerator.MoveNext())
                yield return attachAndActivateCellsEnumerator.Current;

            AreWorldCellsLoaded = true;
        }

        public IEnumerator<YieldInstruction> AddCellUsers_ZeroBased(Dictionary<Cell, int> cellsToAddUsersTo)
        {
            Cell worldOriginCellToBaseCellPositionsOn = new Cell(world.ZeroBasedOriginCellRow, world.ZeroBasedOriginCellColumn, world.ZeroBasedOriginCellLayer);

            DetermineWhichCellsNeedToBeActivated(cellsToAddUsersTo, worldOriginCellToBaseCellPositionsOn);
#if DEBUG_ON
            string o = "Frame " + Time.frameCount + ": After adding the users, the following cells need to be activated (i.e., cell objects need to be loaded).\n";

            foreach (WorldCell cell in cellList1)
                o += string.Format("Row {0} | Column {1} | Users = {2}\n", cell.CellOnWorldGrid.Row, cell.CellOnWorldGrid.Column, cell.users);
            Debug.Log(o);
#endif
            yield return null;

            //This list will keep track of the cells that need primary cell objects.
            cellList3.AddRange(cellList1);
            yield return null;

            IEnumerator<YieldInstruction> attachAndActivateCellsEnumerator = AttachCellObjectsAndActivateCells(cellList3, cellList1, objectGroupCellsReusableList1);

            while (attachAndActivateCellsEnumerator.MoveNext())
                yield return attachAndActivateCellsEnumerator.Current;

            AreWorldCellsLoaded = true;
        }

        public IEnumerator<YieldInstruction> RemoveCellUsers_ZeroBased(Dictionary<Cell, int> cellsToRemoveUsersFrom)
        {
            DetermineWhichCellsNeedToBeDeactivated(cellsToRemoveUsersFrom);
#if DEBUG_ON
            string o = "Frame " + Time.frameCount + ": After removing the users, the following cells need to be deactivated (i.e., cell objects need to be removed), as these cells now have 0 users.\n";

            foreach (WorldCell cell in cellList2)
                o += string.Format("Row {0} | Column {1}\n", cell.CellOnWorldGrid.Row, cell.CellOnWorldGrid.Column);
            Debug.Log(o);
#endif
            yield return null;

            //deactivate the cells
            IEnumerator<YieldInstruction> deactivateEnumerator = DeactivateCells(cellList2);
            while (deactivateEnumerator.MoveNext())
                yield return deactivateEnumerator.Current;

            //detatch and process the objects on the cells
            IEnumerator<YieldInstruction> detatchEnumerator = DetatchCellObjects(cellList2, objectGroupCellsReusableList1);
            while (detatchEnumerator.MoveNext())
                yield return detatchEnumerator.Current;
        }

        public IEnumerator<YieldInstruction> RemoveAllCellUsersAndCellObjects()
        {
            cellList2.AddRange(worldCells.Values);

            yield return null;

            //deactivate the cells
            IEnumerator<YieldInstruction> deactivateEnumerator = DeactivateCells(cellList2);
            while (deactivateEnumerator.MoveNext())
                yield return deactivateEnumerator.Current;

            //detatch and process the objects on the cells
            IEnumerator<YieldInstruction> detatchEnumerator = DetatchCellObjects(cellList2, objectGroupCellsReusableList1);
            while (detatchEnumerator.MoveNext())
                yield return detatchEnumerator.Current;

            worldCells.Clear();
        }

        #endregion

        #region Methods for shifting/recreating the entire world

        public IEnumerator<YieldInstruction> CreateNewShiftedWorld_ZeroBased(Vector3 shiftAmount, Dictionary<Cell, int> cellsToAddUsersTo, Dictionary<Cell, int> cellsToRemoveUsersFrom, Cell endlessGridShift)
        {
            bool shiftEndlessGridCells = endlessGridShift.Row != 0 || endlessGridShift.Column != 0 || endlessGridShift.Layer != 0;

            //Documented, see above
            DetermineWhichCellsNeedToBeDeactivated(cellsToRemoveUsersFrom);
            yield return null;

            //Deactivate those cells
            IEnumerator<YieldInstruction> deactivateEnumerator = DeactivateCells(cellList2);
            while (deactivateEnumerator.MoveNext())
                yield return deactivateEnumerator.Current;

            //if performing the shift in a single frame
            if(world.performShiftActivationInSingleFrame)
            {
                //note that this is going to create unshifted cell, so we'll need to shift them at some point
                //we determine which cells need to be activated here before the dictionary of cells has been shifted,
                //because the determination step needs the dictionary to be unshifted to work correctly

                Cell worldOriginCellToBaseCellPositionsOn = new Cell(world.ZeroBasedOriginCellRow, world.ZeroBasedOriginCellColumn, world.ZeroBasedOriginCellLayer);

                DetermineWhichCellsNeedToBeActivated(cellsToAddUsersTo, worldOriginCellToBaseCellPositionsOn);
                yield return null;

                //Shift all cells in the dictionary that were not just added
                Dictionary<Cell, WorldCell>.Enumerator worldCellsEnumerator = worldCells.GetEnumerator();
                while (worldCellsEnumerator.MoveNext())
                {
                    WorldCell worldCell = worldCellsEnumerator.Current.Value;

                    //only shift the cell if it is not in the cells to activate list, 
                    //as these cells need to remain unshifted
                    if (!cellList1.Contains(worldCell))
                    {
                        if (shiftEndlessGridCells)
                            worldCell.zeroBasedCellOnEndlessGrid += endlessGridShift;
                        worldCell.position += shiftAmount;
                        cellList4.Add(worldCell);
                    }
                }
                //string p1 = "Cells that need to be activated\n";
                //foreach(WorldCell cell in cellList1)
                //{
                //    WorldCellWithTerrain t = (WorldCellWithTerrain)cell;
                //    p1 += "WG = " + (t.CellOnWorldGrid - new Cell(1,1,1)).ToString() + " || EG = " + t.zeroBasedCellOnEndlessGrid.ToString() + "\n";
                //}
                //Debug.Log(p1);
                //p1 = "Cells that need to be shifted\n";
                //foreach (WorldCell cell in cellList4)
                //{
                //    WorldCellWithTerrain t = (WorldCellWithTerrain)cell;
                //    p1 += "WG = " + (t.CellOnWorldGrid - new Cell(1, 1, 1)).ToString() + " || EG = " + t.zeroBasedCellOnEndlessGrid.ToString() + "\n";
                //}
                //Debug.Log(p1);
            }
            else
            {
                //If the shift is not to be performed in a single frame, then we need to fully recreate the world
                //at the shifted location

                //The dictionary will contain all the cells that are still activated at this point.
                //These are the cells that will be "shifted". We don't want to shift them at this point 
                //however, only prepare them to be shifted

                Dictionary<Cell, WorldCell>.Enumerator worldCellsEnumerator = worldCells.GetEnumerator();
                while (worldCellsEnumerator.MoveNext())
                {
                    WorldCell worldCell = worldCellsEnumerator.Current.Value;

                    //Here we create a full copy of the currently activated cell and add it to a 
                    //list of shifted cells that will be deactivated in the future.
                    //note that the shifted cells list is just being used here to save space, really the cells are 
                    //unshifted
                    WorldCell worldCellCopy = CreateCopyOfWorldCell(worldCell);
                    cellList4.Add(worldCellCopy);

                    //prepare the cells for positioning
                    worldCell.positioned = false;
                    if(UsingObjectGroups)
                    {
                        for (int i = 0; i < objectGroups.Length; i++)
                            worldCell.objectGroupCells[i].positioned = false;
                    }

                    //For each activated cell in the dictionary, we null out any reference types on the activated cell and 
                    //add the shift amount to its position. We then add this cell to the cellList1 list.
                    //This cell now represents our shifted cell (which doesn't have an object yet!)
                    NullReferenceTypesOnCell(worldCell);

                    //this cell needs to be activated now, so add it to the cellsToActivateList
                    cellList1.Add(worldCell);
                }

                //Now go through and determine which of the input cells need to be activated
                //After this, the cellList1 list will contain all unshifted cells that need a 
                //cell object and activation

                Cell worldOriginCellToBaseCellPositionsOn = new Cell(world.ZeroBasedOriginCellRow, world.ZeroBasedOriginCellColumn, world.ZeroBasedOriginCellLayer);

                DetermineWhichCellsNeedToBeActivated(cellsToAddUsersTo, worldOriginCellToBaseCellPositionsOn);
                yield return null;
            }

            yield return null;

            //Result of single fame shift
            //cellList1 contains unshifted cells that need object and activation
            //cellList4 contains shifted cells that need objects repositioned

            //result of non single frame shift
            //cellList4 contains non shifted cells with objects that need to be destroyed
            //cellList1 contains non shifted cells that need activation and objects

            //now shift the world cells in the cellList1 list
            foreach (WorldCell worldCell in cellList1)
            {
                worldCell.position += shiftAmount;

                if (shiftEndlessGridCells)
                    worldCell.zeroBasedCellOnEndlessGrid += endlessGridShift;
            }

            cellList3.AddRange(cellList1);
            yield return null;

            IEnumerator<YieldInstruction> matchEnumerator = MatchDeactivatedCellObjectsWithCellsNeedingObject(cellList2, cellList3);
            while (matchEnumerator.MoveNext())
                yield return matchEnumerator.Current;

            IEnumerator<YieldInstruction> detatchEnumator = DetatchCellObjects(cellList2, objectGroupCellsReusableList1);
            while (detatchEnumator.MoveNext())
                yield return detatchEnumator.Current;

            IEnumerator<YieldInstruction> attachAndActivateEnumeator = AttachCellObjectsAndActivateCells(cellList3, cellList1, objectGroupCellsReusableList1, world.performShiftActivationInSingleFrame, cellList4);
            while (attachAndActivateEnumeator.MoveNext())
                yield return attachAndActivateEnumeator.Current;

            //The data of the world cells have been adjusted to account for the endless grid shift, but the actual keys of the 
            //cells within the dictionary still need to be shifted. For this, we need to remove all entries and re-add them
            //with the shifted keys
            if(shiftEndlessGridCells)
            {
                if (allDictionaryCells == null)
                    allDictionaryCells = new List<WorldCell>(worldCells.Count);

                allDictionaryCells.AddRange(worldCells.Values);
                worldCells.Clear();
                foreach (WorldCell cell in allDictionaryCells)
                    worldCells.Add(cell.zeroBasedCellOnEndlessGrid, cell);

                allDictionaryCells.Clear();
            }
        }

        //this should only be called when world.performShiftActivationInSingleFrame = false
        public IEnumerator<YieldInstruction> RemovePreShiftWorld()
        {
            IEnumerator<YieldInstruction> deactivateEnumerator = DeactivateCells(cellList4);
            while (deactivateEnumerator.MoveNext())
                yield return deactivateEnumerator.Current;

            IEnumerator<YieldInstruction> detatchEnumerator = DetatchCellObjects(cellList4, objectGroupCellsReusableList1);
            while (detatchEnumerator.MoveNext())
                yield return detatchEnumerator.Current;
        }

        //This removes the objects used by the old group name and adds objects using the new group name.
        //It does this by adding the new objects before removing the old.
        //While this incurs more memory, it ensures that any object groups that are loaded will have 
        //a valid base terrain/mesh at all times, so they do not just start falling
        public IEnumerator<YieldInstruction> RefreshWorldWithNewGroupNameObjects()
        {
            int oldPrimaryCellObjectSubControllerID = primaryCellObjectSubControllerID;

            //Registers with the sub controller. We now have two active registrations, 
            //one with the old group name and one with the new one. Once the new group is 
            //created we'll deactivate the old one
            RegisterWithSubController();

            Dictionary<Cell, WorldCell>.Enumerator worldCellsEnumerator = worldCells.GetEnumerator();
            while (worldCellsEnumerator.MoveNext())
            {
                WorldCell worldCell = worldCellsEnumerator.Current.Value;
                WorldCell worldCellCopy = CreateCopyOfWorldCell(worldCell);
                //cellList4 contains the old group of cells that were using the previous name
                cellList4.Add(worldCellCopy);

                NullReferenceTypesOnCell(worldCell);
                cellList1.Add(worldCell);
            }

            yield return null;

            cellList3.AddRange(cellList1);
            yield return null;

            //Load new objects
            IEnumerator<YieldInstruction> getCellObjectsEnumerator = world.primaryCellObjectSubController.AttachCellObjectsToCells<WorldCell>(cellList3, primaryCellObjectSubControllerID);
            while (getCellObjectsEnumerator.MoveNext())
                yield return getCellObjectsEnumerator.Current;

            cellList3.Clear();

            //Activate the new cells
            IEnumerator<YieldInstruction> activateCellsEnumerator = ActivateWorldCells();
            while (activateCellsEnumerator.MoveNext())
                yield return activateCellsEnumerator.Current;

            cellList1.Clear();

            //Deactivate the old cells
            IEnumerator<YieldInstruction> deactivateEnumerator = DeactivateWorldCells(cellList4);
            while (deactivateEnumerator.MoveNext())
                yield return deactivateEnumerator.Current;

            foreach (WorldCell cell in cellList4)
                worldCellPool.AddObject(cell);

            //remove old objects
            IEnumerator<YieldInstruction> deactivateCellObjectsEnumerator = world.primaryCellObjectSubController.DetachAndProcessCellObjectsFromDeactivatedCells<WorldCell>(cellList4, oldPrimaryCellObjectSubControllerID);
            while (deactivateCellObjectsEnumerator.MoveNext())
                yield return deactivateCellObjectsEnumerator.Current;

            cellList4.Clear();

            world.primaryCellObjectSubController.DeRegister(oldPrimaryCellObjectSubControllerID);
        }
        
        public IEnumerator<YieldInstruction> AddAndRemoveCellUsersAndResetPositionOfWorld_ZeroBased(Dictionary<Cell, int> cellsToAddUsersTo, Dictionary<Cell, int> cellsToRemoveUsersFrom)
        {
            //Deducts the users from each cell in the world cells dictionary.
            //If user count for a world cell reaches 0, the world cell is removed from the 
            //dictionary and added to the worldCellsToDeactivate list.
            DetermineWhichCellsNeedToBeDeactivated(cellsToRemoveUsersFrom);
            yield return null;

            //The remaining world cells need to be reset. To do this, we're going to create a copy of 
            //each world cell and add that copy to the cells to deactivate list.
            //Then for the original world cell, we'll null out its references, reset its position, 
            //and add it to the cells to activate list.

            //The position of the world cells is set based on the desired origin cell, not the current origin 
            //cell

            List<WorldCell> worldCellsToActivate = cellList1;
            List<WorldCell> worldCellsToDeactivate = cellList2;
            List<WorldCell> worldCellsThatNeedPrimaryCellObject = cellList3;

            Dictionary<Cell, WorldCell>.Enumerator worldCellsEnumerator = worldCells.GetEnumerator();
            Cell worldOriginCellToBaseCellPositionsOn = new Cell(world.DesiredZeroBasedOriginCellRow, world.DesiredZeroBasedOriginCellColumn, world.DesiredZeroBasedOriginCellLayer);

            while (worldCellsEnumerator.MoveNext())
            {
                WorldCell worldCell = worldCellsEnumerator.Current.Value;
                WorldCell worldCellCopy = CreateCopyOfWorldCell(worldCell);
                worldCellsToDeactivate.Add(worldCellCopy);

                NullReferenceTypesOnCell(worldCell);

                Vector3 p = world.GetPositionOfEndlessGridCellUsingTheoreticalOriginCell_ZeroBased(worldCellsEnumerator.Current.Key, worldOriginCellToBaseCellPositionsOn); ;
                //This is the only line that differs from the set of world cell dictionary copy code above
                worldCell.position = p;

                worldCell.positioned = false;

                if (UsingObjectGroups)
                {
                    for (int i = 0; i < objectGroups.Length; i++)
                        worldCell.objectGroupCells[i].positioned = false;
                }

                worldCellsToActivate.Add(worldCell);
            }

            yield return null;

            //Now determine which cells from the input cellsToAddUsersTo need to be activated.
            //this process creates world cells and adds them to the worldCells dictionary,
            //which is why we're doing it after the copies have been made (we don't want copies from these 
            //cells to be made).
            DetermineWhichCellsNeedToBeActivated(cellsToAddUsersTo, worldOriginCellToBaseCellPositionsOn);
            yield return null;

            IEnumerator<YieldInstruction> deactivateEnumerator = DeactivateCells(worldCellsToDeactivate);
            while (deactivateEnumerator.MoveNext())
                yield return deactivateEnumerator.Current;

            //This list will keep track of the cells that need primary cell objects.
            //At first, ALL cells that are going to be activated need a cell object.
            worldCellsThatNeedPrimaryCellObject.AddRange(worldCellsToActivate);
            yield return null;

            IEnumerator<YieldInstruction> matchEnumerator = MatchDeactivatedCellObjectsWithCellsNeedingObject(worldCellsToDeactivate, worldCellsThatNeedPrimaryCellObject);
            while (matchEnumerator.MoveNext())
                yield return matchEnumerator.Current;

            IEnumerator<YieldInstruction> detatchEnumerator = DetatchCellObjects(worldCellsToDeactivate, objectGroupCellsReusableList1);
            while (detatchEnumerator.MoveNext())
                yield return detatchEnumerator.Current;

            IEnumerator<YieldInstruction> attachAndActivateEnumerator = AttachCellObjectsAndActivateCells(worldCellsThatNeedPrimaryCellObject, worldCellsToActivate, objectGroupCellsReusableList1);
            while (attachAndActivateEnumerator.MoveNext())
                yield return attachAndActivateEnumerator.Current;
        }

        #endregion

        #region Common IEnumerator methods used by the methods above

        IEnumerator<YieldInstruction> AttachCellObjectsAndActivateCells(List<WorldCell> cellsNeedingPrimaryObjects, List<WorldCell> cellsNeedingActivation, List<ObjectGroupCell> tempList, bool executeSingleFrameShift = false, List<WorldCell> cellsNeedingObjectRepositioning = null)
        {
            if (UsingObjectGroups)
            {
                if (cellsNeedingPrimaryObjects.Count > 0)
                {
                    List<WorldCell> backupListOfCellsNeedingPrimaryObjects = new List<WorldCell>(cellsNeedingPrimaryObjects.Count);
                    backupListOfCellsNeedingPrimaryObjects.AddRange(cellsNeedingPrimaryObjects);

                    //get main world cell objects
                    IEnumerator<YieldInstruction> getCellObjectsEnumerator = world.primaryCellObjectSubController.AttachCellObjectsToCells<WorldCell>(cellsNeedingPrimaryObjects, primaryCellObjectSubControllerID);
                    while (getCellObjectsEnumerator.MoveNext())
                        yield return getCellObjectsEnumerator.Current;

                    cellsNeedingPrimaryObjects.Clear();

                    //Now get the object group cells
                    for (int i = 0; i < objectGroups.Length; i++)
                    {
                        //Generate list of object group cells that need cell objects
                        //note that not all cells that need a primary object will need a object from the object group
                        //we have to check the object group's IsCellUsed Function to make sure of this first.
                        foreach (WorldCell cell in backupListOfCellsNeedingPrimaryObjects)
                        {
                            if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                                tempList.Add(cell.objectGroupCells[i]);
                        }

                        //Send the cells over to the primary cell object sub controller associated with the object group for detatching
                        IEnumerator<YieldInstruction> getObjectGroupCellObjectsEnumerator = objectGroups[i].PrimaryCellObjectSubController.AttachCellObjectsToCells<ObjectGroupCell>(tempList, objectGroups[i].primaryCellObjectSubControllerID);
                        while (getObjectGroupCellObjectsEnumerator.MoveNext())
                            yield return getObjectGroupCellObjectsEnumerator.Current;

                        //clear the list
                        tempList.Clear();
                    }
                    backupListOfCellsNeedingPrimaryObjects.Clear();
                }

                //Iterate over to Activate the main world cells
                IEnumerator<YieldInstruction> activateCellsEnumerator = ActivateWorldCells();

                //Iterate over to Activate the object group cells
                IEnumerator<YieldInstruction> activateObjectGroupCellsEnumerator = ActivateObjectGroupCells();

                //When executing a single frame shift, we need to reposition all objects associated with each cell
                //in the cellList4 list before activating the other clels
                if(executeSingleFrameShift)
                {
                    foreach (WorldCell cell in cellList4)
                    {
                        for (int i = 0; i < objectGroups.Length; i++)
                        {
                            if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                                cell.objectGroupCells[i].RepositionPrimaryCellObject();
                        }
                        cell.RepositionPrimaryCellObject();
                    }

                    cellList4.Clear();

                    while (activateCellsEnumerator.MoveNext())
                        continue;

                    while (activateObjectGroupCellsEnumerator.MoveNext())
                        continue;
                }
                else
                {
                    //if not executing a single frame shift, we can just go through the process of
                    //activating the cells in the cellList1 list
                    while (activateCellsEnumerator.MoveNext())
                        yield return activateCellsEnumerator.Current;

                    while (activateObjectGroupCellsEnumerator.MoveNext())
                        yield return activateObjectGroupCellsEnumerator.Current;
                }
                
                cellList1.Clear();
            }
            else
            {
                if (cellsNeedingPrimaryObjects.Count > 0)
                {
                    //Now get cell objects from the primary cell object sub controller for any about to be activated cells that still need cell objects.
                    IEnumerator<YieldInstruction> getCellObjectsEnumerator = world.primaryCellObjectSubController.AttachCellObjectsToCells<WorldCell>(cellsNeedingPrimaryObjects, primaryCellObjectSubControllerID);
                    while (getCellObjectsEnumerator.MoveNext())
                        yield return getCellObjectsEnumerator.Current;

                    cellsNeedingPrimaryObjects.Clear();
                }

                //Iterate over to Activate the main world cells
                IEnumerator<YieldInstruction> activateCellsEnumerator = ActivateWorldCells();

                //When executing a single frame shift, we need to reposition all objects associated with each cell
                if (executeSingleFrameShift)
                {
                    foreach (WorldCell cell in cellList4)
                        cell.RepositionPrimaryCellObject();

                    cellList4.Clear();

                    while (activateCellsEnumerator.MoveNext())
                        continue;
                }
                else
                {
                    while (activateCellsEnumerator.MoveNext())
                        yield return activateCellsEnumerator.Current;
                }

                cellList1.Clear();
            }
        }

        IEnumerator<YieldInstruction> DeactivateCells(List<WorldCell> cellList2)
        {
            //First deactivate the object group cells (in reverse order)
            if (UsingObjectGroups)
            {
                IEnumerator<YieldInstruction> deactivateObjectGroupCellsEnumerator = DeactivateObjectGroupCells(cellList2);
                while (deactivateObjectGroupCellsEnumerator.MoveNext())
                    yield return deactivateObjectGroupCellsEnumerator.Current;
            }

            //Next deactivate the main world cells
            IEnumerator<YieldInstruction> deactivateEnumerator = DeactivateWorldCells(cellList2);
            while (deactivateEnumerator.MoveNext())
                yield return deactivateEnumerator.Current;
        }

        IEnumerator<YieldInstruction> DetatchCellObjects(List<WorldCell> cellsNeedingDetatchment, List<ObjectGroupCell> tempList)
        {
            if (UsingObjectGroups)
            {
                //Add the cells back to the pool before sending them over to the primary cell object sub controller for detaching.
                //By doing this first, the user can do whatever they want with the list of deactivated cells (aka, add items, remove items, etc) and it won't effect anything.
                //Of course, if they don't detach the cell object, that could be a problem.
                foreach (WorldCell cell in cellsNeedingDetatchment)
                {
                    for (int i = 0; i < objectGroups.Length; i++)
                    {
                        if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                        {
                            objectGroupCellPool.AddObject(cell.objectGroupCells[i]);
                            cell.objectGroupCells[i].cellActions = null;
                        }
                    }

                    cell.cellActions = null;
                    worldCellPool.AddObject(cell);
                }

                for (int i = 0; i < objectGroups.Length; i++)
                {
                    //Generate list of object group cells
                    foreach (WorldCell cell in cellList2)
                    {
                        if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                            tempList.Add(cell.RemoveObjectGroupCell(i));
                    }

                    //Send the cells over to the primary cell object sub controller associated with the object group for detatching
                    IEnumerator<YieldInstruction> detatchObjectGroupCellObjectsEnumerator = objectGroups[i].PrimaryCellObjectSubController.DetachAndProcessCellObjectsFromDeactivatedCells<ObjectGroupCell>(tempList, objectGroups[i].primaryCellObjectSubControllerID);

                    while (detatchObjectGroupCellObjectsEnumerator.MoveNext())
                        yield return detatchObjectGroupCellObjectsEnumerator.Current;

                    //clear the list
                    tempList.Clear();
                }
            }
            else
            {
                //Add the cells back to the pool before sending them over to the primary cell object sub controller for detaching.
                //By doing this first, the user can do whatever they want with the list of deactivated cells (aka, add items, remove items, etc) and it won't effect anything.
                //Of course, if they don't detach the cell object, that could be a problem.
                foreach (WorldCell cell in cellsNeedingDetatchment)
                    worldCellPool.AddObject(cell);
            }

            //Send any cells that still have cell objects to the primary cell object sub controller for detachment and processing
            IEnumerator<YieldInstruction> deactivateCellObjectsEnumerator = world.primaryCellObjectSubController.DetachAndProcessCellObjectsFromDeactivatedCells<WorldCell>(cellsNeedingDetatchment, primaryCellObjectSubControllerID);
            while (deactivateCellObjectsEnumerator.MoveNext())
                yield return deactivateCellObjectsEnumerator.Current;

            cellsNeedingDetatchment.Clear();
        }

        IEnumerator<YieldInstruction> MatchDeactivatedCellObjectsWithCellsNeedingObject(List<WorldCell> deactivatedCells, List<WorldCell> cellsAboutToBeActivatedThatNeedObject)
        {
            //Here we will search among the deactivated cells for cells with the same 
            //World Grid Cell as the cells that are about to be activated.
            //If a deactivated cell and activated cell have the same World Grid Cell, 
            //then they will use the same Cell Object, so we can just
            //transfer the cell object (and cell actions if necessary) from the deactivated 
            //cell to the activated cell. We will remove that
            //activated cell from the list of cells that need primary cell objects.

            //We also remove the deactivated cell from the cellsAboutToBeActivatedThatNeedObject list, so 
            //that the cell is not sent to the primary cell object sub controller for
            //Post deactivation processing
            for (int i = deactivatedCells.Count - 1; i >= 0; i--)
            {
                int indexOfCellToActivateWithMatchingWorldGridCell;
                if (DoesWorldGridCellOnCellToDeactivateMatchWorldGridCellOnAnyCellsAboutToBeActivated(deactivatedCells[i].CellOnWorldGrid, cellsAboutToBeActivatedThatNeedObject, out indexOfCellToActivateWithMatchingWorldGridCell))
                {
                    WorldCell cellToDeactivate = deactivatedCells[i];
                    TransferCellObjectAndCellActions(cellsAboutToBeActivatedThatNeedObject[indexOfCellToActivateWithMatchingWorldGridCell], cellToDeactivate);

                    cellsAboutToBeActivatedThatNeedObject.RemoveAt(indexOfCellToActivateWithMatchingWorldGridCell);

                    if (UsingObjectGroups)//Add object group cells back to pool
                    {
                        for (int j = 0; j < objectGroups.Length; j++)
                        {
                            cellToDeactivate.objectGroupCells[j].worldCellThisCellBelongsTo = null;
                            objectGroupCellPool.AddObject(cellToDeactivate.RemoveObjectGroupCell(j));
                        }
                    }

                    worldCellPool.AddObject(cellToDeactivate);
                    deactivatedCells.RemoveAt(i);
                }
                yield return null;
            }
        }

        IEnumerator<YieldInstruction> DeactivateWorldCells(List<WorldCell> cellList2)
        {
            if (PreDeactivationCellProcessing != null)
            {
                IEnumerator<YieldInstruction> e = PreDeactivationCellProcessing(cellList2);
                while (e.MoveNext())
                    yield return e.Current;
            }

            if (world.primaryCellObjectSubController.useCellActions)
            {
                foreach (WorldCell cell in cellList2)
                {
                    if (cell.cellActions != null)
                    {
                        for (int j = 0; j < cell.cellActions.Length; j++)
                        {
                            IEnumerator<YieldInstruction> e = cell.cellActions[j].DoStuffBeforeCellIsDeactivated(cell);
                            while (e.MoveNext())
                                yield return e.Current;
                        }
                    }

                    cell.primaryCellObject.SetActive(false);
                    yield return null;
                }
            }
            else
            {
                foreach (WorldCell cell in cellList2)
                {
                    cell.primaryCellObject.SetActive(false);
                    yield return null;
                }
            }

            if (PostDeactivationCellProcessing != null)
            {
                IEnumerator<YieldInstruction> e = PostDeactivationCellProcessing(cellList2);
                while (e.MoveNext())
                    yield return e.Current;
            }
        }

        IEnumerator<YieldInstruction> DeactivateObjectGroupCells(List<WorldCell> cellList2)
        {
            //deactivate in reverse order
            for (int i = objectGroups.Length - 1; i >= 0; i--)
            {
                if (objectGroups[i].PrimaryCellObjectSubController.useCellActions)
                {
                    foreach (WorldCell cell in cellList2)
                    {
                        if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                        {
                            ObjectGroupCell objGroupCell = cell.objectGroupCells[i];
                            if (objGroupCell.cellActions != null)
                            {
                                for (int j = 0; j < objGroupCell.cellActions.Length; j++)
                                {
                                    IEnumerator<YieldInstruction> e = objGroupCell.cellActions[j].DoStuffBeforeCellIsDeactivated(objGroupCell);
                                    while (e.MoveNext())
                                        yield return e.Current;
                                }
                            }

                            objGroupCell.primaryCellObject.SetActive(false);
                            yield return null;
                        }
                    }
                }
                else
                {
                    foreach (WorldCell cell in cellList2)
                    {
                        if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                        {
                            cell.objectGroupCells[i].primaryCellObject.SetActive(false);
                            yield return null;
                        }
                    }
                }
            }
        }

        IEnumerator<YieldInstruction> ActivateWorldCells()
        {
            if (world.primaryCellObjectSubController.useCellActions)
            {
                //Now we will actually activate the cells
                foreach (WorldCell cell in cellList1)
                {
                    if (!cell.positioned)
                    {
                        cell.RepositionPrimaryCellObject();
#if DEBUG_ON
                        Debug.Log(string.Format("Repositioning Cell @ Row {0} | Column {1} as it has not been positioned yet.", cell.CellOnWorldGrid.Row, cell.CellOnWorldGrid.Column));
#endif
                    }

                    //3.5-4.x difference
                    if (cell.primaryCellObject.activeSelf == false)
                        cell.primaryCellObject.SetActive(true);
                
                    cell.cellActions = cell.primaryCellObject.GetComponents<CellAction>();
                    if (cell.cellActions != null)
                    {
                        foreach(CellAction cellAction in cell.cellActions)
                        {
                            IEnumerator<YieldInstruction> e = cellAction.DoStuffAfterCellIsActivated(cell);
                            while (e.MoveNext())
                                yield return e.Current;
                        }
                    }
                    yield return null;
                }
            }
            else
            {
                foreach (WorldCell cell in cellList1)
                {
                    if (!cell.positioned)
                        cell.RepositionPrimaryCellObject();

                    //3.5-4.x difference
                    if (cell.primaryCellObject.activeSelf == false)
                        cell.primaryCellObject.SetActive(true);
                    yield return null;
                }
            }

            if (PostActivationCellProcessing != null)
            {
                IEnumerator<YieldInstruction> e = PostActivationCellProcessing(cellList1);
                while (e.MoveNext())
                    continue;
            }
        }

        IEnumerator<YieldInstruction> ActivateObjectGroupCells()
        {
            for (int i = 0; i < objectGroups.Length; i++)
            {
                if (objectGroups[i].PrimaryCellObjectSubController.useCellActions)
                {
                    //Now we will actually activate the cells
                    foreach (WorldCell cell in cellList1)
                    {
                        if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                        {
                            ObjectGroupCell objGroupCell = cell.objectGroupCells[i];
                            if (!objGroupCell.positioned)
                                objGroupCell.RepositionPrimaryCellObject();

                            //3.5-4.x difference
                            if (objGroupCell.primaryCellObject.activeSelf == false)
                                objGroupCell.primaryCellObject.SetActive(true);

                            objGroupCell.cellActions = objGroupCell.primaryCellObject.GetComponents<CellAction>();
                            if (objGroupCell.cellActions != null)
                            {
                                foreach (CellAction cellAction in objGroupCell.cellActions)
                                {
                                    IEnumerator<YieldInstruction> e = cellAction.DoStuffAfterCellIsActivated(objGroupCell);
                                    while (e.MoveNext())
                                        yield return e.Current;
                                }
                            }
                            yield return null;
                        }
                    }
                }
                else
                {
                    foreach (WorldCell cell in cellList1)
                    {
                        if (objectGroups[i].IsCellUsedFunction(cell.CellOnWorldGrid))
                        {
                            ObjectGroupCell objGroupCell = cell.objectGroupCells[i];
                            if (!objGroupCell.positioned)
                                objGroupCell.RepositionPrimaryCellObject();

                            //3.5-4.x difference
                            if (objGroupCell.primaryCellObject.activeSelf == false)
                                objGroupCell.primaryCellObject.SetActive(true);
                            yield return null;
                        }
                    }
                }
            }
        }

        #endregion

        #region Some Additional Cell Methods

        //Transfer cell object and cell actions from one cell to another.
        //Note that we don't care if there are no cell actions, the assignment is an inexpensive operation
        void TransferCellObjectAndCellActions(WorldCell cellThatNeedsObject, WorldCell cellThatHasObject)
        {
            cellThatNeedsObject.primaryCellObject = cellThatHasObject.primaryCellObject;
            cellThatNeedsObject.cellActions = cellThatHasObject.cellActions;

            cellThatHasObject.primaryCellObject = null;
            cellThatHasObject.cellActions = null;

            //need to transfer the secondary object group cells and cell actions as well
            if(UsingObjectGroups)
            {
                for(int i = 0; i < objectGroups.Length; i++)
                {
                    if (objectGroups[i].IsCellUsedFunction(cellThatNeedsObject.CellOnWorldGrid))
                    {
                        cellThatNeedsObject.objectGroupCells[i].primaryCellObject = cellThatHasObject.objectGroupCells[i].primaryCellObject;
                        cellThatNeedsObject.objectGroupCells[i].cellActions = cellThatHasObject.objectGroupCells[i].cellActions;

                        cellThatHasObject.objectGroupCells[i].primaryCellObject = null;
                        cellThatHasObject.objectGroupCells[i].cellActions = null;
                    }
                }
            }
        }

        

        bool DoesWorldGridCellOnCellToDeactivateMatchWorldGridCellOnAnyCellsAboutToBeActivated(Cell worldGridCellOnCellToDeactivate, List<WorldCell> cellsAboutToBeActivatedThatNeedObject, out int indexOfCellToActivateWithMatchingWorldGridCell)
        {
            int numCellsThatNeedPrimaryCellObjects = cellsAboutToBeActivatedThatNeedObject.Count;
            for (int i = 0; i < numCellsThatNeedPrimaryCellObjects; i++)
            {
                if (cellComparer.Equals(worldGridCellOnCellToDeactivate, cellsAboutToBeActivatedThatNeedObject[i].CellOnWorldGrid))
                {
                    indexOfCellToActivateWithMatchingWorldGridCell = i;
                    return true;
                }
            }

            indexOfCellToActivateWithMatchingWorldGridCell = -1;
            return false;
        }
        
        void DetermineWhichCellsNeedToBeActivated(Dictionary<Cell, int> cellsToAddUsersTo, Cell worldOriginCellToBasePositionOn)
        {
            Dictionary<Cell, int>.Enumerator enumerator = cellsToAddUsersTo.GetEnumerator();
            while(enumerator.MoveNext())
            {
                WorldCell worldCell;
                if (DoesCellNeedToBeActivated(enumerator.Current, worldOriginCellToBasePositionOn, out worldCell))
                    cellList1.Add(worldCell);
            }
        }

        //A cell only needs to be activated if it isn't already present in the worldCells dictionary.
        //Otherwise, we just add new number of users to the existing user count.
        bool DoesCellNeedToBeActivated(KeyValuePair<Cell, int> cellToAddUsersTo, Cell worldOriginCellToBasePositionOn, out WorldCell worldCell)
        {
            if (worldCells.TryGetValue(cellToAddUsersTo.Key, out worldCell))
            {
                worldCell.AddUsers(cellToAddUsersTo.Value);
                return false;
            }
            else
            {
                worldCell = worldCellPool.PoolIsEmpty ? CreateNewWorldCell() : worldCellPool.GetObject();
                worldCell.AddUsers(cellToAddUsersTo.Value);
                SetWorldCellData(worldCell, cellToAddUsersTo.Key, worldOriginCellToBasePositionOn);
                worldCells.Add(cellToAddUsersTo.Key, worldCell);
                return true;
            }
        }

        void DetermineWhichCellsNeedToBeDeactivated(Dictionary<Cell, int> cellsToRemoveUsersFrom)
        {
            foreach (KeyValuePair<Cell, int> cellToRemoveUsersFrom in cellsToRemoveUsersFrom)
            {
                WorldCell worldCell;
                if (DoesCellNeedToBeDeactivated(cellToRemoveUsersFrom, out worldCell))
                    cellList2.Add(worldCell);
            }
        }

        //A cell only needs to be deactivated if it has no users after reducing its user count by the int key value in the cellsToRemoveUsersFrom dictionary
        bool DoesCellNeedToBeDeactivated(KeyValuePair<Cell, int> cellToRemoveUsersFrom, out WorldCell worldCell)
        {
            if (!worldCells.TryGetValue(cellToRemoveUsersFrom.Key, out worldCell))
                return false;

            worldCell.RemoveUsers(cellToRemoveUsersFrom.Value);
            if (!worldCell.DoesCellHaveUsers)
            {
                worldCells.Remove(cellToRemoveUsersFrom.Key);
                return true;
            }
            else
                return false;
        }

        #endregion

        #region Additional Helpful Public Methods
        //Takes in a zero based endless grid cell as the key
        public bool TryGetWorldCellOfEndlessGridCell(Cell cellOnEndlessGrid, out WorldCell worldCell)
        {
            return worldCells.TryGetValue(cellOnEndlessGrid, out worldCell);
        }

        #endregion

        #region Methods for Creating/Copying new world cells and setting/nulling their data

        //Method for creating a new world cell (used when the pool is empty).
        //This method is virtual so you can create your own type of WorldCelll (for instance, the TerrainOrientedCellObjectMasterController overrides
        //this method and creates a WorldCellWithTerrain
        protected virtual WorldCell CreateNewWorldCell()
        {
            return new WorldCell(NumObjectGroups);
        }

        WorldCell CreateCopyOfWorldCell(WorldCell worldCell)
        {
            WorldCell copy = worldCellPool.PoolIsEmpty ? CreateNewWorldCell() : worldCellPool.GetObject();
            copy.dimensions = worldCell.dimensions;
            copy.position = worldCell.position;
            copy.zeroBasedCellOnEndlessGrid = worldCell.zeroBasedCellOnEndlessGrid;
            copy.oneBasedCellOnWorldGrid = worldCell.oneBasedCellOnWorldGrid;
            copy.primaryCellObject = worldCell.primaryCellObject;
            copy.cellActions = worldCell.cellActions;
            copy.offset = worldCell.offset;
            copy.positioned = worldCell.positioned;

            if(UsingObjectGroups)
            {
                for (int i = 0; i < objectGroups.Length; i++)
                {
                    if (objectGroups[i].IsCellUsedFunction(worldCell.CellOnWorldGrid))
                    {
                        copy.objectGroupCells[i] = objectGroupCellPool.PoolIsEmpty ? new ObjectGroupCell() : objectGroupCellPool.GetObject();
                        copy.objectGroupCells[i].offset = worldCell.objectGroupCells[i].offset;
                        copy.objectGroupCells[i].cellActions = worldCell.objectGroupCells[i].cellActions;
                        copy.objectGroupCells[i].primaryCellObject = worldCell.objectGroupCells[i].primaryCellObject;

                        //change world cell the object group cell belongs to to copy
                        copy.objectGroupCells[i].worldCellThisCellBelongsTo = copy;
                    }
                }
            }

            CopyAdditionalWorldCellData(worldCell, copy);

            return copy;
        }

        void NullReferenceTypesOnCell(WorldCell cellToNull)
        {
            cellToNull.primaryCellObject = null;
            cellToNull.cellActions = null;

            if(UsingObjectGroups)
            {
                for (int i = 0; i < objectGroups.Length; i++)
                {
                    if (objectGroups[i].IsCellUsedFunction(cellToNull.CellOnWorldGrid))
                    {
                        cellToNull.objectGroupCells[i].primaryCellObject = null;
                        cellToNull.objectGroupCells[i].cellActions = null;
                    }
                }
            }

            NullAdditionalReferenceTypes(cellToNull);
        }
        
        void SetWorldCellData(WorldCell worldCell, Cell cellOnEndlessGrid, Cell worldOriginCellToBasePositionOn)
        {
            worldCell.zeroBasedCellOnEndlessGrid = cellOnEndlessGrid;
            Cell cellOnWorldGrid = world.ConvertCellOnEndlessGridToCellOnWorldGrid_ZeroBased(cellOnEndlessGrid);
            worldCell.oneBasedCellOnWorldGrid = cellOnWorldGrid.ConvertTo1Based(world.IsWorld3D);

            worldCell.position = world.GetPositionOfEndlessGridCellUsingTheoreticalOriginCell_ZeroBased(cellOnEndlessGrid, worldOriginCellToBasePositionOn);
            worldCell.dimensions = world.GetDimensionsOfWorldGridCell_ZeroBased(cellOnWorldGrid);
            worldCell.offset = world.WorldGrid.OffsetCalculator.CalculateOffset(worldCell.dimensions);
            worldCell.positioned = false;

            if(UsingObjectGroups)
            {
                for (int i = 0; i < objectGroups.Length; i++)
                {
                    if (objectGroups[i].IsCellUsedFunction(worldCell.CellOnWorldGrid))
                    {
                        worldCell.objectGroupCells[i] = objectGroupCellPool.PoolIsEmpty ? new ObjectGroupCell() : objectGroupCellPool.GetObject();

                        worldCell.objectGroupCells[i].offset = objectGroups[i].OffsetCalculator.CalculateOffset(worldCell.dimensions);
                        worldCell.objectGroupCells[i].worldCellThisCellBelongsTo = worldCell;
                        worldCell.objectGroupCells[i].positioned = false;
                    }
                }
            }
        }

        #endregion

        #region Protected virtual methods

        //Can override this in derived Cell Object Master Controllers to assign additional data to your custom WorldCells
        protected virtual void CopyAdditionalWorldCellData(WorldCell copyFrom, WorldCell copyTo) { }
        protected virtual void NullAdditionalReferenceTypes(WorldCell cellToNull) { }
        //protected virtual void SetAdditionalWorldCellData(WorldCell worldCell, Cell cellOnEndlessGrid) { }

        #endregion
    }
}